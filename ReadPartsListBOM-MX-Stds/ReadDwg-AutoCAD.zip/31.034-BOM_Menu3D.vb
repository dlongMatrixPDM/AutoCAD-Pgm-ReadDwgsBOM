﻿Option Strict Off
Option Explicit On
Option Compare Text

'Imports System.Data.OleDb.OleDbConnection
'Imports System.Data.OleDb.OleDbDataAdapter
'Imports System.Data.OleDb.OleDbDataReader
'Imports System.Data.OleDb.OleDbCommand
'Imports System.Data
'Imports System.Data.OleDb
Imports System.IO
Imports System.IO.Stream
Imports System.Data.SqlClient                   'Used for SQL Connection

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Imports AutoCAD
Imports Microsoft.Office.Interop        'RW added 8/16/2023
Imports Microsoft.Office.Interop.Excel
Imports Microsoft.SqlServer
'Imports Microsoft.SqlServer.Server
'Imports Microsoft.SqlServer.Management

Imports ADODB
Imports System.Drawing.Drawing2D
Imports System.Runtime.InteropServices.ComTypes
Imports System.ComponentModel
Imports Microsoft.VisualBasic.Compatibility.VB6

'Imports SpeechLib
'Imports SpeechLib.SpeechAudioState
'Imports System.Speech
'Imports MSForms

Public Structure ManwayInfo3134
    Public Shared MWElev As String
    Public Shared MWSize As String
    Public Shared FlangeOD As String
    Public Shared FlangeID As String
    Public Shared FlangeThk As String
    Public Shared FlangeHoles As String
    Public Shared FlangeChord As String
    Public Shared FlangePartNo As String
    Public Shared FlangeStockNo As String
    Public Shared FlangeDesc As String
    Public Shared UserName As String
    Public Shared AssyMat(0) As Object
    Dim Test As String
    Public Shared OldDesc As String
    Public Shared GetDesc As String
    Public Shared GetMatLen As String
    Public Shared GetMatQty As String
    Public Shared GetShipMk As String
    Public Shared GetPieceMk As String
    Public Shared MatType As String
    Public Shared RevNo As String

    Public Shared AddMat As String
    Public Shared AddMatSize As String
    Public Shared AddMatQty As String

    Public Shared FabInvListData(3, 1) As Object
    Public Shared StructureData(3, 1) As Object
    Public Shared FittingData(3, 1) As Object
    Public Shared GasketData(3, 1) As Object
    Public Shared FlangeData(3, 1) As Object
    Public Shared PipeData(3, 1) As Object
    Public Shared HardwareData(3, 1) As Object
    Public Shared MiscData(3, 1) As Object
    Public Shared SubMFGData(3, 1) As Object
    Public Shared SubPURData(3, 1) As Object
    Public Shared NamePlateData(3, 1) As Object
    Public Shared PlateData(3, 1) As Object
    Public Shared ShipSuplData(3, 1) As Object
    Public Shared TkSealData(3, 1) As Object
    Public Shared AllMatSortDesc(3, 1) As Object
End Structure

Public Structure GenInfo3233
    Dim TestNum As String
    Public Shared MaxDLLevel As String
    Public Shared DLLevel As String

    Public Shared UserName As String
    Public Shared AssyMat(0) As Object
    Public Shared PartType As String
    Public Shared CCFolder As String
    Public Shared CCFamily As String

    Public Shared Number2 As String
    Public Shared FileName As String
    Public Shared FullJobNo As String
    Public Shared BOMList(20, 1)            'BOM Items on drawings.+
    Public Shared STDsList(20, 1)           'Standards found On drawings
    Public Shared StdsFnd2(2, 1)
    Public Shared StdsBOMList(20, 1)        'All Stds for MX-Standards
    Public Shared CollectSTDsList(20, 1)

    Public Shared FileDir As String
    Public Shared JobDir As String
    Public Shared CopyFromFile As String
    Public Shared BomListFileName As String         '-------DJL-12-19-2024

    Public Shared DefaultPrt As String
    Public Shared DefaultPrtSet As Boolean
    Public Shared BlockRef 'As AcadBlockReference

    Public Shared NewLayout 'As AcadLayout
    Public Shared NewPlotConfig 'As AcadPlotConfiguration

    Public Shared StartAdept As Boolean

    Public Shared LLCornerVPort
    Public Shared URCornerVPort
    Public Shared CenterVPort
    Public Shared HeightVPort
    Public Shared WidthVPort

    Public Shared ExDwgs1 As Object
    Public Shared PrgReqSpreadSht As String            'Program Requesting SpreadSheet Info.
    Public Shared SpreadSht As String                   'Spreadsheet user Selected.
    Public Shared SpreadshtLoc As String                'Spreadsheet location.
    Public Shared HVECIssue As String
End Structure

Public Class BOM_Menu3D                         'BulkBOMFab3D
    Inherits System.Windows.Forms.Form
    Public Shared AcadApp As AutoCAD.AcadApplication
    Public Shared ExcelApp As Excel.Application
    Dim ErrMsg, ErrNo, ErrSource, ErrDll, PriPrg, PrgName As String
    Dim ErrException As System.Exception
    Dim ErrLastLineX As Integer
    Dim FileToOpen As String
    Public CBclicked As Boolean
    Public SBclicked As Boolean
    Public SortListing As Boolean
    Declare Function SendMessage Lib "user32.dll" Alias "SendMessageA" (ByVal hwnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, ByRef lParam As VariantType) As Integer

    Public FirstTimeThru As String
    Public FuncGetDataNew As String
    Public NewBulkBOM As Worksheet
    Public MainBOMFile As Microsoft.Office.Interop.Excel.Workbook
    Public NewStickImport As Object
    Public OldBOMFile As Microsoft.Office.Interop.Excel.Workbook
    Public OldBulkBOM As Object
    Public OldBulkBOMFile As String
    Public NewBOM As Object
    Public OldBOM As Object
    Public FindSTD As Object
    Public OldStdItems As Object
    Public BOMType As String
    Public BOMSheet As String
    Public RowNo As String
    Public RowNo2 As String
    Public OldStdDwg As String
    Public NewStdDwg As String
    Public ExceptionPos As Integer
    Public CallPos As Integer
    Public CntExcept As Integer
    Public Count As Integer
    Public PassFilename As String
    Public ReadyToContinue As Boolean
    Public errorExist As Boolean
    Public BOMList(20, 1) As Object         'as String  'Tried Array-------DJL
    Public BOMListColl(20, 1) As Object
    Public BOMListArray(20, 1) As Array
    Public BOMListTemp(20, 1) As Object         'Tried Array-------DJL

    Public NewBOMList(20, 1) As String
    Public FindStdList(20, 1) As String
    Public FoundStdList(20, 1) As String
    Public ShpMkList() As String
    Public STDsList(20, 1)              'As String
    Public StdsBOMList(20, 1)
    Public CollectSTDsList(13, 1)

    Public AcadDoc As AutoCAD.AcadDocument
    Public RevNo As String
    Public RevNo2 As String
    Public Continue_Renamed As Boolean
    Public MatInch As Double
    Public FoundDir As String
    Public SearchException As String
    Public ExceptPos As Integer
    Public LytHid As Boolean
    Public CountBOM As Integer, CountNewItems As Integer, JobNoIndex As Integer
    Public ChkOldBOMTyp, BadDwgFound As String
    Public FindLayer, CurrentLayer, SearchPL, SearchBolt As String
    Public SearchFB, SearchMachine, SearchM, SearchS, SearchMC As String
    Public DwgItem, UserErrMsg, ErrLogFile, SearchValidDwg, SearchPipe, SearchWWF, SearchUBolt As String
    Public SearchGasket, SearchW, SearchC, SearchHP, SearchSheet, SearchTube As String
    Public BoltSize, MMBoltSize, FTypeLoca As String
    Public FootPos, InchPos, PLPos, WPos, CPos, LPos, BoltPos, RBPos, XPos, PrevXPos, HPPos, MCPos, CntSortList As Integer
    Public MPos, SPos, WWFPos, UBoltPos, SheetPos, TubePos, MBEPos As Integer
    Public FBPos, MachinePos, StudPos, PipePos, GasketPos, ValidPos, SearchPos, SearchPos2, LinesReadCnt As Integer
    Public ErrMsg2, UserInfo, FirstPart, SecondPart, ThirdPart, FirstLineFound, NewLine, BlkName, Test As String
    Public MetricFound, FType, FirstJobNo As String
    Public NTest, NTest1, NTest2, NTest3, Ntest4, NTest5, Ntest6, NTest7, NTest8, NTest9, NTest10, FindSortItem, FoundSortItem As String
    Public NTest11, NTest12, NTest13, NTest14, NTest15, NTest16, NTest17, GetPartDesc, GetMat, GetMat2, GetMat3, Inv1, WorkShtName As String
    Public Test2, CFound, sqlStr, StartDir, FileNam, NewDir, SecondChk, FindParameter, PartFound, ProblemAt, FileSaveAS, FullJobNo As String
    Public LookForStd, LookForShipMk, FirstDwg As String
    Public Shared GetShipMk, GetNextShipMk, GetShipMkYesNo As String
    Public CutCount, LineNo2, DwgItem2, CurrentDwgNo, CntDwgsNotFound As Integer
    Public AcadOpen As Boolean
    Public GetLen As String
    Public Workbooks As Microsoft.Office.Interop.Excel.Workbooks
    Public WorkSht As Worksheet
    Public StdsWrkSht As Worksheet
    Public QuoteMkPos As Integer
    Public FoundColdRolled As Integer

    Const SearchInch As String = Chr(34)                'Find " Inch
    Const SearchFoot As String = Chr(39)                'Find ' Feet
    Const SearchReturn As String = Chr(13)              'vbCrLF         '-------End of Look for Hard return.
    Const SearchFraction As String = "/"
    Const SearchSlash As String = "\"
    Const SearchDash As String = "-"
    Const SearchSpace As String = " "

    Const SearchBracket As String = " ("
    Const SearchNote As String = "Note"

    Const SearchRolled As String = "ROLLED"
    Const SearchRoll As String = " ROLLED"
    Const SearchRoll2 As String = " (COLD ROLLED)"
    Const SearchStd As String = "STD"
    Const SearchX As String = " x "
    Const SearchX2 As String = "x "

    Public FabInvListData(3, 1) As Object
    Public StructureData(3, 1) As Object
    Public FittingData(3, 1) As Object
    Public GasketData(3, 1) As Object
    Public FlangeData(3, 1) As Object
    Public PipeData(3, 1) As Object
    Public HardwareData(3, 1) As Object
    Public MiscData(3, 1) As Object
    Public SubMFGData(3, 1) As Object
    Public SubPURData(3, 1) As Object
    Public NamePlateData(3, 1) As Object
    Public PlateData(3, 1) As Object
    Public ShipSuplData(3, 1) As Object
    Public TkSealData(3, 1) As Object
    Public AllMatSortDesc(3, 1) As Object

    Public Shared myarray As Object
    Public Shared myarray2 As Object
    Public Shared CntFrames As Integer
    Public GetFramesSrt
    Public PrgLineNo As String
    Public FindEndStr, LenPrgLineNo As Integer
    Public StartAdept As Boolean
    Public BOMWrkSht As Worksheet
    Public db_String As String
    Public Sapi As Object = CreateObject("SAPI.spvoice")

    Public Structure SECURITY_ATTRIBUTES
        Dim nLength As Integer
        Dim lpSecurityDescriptor As Integer
        Dim bInheritHandle As Boolean
    End Structure

    Private Sub AddAllButton_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles BtnAddAll.Click
        Dim Dupe As Boolean
        Dim Count, i, j, CountDwgs, CntDwgs As Integer
        Dim VarSelArray As Object
        Dim DwgListArray As Object
        Dim Test2 As String

        PrgName = "AddAllButton_Click"

        On Error GoTo Err_AddAllButton_Click

        CntDwgs = 0
        CountDwgs = DwgList.Items.Count
        ReDim DwgListArray(CountDwgs)

        For i = 0 To (CountDwgs - 1)
            SelectList.Items.Add(DwgList.Items.Item(i))
            DwgListArray(CntDwgs) = DwgList.Items.Item(i)
            CntDwgs = (CntDwgs + 1)
        Next i

        For i = 0 To (CountDwgs - 1)
            DwgList.Items.Remove(DwgListArray(i))
        Next

        DwgList.Sorted = True
        SelectList.Sorted = True
        BtnRemove.Enabled = True
        BtnClear.Enabled = True
        BtnStart2.Enabled = True

        If SelectList.Items.Count > 0 Then
            SelectList.BackColor = System.Drawing.Color.GreenYellow
            DwgList.BackColor = System.Drawing.Color.LightBlue
        End If
Err_AddAllButton_Click:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Sub

    Private Sub AddButton_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles BtnAdd.Click
        Dim Dupe As Boolean
        Dim Count, i, j, CountDwgs, CntDwgs As Integer
        Dim DwgListArray As Object
        Dim Test, Test2 As String

        PrgName = "AddButton_Click"

        On Error GoTo Err_AddButton_Click

        CntDwgs = 0
        CountDwgs = DwgList.SelectedItems.Count
        ReDim DwgListArray(CountDwgs)

        For i = 0 To (CountDwgs - 1)                                'Do not need to look at everydwg just look at selected Dwgs.
            SelectList.Items.Add(DwgList.SelectedItems.Item(i))
            DwgListArray(CntDwgs) = DwgList.SelectedItems.Item(i)   'So create Array and delete after complete.
            CntDwgs = (CntDwgs + 1)
        Next i

        For i = 0 To (CountDwgs - 1)
            DwgList.Items.Remove(DwgListArray(i))
        Next

        DwgList.Sorted = True
        SelectList.Sorted = True

        If SelectList.Items.Count = 0 Then
            BtnRemove.Enabled = False
            BtnClear.Enabled = False
        Else
            BtnRemove.Enabled = True
            BtnClear.Enabled = True
        End If

        If Me.SelectList.Items.Count <> 0 Then
            Me.BtnStart2.Enabled = True
        End If

        If SelectList.Items.Count > 0 Then
            SelectList.BackColor = System.Drawing.Color.GreenYellow
            DwgList.BackColor = System.Drawing.Color.LightBlue
        End If

Err_AddButton_Click:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Sub

    Private Sub CancelButton_Renamed_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CancelButton_Renamed.Click
        Me.Close()
    End Sub

    Private Sub ClearButton_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles BtnClear.Click
        SelectList.Items.Clear()
        BtnRemove.Enabled = False
        BtnClear.Enabled = False
        BtnStart2.Enabled = False
    End Sub

    Private Sub RemoveButton_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles BtnRemove.Click
        Dim Dupe As Boolean
        Dim Count, i, j, DwgPos, LenDwg1, LenDwg2, LenPath, CountDwgs, CntDwgs As Integer
        Dim VarSelArray As Object
        Dim GetDwg, FilePath, FindFile As String
        Dim DwgListArray As Object

        PrgName = "RemoveButton_Click"

        On Error GoTo Err_RemoveButton_Click

        Count = Me.SelectList.Items.Count - 1
        CountDwgs = SelectList.SelectedItems.Count
        CntDwgs = 0
        ReDim DwgListArray(CountDwgs)

        For i = 0 To (CountDwgs - 1)    'Do not need to look at every drawing, and Array is not required.
            DwgPos = 0
            GetDwg = SelectList.SelectedItems.Item(i).ToString
            Me.DwgList.Items.Add(GetDwg)
            DwgListArray(CntDwgs) = SelectList.SelectedItems.Item(i)  'So create Array and delete after complete.
        Next i

        If SelectList.Items.Count = 0 Then
            BtnRemove.Enabled = False
            BtnClear.Enabled = False
            BtnStart2.Enabled = False
        End If

        For i = 0 To (CountDwgs - 1)
            SelectList.Items.Remove(DwgListArray(i))
        Next

        DwgList.Sorted = True
        SelectList.Sorted = True

Err_RemoveButton_Click:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Sub

    Private Sub SelectList_DblClick(ByVal Cancel As Boolean)
        If Me.SelectList.SelectedIndex <> -1 Then
            If Me.SelectList.GetSelected(Me.SelectList.SelectedIndex) = True Then
                SelectList.Items.RemoveAt((Me.SelectList.SelectedIndex))
            End If
        End If

        If SelectList.Items.Count = 0 Then
            BtnRemove.Enabled = False
            BtnClear.Enabled = False
            BtnStart2.Enabled = False
        End If

        PrgName = "StartButton_Click"

        On Error GoTo Err_StartButton_Click
Err_StartButton_Click:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Sub

    Private Sub UserForm_Initialize()
        Dim RevList(20) As Short
        Dim i As Short

        PrgName = "UserForm_Initialize"

        On Error GoTo Err_UserForm_Initialize

        SBclicked = False
        Me.LblProgress.Text = "Progress........"

        For i = 0 To 20
            RevList(i) = i
        Next i

        Me.ComboBxRev.Items.Add(RevList)

Err_UserForm_Initialize:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Sub

    Private Async Sub BOM_Menu_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim i As Short
        PrgName = "BOM_Menu_Load"

        'On Error GoTo Err_BOM_Menu_Load

        SBclicked = False
        Me.RadioButton1.Checked = True
        Me.LblProgress.Text = "Progress........"
        btnNewDir.Enabled = False

        For i = 0 To 20
            Me.ComboBxRev.Items.Add(i)
        Next i

        'fs = CreateObject("Scripting.FileSystemObject")

        'BtnGetMWInfo.PerformClick()                         '-------Moved to below to PathBox.click

        'If DwgList.Items.Count > 0 Then                    '-------Moved to PathBox
        '    Me.BtnAddAll.Enabled = True
        '    Me.BtnAdd.Enabled = True
        '    Me.BtnRemove.Enabled = True
        '    Me.BtnClear.Enabled = True
        '    btnNewDir.Enabled = True
        'Else
        '    Me.BtnAddAll.Enabled = False
        '    Me.BtnAdd.Enabled = False
        '    Me.BtnRemove.Enabled = False
        '    Me.BtnClear.Enabled = False
        '    btnNewDir.Enabled = False
        'End If

        Me.PathBox_Click(sender, e)

        '-------Email Bill Sieg, Since you  “I don’t even look at them, I just run them and send them.” Then the process Is being removed.

Err_BOM_Menu_Load:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                'Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                'Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        'Resume
                    End If
                    If CallPos > 0 Then
                        'Resume
                    End If
                End If
            End If
        End If

    End Sub

    Private Sub BtnStart2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnStart2.Click
        Dim xlShiftUp As Object, Columns As Object, xlTopToBottom As Object, xlGuess As Object
        Dim xlDescending As Object, xlToRight As Object
        Dim xlAscending As Object, xlCenter As Object, Selection As Object, Range As Object, Worksheets As Object
        Dim VarSelArray As Object, Excel As Object, BlockData(1) As Object, DwgItem As Object
        Dim BomItem As IAcadBlockReference
        Dim TempAttributes As Object, Temparray As Object, gvntSDIvar As Object, InsertionPT As Object, TempDefinition As Object
        Dim Title, Msg, Style, Response As Object
        Dim TagInsPnt1 As Object, TagInsPnt2 As Object, xlMinimized As Object, ExcelWorkbook As Object
        Dim BlockSel As AutoCAD.AcadSelectionSet
        Dim AMWdisabled As Boolean, AcadOpen As Boolean, MultiLineMatl As Boolean
        Dim BatchYN As Short, GroupCode(1) As Short
        Dim AcadPref As AutoCAD.AcadPreferencesSystemClass
        Dim CompareX1 As Double, CompareX2 As Double, Dimscale As Double
        Dim i, j, k, l2, n, m2, i1, x, Count, Shopwatch, CntWorkbook, CntWrkShts, CountVal, CutCount, Testi, NotePos, z As Integer
        Dim SeeNotePos, ChkPos, SeeDwgPos, ExceptPos, CntExcept, RevPos, ExtPos, jA, FoundPart, DecPos, Cntj, CntCollected As Integer
        Dim FootPos, FootPos2, LenFoot, LinesRemoved, XPos, MMPos1, MMPos2, TestLen, TotalCnt, CntFrames, CntRecToUpdate As Integer
        Dim SpacePos, CntTitleBlks, CntBlks, QtyMarkIssue, HVECIssue, ShtPos, CntCollect, CntSortList4 As Integer
        Dim FullJobNo, CurrentDwgRev, CurrentDwgNo, FilePath, CurrentDWG, PrgName, WorkBookName, Get2DShipQty As String         ', GetDesc2
        Dim WrkBookName, WorkShtName, NextSht, BomWrkShtNam, FileSaveAS, OldFileNam, GetInv1, GetInv2, FindSortItemNo As String
        Dim FindFoot, SearchFoot, FindFoot1, FindFoot2, FirstDwg, TestTags, BOMItemNam, DwgItem2, FoundDwg, FoundX As String
        Dim LookForStd, LookForShipMk, FoundLast, LineNo, LineNo2, LineNo3, LineNo4, FoundRev As String
        Dim AdeptPrg, AdeptStd, Dwg, ExistSTD, Test, SearchException, FindRev, FindRev1, FindRev2 As String
        Dim ShpM, ShpM2, ShpQ, ShpQ2, Desc, Desc2, Ref1, Ref2, Matl, Matl2, Matl3, Wght, NewItem As String
        Dim OldDwg, OldRev, OldShpMk, OldPcMk, OldQty, OldDesc, OldDesc2, OldInv, OldStd, OldMatl As String
        Dim OldWht, OldReq, OldProd, FixPart1, FixPart2, TestDwgNo, LookForMXStd, LookForPartsOnStd As String
        Dim NewDwg, NewRev, NewShpMk, NewPcMk, NewQty, NewDesc, NewInv, NewStd, NewMatl, NewWht As String
        Dim NewReq, NewProd, NewRow, ProblemErr, PrgLineNo, InsPt0, InsPt1, MX2 As String
        Dim FoundItem, SearchSeeNote, SearchNote, SearchNote2, SearchDwg, CompDesc, FirstTimeThru As String
        Dim OldRef, MxPcMk, CurrentStdNo, MissingTxt1, MissingTxt2, MissingTxt3 As String
        Dim Test1, ProblemAt, Inv1, CntDwgNoInsPt0, CntDwgNoInsPt1, InsPt3, FindSortItem2, GetShipStds As String
        Dim GetPartNo, Get2DShipMk, GetQty, GetShipDesc, GetDesc, GetLen, GetMat, GetMat2, GetMat3, GetNotes, GetWt, GetProc As String
        Dim Workbooks As Microsoft.Office.Interop.Excel.Workbooks
        Dim WorkSht As Worksheet, BOMWrkSht As Worksheet, StdsWrkSht As Worksheet            ', ShpCutWrkSht As Worksheet
        Dim StdItemsWrkSht As Worksheet
        Dim ThisDrawing As AutoCAD.AcadDocument
        Dim RowNumFix, CntAttFound As Integer
        Dim StartAdept As Boolean
        Dim CntDwgs, m As Integer
        Dim GetFramesSrt

        PrgName = "StartButton_Click-Part1"

        On Error GoTo Err_StartButton_Click 'On Error Resume Next

        ExceptPos = 0
        Shopwatch = 0
        SortListing = True
        BadDwgFound = "No"
        LinesRemoved = 0
        QtyMarkIssue = 0
        SecondChk = "First"
        Me.BtnStart2.Enabled = False

        If Directory.Exists("K:\AWA\" & System.Environment.UserName & "\AdeptWork\") = False Then                            'DJL 9-17-2024
            ClosePrg("Excel", SecondChk, StartAdept)
            'ClosePrg("Adept", SecondChk, StartAdept)                               '-------Hold for now.
        End If

        PrgName = "StartButton_Click-Part2"

        'ClosePrg("Excel", SecondChk, StartAdept)       Doesn't work in Citrix      RW 8/17/2023
        'ClosePrg("Adept", SecondChk, StartAdept)       Doesn't work in Citrix      RW 8/17/2023

        '-------Email Bill Sieg, Since you  “I don’t even look at them, I just run them and send them.” Then the process Is being removed.

        On Error Resume Next

        ExcelApp = GetObject(, "Excel.Application")

        If Err.Number Then
            Information.Err.Clear()
            ExcelApp = CreateObject("Excel.Application")
            If Err.Number Then
                MsgBox(Err.Description)
                Exit Sub
            End If
        End If

        On Error GoTo Err_StartButton_Click

        BOMType = "Tank"

        If Me.ComboBxRev.Text = vbNullString Then
            Sapi.Speak("Please select a revision number for Bulk BOM")
            MsgBox("Please select a revision number for Bulk BOM")
            Exit Sub
        End If

        Me.LblProgress.Text = "Gathering Information from AutoCAD Drawings........Please Wait"
        Me.Refresh()

        PrgName = "StartButton_Click-Part3"

        On Error Resume Next
        If Err.Number Then
            Err.Clear()
        End If

        AcadApp = GetObject(, "AutoCAD.Application")
        AcadOpen = True

        If Err.Number Then
            Information.Err.Clear()
            AcadApp = CreateObject("AutoCAD.Application")
            AcadOpen = False
            If Err.Number Then
                Information.Err.Clear()
                AcadApp = CreateObject("AutoCAD.Application")
                If Err.Number Then
                    MsgBox(Err.Description)
                    MsgBox("Instance of 'AutoCAD.Application' could not be created.")

                    AcadApp.Visible = False                         'AcadApp.Visible = False
                    MsgBox("Now running " & AcadApp.Name & " version " & AcadApp.Version)

                    If System.Environment.UserName = "dlong" Then
                        Stop
                        Resume
                    Else
                        Exit Sub
                    End If
                End If
            End If
        End If

        AcadApp.Visible = False
        'ThisDrawing = AcadApp.ActiveDocument                           '-------DJL-9-20-2024       'Not used anymore.
        'Dim Mospace As AcadModelSpace = ThisDrawing.ModelSpace
        'Dim Paspace As AcadPaperSpace = ThisDrawing.PaperSpace
        'Dim UtilObj As AcadUtility = ThisDrawing.Utility

        On Error GoTo Err_StartButton_Click

        AcadPref = AcadApp.Preferences.System

        If AcadPref.SingleDocumentMode = True Then
            gvntSDIvar = AcadPref.SingleDocumentMode
        End If

        If gvntSDIvar = True Then
            AcadPref.SingleDocumentMode = False
        End If

        PrgName = "StartButton_Click-Part4"

        AcadApp.WindowState = AutoCAD.AcWindowState.acMin
        FirstDwg = "NotFound"
        FirstDwg = Nothing
        'AcadApp.Visible = False
        Me.Refresh()
        SBclicked = True
        CBclicked = False
        Count = Me.SelectList.Items.Count
        ProgressBar1.Value = 0
        ProgressBar1.Maximum = Count
        ProgressBar1.Visible = True
        CountVal = 0

        If Count <> 0 Then
            ReDim VarSelArray(Count)
            For i = 1 To Count
                VarSelArray(i) = Me.SelectList.Items(i - 1)
            Next i

            'Dim BOMList(18, 1)
            CntDwgs = UBound(VarSelArray)

            For z = 1 To CntDwgs                         'For Each DwgItem In VarSelArray
                ProgressBar1.Value = z
                DwgItem = VarSelArray(z)

                If CBclicked Then
                    If MsgBox("Are you sure?", 36, "Bulk BOM Generator - Cancel") = 6 Then
                        GoTo Cancel
                    End If
                Else
                    If IsNothing(DwgItem) = True Then
                        GoTo NextDwg
                    End If

                    PrgName = "StartButton_Click-Part5"

                    Threading.Thread.Sleep(150)
                    AcadApp.Documents.Open(DwgItem.FullName)         'AcadApp.Documents.Open(PathBox.Text & DwgItem.ToString) 'DJL-------10-11-2023
                    AcadApp.WindowState = AutoCAD.AcWindowState.acMin
                    AcadApp.Visible = False
                    CurrentDwgNo = Nothing
                    Me.TxtBoxDwgsToProcess.Visible = True
                    Me.LblDwgsToProcess.Visible = True
                    Me.TxtBoxDwgsToProcess.Text = CntDwgs - z
                    Me.TxtBoxBOMItemsToProcess.Visible = True
                    Me.LblBOMItemsToProess.Visible = True
                    Me.Refresh()

                    If BadDwgFound = "Yes" Then
                        BadDwgFound = "No"
                        GoTo NextDwg
                    End If

                    On Error Resume Next

                    If Dir("K:\cad\vba\autocad\Layout.dvb") <> vbNullString Then            '-------Looks like layout.dvb is creating a Bad Layout when autocad acts up.
                        AcadApp.UnloadDVB("K:\cad\vba\autocad\Layout.dvb")
                    End If

                    On Error GoTo Err_StartButton_Click

                    System.Threading.Thread.Sleep(50)
                    AcadApp.Visible = False
                    Me.Refresh()
                    AcadDoc = AcadApp.ActiveDocument

                    PrgName = "StartButton_Click-Part6"

                    '-------------------------------------------There is no reason to look at every titleblock ?
                    BlockSel = AcadDoc.SelectionSets.Add("Titleblock")
                    GroupCode(0) = 0
                    BlockData(0) = "INSERT"
                    GroupCode(1) = 2                                                                                                    'Who added this ?   '2211-4070-BRDER_11x17                      
                    BlockData(1) = "AMW_TITLE,OSF_TITLE,OSF_TITLE_D,MX_TITLE,LNG_TITLE_D,MX_TITLE_SP,MX_TITLE-11x17,MTRX_PDM-BRDER_11x17,2211-4070-BRDER_11x17,Title Blocks Matrix,MATRIX TITLEBLOCK,MPDM_STD_TITLE*,MPDM_MEC_TITLE*"          'DJL-------10-11-2023        'BlockData(1) = "AMW_TITLE,OSF_TITLE,OSF_TITLE_D,MX_TITLE,LNG_TITLE_D,MX_TITLE_SP,MX_TITLE-11x17,MTRX_PDM-BRDER_11x17,2211-4070-BRDER_11x17,Title Blocks Matrix,MATRIX TITLEBLOCK" 
                    BlockSel.Select(AutoCAD.AcSelect.acSelectionSetAll, , , GroupCode, BlockData)
                    CntBlks = BlockSel.Count

                    If CntBlks = Nothing Or CntBlks = 0 Then
                        MsgBox("Drawing " & AcadDoc.Name & " has no titleblock and will be skipped.")
                        AcadDoc.Close()
                        GoTo NextDwg
                    End If

                    CntTitleBlks = 0                            'CntTitleBlks = 1
                    Temparray = BlockSel.Item(CntTitleBlks).GetAttributes  'Temparray = BlockSel.Item(0).GetAttributes

                    PrgName = "StartButton_Click-Part7"

FindAttributes:
                    For i = 0 To UBound(Temparray)
                        Test = Temparray(i).TagString                          '-------Requisition Number not on BOM.
                        Test1 = Temparray(i).TextString

                        Select Case Temparray(i).TagString
                            Case "DN"
                                CurrentDwgNo = Temparray(i).TextString

                                If InStr(CurrentDwgNo, "(SH") > 0 Then          '-------New problem Job 2212-1001-HVEC has put the (sht 1 of 2) on DN tag for dwg no.
                                    ShtPos = InStr(CurrentDwgNo, "(SH")
                                    CurrentDwgNo = Mid(CurrentDwgNo, 1, (ShtPos - 1))
                                Else
                                    If InStr(CurrentDwgNo, "(") > 0 Then
                                        ShtPos = InStr(CurrentDwgNo, "(")
                                        CurrentDwgNo = Mid(CurrentDwgNo, 1, (ShtPos - 1))
                                    End If
                                End If

                                CurrentDwgNo = LTrim(CurrentDwgNo)
                                CurrentDwgNo = RTrim(CurrentDwgNo)
                                CntCollect = (CntCollect + 1)
                            Case "TITLE"
                                CurrentDwgNo = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                                CntCollect = (CntCollect + 1)
                            'Case "DT"
                            '    CurrentDwgNo = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                            Case "JN"
                                FullJobNo = Temparray(i).TextString
                                JobNoIndex = i
                                CntCollect = (CntCollect + 1)
                            Case "PROJECT"
                                FullJobNo = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                                JobNoIndex = i
                                CntCollect = (CntCollect + 1)
                            Case "PN"
                                FullJobNo = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                                JobNoIndex = i
                                CntCollect = (CntCollect + 1)
                            Case "RN"
                                CurrentDwgRev = Temparray(i).TextString
                                CntCollect = (CntCollect + 1)
                            Case "REV"
                                CurrentDwgRev = Temparray(i).TextString
                                CntCollect = (CntCollect + 1)
                            Case "REVISION_NUMBER"
                                CurrentDwgRev = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                                CntCollect = (CntCollect + 1)
                                'Case "Rq"
                                '    ReqNo = Temparray(i).TextString                          '-------Requisition Number not on BOM

                                '-------Look at later
                                'Case "DESCRIPTION"
                                '    GetDwgtITLE = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                                'Case "Number of sheets"
                                '    GetDwgShtsNo = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                                'Case "Sheet Number"
                                '    GetShtNo = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                                'Case "State"
                                '    GetState = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                                'Case "CITY"
                                '    GetCity = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                                'Case "TankDia"
                                '    GetTankDia = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                                'Case "COMPANY"
                                '    GetCompany = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                                'Case "SUBJECT"
                                '    GetTankNo = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                                'Case "TANK HT."
                                '    GetTankHt = Temparray(i).TextString                          '-------Drawing Converted for Inventor to AutoCAD
                        End Select

                        If CntCollect = 3 Then                          '-------DJL-10-11-2023--------If CntCollect = 10 Then
                            GoTo FoundAllItems
                        End If

                        PrgName = "StartButton_Click-Part8"
                    Next i

FoundAllItems:
                    If CurrentDwgNo = Nothing And CntBlks > 0 Then                          'If CurrentDwgNo = Nothing And CntBlks > 1 Then
                        CntTitleBlks = (CntTitleBlks + 1)

                        If CntTitleBlks <= (CntBlks - 1) Then                            'If CntTitleBlks = 1 Then
                            Temparray = BlockSel.Item(CntTitleBlks).GetAttributes      'Temparray = BlockSel.Item(1).GetAttributes
                        End If

                        GoTo FindAttributes
                    End If

                    PrgName = "StartButton_Click-Part9"

                    CntCollect = Nothing
                    CurrentDwgNo = CurrentDwgNo     'Reference below had Nothing
                    GenInfo3233.FullJobNo = FullJobNo
                    CurrentDwgRev = CurrentDwgRev

                    If FirstJobNo <> FullJobNo Then
                        If IsNothing(FirstJobNo) = True Then
                            FirstJobNo = FullJobNo
                            GoTo JobNoChecked
                        End If

                        'Sapi.Speak("Drawing " & CurrentDwgNo & " has a different Job Number from the rest of the drawings.")
                        Msg = "Drawing " & CurrentDwgNo & " has a different Job Number example " & FirstJobNo & " and " & FullJobNo & " do not match, Do you want to use Job No ? " & FirstJobNo
                        Style = MsgBoxStyle.YesNo
                        Title = "Job Number Issue"
                        Response = MsgBox(Msg, Style, Title)

                        If Response = 6 Then
                            FullJobNo = FirstJobNo
                            Temparray(JobNoIndex).TextString = FirstJobNo
                        Else
                            FirstJobNo = FullJobNo
                            Temparray(JobNoIndex).TextString = FullJobNo
                        End If
                    End If

JobNoChecked:
                    PrgName = "StartButton_Click-Part10"
                    BlockSel = AcadDoc.SelectionSets.Add("BillOfMaterial")
                    GroupCode(0) = 0
                    BlockData(0) = "INSERT"
                    GroupCode(1) = 2
                    BlockData(1) = "STANDARD_BILL_OF_MATERIAL,B_BILL_OF_MATERIAL,SP_BILL_OF_MATERIAL,BILL OF MATERIAL,STANDARD_BILL_OF_MATERIAL_Erectino Double Digit,STANDARD_BILL_OF_MATERIAL Assembly,STANDARD_BILL_OF_MATERIAL Erection Single Digit"
                    BlockSel.Select(AutoCAD.AcSelect.acSelectionSetAll, , , GroupCode, BlockData)           'Some drawings are giving BlockSel.Count = 0 RW-------DJL this is true if no BOM Blocks exist on drawing.     

                    If BlockSel.Count <> 0 Then
                        CntCollected = 0

                        For Each BomItem In BlockSel
                            PrgName = "StartButton_Click-Part11"
                            CntCollected = CntCollected + 1
                            Me.TxtBoxBOMItemsToProcess.Text = BlockSel.Count - CntCollected
                            Me.Refresh()
                            TempAttributes = BomItem.GetAttributes

                            'Dim AttDef As IAcadAttributeReference       '= BomItem.GetType.Attributes.
                            'Test = AttDef.TextGenerationFlag.ToString()
                            'AttDef.Prompt                          'Was trying to find the Attribute Prompts

                            For x = 0 To UBound(TempAttributes)     'Not Required Found Job Information Previuosly 'Need info for Standards Dwg Number.
                                Test1 = TempAttributes(x).TagString
                                'Dim AttDef As IAcadAttributeReference
                                'AttDef = BlockSel.Item(1).

                                'Test2 = TempAttributes(x).Prompt
                                'Dim AttDef As AcadAttributeReference = TempAttributes(x).Definition

                                Select Case TempAttributes(x).TagString
                                    Case "SLM"                          '-------MK"
                                        Get2DShipMk = TempAttributes(x).TextString

                                        If Get2DShipMk <> "" Then
                                            GetShipStds = "Yes"
                                        Else
                                            GetShipStds = "No"
                                        End If
                                    Case "SLQ"                          '-------MK"
                                        Get2DShipQty = TempAttributes(x).TextString
                                    Case "SM"                           '-------SP"
                                        GetPartNo = TempAttributes(x).TextString            'Found drawing with two different Attributes labeled both m 1 = A105 2 = 5
                                    Case "Q"
                                        GetQty = TempAttributes(x).TextString
                                    Case "SD"
                                        GetShipDesc = TempAttributes(x).TextString
                                    Case "D"
                                        GetDesc = TempAttributes(x).TextString
                                    Case "D2"
                                        GetShipDesc = TempAttributes(x).TextString
                                    Case "IU"
                                        GetInv1 = TempAttributes(x).TextString
                                    Case "IL"
                                        GetInv2 = TempAttributes(x).TextString
                                    Case "SP"
                                        GetPartNo = TempAttributes(x).TextString
                                    Case "MK"
                                        Get2DShipMk = TempAttributes(x).TextString
                                        GetShipStds = "No"
                                    Case "L"
                                        GetLen = TempAttributes(x).TextString
                                    Case "M"      'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                                        If GetMat <> "" And GetPartNo = "" Then
                                            GetPartNo = TempAttributes(x).TextString            'For some reason Users have BOM insert with two m = A105 M2= Part number
                                            MX2 = "Found"                                       'EEP issues on ATTRIBUTES.
                                        Else
                                            If GetMat <> "" Then
                                                GetPartNo = TempAttributes(x).TextString            'For some reason Users have BOM insert with two m = A105 M2= Part number
                                            Else
                                                GetMat = TempAttributes(x).TextString
                                            End If
                                        End If

                                        'If InStr(GetMat, "NOTE") > 0 Then                          'Hold for now.-------DJL-10-11-2023
                                        '    NotePos = InStr(GetMat, "NOTE")
                                        '    GetNotes = Mid(GetMat, NotePos, Len(GetMat))
                                        '    GetMat = Mid(GetMat, 1, (NotePos - 1))
                                        'End If
                                    Case "M2"      'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                                        GetMat2 = TempAttributes(x).TextString
                                    Case "M3"      'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                                        GetMat3 = TempAttributes(x).TextString
                                    Case "N"
                                        GetNotes = TempAttributes(x).TextString
                                    Case "W"
                                        GetWt = TempAttributes(x).TextString
                                    Case "P"
                                        GetProc = TempAttributes(x).TextString
                                End Select
                            Next x

BOMInfoCollected:
                            If GetMat <> "" And MX2 = "Found" Then
                                If GetPartNo = "" And Get2DShipMk = "" Then
                                    GetPartNo = GetMat            'For some reason EEP Users have BOM insert with two m = A105 M2= Part number

                                    If GetMat2 <> "" Then
                                        GetMat = ""
                                    End If
                                End If
                            End If

                            InsertionPT = BomItem.InsertionPoint
                            Dimscale = BomItem.XScaleFactor
                            CompareX1 = 10.5 * Dimscale
                            CompareX1 = InsertionPT(0) - CompareX1
                            CompareX1 = CompareX1 / Dimscale

                            CompareX2 = 6 * Dimscale
                            CompareX2 = InsertionPT(0) - CompareX2
                            CompareX2 = CompareX2 / Dimscale

                            If CompareX1 < 1 Or CompareX2 < 1 Then
                                If CompareX1 > 0 Or CompareX2 > 0 Then
                                    BOMList(16, UBound(BOMList, 2)) = CStr(1)
                                Else
                                    BOMList(16, UBound(BOMList, 2)) = CStr(2)
                                End If
                            Else
                                BOMList(16, UBound(BOMList, 2)) = CStr(2)
                            End If

                            BOMList(1, UBound(BOMList, 2)) = CurrentDwgNo                               '-------Dwg number
                            BOMList(2, UBound(BOMList, 2)) = CurrentDwgRev                              '-------Rev Number
                            BOMList(3, UBound(BOMList, 2)) = Get2DShipMk

                            If GetQty = Nothing Then
                                'If Get2DShipQty = Nothing Then
                                '    BOMList(4, UBound(BOMList, 2)) = "1"
                                'Else
                                BOMList(4, UBound(BOMList, 2)) = Get2DShipQty
                                'End If
                            Else
                                BOMList(4, UBound(BOMList, 2)) = GetQty
                            End If

                            If MX2 = "Found" Then
                                If GetPartNo = "A105" Then
                                    Test1 = GetMat
                                    GetMat = GetPartNo
                                    GetPartNo = Test1
                                Else
                                    If GetPartNo = "A106" Then
                                        Test1 = GetMat
                                        GetMat = GetPartNo
                                        GetPartNo = Test1
                                    Else
                                        If GetPartNo = "A36" Then
                                            Test1 = GetMat
                                            GetMat = GetPartNo
                                            GetPartNo = Test1
                                        Else
                                            If GetPartNo <> "" And GetMat <> "" Then
                                                Test1 = GetMat
                                                GetMat = GetPartNo
                                                GetPartNo = Test1
                                            End If
                                        End If
                                    End If
                                End If
                            End If

                            BOMList(5, UBound(BOMList, 2)) = GetPartNo
                            BOMList(6, UBound(BOMList, 2)) = GetShipDesc                        'BOMList(6, UBound(BOMList, 2)) = GetShipDesc 
                            BOMList(7, UBound(BOMList, 2)) = GetDesc                       'BOMList(7, UBound(BOMList, 2)) = GetDesc
                            BOMList(8, UBound(BOMList, 2)) = GetShipStds
                            BOMList(9, UBound(BOMList, 2)) = GetInv1
                            BOMList(10, UBound(BOMList, 2)) = GetInv2

                            'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                            GetMat = LTrim(GetMat)          'Below has a problem due to someone putting spaces in the values
                            GetMat2 = LTrim(GetMat2)
                            GetMat3 = LTrim(GetMat3)

                            'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                            If IsNothing(GetMat) = False And GetMat <> "" Then
UpdateMat2:
                                If GetMat = " " Or GetMat = "  " Then        'Found material m = " " had a space   "Question if someone is using space to blank out data using replace?
                                    If (GetMat2) <> "" And GetMat3 <> "" Then
                                        GoTo UpdateMat4
                                    End If
                                End If

                                BOMList(11, UBound(BOMList, 2)) = GetMat
                            Else
UpdateMat4:
                                If (GetMat2) <> "" And GetMat3 <> "" Then
                                    BOMList(11, UBound(BOMList, 2)) = (GetMat2 & " " & GetMat3)             'Trevor requested to have the dash between Material 1 and 2 to be removed.  'BOMList(11, UBound(BOMList, 2)) = (GetMat2 & "-" & GetMat3)    'BOMList(11, UBound(BOMList, 2)) = (GetMat2 & "~" & GetMat3)
                                Else
                                    GoTo UpdateMat2
                                End If
                            End If

                            BOMList(13, UBound(BOMList, 2)) = GetLen
                            BOMList(14, UBound(BOMList, 2)) = GetWt
                            BOMList(15, UBound(BOMList, 2)) = CurrentDwgNo
                            BOMList(17, UBound(BOMList, 2)) = InsertionPT(1).ToString
                            BOMList(18, UBound(BOMList, 2)) = GetProc

                            DecPos = Nothing
                            InsPt0 = InsertionPT(0).ToString
                            DecPos = InStr(InsPt0, ".")
                            If DecPos = 2 Then
                                InsPt0 = "0" & InsPt0
                            End If

                            DecPos = Nothing
                            InsPt1 = InsertionPT(1).ToString
                            DecPos = InStr(InsPt1, ".")
                            If DecPos = 2 Then
                                InsPt1 = "0" & InsPt1
                            End If

                            BOMList(19, UBound(BOMList, 2)) = (InsPt0) 'BOMList(19, UBound(BOMList, 2)) = (CurrentDwgNo & InsPt0)     'BOMList(19, UBound(BOMList, 2)) = CurrentDwgNo & InsPt0 & InsPt1       'Does not work
                            BOMList(0, UBound(BOMList, 2)) = InsertionPT(0).ToString
                            ReDim Preserve BOMList(20, UBound(BOMList, 2) + 1)
NextBOMItem:
                            GetPartNo = Nothing
                            Get2DShipMk = Nothing
                            Get2DShipQty = Nothing
                            GetPartNo = Nothing
                            GetQty = Nothing
                            GetShipDesc = Nothing
                            GetDesc = Nothing
                            'GetDesc2 = Nothing
                            GetLen = Nothing
                            GetNotes = Nothing
                            GetMat = Nothing    'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                            GetMat2 = Nothing
                            GetMat3 = Nothing
                            MX2 = Nothing
                            GetShipStds = Nothing
                            GetNotes = Nothing
                            GetWt = Nothing
                        Next BomItem
                    End If
                End If

                PrgName = "StartButton_Click-Part12"

                ProblemAt = "CloseDwg"
                CountVal = (CountVal + 1)
                ProgressBar1.Value = CountVal
                AcadDoc.Close(SaveChanges:=False)        'AcadDoc.Close()        Changed AcadDoc from Object to AcadDocument type    RW 8/17/2023
                ProblemAt = ""
NextDwg:
                GetPartNo = Nothing
                Get2DShipMk = Nothing
                Get2DShipQty = Nothing
                GetPartNo = Nothing
                GetQty = Nothing
                GetShipDesc = Nothing
                GetDesc = Nothing
                'GetDesc2 = Nothing
                GetLen = Nothing
                GetNotes = Nothing
                GetMat = Nothing        'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                GetMat2 = Nothing
                GetMat3 = Nothing
                GetNotes = Nothing
                GetWt = Nothing
            Next z                           'Next DwgItem

            PrgName = "StartButton_Click-Part13"
            SortArrayUsingExcel(BOMList)
            BOMList = GenInfo3233.BOMList
            Me.Refresh()

            On Error GoTo Err_StartButton_Click

            UpdateShpMarksArray(BOMList)            'Array version.
            PrgName = "StartButton_Click-Part14"

            BOMList = GenInfo3233.BOMList
            'WriteToExcel(BOMList)                  '-------Uncomment to Test

            '-------No longer wanted by Fab per email from Trevor Ruffin 2-12-2024
            'FormatBulkBOM(BOMList)              'For some reason extra lines are being deleted.
            'BOMList = GenInfo3233.BOMList
            'WriteToExcel(BOMList)                  '-------Uncomment to Test
        End If

        'FindStdsInfo(BOMList)               ''-------02-09-2024      Has been moved to collecting in First Array.-------DJL-2-9-2024
        '-------                                                    Replaced.
        BOMList = GenInfo3233.BOMList
        STDsList = GenInfo3233.STDsList
        'WriteToExcel(BOMList)                  '-------Uncomment to Test
        '-------DJL-10-11-2023-------Moved to new Function Collect Standards from Data on Drawings.

        WorkShtName = "Stds BOM"
        Workbooks = ExcelApp.Workbooks
        StdsWrkSht = Workbooks.Application.Worksheets(WorkShtName)
        StdsWrkSht.Activate()

        With StdsWrkSht
            .Range("B3").Value = FullJobNo
            .Range("I3").Value = Today
            .Range("F3").Value = Me.ComboBxRev.Text
        End With

        FileToOpen = "Stds BOM"
        PrgName = "StartButton_Click-Part15"

        For i = 1 To (UBound(STDsList, 2) - 1)
            RowNo = i + 4
            ProgressBar1.Maximum = (UBound(STDsList, 2) - 1)
            StdsWrkSht.Activate()

            If RowNo = "5" Then
                FormatLine(RowNo, FileToOpen)
                'FormatLine((RowNo + 1), FileToOpen)

                With StdsWrkSht
                    .Rows(RowNo & ":" & RowNo).Select()
                    .Rows(RowNo & ":" & RowNo).Insert()         '.Rows((RowNo + 1) & ":" & (RowNo + 1)).Insert()
                End With
                LineNo = RowNo
            Else
                With StdsWrkSht
                    .Rows(RowNo & ":" & RowNo).Select()
                    .Rows(RowNo & ":" & RowNo).Insert()
                    LineNo = RowNo
                End With
            End If

            '---------------------------------------Add Data on Sheet STDs BOM
            With StdsWrkSht
                .Range("A" & RowNo).Value = STDsList(1, i)      'Dwg No
                .Range("B" & RowNo).Value = STDsList(2, i)      'Rev No
                .Range("C" & RowNo).Value = STDsList(3, i)      'Ship Mk
                .Range("E" & RowNo).Value = STDsList(4, i)      'Qty
                .Range("D" & RowNo).Value = STDsList(5, i)      'Part No
                '.Range("I" & RowNo).Value = STDsList(6, i)
                .Range("F" & RowNo).Value = STDsList(7, i)      'Desc
                '.Range("H" & RowNo).Value = STDsList(8, i)
                .Range("G" & RowNo).Value = STDsList(9, i)          'Std Part Numbert
                .Range("H" & RowNo).Value = STDsList(10, i)         'Standard number MX0104A
                .Range("U" & RowNo).Value = STDsList(10, i) 'In Order to update all standards found on BOM      'DJL-12-29-2023

                .Range("I" & RowNo).Value = STDsList(11, i)
                .Range("J" & RowNo).Value = STDsList(14, i)
                .Range("M" & RowNo).Value = STDsList(15, i)
                .Range("N" & RowNo).Value = STDsList(16, i)                      'Std Dwg
                .Range("O" & RowNo).Value = STDsList(0, i)                      'Ship Mark
                .Range("P" & RowNo).Value = STDsList(17, i)                      'Description
                .Range("X" & RowNo).Value = STDsList(18, i)
                .Range("Y" & RowNo).Value = STDsList(19, i)
                .Range("Z" & RowNo).Value = STDsList(20, i)
            End With
            ProgressBar1.Value = i
        Next i

        Dim StdsBOMList(20, 1)                          'Dim StdsBOMList(18, 1)            'Moved above
        'LineNo3 = (UBound(STDsList, 2) + 3)
        LineNo3 = StdsWrkSht.Range("A4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row

        With StdsWrkSht
            With .Range("A4:Z" & LineNo3)
                '.Sort(Key1:= .Range("N4"), Order1:=XlSortOrder.xlAscending, Key2:= .Range("O4"), Order2:=XlSortOrder.xlAscending, Header:=XlYesNoGuess.xlYes, OrderCustom:=1, MatchCase:=False, Orientation:=XlSortOrientation.xlSortColumns)
                .Sort(Key1:= .Range("H5"), Order1:=XlSortOrder.xlAscending, Key2:= .Range("G5"), Order2:=XlSortOrder.xlAscending, Header:=XlYesNoGuess.xlYes, OrderCustom:=1, MatchCase:=False, Orientation:=XlSortOrientation.xlSortColumns)
            End With
        End With

        PrgName = "StartButton_Click-Part16"

        Dim StdsFnd(1, 1)

        With StdsWrkSht
            ExistSTD = .Range("H" & 5).Value                        'ExistSTD = .Range("N" & 5).Value
            StdsFnd(0, UBound(StdsFnd, 2)) = ExistSTD
            ReDim Preserve StdsFnd(1, UBound(StdsFnd, 2) + 1)
        End With

        With StdsWrkSht
            For i = (1 + 5) To LineNo3
                If .Range("H" & i).Value = ExistSTD Then                'Std Dwg        'If .Range("N" & i).Value = ExistSTD Then
                    .Range("H" & i).Value = ""                          '.Range("N" & i).Value = ""
                Else
                    ExistSTD = .Range("H" & i).Value
                    StdsFnd(0, UBound(StdsFnd, 2)) = ExistSTD
                    ReDim Preserve StdsFnd(1, UBound(StdsFnd, 2) + 1)
                End If
            Next i
        End With

        PrgName = "StartButton_Click-Part17"
        '----------Resort to record order number descending

        With StdsWrkSht
            With .Range("A4:Z" & LineNo3)
                .Sort(Key1:= .Range("Z5"), Order1:=XlSortOrder.xlDescending, Header:=XlYesNoGuess.xlYes, OrderCustom:=1, MatchCase:=False, Orientation:=XlSortOrientation.xlSortColumns)
            End With
        End With

        Dim StdsFnd2(2, 1)

        With StdsWrkSht
            For i = (1 + 4) To LineNo3                  'For i = (1 + 5) To LineNo3
                StdsFnd2(0, UBound(StdsFnd2, 2)) = .Range("G" & i).Value
                StdsFnd2(1, UBound(StdsFnd2, 2)) = .Range("U" & i).Value                    'StdsFnd2(1, UBound(StdsFnd2, 2)) = .Range("H" & i).Value
                StdsFnd2(2, UBound(StdsFnd2, 2)) = .Range("Z" & i).Value
                ReDim Preserve StdsFnd2(2, UBound(StdsFnd2, 2) + 1)
            Next i
        End With

        GenInfo3233.StdsFnd2 = StdsFnd2


        'WriteToExcel(BOMList)                           '-------Moved below

        Me.LblProgress.Text = "Making sure all Standards are found in user Directory........Please Wait"
        Me.Refresh()
        CountVal = 0
        ProgressBar1.Maximum = LineNo3
        Dim l, CntDwgsNotFound As Integer
        Dim TestForYes, DwgsFound, DwgsFound2 As String

        'ExcelApp.Application.Visible = True                'False

        PrgName = "StartButton_Click-Part18"

        For l = 1 To (UBound(StdsFnd, 2) - 1)                            'For l = 1 To LineNo3
            'With StdsWrkSht
            LookForStd = StdsFnd(0, l)            '.Range("H" & (l + 4)).Value            'LookForStd = .Range("N" & (l + 4)).Value

            If LookForStd = "" Or LookForStd = Nothing Then
                GoTo Nextl
            End If

            AdeptPrg = "\\Adept01\Tulsa\STD\PROGRAM\"
            AdeptStd = "\\Adept01\Tulsa\STD\TANKSTANDARDS\"
            Dwg = ".dwg"

            If Dir(PathBox.Text & FullJobNo & "_" & LookForStd & Dwg) <> "" Then        'If Dir(PathBox.Text & "\" & FullJobNo & "_" & LookForStd & Dwg) <> "" Then 
                DwgItem = PathBox.Text & FullJobNo & "_" & LookForStd & Dwg             'DwgItem = PathBox.Text & "\" & FullJobNo & "_" & LookForStd & Dwg
            Else
                If Dir(PathBox.Text & FullJobNo & "._" & LookForStd & Dwg) <> "" Then        'If Dir(PathBox.Text & "\" & FullJobNo & "_" & LookForStd & Dwg) <> "" Then 
                    DwgItem = PathBox.Text & FullJobNo & "._" & LookForStd & Dwg             'DwgItem = PathBox.Text & "\" & FullJobNo & "_" & LookForStd & Dwg
                Else
                    If Dir(PathBox.Text & FullJobNo & "-" & LookForStd & Dwg) <> "" Then        'If Dir(PathBox.Text & "\" & FullJobNo & "_" & LookForStd & Dwg) <> "" Then 
                        DwgItem = PathBox.Text & FullJobNo & "-" & LookForStd & Dwg             'DwgItem = PathBox.Text & "\" & FullJobNo & "_" & LookForStd & Dwg
                    Else
                        If Dir(PathBox.Text & FullJobNo & ".-" & LookForStd & Dwg) <> "" Then        'If Dir(PathBox.Text & "\" & FullJobNo & "_" & LookForStd & Dwg) <> "" Then 
                            DwgItem = PathBox.Text & FullJobNo & ".-" & LookForStd & Dwg             'DwgItem = PathBox.Text & "\" & FullJobNo & "_" & LookForStd & Dwg
                        Else
                            'If Dir(AdeptPrg & FullJobNo & "_" & LookForStd & Dwg) <> "" Then
                            '    DwgItem = AdeptPrg & FullJobNo & "_" & LookForStd & Dwg
                            'Else
                            '    If Dir(AdeptStd & FullJobNo & "_" & LookForStd & Dwg) <> "" Then
                            '        DwgItem = AdeptStd & FullJobNo & "_" & LookForStd & Dwg
                            '    Else
                            Me.DwgsNotFoundList.Items.Add(FullJobNo & "._" & LookForStd & Dwg)
                            'End If
                            'End If
                        End If
                    End If
                End If
            End If
            'End With
Nextl:
        Next l

        PrgName = "StartButton_Click-Part19"
        CntDwgsNotFound = Me.DwgsNotFoundList.Items.Count

        If CntDwgsNotFound > 0 Then                                 '-----------------------Notify user of Standards missing.
            DwgsFound2 = Nothing

            For l = 0 To (CntDwgsNotFound - 1)
                If CntDwgsNotFound > 0 Then
                    DwgsFound = Me.DwgsNotFoundList.Items(l)
                End If

                If l = 0 Then
                    DwgsFound2 = DwgsFound
                Else
                    DwgsFound2 = DwgsFound2 & ", " & Chr(10) & DwgsFound
                End If
            Next

            MissingTxt1 = "The following Standards are Missing" & Chr(10) & DwgsFound2 & Chr(10) & "Do you want to Continue?    Type   Yes or No" & Chr(10)
            'MissingTxt2 = Chr(10) & "If you copy the standards to this directory," & Chr(10) & File1.Path & Chr(10) & " Then type Yes in the Box below the program will contine without having to be restarted."

            MissingTxt2 = Chr(10) & "If you copy the standards to this directory," & Chr(10) & PathBox.Text & Chr(10) & " Then type Yes in the Box below the program will contine without having to be restarted."

            Sapi.Speak("Some Standard Drawings are missing, If you copy the files to your working Directory, then type Yes in the box below the program will continue without having to be restarted.")
            TestForYes = InputBox(MissingTxt1 & MissingTxt2)            ' & MissingTxt3)

            Select Case TestForYes
                Case "Yes"
                    GoTo Continue_Dwgs
                Case "YES"
                    TestForYes = "Yes"
                    GoTo Continue_Dwgs
                Case "Y"
                    TestForYes = "Yes"
                    GoTo Continue_Dwgs
                Case "y"
                    TestForYes = "Yes"
                    GoTo Continue_Dwgs
                Case "No"
                    Sapi.Speak("After you have put your Standard Drawings in your working directory, you will need to rerun the program.")
                    MsgBox("After you have put your Standard Drawings in your working directory, you will need to rerun the program.")
                    GoTo Cancel
                Case "NO"
                    Sapi.Speak("After you have put your Standard Drawings in your working directory, you will need to rerun the program.")
                    MsgBox("After you have put your Standard Drawings in your working directory, you will need to rerun the program.")
                    GoTo Cancel
                Case "N"
                    Sapi.Speak("After you have put your Standard Drawings in your working directory, you will need to rerun the program.")
                    MsgBox("After you have put your Standard Drawings in your working directory, you will need to rerun the program.")
                    GoTo Cancel
                Case "n"
                    Sapi.Speak("After you have put your Standard Drawings in your working directory, you will need to rerun the program.")
                    MsgBox("After you have put your Standard Drawings in your working directory, you will need to rerun the program.")
                    GoTo Cancel
                Case Else
                    Sapi.Speak("You must enter Yes or No, you will need to rerun the program.")
                    MsgBox("You must enter Yes or No, you will need to rerun the program.")
                    GoTo Cancel
            End Select
        End If

Continue_Dwgs:  '------------------------------Get Standard drawing information for BOM Items.
        PrgName = "StartButton_Click-Part20"
        Me.LblProgress.Text = "Opening Matrix Standard Drawings........Please Wait"
        Me.Refresh()

        CountVal = 0
        ProgressBar1.Maximum = LineNo3
        CntDwgs = (UBound(StdsFnd, 2) - 1)

        For j = 1 To (UBound(StdsFnd, 2) - 1)               'For j = 1 To LineNo3
            'With StdsWrkSht
            LookForStd = StdsFnd(0, j)       'LookForStd = .Range("H" & (j + 4)).Value       'LookForStd = .Range("N" & (j + 4)).Value 

            If LookForStd = "" Then
                GoTo NextDwg2
            End If

            AdeptPrg = "\\Adept01\Tulsa\STD\PROGRAM\"
            AdeptStd = "\\Adept01\Tulsa\STD\TANKSTANDARDS\"
            Dwg = ".dwg"

            PrgName = "StartButton_Click-Part21"

            If Dir(PathBox.Text & FullJobNo & "_" & LookForStd & Dwg) <> "" Then            'If Dir(PathBox.Text & "\" & FullJobNo & "_" & LookForStd & Dwg) <> "" Then
                DwgItem = PathBox.Text & FullJobNo & "_" & LookForStd & Dwg                 'DwgItem = PathBox.Text & FullJobNo & "_" & LookForStd & Dwg
            Else
                If Dir(PathBox.Text & FullJobNo & "._" & LookForStd & Dwg) <> "" Then            'If Dir(PathBox.Text & "\" & FullJobNo & "_" & LookForStd & Dwg) <> "" Then
                    DwgItem = PathBox.Text & FullJobNo & "._" & LookForStd & Dwg                 'DwgItem = PathBox.Text & FullJobNo & "_" & LookForStd & Dwg
                Else
                    If Dir(PathBox.Text & FullJobNo & "-" & LookForStd & Dwg) <> "" Then            'If Dir(PathBox.Text & "\" & FullJobNo & "_" & LookForStd & Dwg) <> "" Then
                        DwgItem = PathBox.Text & FullJobNo & "-" & LookForStd & Dwg                 'DwgItem = PathBox.Text & FullJobNo & "_" & LookForStd & Dwg
                    Else
                        If Dir(PathBox.Text & FullJobNo & ".-" & LookForStd & Dwg) <> "" Then            'If Dir(PathBox.Text & "\" & FullJobNo & "_" & LookForStd & Dwg) <> "" Then
                            DwgItem = PathBox.Text & FullJobNo & ".-" & LookForStd & Dwg                 'DwgItem = PathBox.Text & FullJobNo & "_" & LookForStd & Dwg
                        Else
                            'If Dir(AdeptPrg & FullJobNo & "_" & LookForStd & Dwg) <> "" Then
                            '    DwgItem = AdeptPrg & FullJobNo & "_" & LookForStd & Dwg
                            'Else
                            '    If Dir(AdeptStd & FullJobNo & "_" & LookForStd & Dwg) <> "" Then
                            '        DwgItem = AdeptStd & FullJobNo & "_" & LookForStd & Dwg
                            '    Else
                            GoTo NextDwg2
                            'End If
                            'End If
                            'End If
                        End If
                    End If
                End If
            End If

            'End With

            AcadApp.Documents.Open(DwgItem)
            System.Threading.Thread.Sleep(50)
            AcadApp.Visible = False
            Me.Refresh()
            AcadDoc = AcadApp.ActiveDocument

            BlockSel = AcadDoc.SelectionSets.Add("Titleblock")
            GroupCode(0) = 0
            BlockData(0) = "INSERT"
            GroupCode(1) = 2
            BlockData(1) = "AMW_TITLE,OSF_TITLE,OSF_TITLE_D,MX_TITLE,LNG_TITLE_D,MX_TITLE_SP,Title Blocks Matrix"
            BlockSel.Select(AutoCAD.AcSelect.acSelectionSetAll, , , GroupCode, BlockData)

            Temparray = BlockSel.Item(0).GetAttributes
            CntAttFound = 0

            For i = 0 To UBound(Temparray)
                Select Case Temparray(i).TagString
                    Case "DN"
                        CurrentDwgNo = Temparray(i).TextString
                        CntAttFound = (CntAttFound + 1)
                        'Case "JN"
                        '    FullJobNo = Temparray(i).TextString
                    Case "RN"
                        CurrentDwgRev = Temparray(i).TextString
                        CntAttFound = (CntAttFound + 1)
                    Case "SN"
                        CurrentStdNo = Temparray(i).TextString
                        CntAttFound = (CntAttFound + 1)
                End Select

                If CntAttFound > 2 Then
                    GoTo FoundAtts                      'Why look for all when only three are needed.-------DJL-12-29-2023
                End If
            Next i

FoundAtts:
            If IsNothing(CurrentDwgNo) = True Or CurrentDwgNo = "" Then
                Sapi.Speak("You have a Drawing with no drawing number, Please check your drawings for missing drawing Numbers.")
                MsgBox("You have a Drawing with no drawing number, Please check your drawings for missing drawing Numbers.")

                Sapi.Speak("This standard " & CurrentStdNo & " needs to have a drawing number fixed before this information will be put on BOM List.")
                MsgBox("This standard " & CurrentStdNo & " needs to have the drawing number fixed before this information will be put on the BOM List.")

                Sapi.Speak("Bulk Bom List will show Standard Not Found for" & CurrentStdNo & ".")
                MsgBox("Bulk Bom List will show Standard Not Found for" & CurrentStdNo & ".")
                GoTo NextDwg2
            End If

            PrgName = "StartButton_Click-Part22"
            BlockSel = AcadDoc.SelectionSets.Add("BillOfMaterial")
            GroupCode(0) = 0
            BlockData(0) = "INSERT"
            GroupCode(1) = 2
            BlockData(1) = "STANDARD_BILL_OF_MATERIAL,B_BILL_OF_MATERIAL,SP_BILL_OF_MATERIAL"
            BlockSel.Select(AutoCAD.AcSelect.acSelectionSetAll, , , GroupCode, BlockData)

            Me.TxtBoxDwgsToProcess.Text = CntDwgs - j
            CntCollected = 0

            If BlockSel.Count <> 0 Then
                For Each BomItem In BlockSel
                    CntCollected = (CntCollected + 1)
                    Me.TxtBoxBOMItemsToProcess.Text = BlockSel.Count - CntCollected
                    Me.Refresh()

                    BOMItemNam = BomItem.Name
                    TempAttributes = BomItem.GetAttributes

                    '-------Get Items from Standards sheet were Tag D2 equal to Description
                    'NTest1 = TempAttributes(0).TextString                 'Mark1
                    'NTest2 = TempAttributes(1).TextString                 'Qty1
                    'NTest3 = TempAttributes(2).TextString                 'Mark2
                    'Ntest4 = TempAttributes(3).TextString                 'Qty2
                    NTest5 = TempAttributes(4).TextString                 'Description1
                    Ntest6 = TempAttributes(5).TextString                 'Description2 -Centered
                    'NTest7 = TempAttributes(6).TextString                 'Inv-1
                    'NTest8 = TempAttributes(7).TextString                 'Inv -2
                    'NTest9 = TempAttributes(8).TextString                 'Material1
                    'NTest10 = TempAttributes(9).TextString                 'Material2A
                    'NTest11 = TempAttributes(10).TextString                'Material2B
                    'NTest12 = TempAttributes(11).TextString                'Weight
                    ''Test = TempAttributes(12).TextString               'Only 11 Items exist for BOM Items.
                    ''Test = TempAttributes(13).TextString
                    ''Test = TempAttributes(14).TextString

                    If NTest5 = Nothing Or NTest5 = "" Then                 'New problem remove blank lines....
                        If Ntest6 = Nothing Or Ntest6 = "" Then
                            GoTo NextBOMItem2
                        End If
                    End If

                    'StdsBOMList(1, UBound(StdsBOMList, 2)) = CurrentDwgNo
                    'StdsBOMList(2, UBound(StdsBOMList, 2)) = CurrentDwgRev

                    'Select Case BOMItemNam                          'BomItem.Name
                    '    Case "SUBTITLE"
                    '        SortListing = False
                    '        StdsBOMList(3, UBound(StdsBOMList, 2)) = TempAttributes(0).TextString
                    '        StdsBOMList(4, UBound(StdsBOMList, 2)) = TempAttributes(1).TextString
                    '        StdsBOMList(11, UBound(StdsBOMList, 2)) = TempAttributes(4).TextString
                    '        StdsBOMList(7, UBound(StdsBOMList, 2)) = TempAttributes(5).TextString
                    '        StdsBOMList(10, UBound(StdsBOMList, 2)) = TempAttributes(7).TextString
                    '        StdsBOMList(14, UBound(StdsBOMList, 2)) = TempAttributes(8).TextString
                    '    Case "A_BILL_OF_MATERIAL" 'works on A_BILL_OF_MATERIAL
                    '        For i = 3 To (UBound(TempAttributes) + 4)
                    '            Select Case i
                    '                Case 3 To 8
                    '                    StdsBOMList(i, UBound(StdsBOMList, 2)) = TempAttributes(i - 3).TextString
                    '                Case 9
                    '                    If UBound(TempAttributes) = 10 Then
                    '                        StdsBOMList(9, UBound(StdsBOMList, 2)) = TempAttributes(6).TextString
                    '                        i = 10
                    '                    End If
                    '                Case 10 To 14
                    '                    If UBound(TempAttributes) = 10 Then
                    '                        StdsBOMList(i, UBound(StdsBOMList, 2)) = TempAttributes(i - 4).TextString
                    '                    Else
                    '                        StdsBOMList(i, UBound(StdsBOMList, 2)) = TempAttributes(i - 5).TextString
                    '                    End If
                    '            End Select
                    '        Next i
                    '    Case Else                                                           'works on B_BILL_OF_MATERIAL, STANDARD_BILL_OF_MATERIAL and SP_BILL_OF_MATERIAL
                    '-------Standard drawings messed up 2212-1010-------HVECIssue

                    '                            If GenInfo3233.HVECIssue = 6 Then
                    '                                For x = 0 To UBound(TempAttributes)                         'Not Required Found Job Information Previuosly 'Need info for Standards Dwg Number.
                    '                                    TestTags = TempAttributes(x).TagString

                    '                                    Select Case TempAttributes(x).TagString
                    '                                        Case "SP"
                    '                                            GetPartNo = TempAttributes(x).TextString
                    '                                        Case "MK"
                    '                                            Get2DShipMk = TempAttributes(x).TextString
                    '                                        Case "Q"
                    '                                            GetQty = TempAttributes(x).TextString
                    '                                        Case "SD"
                    '                                            GetShipDesc = TempAttributes(x).TextString
                    '                                        Case "D"
                    '                                            GetDesc = TempAttributes(x).TextString
                    '                                        Case "D2"
                    '                                            GetShipDesc = TempAttributes(x).TextString
                    '                                        Case "L"
                    '                                            GetLen = TempAttributes(x).TextString
                    '                                        Case "M"
                    '                                            GetMat = TempAttributes(x).TextString
                    '                                        Case "M2"
                    '                                            GetMat2 = TempAttributes(x).TextString
                    '                                        Case "M3"
                    '                                            GetMat3 = TempAttributes(x).TextString
                    '                                        Case "N"
                    '                                            GetNotes = TempAttributes(x).TextString
                    '                                        Case "W"
                    '                                            GetWt = TempAttributes(x).TextString
                    '                                    End Select
                    '                                Next x

                    '                                '-------New problem Pittsburgh used our Tags but put them in a different order.----Shiela Ganote 2212-1010
                    '                                If GetPartNo = Nothing Then
                    '                                    For x = 0 To UBound(TempAttributes)                         'Not Required Found Job Information Previuosly 'Need info for Standards Dwg Number.
                    '                                        TestTags = TempAttributes(x).TagString

                    '                                        Select Case TempAttributes(x).TagString
                    '                                            Case "SLM"                                          '-------MK"
                    '                                                Get2DShipMk = TempAttributes(x).TextString
                    '                                            Case "SLQ"                                          '-------MK"
                    '                                                Get2DShipQty = TempAttributes(x).TextString
                    '                                            Case "SM"                                           '-------SP"
                    '                                                GetPartNo = TempAttributes(x).TextString
                    '                                            Case "Q"
                    '                                                GetQty = TempAttributes(x).TextString
                    '                                            Case "SD"
                    '                                                GetShipDesc = TempAttributes(x).TextString
                    '                                            Case "D"
                    '                                                GetDesc = TempAttributes(x).TextString
                    '                                            Case "D2"
                    '                                                GetShipDesc = TempAttributes(x).TextString
                    '                                            Case "IU"
                    '                                                GetInv1 = TempAttributes(x).TextString
                    '                                            Case "IL"
                    '                                                GetInv2 = TempAttributes(x).TextString
                    '                                            Case "L"
                    '                                                GetLen = TempAttributes(x).TextString
                    '                                            Case "M"
                    '                                                GetMat = TempAttributes(x).TextString

                    '                                                If InStr(GetMat, "NOTE") > 0 Then
                    '                                                    NotePos = InStr(GetMat, "NOTE")
                    '                                                    GetNotes = Mid(GetMat, NotePos, Len(GetMat))
                    '                                                    GetMat = Mid(GetMat, 1, (NotePos - 1))
                    '                                                End If
                    '                                            Case "M2"
                    '                                                GetMat2 = TempAttributes(x).TextString
                    '                                            Case "M3"
                    '                                                GetMat3 = TempAttributes(x).TextString
                    '                                            Case "N"
                    '                                                GetNotes = TempAttributes(x).TextString
                    '                                            Case "W"
                    '                                                GetWt = TempAttributes(x).TextString
                    '                                        End Select
                    '                                    Next x
                    '                                End If

                    '                                If GetQty = Nothing And Get2DShipQty <> Nothing Then
                    '                                    GetQty = Get2DShipQty
                    '                                End If

                    '                                If GetDesc = Nothing And GetShipDesc <> Nothing Then
                    '                                    GetDesc = GetShipDesc
                    '                                End If

                    '                                StdsBOMList(1, UBound(StdsBOMList, 2)) = CurrentDwgNo                               '-------Dwg number
                    '                                StdsBOMList(2, UBound(StdsBOMList, 2)) = CurrentDwgRev                              '-------Rev Number
                    '                                StdsBOMList(5, UBound(StdsBOMList, 2)) = GetPartNo
                    '                                StdsBOMList(3, UBound(StdsBOMList, 2)) = Get2DShipMk
                    '                                StdsBOMList(4, UBound(StdsBOMList, 2)) = GetQty
                    '                                StdsBOMList(6, UBound(StdsBOMList, 2)) = GetShipDesc
                    '                                StdsBOMList(7, UBound(StdsBOMList, 2)) = GetDesc
                    '                                StdsBOMList(9, UBound(StdsBOMList, 2)) = GetInv1
                    '                                StdsBOMList(10, UBound(StdsBOMList, 2)) = GetInv2

                    '                                If IsNothing(GetMat) = False And GetMat <> "" Then
                    'UpdateMat3:
                    '                                    StdsBOMList(11, UBound(StdsBOMList, 2)) = GetMat
                    '                                Else
                    '                                    If (GetMat2) <> "" And GetMat3 <> "" Then
                    '                                        StdsBOMList(11, UBound(StdsBOMList, 2)) = (GetMat2 & "~" & GetMat3)
                    '                                    Else
                    '                                        GoTo UpdateMat3
                    '                                    End If
                    '                                End If

                    '                                StdsBOMList(13, UBound(StdsBOMList, 2)) = GetLen
                    '                                StdsBOMList(14, UBound(StdsBOMList, 2)) = GetWt
                    '                                GoTo BOMInfoCollected2
                    '                            End If

                    '-------Redo this mess above and below and fix it so all Attibrutes are found.

                    'For i = 3 To 14
                    '    Select Case i
                    '        Case 3 To 8
                    '            StdsBOMList(i, UBound(StdsBOMList, 2)) = TempAttributes(i - 3).TextString
                    '        Case 9, 10
                    '            If BomItem.Name = "STANDARD_BILL_OF_MATERIAL" Or BomItem.Name = "SP_BILL_OF_MATERIAL" Then
                    '                StdsBOMList(i, UBound(StdsBOMList, 2)) = TempAttributes(i - 3).TextString
                    '            Else
                    '                StdsBOMList(i, UBound(StdsBOMList, 2)) = vbNullString
                    '            End If
                    '        Case 11 To 14
                    '            If BomItem.Name = "STANDARD_BILL_OF_MATERIAL" Or BomItem.Name = "SP_BILL_OF_MATERIAL" Then
                    '                StdsBOMList(i, UBound(StdsBOMList, 2)) = TempAttributes(i - 3).TextString
                    '            Else
                    '                StdsBOMList(i, UBound(StdsBOMList, 2)) = TempAttributes(i - 4).TextString
                    '            End If
                    '    End Select
                    'Next i

                    'For x = 0 To UBound(TempAttributes)                         'Not Required Found Job Information Previuosly 'Need info for Standards Dwg Number.
                    '    TestTags = TempAttributes(x).TagString

                    '    Select Case TempAttributes(x).TagString
                    '        Case "SP"
                    '            GetPartNo = TempAttributes(x).TextString
                    '        Case "MK"
                    '            Get2DShipMk = TempAttributes(x).TextString
                    '        Case "Q"
                    '            GetQty = TempAttributes(x).TextString
                    '        Case "SD"
                    '            GetShipDesc = TempAttributes(x).TextString
                    '        Case "D"
                    '            GetDesc = TempAttributes(x).TextString
                    '        Case "D2"
                    '            GetShipDesc = TempAttributes(x).TextString
                    '        Case "L"
                    '            GetLen = TempAttributes(x).TextString
                    '        Case "M"
                    '            GetMat = TempAttributes(x).TextString
                    '        Case "M2"
                    '            GetMat2 = TempAttributes(x).TextString
                    '        Case "M3"
                    '            GetMat3 = TempAttributes(x).TextString
                    '        Case "N"
                    '            GetNotes = TempAttributes(x).TextString
                    '        Case "W"
                    '            GetWt = TempAttributes(x).TextString
                    '    End Select
                    'Next x

                    PrgName = "StartButton_Click-Part23"

                    For x = 0 To UBound(TempAttributes)                         'Not Required Found Job Information Previuosly 'Need info for Standards Dwg Number.
                        TestTags = TempAttributes(x).TagString

                        Select Case TempAttributes(x).TagString
                            Case "SLM"                                          '-------MK"
                                Get2DShipMk = TempAttributes(x).TextString
                            Case "SLQ"                                          '-------MK"
                                Get2DShipQty = TempAttributes(x).TextString
                            Case "SM"                                           '-------SP"
                                GetPartNo = TempAttributes(x).TextString
                            Case "Q"
                                GetQty = TempAttributes(x).TextString
                            Case "SD"
                                GetShipDesc = TempAttributes(x).TextString
                            Case "D"
                                GetDesc = TempAttributes(x).TextString
                            Case "D2"
                                GetShipDesc = TempAttributes(x).TextString
                            Case "IU"
                                GetInv1 = TempAttributes(x).TextString
                            Case "IL"
                                GetInv2 = TempAttributes(x).TextString
                            Case "L"
                                GetLen = TempAttributes(x).TextString
                            Case "M"        'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                                GetMat = TempAttributes(x).TextString

                                If InStr(GetMat, "NOTE") > 0 Then
                                    NotePos = InStr(GetMat, "NOTE")
                                    GetNotes = Mid(GetMat, NotePos, Len(GetMat))
                                    GetMat = Mid(GetMat, 1, (NotePos - 1))
                                End If
                            Case "M2"       'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                                GetMat2 = TempAttributes(x).TextString
                            Case "M3"       'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                                GetMat3 = TempAttributes(x).TextString
                            Case "N"
                                GetNotes = TempAttributes(x).TextString
                            Case "W"
                                GetWt = TempAttributes(x).TextString
                        End Select
                    Next x

                    'End Select

                    PrgName = "StartButton_Click-Part24"

                    StdsBOMList(1, UBound(StdsBOMList, 2)) = CurrentDwgNo
                    StdsBOMList(2, UBound(StdsBOMList, 2)) = CurrentDwgRev
                    StdsBOMList(3, UBound(StdsBOMList, 2)) = Get2DShipMk
                    StdsBOMList(4, UBound(StdsBOMList, 2)) = GetQty
                    StdsBOMList(5, UBound(StdsBOMList, 2)) = GetPartNo
                    StdsBOMList(6, UBound(StdsBOMList, 2)) = GetShipDesc            'Assembly Description
                    StdsBOMList(7, UBound(StdsBOMList, 2)) = GetDesc                'Part Description
                    StdsBOMList(9, UBound(StdsBOMList, 2)) = GetInv1
                    StdsBOMList(10, UBound(StdsBOMList, 2)) = GetInv2

                    'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                    If IsNothing(GetMat) = False And GetMat <> "" Then
UpdateMat3:
                        StdsBOMList(11, UBound(StdsBOMList, 2)) = GetMat
                    Else
                        If GetMat2 <> "" And GetMat3 <> "" Then
                            StdsBOMList(11, UBound(StdsBOMList, 2)) = (GetMat2 & " " & GetMat3)         'Requested by Trevor Ruffin  'StdsBOMList(11, UBound(StdsBOMList, 2)) = (GetMat2 & "-" & GetMat3)   'StdsBOMList(11, UBound(StdsBOMList, 2)) = (GetMat2 & "~" & GetMat3)
                        Else
                            If GetMat2 <> "" And GetMat3 = "" Then
                                StdsBOMList(11, UBound(StdsBOMList, 2)) = GetMat2
                            Else
                                If GetMat2 = "" And GetMat3 <> "" Then
                                    StdsBOMList(11, UBound(StdsBOMList, 2)) = GetMat3
                                Else
                                    GoTo UpdateMat3
                                End If
                            End If
                        End If
                    End If

                    StdsBOMList(13, UBound(StdsBOMList, 2)) = GetLen
                    StdsBOMList(14, UBound(StdsBOMList, 2)) = GetWt

BOMInfoCollected2:
                    PrgName = "StartButton_Click-Part25"
                    InsertionPT = BomItem.InsertionPoint
                    Dimscale = BomItem.XScaleFactor
                    CompareX1 = 10.5 * Dimscale
                    CompareX1 = InsertionPT(0) - CompareX1
                    CompareX1 = CompareX1 / Dimscale

                    CompareX2 = 6 * Dimscale
                    CompareX2 = InsertionPT(0) - CompareX2
                    CompareX2 = CompareX2 / Dimscale

                    If CompareX1 < 1 Or CompareX2 < 1 Then
                        If CompareX1 > 0 Or CompareX2 > 0 Then
                            StdsBOMList(16, UBound(StdsBOMList, 2)) = CStr(1)
                        Else
                            StdsBOMList(16, UBound(StdsBOMList, 2)) = CStr(2)
                        End If
                    Else
                        StdsBOMList(16, UBound(StdsBOMList, 2)) = CStr(2)
                    End If

                    StdsBOMList(17, UBound(StdsBOMList, 2)) = InsertionPT(1)
                    StdsBOMList(18, UBound(StdsBOMList, 2)) = InsertionPT(0)
                    StdsBOMList(15, UBound(StdsBOMList, 2)) = CurrentDwgNo
                    ReDim Preserve StdsBOMList(20, UBound(StdsBOMList, 2) + 1)
NextBOMItem2:
                Next BomItem
            End If

            CountVal = (CountVal + 1)
            ProgressBar1.Value = j
            ProblemAt = "CloseDwg"
            AcadDoc.Close()
            ProblemAt = ""
NextDwg2:
        Next j                                    'Next DwgItem

        'GenInfo3233.StdsBOMList = StdsBOMList          'Not here need them sorted.

        'AcadApp.Documents.Add()
        If Not IsNothing(gvntSDIvar) Then
            AcadPref.SingleDocumentMode = gvntSDIvar    'reset to sdi mode
        End If

        PrgName = "StartButton_Click-Part26"
        Me.LblProgress.Text = "Placing MX Standards List on BOM........Please Wait"
        Me.Refresh()

        '---------------------------------------------Create new sheet for Standards found.
        WorkShtName = "STD Items"
        StdItemsWrkSht = Workbooks.Application.Worksheets(WorkShtName)
        StdItemsWrkSht.Activate()

        With StdItemsWrkSht
            .Range("B3").Value = FullJobNo
            .Range("I3").Value = Today
            .Range("F3").Value = Me.ComboBxRev.Text
        End With

        For i = 1 To (UBound(StdsBOMList, 2) - 1)
            PrgName = "StartButton_Click-Part27"
            RowNo = i + 4
            ProgressBar1.Maximum = (UBound(StdsBOMList, 2) - 1)
            FileToOpen = "STD Items"
            StdItemsWrkSht.Activate()

            If RowNo = "5" Then
                FormatLine(RowNo, FileToOpen)
                'FormatLine((RowNo + 1), FileToOpen)\

                With StdItemsWrkSht
                    .Rows(RowNo & ":" & RowNo).Select()
                    .Rows(RowNo & ":" & RowNo).Insert()     '.Rows((RowNo + 1) & ":" & (RowNo + 1)).Insert()
                    LineNo = RowNo
                End With

                LineNo = RowNo
            Else
                With StdItemsWrkSht
                    .Rows(RowNo & ":" & RowNo).Select()
                    .Rows(RowNo & ":" & RowNo).Insert()
                    LineNo = RowNo
                End With
            End If

            With StdItemsWrkSht
                .Range("A" & RowNo).Value = StdsBOMList(1, i)
                .Range("B" & RowNo).Value = StdsBOMList(2, i)
                .Range("C" & RowNo).Value = StdsBOMList(3, i)
                .Range("D" & RowNo).Value = StdsBOMList(5, i)

                'If StdsBOMList(4, i) = "" Or StdsBOMList(4, i) = " " Then
                '    .Range("E" & RowNo).Value = StdsBOMList(6, i)
                'Else

                .Range("E" & RowNo).Value = StdsBOMList(4, i)

                'End If

                '-------8 does not exist at this time, or is not used.

                If StdsBOMList(6, i) = vbNullString Or StdsBOMList(6, i) = " " Then             'If StdsBOMList(8, i) = vbNullString Or StdsBOMList(8, i) = " " Then
                    If InStr(1, StdsBOMList(7, i), "%%D") <> 0 Then
                        'StdsBOMList(7, i) = Misc31_090.InputType2.sReplace(StdsBOMList(7, i), "%%D", " DEG.")      'Repla  ced below
                        GetDesc = StdsBOMList(7, i)
                        GetDesc = GetDesc.Replace("%%D", " DEG.")
                        StdsBOMList(7, i) = GetDesc
                    End If
                    .Range("F" & RowNo).Value = StdsBOMList(7, i)
                Else
                    If InStr(1, StdsBOMList(6, i), "%%D") <> 0 Then                             'If InStr(1, StdsBOMList(8, i), "%%D") <> 0 Then
                        'StdsBOMList(8, i) = Misc31_090.InputType2.sReplace(StdsBOMList(8, i), "%%D", " DEG.")
                        GetDesc = StdsBOMList(6, i)                                             'GetDesc = StdsBOMList(8, i)
                        GetDesc = GetDesc.Replace("%%D", " DEG.")                               'GetDesc = GetDesc.Replace("%%D", " DEG.")
                        StdsBOMList(6, i) = GetDesc                                             'StdsBOMList(8, i) = GetDesc
                    End If
                    .Range("F" & RowNo).Value = StdsBOMList(6, i)                               '.Range("F" & RowNo).Value = StdsBOMList(8, i)
                End If

                '-------8 does not exist at this time, or is not used.

                .Range("G" & RowNo).Value = StdsBOMList(9, i)
                .Range("H" & RowNo).Value = StdsBOMList(10, i)

                'If StdsBOMList(11, i) = vbNullString Or Mid(StdsBOMList(11, i), 1, 1) = " " Then
                '    With StdItemsWrkSht
                '        With .Range("I" & RowNo)
                '            .HorizontalAlignment = XlHAlign.xlHAlignCenter
                '            .VerticalAlignment = XlVAlign.xlVAlignCenter
                '            .Font.Name = "Arial"
                '            .Font.Size = 7
                '            .Value = StdsBOMList(12, i) & Chr(10) & StdsBOMList(13, i)
                '        End With
                '    End With
                'Else
                .Range("I" & RowNo).Value = StdsBOMList(11, i)          '11 will always be material even when two types of material.
                'End If

                .Range("J" & RowNo).Value = StdsBOMList(14, i)          'Weight
                .Range("M" & RowNo).NumberFormat = "@"
                .Range("M" & RowNo).Value = StdsBOMList(15, i)          'Standard No
                .Range("N" & RowNo).NumberFormat = "General"
                .Range("N" & RowNo).Value = StdsBOMList(16, i)          'one or two
                .Range("O" & RowNo).NumberFormat = "General"
                .Range("O" & RowNo).Value = StdsBOMList(17, i)          'Y point for insertion
                .Range("P" & RowNo).NumberFormat = "General"
                .Range("P" & RowNo).Value = StdsBOMList(18, i)          'X point for insertion
            End With
            ProgressBar1.Value = i
        Next i

        PrgName = "StartButton_Click-Part28"

        With StdItemsWrkSht
            With .Range("A4:P" & RowNo)
                .Sort(Key1:= .Range("M4"), Order1:=XlSortOrder.xlAscending, Key2:= .Range("N4"), Order2:=XlSortOrder.xlAscending, Key3:= .Range("O4"), Order3:=XlSortOrder.xlDescending, Header:=XlYesNoGuess.xlYes, OrderCustom:=1, MatchCase:=False, Orientation:=XlSortOrientation.xlSortColumns)
            End With
        End With

        LineNo2 = StdItemsWrkSht.Range("A4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row
        RowNo = 5
        ReDim StdsBOMList(20, 1)

        For i = 1 To (LineNo2 - 4)
            With StdItemsWrkSht
                StdsBOMList(1, i) = .Range("A" & RowNo).Value           'MX-Std
                StdsBOMList(2, i) = .Range("B" & RowNo).Value           'Rev
                StdsBOMList(3, i) = .Range("C" & RowNo).Value           'Ship Mark
                StdsBOMList(5, i) = .Range("D" & RowNo).Value           'Piece Mark
                StdsBOMList(4, i) = .Range("E" & RowNo).Value           'Qty

                '-------6 does not exist at this time, or is not used.

                StdsBOMList(7, i) = .Range("F" & RowNo).Value           'Description

                '-------8 does not exist at this time, or is not used.

                StdsBOMList(9, i) = .Range("G" & RowNo).Value           'Std Part No = 2RR
                StdsBOMList(10, i) = .Range("H" & RowNo).Value          'MX0104A
                StdsBOMList(11, i) = .Range("I" & RowNo).Value         'material.
                StdsBOMList(14, i) = .Range("J" & RowNo).Value          'Weight
                StdsBOMList(15, i) = .Range("M" & RowNo).Value          'MX Std read MX0104A
                StdsBOMList(16, i) = .Range("N" & RowNo).Value          'one or two column one or two for BOM columns on drawings
                StdsBOMList(17, i) = .Range("O" & RowNo).Value         'Y point for insertion
                StdsBOMList(18, i) = .Range("P" & RowNo).Value          'X point for insertion
                ReDim Preserve StdsBOMList(20, UBound(StdsBOMList, 2) + 1)
                RowNo = (RowNo + 1)
            End With
            ProgressBar1.Value = i
        Next i

        PrgName = "StartButton_Click-Part29"
        GenInfo3233.StdsBOMList = StdsBOMList

        '-------------------------Copy Standards BOM to Bulk BOM
        '-------------------------Created new Function "FindStdsBOM"
        '-------------------------Before starting on FindStdsBOM re-sort so that items will be found in order.

        'Not needed
        'LineNo3 = (UBound(STDsList, 2) - 1)                         'LineNo3 = (UBound(STDsList, 2) + 3)
        'StdsWrkSht.Activate()

        WorkShtName = "Bulk BOM"
        BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
        WorkSht = Workbooks.Application.ActiveSheet
        WorkShtName = WorkSht.Name
        BOMWrkSht.Activate()

        LineNo2 = BOMWrkSht.Range("B4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row

        With BOMWrkSht                          'Start Clean New sheet-------DJL-12-29-2023
            'For z = 5 To LineNo2
            z = 5
            .Range("A" & z & ":AC" & (LineNo2 + 18)).Delete()
            'Next z
        End With

        PrgName = "StartButton_Click-Part30"
        WriteToExcelAfterSort(BOMList)           'Write new data to Spreadsheet
        '''CntRecToUpdate = (UBound(STDsList, 2) - 1)           'Done above in WriteToExcelAfterSort

        '''For z = 0 To CntRecToUpdate      'Update Standards Information using Record Number.
        '''    i = (CntRecToUpdate - z)

        '''    RowNo = STDsList(20, i)
        '''    LookForMXStd = STDsList(10, i)
        '''    LookForPartsOnStd = STDsList(9, i)

        '''    FindMXStdParts(StdsBOMList, RowNo, LookForMXStd, LookForPartsOnStd)         'FindMXStdParts(BOMList, RowNo, LookForMXStd, LookForPartsOnStd)
        '''Next

        '''GenInfo3233.StdsBOMList = StdsBOMList

        ''This data will now be used in "FindStdsBOM"
        ''--------------------------Collect Database Information for Fabrication Item Numbers------------------
        'GetFabDBase()

        'Test3 = FabInvListData(3, 1)
        'Test0 = GasketData(0, 1)
        'Test1 = GasketData(1, 1)
        'Test2 = GasketData(2, 1)

        'ManwayInfo3134.FabInvListData = FabInvListData
        'ManwayInfo3134.StructureData = StructureData
        'ManwayInfo3134.FittingData = FittingData
        'ManwayInfo3134.GasketData = GasketData
        'ManwayInfo3134.FlangeData = FlangeData
        'ManwayInfo3134.PipeData = PipeData
        'ManwayInfo3134.HardwareData = HardwareData
        'ManwayInfo3134.MiscData = MiscData
        'ManwayInfo3134.SubMFGData = SubMFGData
        'ManwayInfo3134.SubPURData = SubPURData
        'ManwayInfo3134.NamePlateData = NamePlateData
        'ManwayInfo3134.PlateData = PlateData
        'ManwayInfo3134.ShipSuplData = ShipSuplData
        'ManwayInfo3134.TkSealData = TkSealData
        'ManwayInfo3134.AllMatSortDesc = AllMatSortDesc      '-----------------------AllMatSortDesc fixed in GetFabDBAse.
        'Test = FabInvListData(2, 1)

        ''''Replaced above in WriteToExcelAfterSort        'FindStdsBOM()                               '---------"Copy Standards to Bulk BOM........Please Wait"

        'Me.LblProgress.Text = "Updating Reference Information........Please Wait"
        'Me.Refresh()
        'ProgressBar1.Value = 0
        'BOMWrkSht.Activate()
        'LineNo2 = BOMWrkSht.Range("A4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row

        'With BOMWrkSht

        '    With .Range("A:A")
        '        .Insert(Shift:=XlInsertShiftDirection.xlShiftToRight)
        '    End With

        '    .Range("A" & 4).Value = "Ref"

        '    With .Range("A" & 4 & ":A" & LineNo2)
        '        .HorizontalAlignment = XlHAlign.xlHAlignCenter
        '        .VerticalAlignment = XlVAlign.xlVAlignCenter
        '        .Font.Name = "Arial"
        '        .Font.FontStyle = "Regular"
        '        .Font.Size = 9
        '        .NumberFormat = "@"
        '        With .Borders.Item(XlBordersIndex.xlDiagonalDown)
        '            .LineStyle = XlLineStyle.xlLineStyleNone
        '        End With
        '        With .Borders.Item(XlBordersIndex.xlDiagonalUp)
        '            .LineStyle = XlLineStyle.xlLineStyleNone
        '        End With
        '        With .Borders.Item(XlBordersIndex.xlEdgeLeft)
        '            .LineStyle = XlLineStyle.xlContinuous
        '            .Weight = XlBorderWeight.xlThin
        '            .ColorIndex = XlColorIndex.xlColorIndexAutomatic
        '        End With
        '        With .Borders.Item(XlBordersIndex.xlEdgeTop)
        '            .LineStyle = XlLineStyle.xlContinuous
        '            .Weight = XlBorderWeight.xlThin
        '            .ColorIndex = XlColorIndex.xlColorIndexAutomatic
        '        End With
        '        With .Borders.Item(XlBordersIndex.xlEdgeBottom)
        '            .LineStyle = XlLineStyle.xlContinuous
        '            .Weight = XlBorderWeight.xlThin
        '            .ColorIndex = XlColorIndex.xlColorIndexAutomatic
        '        End With
        '        With .Borders.Item(XlBordersIndex.xlEdgeRight)
        '            .LineStyle = XlLineStyle.xlContinuous
        '            .Weight = XlBorderWeight.xlThin
        '            .ColorIndex = XlColorIndex.xlColorIndexAutomatic
        '        End With
        '        With .Borders.Item(XlBordersIndex.xlInsideVertical)
        '            '.LineStyle = XlLineStyle.xlContinuous
        '            .Weight = XlBorderWeight.xlThin
        '            '.ColorIndex = XlColorIndex.xlColorIndexAutomatic
        '        End With
        '    End With
        'End With

        '        Count = 0
        '        CountVal = 0
        '        i = 1

        'RptGetData2: Testi = (i)
        'If Testi > (LineNo2 + CountVal) Then
        '    ProgressBar1.Maximum = Testi                                'Check for added Items.
        'Else
        '    ProgressBar1.Maximum = (LineNo2 + CountVal)                 'At Start of loop LineNo2 + CountVal is greater
        'End If

        'For i = Testi To ((LineNo2 + CountVal) - 4)
        '    RowNo = i + 4

        '    If RowNo < LineNo2 Then
        '        ProgressBar1.Value = RowNo
        '    End If

        '    With BOMWrkSht
        '        LookForStd = .Range("B" & RowNo).Value
        '        If Mid(LookForStd, 1, 2) = "MX" Then                '-------------------Find Standard
        '            OldRef = .Range("A" & RowNo).Value              'Ref Number
        '            'OldDwg = .Range("B" & RowNo).Value              'Dwg
        '            'OldRev = .Range("C" & RowNo).Value              'Rev
        '            'OldShpMk = .Range("D" & RowNo).Value            'Ship Mark
        '            MxPcMk = .Range("E" & RowNo).Value             'Piece Mark
        '            'OldQty = .Range("F" & RowNo).Value              'QTY
        '            'OldDesc = .Range("G" & RowNo).Value             'Description
        '            'OldInv = .Range("H" & RowNo).Value              'INV-1
        '            'OldStd = .Range("I" & RowNo).Value              'Standard Number Example:MX1001A
        '            'OldMatl = .Range("J" & RowNo).Value             'Material
        '            'OldWht = .Range("K" & RowNo).Value              'Weight
        '            'OldReq = .Range("L" & RowNo).Value              'Required Type
        '            'OldProd = .Range("M" & RowNo).Value             'Production Code
        '        Else
        '            OldRef = .Range("A" & RowNo).Value              'Ref Number
        '            OldDwg = .Range("B" & RowNo).Value              'Dwg
        '            OldDwg = OldDwg
        '            'OldRev = .Range("C" & RowNo).Value              'Rev
        '            'OldShpMk = .Range("D" & RowNo).Value            'Ship Mark
        '            OldPcMk = .Range("E" & RowNo).Value             'Piece Mark
        '            If OldPcMk = Nothing Then
        '                OldPcMk = .Range("D" & RowNo).Value             'Ship Mark
        '            End If
        '        End If
        '        If MxPcMk = "" Then
        '            .Range("A" & RowNo).Value = OldDwg & "_" & OldPcMk
        '        Else
        '            .Range("A" & RowNo).Value = OldDwg & "_" & OldPcMk & "_" & MxPcMk
        '        End If
        '        MxPcMk = ""

        '        With .Range("A" & RowNo)
        '            With .Borders.Item(XlBordersIndex.xlEdgeBottom)
        '                .LineStyle = XlLineStyle.xlContinuous
        '                .Weight = XlBorderWeight.xlThin
        '                .ColorIndex = XlColorIndex.xlColorIndexAutomatic
        '            End With
        '        End With
        '        With .Range("N" & RowNo)                            'Do column N as well for Procurement-------DJL-10-11-2023
        '            With .Borders.Item(XlBordersIndex.xlEdgeBottom)
        '                .LineStyle = XlLineStyle.xlContinuous
        '                .Weight = XlBorderWeight.xlThin
        '                .ColorIndex = XlColorIndex.xlColorIndexAutomatic
        '            End With
        '        End With
        '    End With
        'Next i

        'ProgressBar1.Value = 0                       'Export BOM info to Bulk BOM now
        'RevNo = Me.ComboBxRev.Text
        'ManwayInfo3134.RevNo = RevNo
        'RevNo2 = RevNo
        'WorkBookName = MainBOMFile.Application.ActiveWorkbook.Name
        'OldFileNam = Me.PathBox.Text                          'OldFileNam = Me.File1.Path

        '-------Modify previous program to find Bolts, Gaskets, and add Nuts.
        '---------------------------Add new function for David Redman get BOM Item numbers and add to existing BOM.
        'GetBOMItemNo2(FileSaveAS)    '-------This function finds Item Numbers for Bolts, and creates a new line for NUTS and finds nut Item numbers.

        'Test = Me.CheckBox1.CheckState

        '-------DJL-------10-11-2023-----Everyone except Bill Sieg wants the compare process removed.  bsieg
        '-------Email Bill Sieg, Since you  “I don’t even look at them, I just run them and send them.” Then the process Is being removed.
        'If Me.CheckBox1.CheckState = 1 Then
        '    NewBulkBOM = ExcelApp.Application.ActiveWorkbook.Sheets("Bulk BOM")
        '    OldBulkBOMFile = File2.Path & "\" & File2.SelectedItem

        '    CompareBOM()    '----------------Need to compare before producing Stick BOM, Plate BOM, and Purchase BOM........Etc....

        '    Me.Label2.Text = "Outputting Stick BOM, Plate BOM, and Purchase BOM........Please Wait"
        '    Me.Refresh()
        '    NewBulkBOM = ExcelApp.Application.ActiveWorkbook.Sheets("Bulk BOM")
        '    OldBOMFile.Close(False)

        '    '-------Logic to break down Design descriptions to Fab Material List Numbers-------
        'ShopCUT(RevNo)      'NOT REQUIRED ANYMORE PER TREVOR.    '-------If a number is not found need to look here first, then check database.
        '    Shopwatch = 1
        'End If

        'If Shopwatch = 0 Then                           '--------Compare process is not required.
        '    ShopCUT(RevNo)
        'End If

        'Me.LblProgress.Text = "Updating BOM for Color Number Information........Please Wait"

        '-------------------------------------------------Required information for new program Pipe Cut Suite.
        'Me.LblProgress.Text = "Updating Stick Import Information........Please Wait"
        'Me.Refresh()

        'ProgressBar1.Value = 0
        'NewStickImport = MainBOMFile.Application.ActiveWorkbook.Sheets("Stick Import")
        'NewStickBOM = MainBOMFile.Application.ActiveWorkbook.Sheets("Stick BOM")
        'NewStickBOM.Activate()

        'LineNo2 = NewStickBOM.Range("A4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row

        'With NewStickBOM
        '    'FoundLast = False
        '    'LineNo2 = 4

        '    For z = 4 To LineNo2
        '        'Do Until FoundLast = True
        '        'LineNo2 = LineNo2 + 1
        '        'Test1 = .Range("A" & LineNo2).Value
        '        'If .Range("A" & LineNo2).Value = Nothing And .Range("G" & LineNo2).Value = Nothing Then
        '        '    LineNo2 = LineNo2 - 1
        '        '    FoundLast = True
        '        'Else
        '        'Test = .Range("A" & LineNo2).Value
        '        'Test1 = .Range("A" & (LineNo2 + 1)).Value
        '        If .Range("A" & z).Value = .Range("A" & (z + 1)).Value Then         'If .Range("A" & LineNo2).Value = .Range("A" & (LineNo2 + 1)).Value Then
        '            .Range("A" & z).Value = .Range("A" & z).Value & "-A"            '.Range("A" & LineNo2).Value = .Range("A" & LineNo2).Value & "-A"
        '            .Range("A" & (z + 1)).Value = .Range("A" & (z + 1)).Value & "-B"            '.Range("A" & (LineNo2 + 1)).Value = .Range("A" & (LineNo2 + 1)).Value & "-B"
        '        End If
        '        'End If
        '        'Loop
        '    Next z
        'End With

        'With NewStickBOM
        '    With .Range("A4:R" & LineNo2)
        '        .Sort(Key1:= .Columns("N"), Order1:=XlSortOrder.xlAscending, Header:=XlYesNoGuess.xlYes, Orientation:=XlSortOrientation.xlSortColumns)
        '    End With
        'End With

        'NewStickImport.Activate()
        'ProgressBar1.Maximum = LineNo2
        'Dim TestColor As Long

        'For i = 1 To (LineNo2 - 5)
        '    RowNo = i + 4
        '    ProgressBar1.Value = RowNo

        '    With NewStickBOM
        '        TestColor = .Range("A" & RowNo & ":B" & RowNo).Interior.ColorIndex
        '    End With

        '    With NewStickImport
        '        .Range("A1:AF1").Copy()
        '        .Rows(RowNo - 3 & ":" & RowNo - 3).Insert()
        '        .Range("A" & (RowNo - 4) & ":F" & (RowNo - 4)).Interior.ColorIndex = TestColor
        '    End With
        'Next i

        'ProgressBar1.Value = 0
        'BOMWrkSht.Activate()

        'With BOMWrkSht
        '    RowNo = "5"
        '    .Rows(RowNo & ":" & RowNo).Select()
        'End With

        'GetBOMItemNo(FileSaveAS)    '-------This function finds Item Numbers for Bolts, and creates a new line for NUTS and finds nut Item numbers.
        'DelHeaders(FileSaveAS)    '-------This function Deletes headers not needed.

        PrgName = "StartButton_Click-Part31"
        AcadApp.WindowState = AutoCAD.AcWindowState.acMin       'AcadApp.WindowState = AutoCAD.AcWindowState.acMax      RW 8/17/2023
        LineNo2 = BOMWrkSht.Range("B4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row

        With BOMWrkSht
            RevNo = .Range("G3").Value           'ManwayInfo3134.RevNo = .Range("F3").Value

            z = 5
            .Range("X" & z & ":AB" & (LineNo2)).Delete()
            .Range("N1" & ":V" & (LineNo2)).Delete()
            .Range("A1" & ":A" & (LineNo2)).Delete()

            .Columns("A:A").EntireColumn.AutoFit
            .Columns("B:B").EntireColumn.AutoFit
            .Columns("C:C").EntireColumn.AutoFit
            .Columns("D:D").EntireColumn.AutoFit
            .Columns("E:E").EntireColumn.AutoFit
            .Columns("F:F").ColumnWidth = 74.43
            .Columns("F:F").EntireColumn.AutoFit
            .Columns("G:G").EntireColumn.AutoFit
            .Columns("H:H").EntireColumn.AutoFit
            .Columns("I:I").EntireColumn.AutoFit
            .Columns("I:I").EntireColumn.AutoFit
            .Columns("I:I").ColumnWidth = 22.29
            .Columns("I:I").ColumnWidth = 18.29
            .Columns("J:J").EntireColumn.AutoFit
            .Columns("I:I").EntireColumn.AutoFit
            .Columns("M:M").ColumnWidth = 24.43
            .Columns("M:M").EntireColumn.AutoFit

            .Rows("5:" & LineNo2).RowHeight = 21.75
        End With

        PrgName = "StartButton_Click-Part32"
        OldFileNam = Me.PathBox.Text
        FileToOpen = "K:\CAD\VBA\XLTSheets\BOM-New-1-15-2024.xltm"          '-------DJL-11-10-2024          'FileToOpen = "K:\CAD\VBA\XLTSheets\BOM-New-1-15-2023.xltm"

        'RevNo = ManwayInfo3134.RevNo
        CopyBOMFile(OldFileNam, RevNo)
Cancel:

        ''If AcadOpen = False Then
        ''    For Each docu In AcadApp.Documents
        ''        docu.Close(SaveChanges:=False)
        ''    Next
        ''    If gvntSDIvar = True Then
        ''        AcadPref.SingleDocumentMode = False
        ''        AcadApp.Quit()
        ''    Else
        ''        AcadApp.Quit()
        ''    End If
        ''Else
        ''    AcadApp.Quit()
        ''End If

        ''AcadDoc = Nothing
        ''AcadApp = Nothing
        'ExcelApp.Application.Visible = True

        'If GenInfo3233.StartAdept = True Then
        '    OpenPrg("Adept")
        'End If

        ''Select Case TestForYes
        ''    Case "Yes"
        ''        Sapi.Speak("Your Bill of Material has been created.")
        ''        MsgBox("Your Bulk BOM has been Created.")
        ''        ExcelApp.Application.Visible = True
        ''        MainBOMFile.Close(False)
        ''    Case "No"
        ''        ExcelApp.Application.Visible = True
        ''        MainBOMFile.Close(False)
        ''    Case Else
        ''Sapi.Speak("Your Bill of Material has been created.")

        'MsgBox("Your Bulk BOM has been Created.")
        'ExcelApp.Application.Visible = True

        'MainBOMFile.Close(False)
        ''End Select

        'Close()

Err_StartButton_Click:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            DwgItem2 = CurrentDwgNo
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException
            Test = DwgItem2

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ErrNo = 9 And InStr(ErrMsg, "Index was outside the bounds of the array") > 0 Then
                Resume Next
            End If

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            If ErrNo = -2147417848 And InStr(ErrMsg, "The object invoked has disconnected") > 0 Then
                AcadApp = GetObject(, "AutoCAD.Application")
                System.Threading.Thread.Sleep(25)

                If ProblemAt = "CloseDwg" Then
                    Resume Next
                Else
                    Resume
                End If
            End If

            If ErrNo = -2145320885 And ErrMsg = "Problem in unloading DVB file" Then
                Resume Next                     'Layout.dvb was not found to be loaded
            End If

            If ErrNo = -2145320924 And InStr(ErrMsg, "is not found.") < 0 Then
                'DwgItem = VarSelArray(z)
                Resume
            End If

            CntDwgsNotFound = InStr(ErrMsg, "not a valid drawing")

            If ErrNo = -2145320825 And CntDwgsNotFound > 0 Then
                Sapi.Speak("AutoCAD found a bad Drawing, " & DwgItem & ", Going to next drawing.")
                MsgBox("AutoCAD found a bad Drawing, " & DwgItem & ", Going to next drawing.")
                BadDwgFound = "Yes"
                CntDwgsNotFound = 0
                Resume Next
            End If

            If ErrNo = -2145320851 And ErrMsg = "The named selection set exists" Then
                BlockSel.Delete()
                Resume
            End If

            If ErrNo = 91 And ErrMsg = "Problem in unloading DVB file" Then
                Resume Next                     'Layout.dvb was not found to be loaded
            End If

            If ErrNo = 462 And Mid(ErrMsg, 1, 29) = "The RPC server is unavailable" Then
                Information.Err.Clear()
                AcadApp = CreateObject("AutoCAD.Application")
                AcadOpen = False
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            'PrgLineNo = PrgLineNo.Replace("vbCrlf", "")
            'PrgLineNo = PrgLineNo.Replace(Chr(15), "")
            'PrgLineNo = PrgLineNo.Replace(Chr(10), "")
            'FindEndStr = InStr(2, PrgLineNo, Chr(39))
            'FindEndStr = InStr(2, PrgLineNo, Chr(34))
            'PrgLineNo = Mid(PrgLineNo, 1, FindEndStr)
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            'PrgLineNo = st.GetFrame(3).GetFileLineNumber().ToString
            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If ErrNo = -2145320900 And ErrMsg = "Failed to get the Document object" Then
                If FirstDwg = "NotFound" Then
                    AcadApp.Application.Documents.Add()
                    Resume
                End If
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If

                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If

                If ErrNo = -2147418113 And ErrMsg = "Internal application error." Then
                    Information.Err.Clear()
                    AcadApp = CreateObject("AutoCAD.Application")
                    AcadOpen = False
                    Resume
                End If
            End If
        End If

    End Sub

    Function GetFabDBase()
        '------------------------------------------------------------------------------------------------
        '-------Creator:        Dennis J. Long
        '-------Date:           Sometime before 4/2/2015    ?2014?
        '-------Description:    Collect Database Information for Fabrication Item Numbers
        '-------
        '-------Updates:        Description:
        '-------    4/2/2015    Move point of entry to before "FindStdsBOM" was after "Create Ref Column" in     
        '-------                program "BOM Menu.vb".
        '-------                
        '------------------------------------------------------------------------------------------------
        Dim lngLen, lngX As Long
        Dim strUserName, PrgName, LastNam, FirstNam, FChrTest, WorkStationID1, strSQL1, FChr, UserNamex2 As String
        Dim dbSQL As New SqlClient.SqlConnection
        Dim dbSQL2 As New SqlClient.SqlConnection
        Dim dbSQLState As Boolean
        Dim Adapter2 As New SqlDataAdapter()
        Dim Cnt1 As Integer = 0
        Dim i, k As Integer

        On Error GoTo Err_GetBOMDBase

        PrgName = "GetFabDBase"
        dbSQL = New SqlClient.SqlConnection
        dbSQL2 = New SqlClient.SqlConnection
        dbSQLState = dbSQL.State

        If dbSQLState = 0 Then
            db_String = "Server=MTX16SQL09\Engineering;Database=HandleErrors;User=devDennis;Password=d3v3lop3r;Trusted_Connection=False"
            dbSQL.ConnectionString = db_String
            dbSQL.Open()
            WorkStationID1 = dbSQL.WorkstationId.ToString
        End If

        'For i = 1 To 15

        '    Select Case i
        '        Case 1
        '            strSQL1 = "SELECT * FROM [Fab Mat - Brian Smith-Sort-Commodity]"            '       = Fab Inv List
        '        Case 2
        '            strSQL1 = "SELECT * FROM [Fab Mat - Structure-Sort-Desc]"
        '        Case 3
        '            strSQL1 = "SELECT * FROM [Fab Mat - Fittings-Sort-Desc]"
        '        Case 4
        '            strSQL1 = "SELECT * FROM [Fab Mat - Gaskets-Sort-Desc]"
        '        Case 5
        '            strSQL1 = "SELECT * FROM [Fab Mat - Flange-Sort-Desc]"
        '        Case 6
        '            strSQL1 = "SELECT * FROM [Fab Mat - Pipe-Sort-Desc]"
        '        Case 7
        '            strSQL1 = "SELECT * FROM [Fab Mat - Hardware-Sort-Desc]"
        '        Case 8
        '            strSQL1 = "SELECT * FROM [Fab Mat - Misc-Sort-Desc]"
        '        Case 9
        strSQL1 = "SELECT * FROM [Fab Mat - SubMFG-Sort-Desc]"
        '    Case 10
        '        strSQL1 = "SELECT * FROM [Fab Mat - SubPUR-Sort-Desc]"
        '    Case 11
        '        strSQL1 = "SELECT * FROM [Fab Mat - NamePlate-Sort-Desc]"
        '    Case 12
        '        GoTo CloseReader       'Plate not in database at this time
        '    Case 13
        '        strSQL1 = "SELECT * FROM [Fab Mat - ShipSupl-Sort-Desc]"
        '    Case 14
        '        strSQL1 = "SELECT * FROM [Fab Mat - TkSeal-Sort-Desc]"
        '    Case 15
        '        strSQL1 = "SELECT * FROM [Fab Mat - All Sheets-Sort-Desc]"
        'End Select

        Dim command As New SqlCommand(strSQL1, dbSQL)
        dbSQLState = dbSQL.State

        If dbSQLState = 0 Then
            dbSQL.Open()
        End If

        Dim reader As SqlDataReader = command.ExecuteReader()
        Dim oProduct As String
        k = 0
        If reader.HasRows = False Then
            Throw New System.Exception("Invalid User")
            MsgBox("A problem has been found were you are not a valid User, Please have IT or (Dennis Long) add you to the system.")
            MsgBox(" Or you have not selected Button Get Manway Information, This program requires move information in order to run.")
            System.Windows.Forms.Application.Exit()
        Else
            While reader.Read()
                If Cnt1 = 0 Then
                    If Not reader("Old SC#") Is DBNull.Value Then
                        NTest1 = reader("Old SC#").ToString()

                        If NTest1 <> "NULL" Then



                            If Not reader("Part Number") Is DBNull.Value Then
                                'Select Case i
                                '    Case 1
                                '        FabInvListData(0, k) = reader("Part Number").ToString()
                                '    Case 2
                                '        StructureData(0, k) = reader("Part Number").ToString()
                                '    Case 3
                                '        FittingData(0, k) = reader("Part Number").ToString()
                                '    Case 4
                                '        GasketData(0, k) = reader("Part Number").ToString()
                                '    Case 5
                                '        FlangeData(0, k) = reader("Part Number").ToString()
                                '    Case 6
                                '        PipeData(0, k) = reader("Part Number").ToString()
                                '    Case 7
                                '        HardwareData(0, k) = reader("Part Number").ToString()
                                '    Case 8
                                '        MiscData(0, k) = reader("Part Number").ToString()
                                '    Case 9
                                SubMFGData(0, k) = reader("Part Number").ToString()
                                '    Case 10
                                '        SubPURData(0, k) = reader("Part Number").ToString()
                                '    Case 11
                                '        NamePlateData(0, k) = reader("Part Number").ToString()
                                '    Case 12
                                '        PlateData(0, k) = reader("Part Number").ToString()
                                '    Case 13
                                '        ShipSuplData(0, k) = reader("Part Number").ToString()
                                '    Case 14
                                '        TkSealData(0, k) = reader("Part Number").ToString()
                                '    Case 15
                                '        AllMatSortDesc(0, k) = reader("Part Number").ToString()
                                'End Select
                            End If

                            If Not reader("Old SC#") Is DBNull.Value Then
                                'Select Case i
                                '    Case 1
                                '        FabInvListData(1, k) = reader("Old SC#").ToString()
                                '    Case 2
                                '        StructureData(1, k) = reader("Old SC#").ToString()
                                '    Case 3
                                '        FittingData(1, k) = reader("Old SC#").ToString()
                                '    Case 4
                                '        GasketData(1, k) = reader("Old SC#").ToString()
                                '    Case 5
                                '        FlangeData(1, k) = reader("Old SC#").ToString()
                                '    Case 6
                                '        PipeData(1, k) = reader("Old SC#").ToString()
                                '    Case 7
                                '        HardwareData(1, k) = reader("Old SC#").ToString()
                                '    Case 8
                                '        MiscData(1, k) = reader("Old SC#").ToString()
                                '    Case 9
                                SubMFGData(1, k) = reader("Old SC#").ToString()
                                '    Case 10
                                '        SubPURData(1, k) = reader("Old SC#").ToString()
                                '    Case 11
                                '        NamePlateData(1, k) = reader("Old SC#").ToString()
                                '    Case 12
                                '        PlateData(1, k) = reader("Old SC#").ToString()
                                '    Case 13
                                '        ShipSuplData(1, k) = reader("Old SC#").ToString()
                                '    Case 14
                                '        TkSealData(1, k) = reader("Old SC#").ToString()
                                '    Case 15
                                '        AllMatSortDesc(1, k) = reader("Old SC#").ToString()
                                'End Select
                            End If

                            If Not reader("Description") Is DBNull.Value Then
                                'Select Case i
                                '    Case 1
                                '        FabInvListData(2, k) = reader("Description").ToString()
                                '    Case 2
                                '        StructureData(2, k) = reader("Description").ToString()
                                '    Case 3
                                '        FittingData(2, k) = reader("Description").ToString()
                                '    Case 4
                                '        GasketData(2, k) = reader("Description").ToString()
                                '    Case 5
                                '        FlangeData(2, k) = reader("Description").ToString()
                                '    Case 6
                                '        PipeData(2, k) = reader("Description").ToString()
                                '    Case 7
                                '        HardwareData(2, k) = reader("Description").ToString()
                                '    Case 8
                                '        MiscData(2, k) = reader("Description").ToString()
                                '    Case 9
                                SubMFGData(2, k) = reader("Description").ToString()
                                'Case 10
                                '        SubPURData(2, k) = reader("Description").ToString()
                                '    Case 11
                                '        NamePlateData(2, k) = reader("Description").ToString()
                                '    Case 12
                                '        PlateData(2, k) = reader("Description").ToString()
                                '    Case 13
                                '        ShipSuplData(2, k) = reader("Description").ToString()
                                '    Case 14
                                '        TkSealData(2, k) = reader("Description").ToString()
                                '    Case 15
                                '        AllMatSortDesc(2, k) = reader("Description").ToString()
                                'End Select
                            End If

                            If Not reader("Commodity") Is DBNull.Value Then
                                'Select Case i
                                '    Case 1
                                '        FabInvListData(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve FabInvListData(3, UBound(FabInvListData, 2) + 1)
                                '    Case 2
                                '        StructureData(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve StructureData(3, UBound(StructureData, 2) + 1)
                                '    Case 3
                                '        FittingData(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve FittingData(3, UBound(FittingData, 2) + 1)
                                '    Case 4
                                '        GasketData(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve GasketData(3, UBound(GasketData, 2) + 1)
                                '    Case 5
                                '        FlangeData(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve FlangeData(3, UBound(FlangeData, 2) + 1)
                                '    Case 6
                                '        PipeData(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve PipeData(3, UBound(PipeData, 2) + 1)
                                '    Case 7
                                '        HardwareData(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve HardwareData(3, UBound(HardwareData, 2) + 1)
                                '    Case 8
                                '        MiscData(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve MiscData(3, UBound(MiscData, 2) + 1)
                                '    Case 9
                                SubMFGData(3, k) = reader("Commodity").ToString()
                                ReDim Preserve SubMFGData(3, UBound(SubMFGData, 2) + 1)
                                '    Case 10
                                '        SubPURData(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve SubPURData(3, UBound(SubPURData, 2) + 1)
                                '    Case 11
                                '        NamePlateData(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve NamePlateData(3, UBound(NamePlateData, 2) + 1)
                                '    Case 12
                                '        PlateData(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve PlateData(3, UBound(PlateData, 2) + 1)
                                '    Case 13
                                '        ShipSuplData(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve ShipSuplData(3, UBound(ShipSuplData, 2) + 1)
                                '    Case 14
                                '        TkSealData(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve TkSealData(3, UBound(TkSealData, 2) + 1)
                                '    Case 15
                                '        AllMatSortDesc(3, k) = reader("Commodity").ToString()
                                '        ReDim Preserve AllMatSortDesc(3, UBound(AllMatSortDesc, 2) + 1)
                                'End Select
                            End If

                            k = (k + 1)

                        End If
                    End If
                End If

                'k = (k + 1)       'Moved above
            End While
CloseReader:
            If Not reader.IsClosed Then
                reader.Close()
            End If
        End If
        'End If

        k = 0
        'Next i

Err_GetBOMDBase:
        ErrNo = Err.Number
        If ErrNo <> 0 Then
            PriPrg = "MX02-Manways"
            PrgName = "GetFabDBase"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            Dim st As New StackTrace(Err.GetException, True)
            'HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem)
            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2, PrgLineNo)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 30 Then
                    If ExceptionPos > 0 Then
                        System.Threading.Thread.Sleep(100)
                        Resume
                    End If
                    If CallPos > 0 Then
                        System.Threading.Thread.Sleep(100)
                        Resume
                    End If
                End If
            End If
        End If

    End Function

    'Public Function Sort2DimArray(BOMList As Array, order As Boolean, sc0 As Integer, Optional sc1 As Integer = -1, Optional sc2 As Integer = -1) As Array
    '    '-------Copied from Internet.
    '    Dim cols As Integer = BOMList.GetLength(1) - 1
    '    Dim rows As Integer = BOMList.GetLength(0) - 1
    '    Dim na(rows, cols) As String
    '    Dim a(rows) As String
    '    Dim b(rows) As Integer
    '    Dim c As Integer = 1

    '    If sc1 > -1 Then c = c + 1
    '    If sc2 > -1 Then c = c + 1

    '    For x = 0 To rows
    '        If c = 1 Then a(x) = BOMList(x, sc0)
    '        If c = 2 Then a(x) = BOMList(x, sc0) & BOMList(x, sc1)
    '        If c = 3 Then a(x) = BOMList(x, sc0) & BOMList(x, sc1) & BOMList(x, sc2)
    '        b(x) = x
    '    Next

    '    Array.Sort(a, b)
    '    If order = False Then
    '        For x = 0 To rows
    '            For y = 0 To cols
    '                na(x, y) = BOMList(b(x), y)
    '            Next
    '        Next
    '    Else
    '        For x = 0 To rows
    '            For y = 0 To cols
    '                na(rows - x, y) = BOMList(b(x), y)
    '            Next
    '        Next
    '    End If
    '    Sort2DimArray = na
    'End Function

    Function FindStdsInfo(ByVal BOMList As Array)
        '-------Move to new function-------FindStdsInfo-------DJL-10-11-2023            
        '------------------------------------------------------------------------------------------------
        '-------Creator:        Dennis J. Long
        '-------Date:           10/4/2023
        '-------Description:    Collect Standard numbers from BOMList Array so that BOM can
        '-------                be updated.
        '-------
        '-------Updates:        Description:
        '-------12-22-2023      Make work with Array Only.    
        '-------02-09-2024      Has been moved to collecting in First Array.-------DJL-2-9-2024
        '-------                Replaced.
        '-----------------------------------------------------------------------------------------------
        Dim LookForStd2, LookForStdYesNo As String
        Dim CntStd As Integer
        Dim STDsList(20, 1)

        On Error GoTo Err_FindStdsInfo

        Me.LblProgress.Text = "Outputting Standards Drawings BOM........Please Wait"
        Me.Refresh()

        For i = 0 To (UBound(BOMList, 2))                                   'For i = 1 To LineNo2
            RowNo = i + 4
            ProgressBar1.Maximum = (UBound(BOMList, 2))                     'LineNo2

            'With BOMWrkSht
            LookForStd = BOMList(10, i)                             'MX0252 Standard    '.Range("H" & RowNo).Value
            LookForStd2 = BOMList(9, i)                             '24MM   Std Part Number
            LookForStdYesNo = BOMList(8, i)
            LookForShipMk = BOMList(3, i)                          'Ship Mark           '.Range("C" & RowNo).Value

            If Mid(LookForStd, 1, 2) = "MX" Or Mid(LookForStd, 1, 2) = "CA" Then                            'CA Canada Standards.       ' Ship Marks.
                If Mid(LookForStd, 1, 2) = "CH" Then
                    'If LookForStdYesNo = "No" Then     'Some drawings reference a Standard only for Checking what is on drawing.  Simlar but Not the same.
                    '    Stop
                    'Else
                    If LookForStdYesNo = "Yes" Then     'Some drawings reference a Standard only for Checking what is on drawing.  Simlar but Not the same.
                        CntStd = CntStd + 1
                        STDsList(0, CntStd) = BOMList(0, i)
                        STDsList(1, CntStd) = BOMList(1, i)           'STDsList(1, UBound(STDsList, 2)) = .Range("A" & RowNo).Value
                        STDsList(2, CntStd) = BOMList(2, i)            'STDsList(2, UBound(STDsList, 2)) = .Range("B" & RowNo).Value
                        STDsList(3, CntStd) = BOMList(3, i)            'STDsList(3, UBound(STDsList, 2)) = .Range("C" & RowNo).Value
                        STDsList(4, CntStd) = BOMList(4, i)            'STDsList(4, UBound(STDsList, 2)) = .Range("D" & RowNo).Value
                        STDsList(5, CntStd) = BOMList(5, i)             'STDsList(5, UBound(STDsList, 2)) = .Range("E" & RowNo).Value
                        STDsList(6, CntStd) = BOMList(6, i)            'STDsList(6, UBound(STDsList, 2)) = .Range("F" & RowNo).Value
                        STDsList(7, CntStd) = BOMList(7, i)            'STDsList(7, UBound(STDsList, 2)) = .Range("G" & RowNo).Value
                        STDsList(8, CntStd) = BOMList(8, i)            'STDsList(8, UBound(STDsList, 2)) = .Range("H" & RowNo).Value
                        STDsList(9, CntStd) = BOMList(9, i)            'STDsList(9, UBound(STDsList, 2)) = .Range("I" & RowNo).Value
                        STDsList(10, CntStd) = BOMList(10, i)           'STDsList(10, UBound(STDsList, 2)) = .Range("J" & RowNo).Value
                        STDsList(11, CntStd) = BOMList(11, i)          'STDsList(11, UBound(STDsList, 2)) = .Range("K" & RowNo).Value
                        STDsList(12, CntStd) = BOMList(12, i)           'STDsList(12, UBound(STDsList, 2)) = .Range("L" & RowNo).Value
                        STDsList(13, CntStd) = BOMList(13, i)
                        STDsList(14, CntStd) = BOMList(14, i)
                        STDsList(15, CntStd) = BOMList(15, i)
                        STDsList(16, CntStd) = BOMList(16, i)
                        STDsList(17, CntStd) = BOMList(17, i)
                        STDsList(18, CntStd) = BOMList(18, i)
                        STDsList(19, CntStd) = BOMList(19, i)        '------Row Count for where Std is on BOM.     'STDsList(13, UBound(STDsList, 2)) = RowNo
                        STDsList(20, CntStd) = BOMList(20, i)                   'STDsList(20, CntStd) = RowNo
                        ReDim Preserve STDsList(20, UBound(STDsList, 2) + 1)
                    End If
                End If
            End If
            ProgressBar1.Value = i
            'End With
        Next i

        GenInfo3233.STDsList = STDsList
Err_FindStdsInfo:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            DwgItem2 = CurrentDwgNo
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException
            Test = DwgItem2

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ErrNo = 9 And InStr(ErrMsg, "Index was outside the bounds of the array") > 0 Then
                Resume Next
            End If

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            If ErrNo = -2147417848 And InStr(ErrMsg, "The object invoked has disconnected") > 0 Then
                AcadApp = GetObject(, "AutoCAD.Application")
                System.Threading.Thread.Sleep(25)

                If ProblemAt = "CloseDwg" Then
                    Resume Next
                Else
                    Resume
                End If
            End If

            If ErrNo = -2145320885 And ErrMsg = "Problem in unloading DVB file" Then
                Resume Next                     'Layout.dvb was not found to be loaded
            End If

            If ErrNo = -2145320924 And InStr(ErrMsg, "is not found.") < 0 Then
                Resume
            End If

            CntDwgsNotFound = InStr(ErrMsg, "not a valid drawing")

            If ErrNo = -2145320825 And CntDwgsNotFound > 0 Then
                Sapi.Speak("AutoCAD found a bad Drawing, " & DwgItem & ", Going to next drawing.")
                MsgBox("AutoCAD found a bad Drawing, " & DwgItem & ", Going to next drawing.")
                BadDwgFound = "Yes"
                CntDwgsNotFound = 0
                Resume Next
            End If

            If ErrNo = 91 And ErrMsg = "Problem in unloading DVB file" Then
                Resume Next                     'Layout.dvb was not found to be loaded
            End If

            If ErrNo = 462 And Mid(ErrMsg, 1, 29) = "The RPC server is unavailable" Then
                Information.Err.Clear()
                AcadApp = CreateObject("AutoCAD.Application")
                AcadOpen = False
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If ErrNo = -2145320900 And ErrMsg = "Failed to get the Document object" Then
                If FirstDwg = "NotFound" Then
                    AcadApp.Application.Documents.Add()
                    Resume
                End If
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If

                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If

                If ErrNo = -2147418113 And ErrMsg = "Internal application error." Then
                    Information.Err.Clear()
                    AcadApp = CreateObject("AutoCAD.Application")
                    AcadOpen = False
                    Resume
                End If
            End If
        End If

    End Function

    Function FindMXStdParts(ByVal StdsBOMList As Array, ByVal RowNo As Integer, ByVal LookForMXStd As String, ByVal LookForPartsOnStd As String)
        '------------------------------------------------------------------------------------------------
        '-------Creator:        Dennis J. Long
        '-------Date:           12/29/2023
        '-------Description:    Collect MX Standard Parts numbers and add to BOMList Array so that BOM can
        '-------                be updated with Standards Information.
        '-------
        '-------Updates:        Description:
        '-------12-29-2023      Make work with Spread Sheet.    
        '-------                
        '-------                
        '-----------------------------------------------------------------------------------------------
        Dim CntStd, ii As Integer
        Dim FindMXStd, FindStdParts, FindShipMk As String
        Dim CollectSTDsList(13, 1)                              'Dim CollectSTDsList(20, 1)

        On Error GoTo Err_FindMXStdsParts

        ProgressBar1.Maximum = (UBound(BOMList, 2))
        Me.LblProgress.Text = "Outputting MX Standards parts information to BOM........Please Wait"
        Me.Refresh()

        For i = 0 To (UBound(StdsBOMList, 2))
            FindMXStd = StdsBOMList(10, i)                             'MX0252 Standard    
            FindStdParts = StdsBOMList(9, i)                             '24MM   Std Part Number
            FindShipMk = StdsBOMList(3, i)                          'Ship Mark          

            If LookForMXStd = FindMXStd And LookForPartsOnStd = FindStdParts Then
                ii = i

                For ii = i To (UBound(StdsBOMList, 2))
                    FindMXStd = StdsBOMList(10, ii)

                    While LookForMXStd = FindMXStd
                        CntStd = CntStd + 1
                        CollectSTDsList(0, CntStd) = StdsBOMList(0, ii)
                        CollectSTDsList(1, CntStd) = StdsBOMList(1, ii)
                        CollectSTDsList(2, CntStd) = StdsBOMList(2, ii)
                        CollectSTDsList(3, CntStd) = StdsBOMList(3, ii)
                        CollectSTDsList(4, CntStd) = StdsBOMList(4, ii)
                        CollectSTDsList(5, CntStd) = StdsBOMList(5, ii)
                        CollectSTDsList(6, CntStd) = StdsBOMList(6, ii)
                        CollectSTDsList(7, CntStd) = StdsBOMList(7, ii)
                        CollectSTDsList(8, CntStd) = StdsBOMList(8, ii)
                        CollectSTDsList(9, CntStd) = StdsBOMList(9, ii)
                        CollectSTDsList(10, CntStd) = StdsBOMList(10, ii)
                        CollectSTDsList(11, CntStd) = StdsBOMList(11, ii)
                        CollectSTDsList(12, CntStd) = StdsBOMList(12, ii)
                        CollectSTDsList(13, CntStd) = StdsBOMList(13, ii)
                        'CollectSTDsList(14, CntStd) = StdsBOMList(14, ii)
                        'CollectSTDsList(15, CntStd) = StdsBOMList(15, ii)
                        'CollectSTDsList(16, CntStd) = StdsBOMList(16, ii)
                        'CollectSTDsList(17, CntStd) = StdsBOMList(17, ii)
                        'CollectSTDsList(18, CntStd) = StdsBOMList(18, ii)
                        'CollectSTDsList(19, CntStd) = StdsBOMList(19, ii)        '------Row Count for where Std is on BOM.     
                        'CollectSTDsList(20, CntStd) = StdsBOMList(20, ii)                   'CollectSTDsList(20, CntStd) = RowNo
                        ReDim Preserve CollectSTDsList(13, UBound(CollectSTDsList, 2) + 1)      'ReDim Preserve CollectSTDsList(20, UBound(CollectSTDsList, 2) + 1)
                    End While
                Next ii
            End If

            For k = 1 To (UBound(CollectSTDsList, 2))
                With BOMWrkSht
                    If k = 1 Then
                        .Rows(RowNo & ":" & RowNo).Select()
                        .Rows(RowNo & ":" & RowNo).Insert()

                        .Range("A" & (RowNo + k)).Value = CollectSTDsList(1, i)
                        .Range("B" & (RowNo + k)).Value = CollectSTDsList(2, i)
                        .Range("C" & (RowNo + k)).Value = CollectSTDsList(3, i)
                        .Range("D" & (RowNo + k)).Value = CollectSTDsList(5, i)
                        .Range("E" & (RowNo + k)).Value = CollectSTDsList(4, i)

                        .Range("F" & (RowNo + k)).Value = CollectSTDsList(6, i)
                        .Range("G" & (RowNo + k)).Value = CollectSTDsList(7, i)
                        .Range("H" & (RowNo + k)).Value = CollectSTDsList(8, i)
                        .Range("I" & (RowNo + k)).Value = CollectSTDsList(9, i)
                        .Range("J" & (RowNo + k)).Value = CollectSTDsList(10, i)

                        .Range("K" & (RowNo + k)).Value = CollectSTDsList(11, i)
                        .Range("L" & (RowNo + k)).Value = CollectSTDsList(12, i)
                        .Range("M" & (RowNo + k)).Value = CollectSTDsList(13, i)
                    Else
                        .Rows((RowNo + k) & ":" & (RowNo + k)).Select()
                        .Rows((RowNo + k) & ":" & (RowNo + k)).Insert()

                        .Range("A" & (RowNo + k)).Value = CollectSTDsList(1, i)
                        .Range("B" & (RowNo + k)).Value = CollectSTDsList(2, i)
                        .Range("C" & (RowNo + k)).Value = CollectSTDsList(3, i)
                        .Range("D" & (RowNo + k)).Value = CollectSTDsList(5, i)
                        .Range("E" & (RowNo + k)).Value = CollectSTDsList(4, i)

                        .Range("F" & (RowNo + k)).Value = CollectSTDsList(6, i)
                        .Range("G" & (RowNo + k)).Value = CollectSTDsList(7, i)
                        .Range("H" & (RowNo + k)).Value = CollectSTDsList(8, i)
                        .Range("I" & (RowNo + k)).Value = CollectSTDsList(9, i)
                        .Range("J" & (RowNo + k)).Value = CollectSTDsList(10, i)

                        .Range("K" & (RowNo + k)).Value = CollectSTDsList(11, i)
                        .Range("L" & (RowNo + k)).Value = CollectSTDsList(12, i)
                        .Range("M" & (RowNo + k)).Value = CollectSTDsList(13, i)
                    End If
                End With
            Next k

            ReDim CollectSTDsList(13, 1)
            ProgressBar1.Value = i
        Next i

        GenInfo3233.CollectSTDsList = CollectSTDsList

Err_FindMXStdsParts:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            DwgItem2 = CurrentDwgNo
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException
            Test = DwgItem2

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ErrNo = 9 And InStr(ErrMsg, "Index was outside the bounds of the array") > 0 Then
                Resume Next
            End If

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            If ErrNo = -2147417848 And InStr(ErrMsg, "The object invoked has disconnected") > 0 Then
                AcadApp = GetObject(, "AutoCAD.Application")
                System.Threading.Thread.Sleep(25)

                If ProblemAt = "CloseDwg" Then
                    Resume Next
                Else
                    Resume
                End If
            End If

            If ErrNo = -2145320885 And ErrMsg = "Problem in unloading DVB file" Then
                Resume Next                     'Layout.dvb was not found to be loaded
            End If

            If ErrNo = -2145320924 And InStr(ErrMsg, "is not found.") < 0 Then
                Resume
            End If

            CntDwgsNotFound = InStr(ErrMsg, "not a valid drawing")

            If ErrNo = -2145320825 And CntDwgsNotFound > 0 Then
                Sapi.Speak("AutoCAD found a bad Drawing, " & DwgItem & ", Going to next drawing.")
                MsgBox("AutoCAD found a bad Drawing, " & DwgItem & ", Going to next drawing.")
                BadDwgFound = "Yes"
                CntDwgsNotFound = 0
                Resume Next
            End If

            If ErrNo = 91 And ErrMsg = "Problem in unloading DVB file" Then
                Resume Next                     'Layout.dvb was not found to be loaded
            End If

            If ErrNo = 462 And Mid(ErrMsg, 1, 29) = "The RPC server is unavailable" Then
                Information.Err.Clear()
                AcadApp = CreateObject("AutoCAD.Application")
                AcadOpen = False
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If ErrNo = -2145320900 And ErrMsg = "Failed to get the Document object" Then
                If FirstDwg = "NotFound" Then
                    AcadApp.Application.Documents.Add()
                    Resume
                End If
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If

                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If

                If ErrNo = -2147418113 And ErrMsg = "Internal application error." Then
                    Information.Err.Clear()
                    AcadApp = CreateObject("AutoCAD.Application")
                    AcadOpen = False
                    Resume
                End If
            End If
        End If

    End Function

    Function WriteToExcel(BOMList)
        '-------Move to new function-------WritetoExcel-------DJL-10-11-2023            
        '------------------------------------------------------------------------------------------------
        '-------Creator:        Dennis J. Long
        '-------Date:           10/4/2023
        '-------Description:    Write data to Excel Spreadsheet
        '-------
        '-------Updates:        Description:
        '-------10-11-2023       Read Array and write to Excel what was collected from AutoCAD.     
        '-------                
        '-------                
        '------------------------------------------------------------------------------------------------
        Dim i, j, k As Integer
        Dim DwgItem2, CurrentDwgNo, FirstDwg, GetDwgNo, GetRowNo, GetX, GetY, FoundDwgNo, FoundX, FoundY, FoundItem, TotalCnt As String
        Dim CntDwgsNotFound, StrLineNo, PrevCnt As Integer
        Dim AcadOpen As Boolean

        On Error GoTo Err_WriteToExcel

        ProgressBar1.Value = 0
        Me.LblProgress.Text = "Outputting Information To Bulk BOM........Please Wait"
        Me.Refresh()

        ProblemAt = "File not found for 2019"

        If Dir("K:\CAD\VBA\AutoCADXLTSheets\BOM.xlt") <> vbNullString Then
            FileToOpen = "K:\CAD\VBA\AutoCADXLTSheets\BOM.xltm"
        Else
            If Dir("K:\CAD\VBA\XLTSheets\BOM-New-1-15-2024.xltm") <> vbNullString Then                  '-------DJL-12-10-2024          'If Dir("K:\CAD\VBA\XLTSheets\BOM-New-1-15-2023.xltm") <> vbNullString Then
                FileToOpen = "K:\CAD\VBA\XLTSheets\BOM-New-1-15-2024.xltm"                               '-------DJL-12-10-2024        'FileToOpen = "K:\CAD\VBA\XLTSheets\BOM-New-1-15-2023.xltm"      'FileToOpen = "K:\CAD\VBA\XLTSheets\BOM.xltm"
            End If
        End If

        If Dir(FileToOpen) <> "" Then
            MainBOMFile = ExcelApp.Application.Workbooks.Open(FileToOpen)
        Else
            If IsNothing(MainBOMFile) = True Then
                ProblemAt = "File not found for 2020"
                FileToOpen = "K:\VBA\XLTSheets\BOM.xltm"

                If Dir(FileToOpen) <> "" Then
                    MainBOMFile = ExcelApp.Application.Workbooks.Open(FileToOpen)
                Else
                    MsgBox("The following file was not found " & Chr(34) & FileToOpen & Chr(34) & ".")
                End If
            End If
        End If

        FileSaveAS = PathBox.Text & "\" & FullJobNo & "BOM.xls"                           'FileSaveAS = File1.Path & "\" & FullJobNo & "BOM.xls"
        Workbooks = ExcelApp.Workbooks

        WorkShtName = "Bulk BOM"
        BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
        WorkSht = Workbooks.Application.ActiveSheet
        WorkShtName = WorkSht.Name

        With BOMWrkSht
            .Range("B3").Value = GenInfo3233.FullJobNo
            .Range("I3").Value = Today
            .Range("F3").Value = Me.ComboBxRev.Text
        End With

        FileToOpen = "Bulk BOM"
        ExcelApp.Visible = True
        Test = (UBound(BOMList, 2) - 1)
        TotalCnt = (UBound(BOMList, 2) - 1)

        'Minimize Excel so user can see dialogs from program
        ExcelApp.WindowState = XlWindowState.xlMinimized

        '-------DJL-10-11-2023-------Need to move this to a later point.
        For i = 1 To (UBound(BOMList, 2) - 1)                           '-------Look at doing this later and using Array's for everything.
            RowNo = i + 4
            ProgressBar1.Maximum = (UBound(BOMList, 2) - 1)

            If RowNo = "5" Then           'Look at speeding up process by coping formatted lines   --- To Speed up Process
                BOMWrkSht.Activate()
                FormatLine(RowNo, FileToOpen)
                FormatLine((RowNo + 1), FileToOpen)

                With BOMWrkSht
                    With .Range("I" & RowNo & ":I" & TotalCnt)
                        .HorizontalAlignment = XlHAlign.xlHAlignCenter
                        .VerticalAlignment = XlVAlign.xlVAlignCenter
                        .Font.Name = "Arial"
                        .Font.Size = 7
                        .Value = BOMList(12, i) & Chr(10) & BOMList(13, i)
                    End With
                End With
            Else
                With BOMWrkSht         '-----------------------Do Not need to format everyline, Speeds up Process.
                    .Rows(RowNo & ":" & RowNo).Select()
                    .Rows(RowNo & ":" & RowNo).Insert()
                End With
            End If

            With BOMWrkSht
                If InStr(BOMList(1, i), "Delete") > 0 Then
                    GoTo DeleteDup
                End If

                .Range("A" & RowNo).Value = BOMList(1, i)
                'BOMListColl(1, i) = BOMList(1, i)

                .Range("B" & RowNo).Value = BOMList(2, i)
                'BOMListColl(2, i) = BOMList(2, i)

                .Range("C" & RowNo).Value = BOMList(3, i)
                'BOMListColl(3, i) = BOMList(3, i)

                .Range("D" & RowNo).Value = BOMList(5, i)
                'BOMListColl(5, i) = BOMList(5, i)

                .Range("E" & RowNo).Value = BOMList(4, i)                           'Will always be BOMList(4, i)       '-------DJL-10-11-2023
                'BOMListColl(4, i) = BOMList(4, i)

                'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                GetMat = BOMList(11, i)
                'BOMListColl(11, i) = BOMList(11, i)

                GetMat2 = BOMList(12, i)
                'BOMListColl(12, i) = BOMList(12, i)

                GetMat3 = BOMList(13, i)
                'BOMListColl(13, i) = BOMList(13, i)

                '-------Should below be looking at 6 and 7 instead of 7 and 8-------DJL-10-11-2023
                If BOMList(7, i) = vbNullString Or BOMList(7, i) = " " Then
                    If InStr(1, BOMList(6, i), "%%D") <> 0 And BOMList(6, i) <> Nothing Then
                        'GetPartDesc = Misc31_090.InputType2.sReplace(BOMList(6, i), "%%D", " DEG.")            'Replaced below
                        GetPartDesc = BOMList(6, i)
                        GetPartDesc = GetPartDesc.Replace("%%D", " DEG.")
                    Else
                        GetPartDesc = BOMList(6, i)
                    End If

                    If IsNothing(GetLen) = False And GetLen <> "" Then
                        GetPartDesc = GetPartDesc & " x " & GetLen
                    End If

                    'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                    'If IsNothing(GetMat) = False And GetMat <> "" Then
                    '    GetPartDesc = GetPartDesc & " - " & GetMat
                    'Else
                    '    If GetMat2 = vbNullString And GetMat3 = vbNullString Then
                    '        '---------Do Nothing is already done.           'GetPartDesc = BOMList(7, i)
                    '    Else
                    '        GetPartDesc = GetPartDesc & " - " & GetMat2 & " " & GetMat3
                    '    End If
                    'End If
                Else
                    If InStr(1, BOMList(7, i), "%%D") <> 0 Then
                        'GetPartDesc = Misc31_090.InputType2.sReplace(BOMList(7, i), "%%D", " DEG.")
                        GetPartDesc = BOMList(7, i)
                        GetPartDesc = GetPartDesc.Replace("%%D", " DEG.")
                    Else
                        GetPartDesc = BOMList(7, i)
                    End If

                    If IsNothing(GetLen) = False And GetLen <> "" Then
                        GetPartDesc = GetPartDesc & " x " & GetLen
                    End If

                    'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                    'If IsNothing(GetMat) = False And GetMat <> "" Then
                    '    GetPartDesc = GetPartDesc & " - " & GetMat
                    'Else
                    '    If GetMat2 = vbNullString And GetMat3 = vbNullString Then
                    '        '---------Do Nothing is already done.           'GetPartDesc = BOMList(7, i)
                    '    Else
                    '        GetPartDesc = GetPartDesc & " - " & GetMat2 & " " & GetMat3
                    '    End If
                    'End If
                End If

                .Range("F" & RowNo).Value = GetPartDesc
                BOMList(7, i) = GetPartDesc
                'BOMListColl(7, i) = GetPartDesc

                Inv1 = BOMList(9, i)                                'Found problem were user are entering a space before the Inventory number not 
                Inv1 = LTrim(Inv1)                                  'allowing the program to find the matching Inventory number on the standards sheet.
                Inv1 = RTrim(Inv1)                                  'Modified the program here to fix issue.   DJL 03/21/2013

                .Range("G" & RowNo).Value = Inv1
                BOMList(9, i) = Inv1

                .Range("H" & RowNo).Value = BOMList(10, i)
                'BOMListColl(10, i) = BOMList(10, i)

                'If i = 5 And PrevCnt = 0 Then
                '    With BOMWrkSht
                '        With .Range("I" & RowNo & "I" & (UBound(BOMList, 2) - 1))
                '            .HorizontalAlignment = XlHAlign.xlHAlignCenter
                '            .VerticalAlignment = XlVAlign.xlVAlignCenter
                '            .Font.Name = "Arial"
                '            .Font.Size = 7
                '            .Value = BOMList(12, i) & Chr(10) & BOMList(13, i)
                '        End With
                '    End With
                'End If

                If BOMList(11, i) = vbNullString Or Mid(BOMList(11, i), 1, 1) = " " Then
                    'With BOMWrkSht
                    '    With .Range("I" & RowNo)
                    '        .HorizontalAlignment = XlHAlign.xlHAlignCenter
                    '        .VerticalAlignment = XlVAlign.xlVAlignCenter
                    '        .Font.Name = "Arial"
                    '        .Font.Size = 7
                    '        .Value = BOMList(12, i) & Chr(10) & BOMList(13, i)
                    '    End With
                    'End With

                    .Range("I" & RowNo).Value = BOMList(12, i) & Chr(10) & BOMList(13, i)
                Else
                    .Range("I" & RowNo).Value = BOMList(11, i)
                End If


                .Range("J" & RowNo).Value = BOMList(14, i)
                'BOMListColl(14, i) = BOMList(14, i)

                .Range("M" & RowNo).NumberFormat = "@"
                .Range("M" & RowNo).Value = BOMList(15, i)
                'BOMListColl(15, i) = BOMList(15, i)                         'DwgNo

                .Range("N" & RowNo).NumberFormat = "General"
                .Range("N" & RowNo).Value = BOMList(16, i)
                'BOMListColl(16, i) = BOMList(16, i)

                .Range("O" & RowNo).NumberFormat = "General"
                .Range("O" & RowNo).Value = BOMList(0, i)
                'BOMListColl(0, i) = BOMList(0, i)

                .Range("P" & RowNo).NumberFormat = "General"
                .Range("P" & RowNo).Value = BOMList(17, i)
                'BOMListColl(17, i) = BOMList(17, i)

                .Range("V" & RowNo).Value = BOMList(13, i)                          'Length
                'BOMListColl(13, i) = BOMList(13, i)

                .Range("W" & RowNo).Value = BOMList(18, i)
                'BOMListColl(18, i) = BOMList(18, i)

                .Range("X" & RowNo).Value = BOMList(19, i)          'SortList.Items.Item(i - 1)
                'BOMListColl(19, i) = BOMList(19, i)

                .Range("Y" & RowNo).Value = BOMList(0, i)                           'DJL-------11-3-2023

                If ChkBoxAutoCAD3D.Checked Then
                    .Range("T" & RowNo).Value = BOMList(12, i)
                    'BOMListColl(12, i) = BOMList(12, i)
                End If

                .Range("Z" & RowNo).Value = RowNo
                'ReDim Preserve BOMListColl(20, UBound(BOMListColl, 2) + 1)
            End With

DontAddBlankLines:  '---------------Do not Add Blank BOM Lines:
DeleteDup:
            ProgressBar1.Value = i
        Next i

        ExcelApp.WindowState = XlWindowState.xlNormal

        If IsNothing(RowNo) Then
            MsgBox("There were no BOM blocks found in any of the drawings. Please try again.")
            MainBOMFile.Close(SaveChanges:=False)
            ExcelApp.Quit()
            LblProgress.Text = ""
            Exit Function
        End If

        '-------DJL-10-11-2023           'Alreay done above in an Array
        With BOMWrkSht
            With .Range("A4:BM" & RowNo)
                .Sort(Key1:= .Range("M5"), Order1:=XlSortOrder.xlAscending, Key2:= .Range("O5"), Order2:=XlSortOrder.xlDescending, Key3:= .Range("P5"), Order3:=XlSortOrder.xlDescending, Header:=XlYesNoGuess.xlYes, OrderCustom:=1, MatchCase:=False, Orientation:=XlSortOrientation.xlSortColumns)
            End With
        End With

        '-------DJL-------11-27-2023-------New process create sort.
        k = 1
        ProgressBar1.Maximum = RowNo + 1
        RowNo = BOMWrkSht.Range("E4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row
        ReDim BOMList(20, 1)

        With BOMWrkSht
            If StrLineNo = 0 And .Range("A4").Value = "DWG" Then
                StrLineNo = 5
            End If

            For i = StrLineNo To RowNo
                GetDwgNo = .Range("M" & i).Value                            'GetDwgNo = .Range("V" & i).Value
                GetX = .Range("N" & i).Value                                'GetX = .Range("W" & i).Value
                GetY = .Range("P" & i).Value                                'GetY = .Range("O" & i).Value           'GetY = .Range("X" & i).Value
                'GetRowNo = .Range("Z" & i).Value                            'not used

                If i = 44 And GetDwgNo = Nothing Then
                    GoTo Nexti2
                Else
                    If i = 45 And GetDwgNo = Nothing Then
                        GoTo Nexti2
                    End If
                End If

                If PrevCnt = 0 Then
                    PrevCnt = 1
                End If

                For j = PrevCnt To RowNo                         'For j = PrevCnt To (UBound(BOMListColl, 2) - 1)
                    'FoundDwgNo = BOMListColl(15, j)             'ColumnV
                    'FoundX = BOMListColl(16, j)                 'ColumnW
                    'FoundY = BOMListColl(17, j)                 'ColumnX
                    'FoundItem = BOMListColl(20, j)

                    'If FoundItem = "Found" Then
                    '    If BOMListColl(20, PrevCnt) = "Found" And PrevCnt = (j - 1) Then
                    '        If BOMListColl(20, PrevCnt) = "Found" Then
                    '            PrevCnt = j
                    '        End If
                    '    Else
                    '        For l = PrevCnt To j
                    '            If BOMListColl(20, l) = "Found" And BOMListColl(20, PrevCnt) = "Found" Then
                    '                PrevCnt = l + 1
                    '            End If
                    '        Next l
                    '    End If

                    '    GoTo Nextj
                    'Else
                    '    If PrevCnt > j And BOMListColl(20, PrevCnt) = "Found" Then
                    '        PrevCnt = j
                    '    End If
                    'End If

                    'If GetDwgNo = FoundDwgNo And GetX = FoundX Then
                    '    If GetY = FoundY Then
                    BOMList(0, k) = .Range("O" & i).Value
                    BOMList(1, k) = .Range("A" & i).Value                 'ColumnC    'Job Number           'BOMList(1, k) = BOMListColl(1, j)
                    BOMList(2, k) = .Range("B" & i).Value                 'ColumnD    'Dwg No.              'BOMList(2, k) = BOMListColl(2, j)
                    BOMList(3, k) = .Range("C" & i).Value                 'ColumnE    'Rev No.              'BOMList(3, k) = BOMListColl(3, j)
                    BOMList(4, k) = .Range("E" & i).Value                 'ColumnF    'Ship No.                 'BOMList(4, k) = BOMListColl(4, j)
                    BOMList(5, k) = .Range("D" & i).Value                 'ColumnG    'Qty                      'BOMList(5, k) = BOMListColl(5, j) 
                    'BOMList(6, k) = .Range("F" & i).Value                  'ColumnH   'Desc                     'BOMList(6, k) = BOMListColl(6, j)
                    '
                    BOMList(7, k) = .Range("F" & i).Value                  'ColumnH   'Desc                     'BOMList(7, k) = BOMListColl(7, j)
                    'BOMList(8, k) = BOMListColl(8, j)                  '                                    'BOMList(8, k) = BOMListColl(8, j)

                    BOMList(9, k) = .Range("G" & i).Value                 'ColumnK    'Inv No.                  'BOMList(9, k) = BOMListColl(9, j)
                    BOMList(10, k) = .Range("H" & i).Value               'ColumnL    'Std No.                  'BOMList(10, k) = BOMListColl(10, j) 
                    BOMList(11, k) = .Range("I" & i).Value               'ColumnM    'Material                     'BOMList(11, k) = BOMListColl(11, j)
                    BOMList(12, k) = .Range("T" & i).Value               'ColumnN    'Weight                       'BOMList(12, k) = BOMListColl(12, j)

                    BOMList(13, k) = .Range("V" & i).Value                             'BOMList(13, k) = BOMListColl(13, j)
                    BOMList(14, k) = .Range("J" & i).Value                 'Weight                                 'BOMList(14, k) = BOMListColl(14, j)

                    BOMList(15, k) = .Range("M" & i).Value               'ColumnV    'Dwg No                       'BOMList(15, k) = BOMListColl(15, j)
                    BOMList(16, k) = .Range("N" & i).Value               'ColumnW    'X                            'BOMList(16, k) = BOMListColl(16, j)
                    BOMList(17, k) = .Range("P" & i).Value               'ColumnX    'Y                            'BOMList(17, k) = BOMListColl(17, j)
                    BOMList(18, k) = .Range("W" & i).Value                    '"Found"    'We know it was found just need row number.
                    BOMList(19, k) = .Range("X" & i).Value             'Drawing Number Plus X              'BOMList(19, k) = BOMListColl(19, j)
                    BOMList(20, k) = "Found"

                    'BOMListColl(20, j) = "Found"
                    'ReDim Preserve BOMListColl(20, UBound(BOMListColl, 2))
                    ReDim Preserve BOMList(20, UBound(BOMList, 2) + 1)
                    k = (k + 1)

                    'If PrevCnt + 1 = j And FoundItem <> "Found" Then
                    '    If PrevCnt < 3 And BOMListColl(18, (j - 1)) <> "Found" Then
                    '        'Do nothing             'PrevCnt = j
                    '    Else
                    '        If BOMListColl(20, (j - 1)) = "Found" And BOMListColl(20, j) = "Found" Then
                    '            If BOMListColl(20, PrevCnt) = "Found" Then
                    '                PrevCnt = j
                    '            End If
                    '        End If
                    '    End If
                    'Else
                    '    If PrevCnt = j And BOMListColl(20, j) = "Found" Then
                    '        If BOMListColl(20, PrevCnt) = "Found" Then
                    '            PrevCnt = j + 1
                    '        End If
                    '    End If
                    'End If

                    'GoTo Nexti2
                    '    Else
                    '        GoTo Nextj
                    '    End If
                    'Else
                    '    GoTo Nextj
                    'End If

Nextj:
                Next j

Nexti2:
                ProgressBar1.Value = i
            Next i

        End With


        With BOMWrkSht
            With .Range("M:V")
                .Delete(Shift:=XlDeleteShiftDirection.xlShiftUp)
            End With
        End With

        GenInfo3233.BOMList = BOMList

Err_WriteToExcel:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            DwgItem2 = CurrentDwgNo
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException
            Test = DwgItem2

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ErrNo = 9 And InStr(ErrMsg, "Index was outside the bounds of the array") > 0 Then
                Resume Next
            End If

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            If ErrNo = -2147417848 And InStr(ErrMsg, "The object invoked has disconnected") > 0 Then
                AcadApp = GetObject(, "AutoCAD.Application")
                System.Threading.Thread.Sleep(25)

                If ProblemAt = "CloseDwg" Then
                    Resume Next
                Else
                    Resume
                End If
            End If

            If ErrNo = -2145320885 And ErrMsg = "Problem in unloading DVB file" Then
                Resume Next                     'Layout.dvb was not found to be loaded
            End If

            If ErrNo = -2145320924 And InStr(ErrMsg, "is not found.") < 0 Then
                'DwgItem = VarSelArray(z)
                Resume
            End If

            CntDwgsNotFound = InStr(ErrMsg, "not a valid drawing")

            If ErrNo = -2145320825 And CntDwgsNotFound > 0 Then
                Sapi.Speak("AutoCAD found a bad Drawing, " & DwgItem & ", Going to next drawing.")
                MsgBox("AutoCAD found a bad Drawing, " & DwgItem & ", Going to next drawing.")
                BadDwgFound = "Yes"
                CntDwgsNotFound = 0
                Resume Next
            End If

            If ErrNo = 91 And ErrMsg = "Problem in unloading DVB file" Then
                Resume Next                     'Layout.dvb was not found to be loaded
            End If

            If ErrNo = 462 And Mid(ErrMsg, 1, 29) = "The RPC server is unavailable" Then
                Information.Err.Clear()
                AcadApp = CreateObject("AutoCAD.Application")
                AcadOpen = False
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If ErrNo = -2145320900 And ErrMsg = "Failed to get the Document object" Then
                If FirstDwg = "NotFound" Then
                    AcadApp.Application.Documents.Add()
                    Resume
                End If
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If

                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If

                If ErrNo = -2147418113 And ErrMsg = "Internal application error." Then
                    Information.Err.Clear()
                    AcadApp = CreateObject("AutoCAD.Application")
                    AcadOpen = False
                    Resume
                End If
            End If
        End If

    End Function

    Function WriteToExcelAfterSort(BOMList)
        '-------Move to new function-------WritetoExcel-------DJL-10-11-2023            
        '------------------------------------------------------------------------------------------------
        '-------Creator:        Dennis J. Long
        '-------Date:           1/2/2024
        '-------Description:    Write data to Excel Spreadsheet
        '-------
        '-------Updates:        Description:
        '-------1-2-2024       Read Array and write to Excel what was collected from AutoCAD.     
        '-------                
        '-------                
        '------------------------------------------------------------------------------------------------
        Dim i, j, k As Integer
        Dim DwgItem2, CurrentDwgNo, FirstDwg, GetDwgNo, GetRowNo, GetX, GetY, FoundDwgNo, FoundX, FoundY, FoundItem, TotalCnt As String
        Dim GetStdPartNo, GetMXStd, FoundStdPartNo, FoundMXStd, GetRecNo, FoundDesc, FoundMat, DelItem, StdPart, StdDwg, FoundStdQty As String
        Dim GetPrevPartNo, GetPartNo, GetDesc, GetStdDesc As String
        Dim CntDwgsNotFound, StrLineNo, PrevCnt, CntStdFound As Integer
        Dim AcadOpen As Boolean
        Dim FoundStds(20, 1)
        Dim StdsFnd2(2, 1)

        On Error GoTo Err_WriteToExcelAfterSort

        ProgressBar1.Value = 0
        Me.LblProgress.Text = "Outputting Information To Bulk BOM........Please Wait"
        Me.Refresh()

        FileSaveAS = PathBox.Text & "\" & GenInfo3233.FullJobNo & "BOM.xls"
        Workbooks = ExcelApp.Workbooks

        WorkShtName = "Bulk BOM"
        BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
        WorkSht = Workbooks.Application.ActiveSheet
        WorkShtName = WorkSht.Name

        With BOMWrkSht
            .Range("C3").Value = GenInfo3233.FullJobNo
            .Range("J3").Value = Today
            .Range("G3").Value = Me.ComboBxRev.Text
        End With

        FileToOpen = "Bulk BOM"
        ExcelApp.Visible = True
        Test = (UBound(BOMList, 2) - 1)
        TotalCnt = (UBound(BOMList, 2) - 1)
        ExcelApp.WindowState = XlWindowState.xlMinimized            'Minimize Excel so user can see dialogs from program
        FirstTimeThru = "Yes"
        StdsFnd2 = GenInfo3233.StdsFnd2
        StdsBOMList = GenInfo3233.StdsBOMList            'CollectSTDsList = GenInfo3233.CollectSTDsList

        For i = 1 To (UBound(BOMList, 2) - 1)
            If i = 1 Then
                RowNo = i + 4
            Else
                RowNo = RowNo + 1
            End If

            ProgressBar1.Maximum = (UBound(BOMList, 2) - 1)

            If RowNo = "5" And FirstTimeThru = "Yes" Then
                BOMWrkSht.Activate()
                FormatLine(RowNo, FileToOpen)
                FirstTimeThru = "No"

                With BOMWrkSht         '-----------------------Do Not need to format everyline, Speeds up Process.
                    .Rows(RowNo & ":" & RowNo).Select()
                    .Rows(RowNo & ":" & RowNo).Insert()
                End With
                'Else
                '    With BOMWrkSht         '-----------------------Do Not need to format everyline, Speeds up Process.
                '        .Rows(RowNo & ":" & RowNo).Select()            '-------Moved below.
                '        .Rows(RowNo & ":" & RowNo).Insert()
                '    End With
            End If

            DelItem = BOMList(1, i)
            StdPart = BOMList(9, i)
            StdDwg = BOMList(10, i)

            If InStr(DelItem, "Delete") = 0 Then

                With BOMWrkSht
                    .Rows(RowNo & ":" & RowNo).Select()
                    .Rows(RowNo & ":" & RowNo).Insert()

                    .Range("A" & RowNo).Value = BOMList(13, i)
                    .Range("B" & RowNo).Value = BOMList(1, i)
                    .Range("C" & RowNo).Value = BOMList(2, i)
                    .Range("D" & RowNo).Value = BOMList(3, i)
                    .Range("E" & RowNo).Value = BOMList(5, i)
                    .Range("F" & RowNo).Value = BOMList(4, i)
                    .Range("G" & RowNo).Value = BOMList(7, i)
                    .Range("H" & RowNo).Value = BOMList(9, i)
                    .Range("I" & RowNo).Value = BOMList(10, i)
                    .Range("J" & RowNo).Value = BOMList(11, i)
                    .Range("K" & RowNo).Value = BOMList(14, i)
                    .Range("N" & RowNo).Value = BOMList(15, i)
                    .Range("O" & RowNo).Value = BOMList(16, i)
                    .Range("P" & RowNo).Value = BOMList(0, i)
                    .Range("Q" & RowNo).Value = BOMList(17, i)
                    .Range("R" & RowNo).Value = BOMList(8, i)
                    '.Range("W" & RowNo).Value = BOMList(13, i)                          'Length
                    .Range("W" & RowNo).Value = BOMList(18, i)          'Y
                    .Range("Z" & RowNo).Value = BOMList(19, i)
                    .Range("AA" & RowNo).Value = BOMList(0, i)
                    .Range("AB" & RowNo).Value = BOMList(19, i)
                    'End With

                    If BOMList(9, i) <> "" Or BOMList(10, i) <> "" Then
                        GetStdPartNo = BOMList(9, i)
                        GetMXStd = BOMList(10, i)
                        'FindStdInfo:

                        For l = 1 To (UBound(StdsFnd2, 2) - 1)                         'For l = 5 To (UBound(STDsFnd2, 2) - 1)      'For i = 5 To RowNo
                            'GetStdPartNo = StdsFnd2(0, l)                              'Done above --------DJL-------2-9-2024
                            'GetMXStd = StdsFnd2(1, l)
                            'GetRecNo = StdsFnd2(2, l)

                            For m = 5 To (UBound(StdsBOMList, 2) - 1)
                                FoundStdQty = StdsBOMList(4, m)
                                FoundStdPartNo = StdsBOMList(9, m)
                                FoundMXStd = StdsBOMList(10, m)

                                If GetStdPartNo = FoundStdPartNo And GetMXStd = FoundMXStd Then
                                    PartFound = "Yes"
                                    'RowNo = (RowNo + 1)                    'Creates a duplicate header or Assembly Item but is good if you are hunting for errors.
                                    '.Rows(RowNo & ":" & RowNo).Select()
                                    '.Rows(RowNo & ":" & RowNo).Insert()

                                    '.Range("B" & RowNo).Value = StdsBOMList(1, m) 'ColumnA    'Dwg No.
                                    '.Range("C" & RowNo).Value = StdsBOMList(2, m) 'ColumnB    'Rev No.
                                    '.Range("D" & RowNo).Value = StdsBOMList(3, m) 'ColumnC    'Ship No.
                                    '.Range("F" & RowNo).Value = StdsBOMList(4, m) 'ColumnD    'Qty 
                                    '.Range("E" & RowNo).Value = StdsBOMList(5, m) 'ColumnE    'Part No.
                                    '.Range("G" & RowNo).Value = StdsBOMList(7, m) 'ColumnH   'Desc 
                                    '.Range("H" & RowNo).Value = StdsBOMList(9, m) 'ColumnL    'Std No. 
                                    '.Range("I" & RowNo).Value = StdsBOMList(10, m) 'ColumnK    'Inv No.
                                    '.Range("J" & RowNo).Value = StdsBOMList(11, m) 'ColumnM    'Material                                   
                                    '.Range("K" & RowNo).Value = StdsBOMList(14, m) 'ColumnN    'Weight

                                    '-------New probleem Trevor is want the Bolt, Nut, and Gasket information on the standards.
                                    GetDesc = BOMList(7, i)
                                    GetPartNo = BOMList(5, i)
                                    GetPrevPartNo = StdsBOMList(5, (m - 1))
                                    GetStdDesc = StdsBOMList(7, m)
                                    FoundStdQty = StdsBOMList(4, m)

                                    If InStr(GetDesc, "BOLT") > 0 Then         'If InStr(GetDesc, "BOLT") > 0 And GetDesc = GetStdDesc Then        'Per Trevor Ruffin do not check description
                                        'If FoundStdQty <> "" Then
                                        RowNo = (RowNo + 1)
                                        .Rows(RowNo & ":" & RowNo).Select()
                                        .Rows(RowNo & ":" & RowNo).Insert()

                                        .Range("B" & RowNo).Value = StdsBOMList(1, m) 'ColumnA    'Dwg No.
                                        .Range("C" & RowNo).Value = StdsBOMList(2, m) 'ColumnB    'Rev No.
                                        .Range("D" & RowNo).Value = StdsBOMList(3, m) 'ColumnC    'Ship No.
                                        .Range("F" & RowNo).Value = StdsBOMList(4, m) 'ColumnD    'Qty 
                                        .Range("E" & RowNo).Value = StdsBOMList(5, m) 'ColumnE    'Part No.
                                        .Range("G" & RowNo).Value = StdsBOMList(7, m) 'ColumnH   'Desc 
                                        .Range("H" & RowNo).Value = StdsBOMList(9, m) 'ColumnL    'Std No. 
                                        .Range("I" & RowNo).Value = StdsBOMList(10, m) 'ColumnK    'Inv No.
                                        .Range("J" & RowNo).Value = StdsBOMList(11, m) 'ColumnM    'Material                                   
                                        .Range("K" & RowNo).Value = StdsBOMList(14, m) 'ColumnN    'Weight    
                                        GoTo Nextm
                                        'End If
                                    Else
                                        If InStr(GetDesc, "NUTS") > 0 Then     'If InStr(GetDesc, "NUTS") > 0 And GetDesc = GetStdDesc Then        'Per Trevor Ruffin do not check description
                                            'If FoundStdQty <> "" Then
                                            RowNo = (RowNo + 1)
                                            .Rows(RowNo & ":" & RowNo).Select()
                                            .Rows(RowNo & ":" & RowNo).Insert()

                                            .Range("B" & RowNo).Value = StdsBOMList(1, m) 'ColumnA    'Dwg No.
                                            .Range("C" & RowNo).Value = StdsBOMList(2, m) 'ColumnB    'Rev No.
                                            .Range("D" & RowNo).Value = StdsBOMList(3, m) 'ColumnC    'Ship No.
                                            .Range("F" & RowNo).Value = StdsBOMList(4, m) 'ColumnD    'Qty 
                                            .Range("E" & RowNo).Value = StdsBOMList(5, m) 'ColumnE    'Part No.
                                            .Range("G" & RowNo).Value = StdsBOMList(7, m) 'ColumnH   'Desc 
                                            .Range("H" & RowNo).Value = StdsBOMList(9, m) 'ColumnL    'Std No. 
                                            .Range("I" & RowNo).Value = StdsBOMList(10, m) 'ColumnK    'Inv No.
                                            .Range("J" & RowNo).Value = StdsBOMList(11, m) 'ColumnM    'Material                                   
                                            .Range("K" & RowNo).Value = StdsBOMList(14, m) 'ColumnN    'Weight    
                                            GoTo Nextm
                                            'End If
                                        Else
                                            If InStr(GetDesc, "GASKET") > 0 Then       'If InStr(GetDesc, "GASKET") > 0 And GetDesc = GetStdDesc Then        'Per Trevor Ruffin do not check description
                                                'If FoundStdQty <> "" Then
                                                RowNo = (RowNo + 1)
                                                .Rows(RowNo & ":" & RowNo).Select()
                                                .Rows(RowNo & ":" & RowNo).Insert()

                                                .Range("B" & RowNo).Value = StdsBOMList(1, m) 'ColumnA    'Dwg No.
                                                .Range("C" & RowNo).Value = StdsBOMList(2, m) 'ColumnB    'Rev No.
                                                .Range("D" & RowNo).Value = StdsBOMList(3, m) 'ColumnC    'Ship No.
                                                .Range("F" & RowNo).Value = StdsBOMList(4, m) 'ColumnD    'Qty 
                                                .Range("E" & RowNo).Value = StdsBOMList(5, m) 'ColumnE    'Part No.
                                                .Range("G" & RowNo).Value = StdsBOMList(7, m) 'ColumnH   'Desc 
                                                .Range("H" & RowNo).Value = StdsBOMList(9, m) 'ColumnL    'Std No. 
                                                .Range("I" & RowNo).Value = StdsBOMList(10, m) 'ColumnK    'Inv No.
                                                .Range("J" & RowNo).Value = StdsBOMList(11, m) 'ColumnM    'Material                                   
                                                .Range("K" & RowNo).Value = StdsBOMList(14, m) 'ColumnN    'Weight    
                                                GoTo Nextm
                                                'End If
                                            End If
                                        End If
                                    End If
                                    '--------------------------------------------------------------------------------------------

                                Else
                                    If PartFound = "Yes" Then
                                        If FoundStdPartNo = "" And FoundMXStd = "" Then         'There are times when parts only have one reference, and there are times when many parts are part of an assembly or Standard.
                                            If FoundStdQty <> "" Then
                                                RowNo = (RowNo + 1)
                                                .Rows(RowNo & ":" & RowNo).Select()
                                                .Rows(RowNo & ":" & RowNo).Insert()

                                                .Range("B" & RowNo).Value = StdsBOMList(1, m) 'ColumnA    'Dwg No.
                                                .Range("C" & RowNo).Value = StdsBOMList(2, m) 'ColumnB    'Rev No.
                                                .Range("D" & RowNo).Value = StdsBOMList(3, m) 'ColumnC    'Ship No.
                                                .Range("F" & RowNo).Value = StdsBOMList(4, m) 'ColumnD    'Qty 
                                                .Range("E" & RowNo).Value = StdsBOMList(5, m) 'ColumnE    'Part No.
                                                .Range("G" & RowNo).Value = StdsBOMList(7, m) 'ColumnH   'Desc 
                                                .Range("H" & RowNo).Value = StdsBOMList(9, m) 'ColumnL    'Std No. 
                                                .Range("I" & RowNo).Value = StdsBOMList(10, m) 'ColumnK    'Inv No.
                                                .Range("J" & RowNo).Value = StdsBOMList(11, m) 'ColumnM    'Material                                   
                                                .Range("K" & RowNo).Value = StdsBOMList(14, m) 'ColumnN    'Weight    
                                            End If
                                        Else
                                            GetDesc = StdsBOMList(7, m)
                                            GetPartNo = StdsBOMList(5, m)
                                            GetPrevPartNo = StdsBOMList(5, (m - 1))

                                            If InStr(GetDesc, "BOLT") > 0 And GetPartNo > GetPrevPartNo Then
                                                If FoundStdQty <> "" Then
                                                    RowNo = (RowNo + 1)
                                                    .Rows(RowNo & ":" & RowNo).Select()
                                                    .Rows(RowNo & ":" & RowNo).Insert()

                                                    .Range("B" & RowNo).Value = StdsBOMList(1, m) 'ColumnA    'Dwg No.
                                                    .Range("C" & RowNo).Value = StdsBOMList(2, m) 'ColumnB    'Rev No.
                                                    .Range("D" & RowNo).Value = StdsBOMList(3, m) 'ColumnC    'Ship No.
                                                    .Range("F" & RowNo).Value = StdsBOMList(4, m) 'ColumnD    'Qty 
                                                    .Range("E" & RowNo).Value = StdsBOMList(5, m) 'ColumnE    'Part No.
                                                    .Range("G" & RowNo).Value = StdsBOMList(7, m) 'ColumnH   'Desc 
                                                    .Range("H" & RowNo).Value = StdsBOMList(9, m) 'ColumnL    'Std No. 
                                                    .Range("I" & RowNo).Value = StdsBOMList(10, m) 'ColumnK    'Inv No.
                                                    .Range("J" & RowNo).Value = StdsBOMList(11, m) 'ColumnM    'Material                                   
                                                    .Range("K" & RowNo).Value = StdsBOMList(14, m) 'ColumnN    'Weight    
                                                    GoTo Nextm
                                                End If
                                            Else
                                                If InStr(GetDesc, "NUTS") > 0 And GetPartNo > GetPrevPartNo Then
                                                    If FoundStdQty <> "" Then
                                                        RowNo = (RowNo + 1)
                                                        .Rows(RowNo & ":" & RowNo).Select()
                                                        .Rows(RowNo & ":" & RowNo).Insert()

                                                        .Range("B" & RowNo).Value = StdsBOMList(1, m) 'ColumnA    'Dwg No.
                                                        .Range("C" & RowNo).Value = StdsBOMList(2, m) 'ColumnB    'Rev No.
                                                        .Range("D" & RowNo).Value = StdsBOMList(3, m) 'ColumnC    'Ship No.
                                                        .Range("F" & RowNo).Value = StdsBOMList(4, m) 'ColumnD    'Qty 
                                                        .Range("E" & RowNo).Value = StdsBOMList(5, m) 'ColumnE    'Part No.
                                                        .Range("G" & RowNo).Value = StdsBOMList(7, m) 'ColumnH   'Desc 
                                                        .Range("H" & RowNo).Value = StdsBOMList(9, m) 'ColumnL    'Std No. 
                                                        .Range("I" & RowNo).Value = StdsBOMList(10, m) 'ColumnK    'Inv No.
                                                        .Range("J" & RowNo).Value = StdsBOMList(11, m) 'ColumnM    'Material                                   
                                                        .Range("K" & RowNo).Value = StdsBOMList(14, m) 'ColumnN    'Weight    
                                                        GoTo Nextm
                                                    End If
                                                Else
                                                    If InStr(GetDesc, "GASKET") > 0 And GetPartNo > GetPrevPartNo Then
                                                        If FoundStdQty <> "" Then
                                                            RowNo = (RowNo + 1)
                                                            .Rows(RowNo & ":" & RowNo).Select()
                                                            .Rows(RowNo & ":" & RowNo).Insert()

                                                            .Range("B" & RowNo).Value = StdsBOMList(1, m) 'ColumnA    'Dwg No.
                                                            .Range("C" & RowNo).Value = StdsBOMList(2, m) 'ColumnB    'Rev No.
                                                            .Range("D" & RowNo).Value = StdsBOMList(3, m) 'ColumnC    'Ship No.
                                                            .Range("F" & RowNo).Value = StdsBOMList(4, m) 'ColumnD    'Qty 
                                                            .Range("E" & RowNo).Value = StdsBOMList(5, m) 'ColumnE    'Part No.
                                                            .Range("G" & RowNo).Value = StdsBOMList(7, m) 'ColumnH   'Desc 
                                                            .Range("H" & RowNo).Value = StdsBOMList(9, m) 'ColumnL    'Std No. 
                                                            .Range("I" & RowNo).Value = StdsBOMList(10, m) 'ColumnK    'Inv No.
                                                            .Range("J" & RowNo).Value = StdsBOMList(11, m) 'ColumnM    'Material                                   
                                                            .Range("K" & RowNo).Value = StdsBOMList(14, m) 'ColumnN    'Weight    
                                                            GoTo Nextm
                                                        End If
                                                    End If
                                                End If
                                            End If

                                            If GetStdPartNo <> FoundStdPartNo Then           'If GetStdPartNo <> FoundStdPartNo And GetMXStd <> FoundMXStd Then
                                                GoTo LastItemFound                          'It is possible to have additional parts on same Standard.
                                            End If
                                        End If
                                    End If
                                End If

                                'Nextj:
Nextm:
                                If m = (UBound(StdsBOMList, 2) - 1) Then
                                    GoTo LastItemFound
                                End If
                            Next m

NextL:
                        Next l
                    End If
                End With

                '                    GoTo FindStdInfo
                'FndNextStd:
            Else
                If StdPart <> "" Or StdDwg <> "" Then
                    If StdPart = " " Or StdDwg = " " Then
                        GoTo FoundSpace
                    Else
                        Stop
                    End If
                End If

FoundSpace:
                RowNo = (RowNo - 1)
            End If

LastItemFound:
            PartFound = "No"
            ProgressBar1.Value = i
        Next i

        ExcelApp.WindowState = XlWindowState.xlNormal

        If IsNothing(RowNo) Then
            MsgBox("There were no BOM blocks found in any of the drawings. Please try again.")
            MainBOMFile.Close(SaveChanges:=False)
            ExcelApp.Quit()
            LblProgress.Text = ""
            Exit Function
        End If

        k = 1
        ProgressBar1.Maximum = UBound(BOMList, 2)
        'RowNo = StdsWrkSht.Range("E4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row

        'FindStdInfo:                       'Moved Above-------DJL-2-9-2024
        '        StdsFnd2 = GenInfo3233.StdsFnd2
        '        StdsBOMList = GenInfo3233.StdsBOMList            'CollectSTDsList = GenInfo3233.CollectSTDsList

        '        '                                                               With StdsWrkSht
        '        For l = 1 To (UBound(StdsFnd2, 2) - 1)                         'For l = 5 To (UBound(STDsFnd2, 2) - 1)      'For i = 5 To RowNo
        '            'GetStdPartNo = StdsFnd2(0, l)                              'Done above --------DJL-------2-9-2024
        '            'GetMXStd = StdsFnd2(1, l)
        '            'GetRecNo = StdsFnd2(2, l)

        '            For m = 5 To (UBound(StdsBOMList, 2) - 1)
        '                FoundStdPartNo = StdsBOMList(9, m)
        '                FoundMXStd = StdsBOMList(10, m)
        '                'GetRecNo = StdsBOMList(20, m)        'Does not exist in this Array

        '                If GetStdPartNo = FoundStdPartNo And GetMXStd = FoundMXStd Then
        '                    PartFound = "Yes"
        '                    FoundStds(0, k) = StdsBOMList(0, m)
        '                    FoundStds(1, k) = StdsBOMList(1, m)                 'ColumnC    'Job Number        
        '                    FoundStds(2, k) = StdsBOMList(2, m)                'ColumnD    'Dwg No.            
        '                    FoundStds(3, k) = StdsBOMList(3, m)                 'ColumnE    'Rev No.             
        '                    FoundStds(4, k) = StdsBOMList(4, m)                 'ColumnF    'Ship No.         
        '                    FoundStds(5, k) = StdsBOMList(5, m)                 'ColumnG    'Qty         

        '                    FoundStds(7, k) = StdsBOMList(7, m)                  'ColumnH   'Desc            

        '                    FoundStds(9, k) = StdsBOMList(9, m)                 'ColumnK    'Inv No.            
        '                    FoundStds(10, k) = StdsBOMList(10, m)              'ColumnL    'Std No.                 
        '                    FoundStds(11, k) = StdsBOMList(11, m)               'ColumnM    'Material                    
        '                    FoundStds(12, k) = StdsBOMList(12, m)               'ColumnN    'Weight                      

        '                    FoundStds(13, k) = StdsBOMList(13, m)
        '                    FoundStds(14, k) = StdsBOMList(14, m)                 'Weight                                 

        '                    FoundStds(15, k) = StdsBOMList(15, m)               'ColumnV    'Dwg No                       
        '                    FoundStds(16, k) = StdsBOMList(16, m)               'ColumnW    'X                            
        '                    FoundStds(17, k) = StdsBOMList(17, m)               'ColumnX    'Y                            
        '                    FoundStds(18, k) = StdsBOMList(18, m)
        '                    FoundStds(19, k) = StdsBOMList(19, m)
        '                    FoundStds(20, k) = GetRecNo
        '                    ReDim Preserve FoundStds(20, UBound(FoundStds, 2) + 1)
        '                    k = (k + 1)
        '                Else
        '                    If PartFound = "Yes" Then
        '                        If FoundStdPartNo = "" And FoundMXStd = "" Then         'There are times when parts only have one reference, and there are times when many parts are part of an assembly or Standard.
        '                            FoundStds(0, k) = StdsBOMList(0, m)
        '                            FoundStds(1, k) = StdsBOMList(1, m)                 'ColumnC    'Job Number        
        '                            FoundStds(2, k) = StdsBOMList(2, m)                'ColumnD    'Dwg No.            
        '                            FoundStds(3, k) = StdsBOMList(3, m)                 'ColumnE    'Rev No.             
        '                            FoundStds(4, k) = StdsBOMList(4, m)                 'ColumnF    'Ship No.         
        '                            FoundStds(5, k) = StdsBOMList(5, m)                 'ColumnG    'Qty         

        '                            FoundStds(7, k) = StdsBOMList(7, m)                  'ColumnH   'Desc            

        '                            FoundStds(9, k) = StdsBOMList(9, m)                 'ColumnK    'Inv No.            
        '                            FoundStds(10, k) = StdsBOMList(10, m)              'ColumnL    'Std No.                 
        '                            FoundStds(11, k) = StdsBOMList(11, m)               'ColumnM    'Material                    
        '                            FoundStds(12, k) = StdsBOMList(12, m)               'ColumnN    'Weight                      

        '                            FoundStds(13, k) = StdsBOMList(13, m)
        '                            FoundStds(14, k) = StdsBOMList(14, m)                 'Weight                                 

        '                            FoundStds(15, k) = StdsBOMList(15, m)               'ColumnV    'Dwg No                       
        '                            FoundStds(16, k) = StdsBOMList(16, m)               'ColumnW    'X                            
        '                            FoundStds(17, k) = StdsBOMList(17, m)               'ColumnX    'Y                            
        '                            FoundStds(18, k) = StdsBOMList(18, m)
        '                            FoundStds(19, k) = StdsBOMList(19, m)
        '                            FoundStds(20, k) = GetRecNo
        '                            ReDim Preserve FoundStds(20, UBound(FoundStds, 2) + 1)
        '                            k = (k + 1)
        '                        Else
        '                            If GetStdPartNo <> FoundStdPartNo Then           'If GetStdPartNo <> FoundStdPartNo And GetMXStd <> FoundMXStd Then
        '                                GoTo LastItemFound                          'It is possible to have additional parts on same Standard.
        '                            End If
        '                        End If
        '                    End If
        '                End If

        'Nextj:
        '            Next m

        'LastItemFound:
        '            CntStdFound = (UBound(FoundStds, 2) - 1)

        '            For n = 1 To CntStdFound                        'For n = 1 To (UBound(FoundStds, 2) - 1)
        '                FoundDesc = FoundStds(7, n)
        '                FoundStdPartNo = FoundStds(9, n)
        '                FoundMXStd = FoundStds(10, n)
        '                FoundMat = FoundStds(11, n)
        '                'GetRecNo = StdsBOMList(20, n)        'Does not exist in this Array

        '                If GetStdPartNo = FoundStdPartNo And GetMXStd = FoundMXStd Then



        '                    With BOMWrkSht
        '                        GetPartDesc = .Range("F" & GetRecNo).Value          'Found Problem where record numbers are not in order.
        '                    End With

        '                    If FoundDesc & " - " & FoundMat = GetPartDesc Then
        '                        If n < CntStdFound Then
        '                            GoTo Nextn
        '                        Else
        '                            With BOMWrkSht
        '                                '.Rows(GetRecNo & ":" & GetRecNo).Select()                                                                                                                                                                                      
        '                                '.Rows((GetRecNo + 1) & ":" & (GetRecNo + 1)).Insert()
        '                                .Range("R" & GetRecNo).Value = "Reference Only"                         'Yes this tells us that Standard was found and has no additional parts.
        '                            End With
        '                        End If

        '                        GoTo Nextl
        '                    End If
        '                Else
        '                    If FoundStdPartNo = "" And FoundMXStd = "" Then
        '                        With BOMWrkSht
        '                            If n < 3 Then
        '                                .Rows(GetRecNo & ":" & GetRecNo).Select()
        '                                .Rows((GetRecNo + 1) & ":" & (GetRecNo + 1)).Insert()
        '                                '.Range("A" & GetRecNo & ":Z" & GetRecNo).Value = ""            'Not required.

        '                                .Range("A" & (GetRecNo + 1)).Value = FoundStds(1, n)                'ColumnC    'Job Number        
        '                                .Range("B" & (GetRecNo + 1)).Value = FoundStds(2, n)                 'ColumnD    'Dwg No.            
        '                                .Range("C" & (GetRecNo + 1)).Value = FoundStds(3, n)                 'ColumnE    'Rev No.             
        '                                .Range("E" & (GetRecNo + 1)).Value = FoundStds(4, n)                 'ColumnF    'Ship No.         
        '                                .Range("D" & (GetRecNo + 1)).Value = FoundStds(5, n)                 'ColumnG    'Qty         

        '                                .Range("F" & (GetRecNo + 1)).Value = FoundStds(7, n)                 'ColumnH   'Desc            

        '                                .Range("G" & (GetRecNo + 1)).Value = FoundStds(9, n)                'ColumnK    'Inv No.            
        '                                .Range("H" & (GetRecNo + 1)).Value = FoundStds(10, n)              'ColumnL    'Std No.                 
        '                                .Range("I" & (GetRecNo + 1)).Value = FoundStds(11, n)              'ColumnM    'Material                    
        '                                .Range("T" & (GetRecNo + 1)).Value = FoundStds(12, n)              'ColumnN    'Weight                      

        '                                .Range("V" & (GetRecNo + 1)).Value = FoundStds(13, n)
        '                                .Range("J" & (GetRecNo + 1)).Value = FoundStds(14, n)                'Weight                                 

        '                                .Range("M" & (GetRecNo + 1)).Value = FoundStds(15, n)               'ColumnV    'Dwg No                       
        '                                .Range("N" & (GetRecNo + 1)).Value = FoundStds(16, n)              'ColumnW    'X                            
        '                                .Range("P" & (GetRecNo + 1)).Value = FoundStds(17, n)               'ColumnX    'Y                            
        '                                .Range("W" & (GetRecNo + 1)).Value = FoundStds(18, n)                   '"Found"    'We know it was found just need row number.
        '                                .Range("X" & (GetRecNo + 1)).Value = FoundStds(19, n)            'Drawing Number Plus X  
        '                            Else
        '                                .Rows((GetRecNo + (n - 2)) & ":" & (GetRecNo + (n - 2))).Select()
        '                                .Rows((GetRecNo + (n - 1)) & ":" & (GetRecNo + (n - 1))).Insert()

        '                                .Range("A" & (GetRecNo + (n - 1))).Value = FoundStds(1, n)                'ColumnC    'Job Number        
        '                                .Range("B" & (GetRecNo + (n - 1))).Value = FoundStds(2, n)                 'ColumnD    'Dwg No.            
        '                                .Range("C" & (GetRecNo + (n - 1))).Value = FoundStds(3, n)                 'ColumnE    'Rev No.             
        '                                .Range("E" & (GetRecNo + (n - 1))).Value = FoundStds(4, n)                 'ColumnF    'Ship No.         
        '                                .Range("D" & (GetRecNo + (n - 1))).Value = FoundStds(5, n)                 'ColumnG    'Qty         

        '                                .Range("F" & (GetRecNo + (n - 1))).Value = FoundStds(7, n)                 'ColumnH   'Desc            

        '                                .Range("G" & (GetRecNo + (n - 1))).Value = FoundStds(9, n)                'ColumnK    'Inv No.            
        '                                .Range("H" & (GetRecNo + (n - 1))).Value = FoundStds(10, n)              'ColumnL    'Std No.                 
        '                                .Range("I" & (GetRecNo + (n - 1))).Value = FoundStds(11, n)              'ColumnM    'Material                    
        '                                .Range("T" & (GetRecNo + (n - 1))).Value = FoundStds(12, n)              'ColumnN    'Weight                      

        '                                .Range("V" & (GetRecNo + (n - 1))).Value = FoundStds(13, n)
        '                                .Range("J" & (GetRecNo + (n - 1))).Value = FoundStds(14, n)                'Weight                                 

        '                                .Range("M" & (GetRecNo + (n - 1))).Value = FoundStds(15, n)               'ColumnV    'Dwg No                       
        '                                .Range("N" & (GetRecNo + (n - 1))).Value = FoundStds(16, n)              'ColumnW    'X                            
        '                                .Range("P" & (GetRecNo + (n - 1))).Value = FoundStds(17, n)               'ColumnX    'Y                            
        '                                .Range("W" & (GetRecNo + (n - 1))).Value = FoundStds(18, n)                   '"Found"    'We know it was found just need row number.
        '                                .Range("X" & (GetRecNo + (n - 1))).Value = FoundStds(19, n)            'Drawing Number Plus X  
        '                            End If
        '                        End With
        '                    End If
        '                End If
        'Nextn:
        '            Next n

        'Nextl:
        '            k = 1
        '            ReDim FoundStds(20, 1)
        '            PartFound = "No"
        '            ProgressBar1.Value = i
        '        Next l

        'GoTo FndNextStd


        '    With BOMWrkSht
        '    If StrLineNo = 0 And .Range("A4").Value = "DWG" Then
        '        StrLineNo = 5
        '    End If

        '    For i = StrLineNo To RowNo
        '        GetDwgNo = .Range("M" & i).Value
        '        GetX = .Range("N" & i).Value
        '        GetY = .Range("P" & i).Value

        '        'If i = 44 And GetDwgNo = Nothing Then
        '        '    GoTo Nexti2
        '        'Else
        '        '    If i = 45 And GetDwgNo = Nothing Then
        '        '        GoTo Nexti2
        '        '    End If
        '        'End If

        '        If PrevCnt = 0 Then
        '            PrevCnt = 1
        '        End If

        '        For j = PrevCnt To RowNo
        '            BOMList(0, k) = .Range("O" & i).Value
        '            BOMList(1, k) = .Range("A" & i).Value                 'ColumnC    'Job Number        
        '            BOMList(2, k) = .Range("B" & i).Value                 'ColumnD    'Dwg No.            
        '            BOMList(3, k) = .Range("C" & i).Value                 'ColumnE    'Rev No.             
        '            BOMList(4, k) = .Range("E" & i).Value                 'ColumnF    'Ship No.         
        '            BOMList(5, k) = .Range("D" & i).Value                 'ColumnG    'Qty         

        '            BOMList(7, k) = .Range("F" & i).Value                  'ColumnH   'Desc            

        '            BOMList(9, k) = .Range("G" & i).Value                 'ColumnK    'Inv No.            
        '            BOMList(10, k) = .Range("H" & i).Value               'ColumnL    'Std No.                 
        '            BOMList(11, k) = .Range("I" & i).Value               'ColumnM    'Material                    
        '            BOMList(12, k) = .Range("T" & i).Value               'ColumnN    'Weight                      

        '            BOMList(13, k) = .Range("V" & i).Value
        '            BOMList(14, k) = .Range("J" & i).Value                 'Weight                                 

        '            BOMList(15, k) = .Range("M" & i).Value               'ColumnV    'Dwg No                       
        '            BOMList(16, k) = .Range("N" & i).Value               'ColumnW    'X                            
        '            BOMList(17, k) = .Range("P" & i).Value               'ColumnX    'Y                            
        '            BOMList(18, k) = .Range("W" & i).Value                    '"Found"    'We know it was found just need row number.
        '            BOMList(19, k) = .Range("X" & i).Value             'Drawing Number Plus X              
        '            BOMList(20, k) = "Found"
        '            ReDim Preserve BOMList(20, UBound(BOMList, 2) + 1)
        '            k = (k + 1)

        '            'Nextj:
        '        Next j

        '        'Nexti2:
        '        ProgressBar1.Value = i
        '    Next i

        'End With


        'With BOMWrkSht
        '    With .Range("M:V")
        '        .Delete(Shift:=XlDeleteShiftDirection.xlShiftUp)
        '    End With
        'End With

        'GenInfo3233.BOMList = BOMList

Err_WriteToExcelAfterSort:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            DwgItem2 = CurrentDwgNo
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException
            Test = DwgItem2

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ErrNo = 9 And InStr(ErrMsg, "Index was outside the bounds of the array") > 0 Then
                Resume Next
            End If

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            If ErrNo = -2147417848 And InStr(ErrMsg, "The object invoked has disconnected") > 0 Then
                AcadApp = GetObject(, "AutoCAD.Application")
                System.Threading.Thread.Sleep(25)

                If ProblemAt = "CloseDwg" Then
                    Resume Next
                Else
                    Resume
                End If
            End If

            If ErrNo = -2145320885 And ErrMsg = "Problem in unloading DVB file" Then
                Resume Next                     'Layout.dvb was not found to be loaded
            End If

            If ErrNo = -2145320924 And InStr(ErrMsg, "is not found.") < 0 Then
                'DwgItem = VarSelArray(z)
                Resume
            End If

            CntDwgsNotFound = InStr(ErrMsg, "not a valid drawing")

            If ErrNo = -2145320825 And CntDwgsNotFound > 0 Then
                Sapi.Speak("AutoCAD found a bad Drawing, " & DwgItem & ", Going to next drawing.")
                MsgBox("AutoCAD found a bad Drawing, " & DwgItem & ", Going to next drawing.")
                BadDwgFound = "Yes"
                CntDwgsNotFound = 0
                Resume Next
            End If

            If ErrNo = 91 And ErrMsg = "Problem in unloading DVB file" Then
                Resume Next                     'Layout.dvb was not found to be loaded
            End If

            If ErrNo = 462 And Mid(ErrMsg, 1, 29) = "The RPC server is unavailable" Then
                Information.Err.Clear()
                AcadApp = CreateObject("AutoCAD.Application")
                AcadOpen = False
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If ErrNo = -2145320900 And ErrMsg = "Failed to get the Document object" Then
                If FirstDwg = "NotFound" Then
                    AcadApp.Application.Documents.Add()
                    Resume
                End If
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If

                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If

                If ErrNo = -2147418113 And ErrMsg = "Internal application error." Then
                    Information.Err.Clear()
                    AcadApp = CreateObject("AutoCAD.Application")
                    AcadOpen = False
                    Resume
                End If
            End If
        End If

    End Function
    Public Function DelHeaders(ByVal FileSaveAS As String)
        Dim LookForStd, LookForShipMk, FoundLast, LineNo, LineNo3, LineNo4, FoundRev As String
        Dim OldRef, MxPcMk, CurrentStdNo, MissingTxt1, MissingTxt2, MissingTxt3, WorkShtName As String
        Dim OldDwg, OldRev, OldShpMk, OldPcMk, OldQty, OldDesc, OldDesc2, OldInv, OldStd, OldMatl As String
        Dim FiletoOpen2, WorkShtFabName, OldItem, OldSC, OldCommodity, OldWhse, OldOnHand, OldUM As String
        Dim PartNo, MatType, Coating1, Coating2, FindDesc, GetMatType, SearchMat As String
        Dim OldUnitCost, OldExtCost, OldStkMfgAssy, Transfer, GetMatType1, GetMatType2, FindDesc2 As String
        Dim GetPartNo, GetStdDwgNo, GetFndStd, GetFndStd2, GetShipMk, GetPieceMk, ItemNo As String
        Dim NutsNo, AddMat, FirstPart1, FirstPart2, GetMatLen As String
        Dim PrevInchPos, WithPos, HHPos, A1942HPos, A563APos, SpacePos, MatPos As Integer
        Dim i, j, k, i1, x, Count, Shopwatch, CntWorkbook, CntWrkShts, CountVal, CutCount, Testi As Integer
        Dim RowNo, LineNo2, DashPos, GetMatQty, MachineBoltPos, TotalMatCnt, FoundRolled As Integer
        Dim AddRolled As Double
        Dim WorkBooks2 As Workbooks
        Dim WorkbookEpicorFile As Workbooks
        Dim BOMWrkSht As Worksheet
        Dim WorkSht As Worksheet
        Dim FabInvListWrkSht As Worksheet
        Dim WorkShtFab As Worksheet
        Dim BOMFabInvListWrkSht As Worksheet
        Dim MatData(3, 1) As Object
        Dim EpicorFile As Microsoft.Office.Interop.Excel.Workbook

        Me.LblProgress.Text = "Removing Headers........Please Wait"
        Me.Refresh()

        On Error Resume Next

        ExcelApp = GetObject(, "Excel.Application")

        If Err.Number Then
            Information.Err.Clear()
            ExcelApp = CreateObject("Excel.Application")
            If Err.Number Then
                MsgBox(Err.Description)
                Exit Function
            End If
        End If

        On Error GoTo Err_DelHeaders

        Transfer = "NotComplete"
        WorkBooks2 = ExcelApp.Workbooks
        WorkShtName = "Bulk BOM"
        BOMWrkSht = WorkBooks2.Application.Worksheets(WorkShtName)
        BOMFabInvListWrkSht = WorkBooks2.Application.Worksheets(WorkShtName)
        WorkSht = WorkBooks2.Application.ActiveSheet
        WorkShtName = WorkSht.Name
        ProgressBar1.Value = 0
        BOMWrkSht.Activate()
        LineNo2 = BOMWrkSht.Range("A4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row
        Count = 0
        CountVal = 0
        i = 1
        RowNo = 1

RptGetData2: Testi = (i)
        If Testi > (LineNo2 + CountVal) Then
            ProgressBar1.Maximum = Testi
        Else
            ProgressBar1.Maximum = (LineNo2 + CountVal)
        End If

        For i = Testi To ((LineNo2 + CountVal) - 4)
            If RowNo = 1 Then
                RowNo = LineNo2
            End If

            If RowNo < LineNo2 Then
                ProgressBar1.Value = i
            End If

            If Transfer <> "Complete" Then
                Dim CntWorkShts As Integer
                Dim Shts As Worksheet

                BOMWrkSht.Activate()
                Transfer = "Complete"
            End If

            If RowNo = 0 Then
                RowNo = LineNo2
            End If

            ManwayInfo3134.GetShipMk = Nothing
            ManwayInfo3134.GetPieceMk = Nothing
            GetShipMk = Nothing
            GetPieceMk = Nothing

            With BOMWrkSht
                GetShipMk = .Range("D" & RowNo).Value         'Ship Mark
                GetPieceMk = .Range("E" & RowNo).Value         'Piece Mark
                GetFndStd = .Range("N" & RowNo).Value           'Standard Found
                If GetShipMk <> Nothing And GetShipMk <> "" Then
                    If GetPieceMk = Nothing Or GetPieceMk = "" Then
                        Select Case 0
                            Case Is < InStr(GetFndStd, "Found Standard Information")
                                With .Range("A" & RowNo & ":T" & RowNo)
                                    .Delete(Shift:=XlDeleteShiftDirection.xlShiftUp)
                                End With
                            Case Is < InStr(GetFndStd, "Standard Reference Only")
                                GoTo NextHeader
                            Case Is < InStr(GetFndStd, Nothing)
                                GoTo NextHeader
                            Case Else
                                If GetFndStd = Nothing Then
                                    GoTo NextHeader
                                End If
                        End Select
                    End If
                End If
NextHeader:
            End With

            FType = ""
            RowNo = (RowNo - 1)
        Next i

        ProgressBar1.Value = 0
Err_DelHeaders:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = "1004" And InStr(ErrMsg, "Exception") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If
    End Function

    '    Public Function ColortoNumber(ByVal TotalCnt As Integer) As Object
    '        Dim Excel As Object
    '        Dim Test As String
    '        Dim CutCount, LineNo2, RevColor, DescColor As Integer
    '        Dim OldBOMTest, OldPlateTest, OldStickTest, OldPurchaseTest As Boolean
    '        Dim OldGratingTest, OldStickImportTest, FoundLast As Boolean
    '        Dim Workbooks As Microsoft.Office.Interop.Excel.Workbooks
    '        Dim BOMWrkSht As Worksheet
    '        Dim WrkBooksCnt As Integer
    '        Dim BOMMnu As BOM_Menu3D
    '        BOMMnu = Me

    '        On Error Resume Next

    '        Excel = GetObject(, "Excel.Application")

    '        If Err.Number Then
    '            Information.Err.Clear()
    '            Excel = CreateObject("Excel.Application")
    '            If Err.Number Then
    '                MsgBox(Err.Description)
    '                Exit Function
    '            End If
    '        End If

    '        On Error GoTo Err_ColorToNumber

    '        Workbooks = Excel.Workbooks
    '        WrkBooksCnt = Workbooks.Count
    '        BOMWrkSht = MainBOMFile.Application.ActiveWorkbook.Sheets("Bulk BOM")

    '        With BOMWrkSht
    '            FoundLast = False
    '            LineNo2 = 4
    '            CutCount = 1
    '            Count = 1
    '            Do Until FoundLast = True
    '                LineNo2 = LineNo2 + 1
    '                If .Range("B" & LineNo2).Value = "" And .Range("G" & LineNo2).Value = "" Then
    '                    LineNo2 = LineNo2 - 1
    '                    FoundLast = True
    '                End If
    '            Loop
    '        End With

    '        With BOMWrkSht
    '            For i = 5 To LineNo2
    '                RevColor = .Range("C" & i).Interior.ColorIndex
    '                DescColor = .Range("G" & i).Interior.ColorIndex

    '                If i = 5 Then
    '                    .Range("R" & (i - 1)).Value = "Color Code No"
    '                    .Range("R" & (i - 1)).Font.Bold = True
    '                    .Range("R" & (i - 1)).Font.Size = 12
    '                    .Range("R" & (i - 1)).Orientation = 90
    '                End If

    '                If RevColor = DescColor Then
    'FixColor:
    '                    Select Case RevColor
    '                        Case 4
    '                            .Range("R" & i).Value = 1           'Green                        
    '                        Case 6
    '                            .Range("R" & i).Value = 2           'Yellow
    '                        Case 3
    '                            .Range("R" & i).Value = 3           'Red
    '                        Case 7
    '                            .Range("R" & i).Value = 4           'Purple
    '                        Case 8
    '                            .Range("R" & i).Value = 5           'Cyan
    '                        Case 45
    '                            .Range("R" & i).Value = 6           'Color Orange
    '                        Case -4142
    '                            .Range("R" & i).Value = 8           'No Color, No Change
    '                        Case Else
    '                            MsgBox("Error has been found in Function ColorToNumber on Program BulkBOM.")
    '                    End Select
    '                Else
    '                    If DescColor = -4142 And RevColor = 6 Then
    '                        .Range("R" & i).Value = 7
    '                    Else
    '                        If DescColor = -4142 Then
    '                            GoTo FixColor
    '                        Else
    '                            If DescColor = 7 And RevColor = 6 Then
    '                                .Range("R" & i).Value = 7
    '                            Else
    '                                If DescColor = 8 And RevColor = 6 Then
    '                                    .Range("R" & i).Value = 7
    '                                Else
    '                                    If DescColor = 45 And RevColor = 6 Then
    '                                        .Range("R" & i).Value = 7
    '                                    Else
    '                                        .Range("R" & i).Value = RevColor
    '                                        .Range("S" & i).Value = DescColor
    '                                    End If
    '                                End If
    '                            End If
    '                        End If
    '                    End If

    '                End If
    '            Next
    '        End With

    'Err_ColorToNumber:
    '        ErrNo = Err.Number

    '        If ErrNo <> 0 Then
    '            PriPrg = "BulkBOMFab3D-Intent"
    '            ErrMsg = Err.Description
    '            ErrSource = Err.Source
    '            ErrDll = Err.LastDllError
    '            ErrLastLineX = Err.Erl
    '            ErrException = Err.GetException

    '            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
    '                System.Threading.Thread.Sleep(25)
    '                Resume
    '            End If

    'Dim st As New StackTrace(Err.GetException, True)
    '        CntFrames = st.FrameCount
    '        GetFramesSrt = st.GetFrames
    '        PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
    '        PrgLineNo = PrgLineNo.Replace("@", "at")
    '        LenPrgLineNo = (Len(PrgLineNo))
    '        PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

    ' HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

    '            If IsNothing(ManwayInfo3134.UserName) = True Then
    '                ManwayInfo3134.UserName = System.Environment.UserName()
    '            End If

    '            If ManwayInfo3134.UserName = "dlong" Then
    '                MsgBox(ErrMsg)
    '                Stop
    '                Resume
    '            Else
    '                ExceptionPos = InStr(1, ErrMsg, "Exception")
    '                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
    '                CntExcept = (CntExcept + 1)

    '                If CntExcept < 20 Then
    '                    If ExceptionPos > 0 Then
    '                        Resume
    '                    End If
    '                    If CallPos > 0 Then
    '                        Resume
    '                    End If
    '                End If
    '            End If
    '        End If

    '    End Function

    'Public Function CompareBOM() As Object
    '    Dim Excel As Object
    '    Dim Test As String
    '    Dim OldBOMTest As Boolean, OldPlateTest As Boolean, OldStickTest As Boolean, OldPurchaseTest As Boolean
    '    Dim OldGratingTest As Boolean, OldStickImportTest As Boolean
    '    Dim Workbooks As Microsoft.Office.Interop.Excel.Workbooks
    '    Dim WrkBooksCnt As Integer
    '    Dim BOMMnu As BOM_Menu3D
    '    BOMMnu = Me

    '    On Error Resume Next

    '    Excel = GetObject(, "Excel.Application")

    '    If Err.Number Then
    '        Information.Err.Clear()
    '        Excel = CreateObject("Excel.Application")
    '        If Err.Number Then
    '            MsgBox(Err.Description)
    '            Exit Function
    '        End If
    '    End If

    '    Workbooks = Excel.Workbooks
    '    WrkBooksCnt = Workbooks.Count
    '    NewBulkBOM = MainBOMFile.Application.ActiveWorkbook.Sheets("Bulk BOM")                          '-------Open New bulk bom to compare.
    '    OldBOMFile = Excel.Application.Workbooks.Open(OldBulkBOMFile)
    '    OldBulkBOM = OldBOMFile.Application.ActiveWorkbook.Sheets("Bulk BOM")
    '    OldBOMTest = Comparison31_142.InputType3.CheckOldBOM(OldBulkBOM, ChkOldBOMTyp)

    '    If OldBOMTest = False And ChkOldBOMTyp = "OLD" Then
    '        OldBOMTest = True
    '    End If

    '    If OldBOMTest = True Then
    '        NewBulkBOM.Activate()
    '        NewBOM = Nothing
    '        OldBOM = Nothing

    '        Me.Label2.Text = "Read New BOM, Getting ready to Compare BOM's........Please Wait"
    '        Me.Refresh()

    '        If ChkOldBOMTyp = "NEW" Then
    '            Comparison31_142.InputType3.ReadBOM(NewBOM, NewBulkBOM)
    '        Else
    '            Comparison31_142.InputType3.ReadBOMOld(NewBOM, NewBulkBOM)
    '        End If
    '        NewBOM = NewBOM
    '        Me.Label2.Text = "Read Old BOM, Getting ready to Compare BOM's........Please Wait"
    '        Me.Refresh()
    '        Comparison31_142.InputType3.ReadBOM(OldBOM, OldBulkBOM)                                     '---Look at Prev. Bulk BOM   Create an Array of the information.
    '        Me.Label2.Text = "Comparing Old BOM to New BOM, looking for changes in BOM........Please Wait"
    '        Me.Refresh()

    '        OldBOM = OldBOM
    '        BOMSheet = "Bulk BOM"
    '        If BOMType = "TANK" Then
    '            Comparison31_142.InputType3.CompareArraysTank(NewBOM, OldBOM)
    '        ElseIf BOMType = "SEAL" Then
    '            Comparison31_142.InputType3.CompareArraysSeal(NewBOM, OldBOM)
    '        End If

    '        FormatNewBulkBOM(NewBOM, OldBOM, NewBulkBOM, BOMSheet)
    '    Else
    '        BOMMnu.Hide()
    '        Sapi.Speak("No comparison done. One of the selected BOM file does not appear to be a Bulk BOM")
    '        MsgBox("No comparison done. One of the selected BOM file does not appear to be a Bulk BOM")
    '        OldBulkBOM.Activate()
    '    End If
    'End Function

    'Public Function CompareStickBOM() As Object
    '    Dim Excel As Object
    '    Dim Test As String, ChkOldBOMTyp As String
    '    Dim OldBOMTest As Boolean, OldPlateTest As Boolean, OldStickTest As Boolean, OldPurchaseTest As Boolean
    '    Dim OldGratingTest As Boolean, OldStickImportTest As Boolean
    '    Dim Workbooks As Microsoft.Office.Interop.Excel.Workbooks
    '    Dim WrkBooksCnt As Integer
    '    Dim BOMMnu As BOM_Menu3D
    '    BOMMnu = Me

    '    On Error Resume Next

    '    Excel = GetObject(, "Excel.Application")

    '    If Err.Number Then
    '        Information.Err.Clear()
    '        Excel = CreateObject("Excel.Application")
    '        If Err.Number Then
    '            MsgBox(Err.Description)
    '            Exit Function
    '        End If
    '    End If

    '    Workbooks = Excel.Workbooks
    '    WrkBooksCnt = Workbooks.Count
    '    NewBulkBOM = MainBOMFile.Application.ActiveWorkbook.Sheets("Bulk BOM")
    '    NewGratingBOM = MainBOMFile.Application.ActiveWorkbook.Sheets("Grating BOM")
    '    NewPlateBOM = MainBOMFile.Application.ActiveWorkbook.Sheets("Plate BOM")
    '    NewStickBOM = MainBOMFile.Application.ActiveWorkbook.Sheets("Stick BOM")
    '    NewStickImportBOM = MainBOMFile.Application.ActiveWorkbook.Sheets("Stick Import")
    '    NewPurchaseBOM = MainBOMFile.Application.ActiveWorkbook.Sheets("Other BOM")

    '    '-------------------------------------------------------------Open previous bulk bom to compare.
    '    OldBOMFile = Excel.Application.Workbooks.Open(OldBulkBOMFile)
    '    OldBulkBOM = OldBOMFile.Application.ActiveWorkbook.Sheets("Bulk BOM")
    '    OldGratingBOM = OldBOMFile.Application.ActiveWorkbook.Sheets("Grating BOM")
    '    OldPlateBOM = OldBOMFile.Application.ActiveWorkbook.Sheets("Plate BOM")
    '    OldStickBOM = OldBOMFile.Application.ActiveWorkbook.Sheets("Stick BOM")
    '    OldStickImportBOM = OldBOMFile.Application.ActiveWorkbook.Sheets("Stick Import")
    '    OldPurchaseBOM = OldBOMFile.Application.ActiveWorkbook.Sheets("Other BOM")

    '    '-----------------------Check to see if selected file is a bulk bom-----"Verify Headers are the same.
    '    OldBOMTest = Comparison31_142.InputType3.CheckOldBOM(OldBulkBOM, ChkOldBOMTyp)
    '    OldGratingTest = Comparison31_142.InputType3.CheckOldBOM(OldGratingBOM, ChkOldBOMTyp)
    '    OldPlateTest = Comparison31_142.InputType3.CheckOldBOM(OldPlateBOM, ChkOldBOMTyp)
    '    OldStickTest = Comparison31_142.InputType3.CheckOldBOM(OldStickBOM, ChkOldBOMTyp)
    '    'OldStickImportTest = Comparison31_142.InputType3.CheckOldBOM(OldStickImportBOM)
    '    OldPurchaseTest = Comparison31_142.InputType3.CheckOldBOM(OldPurchaseBOM, ChkOldBOMTyp)

    '    If OldBOMTest = True And OldGratingTest = True And OldPlateTest = True And OldStickTest = True And OldPurchaseTest = True Then
    '        NewBulkBOM.Activate()
    '        NewBOM = Nothing
    '        OldBOM = Nothing
    '        Comparison31_142.InputType3.ReadBOM(NewBOM, NewBulkBOM)
    '        NewBOM = NewBOM
    '        Comparison31_142.InputType3.ReadBOM(OldBOM, OldBulkBOM)
    '        OldBOM = OldBOM
    '        BOMSheet = "Bulk BOM"

    '        If BOMType = "TANK" Then
    '            Comparison31_142.InputType3.CompareArraysTank(NewBOM, OldBOM)
    '        ElseIf BOMType = "SEAL" Then
    '            Comparison31_142.InputType3.CompareArraysSeal(NewBOM, OldBOM)
    '        End If

    '        FormatNewBulkBOM(NewBOM, OldBOM, NewBulkBOM, BOMSheet)
    '        NewPlateBOM.activate()
    '        NewBOM = Nothing
    '        OldBOM = Nothing
    '        Comparison31_142.InputType3.ReadBOM(NewBOM, NewPlateBOM)
    '        NewBOM = NewBOM
    '        Comparison31_142.InputType3.ReadBOM(OldBOM, OldPlateBOM)
    '        OldBOM = OldBOM
    '        BOMSheet = "Plate BOM"

    '        If BOMType = "TANK" Then
    '            Comparison31_142.InputType3.CompareArraysTank(NewBOM, OldBOM)
    '        ElseIf BOMType = "SEAL" Then
    '            Comparison31_142.InputType3.CompareArraysSeal(NewBOM, OldBOM)
    '        End If

    '        FormatNewBulkBOM(NewBOM, OldBOM, NewPlateBOM, BOMSheet)
    '        NewStickBOM.activate()
    '        NewBOM = Nothing
    '        OldBOM = Nothing
    '        Comparison31_142.InputType3.ReadBOM(NewBOM, NewStickBOM)
    '        NewBOM = NewBOM
    '        Comparison31_142.InputType3.ReadBOM(OldBOM, OldStickBOM)
    '        OldBOM = OldBOM
    '        BOMSheet = "Stick BOM"

    '        If BOMType = "TANK" Then
    '            'Make sure "Stick BOM" Data exist
    '            Comparison31_142.InputType3.CompareArraysTank(NewBOM, OldBOM)
    '        ElseIf BOMType = "SEAL" Then
    '            Comparison31_142.InputType3.CompareArraysSeal(NewBOM, OldBOM)
    '        End If

    '        FormatNewBulkBOM(NewBOM, OldBOM, NewStickBOM, BOMSheet)
    '        NewPurchaseBOM.activate()
    '        NewBOM = Nothing
    '        OldBOM = Nothing
    '        Comparison31_142.InputType3.ReadBOM(NewBOM, NewPurchaseBOM)
    '        NewBOM = NewBOM
    '        Comparison31_142.InputType3.ReadBOM(OldBOM, OldPurchaseBOM)
    '        OldBOM = OldBOM
    '        BOMSheet = "Other BOM"

    '        If BOMType = "TANK" Then
    '            Comparison31_142.InputType3.CompareArraysTank(NewBOM, OldBOM)
    '        ElseIf BOMType = "SEAL" Then
    '            Comparison31_142.InputType3.CompareArraysSeal(NewBOM, OldBOM)
    '        End If

    '        FormatNewBulkBOM(NewBOM, OldBOM, NewPurchaseBOM, BOMSheet)
    '    Else
    '        BOMMnu.Hide()
    '        Sapi.Speak("No comparison done. One of the selected BOM file does not appear to be a Bulk BOM")
    '        MsgBox("No comparison done. One of the selected BOM file does not appear to be a Bulk BOM")
    '        OldBulkBOM.Activate()
    '    End If
    'End Function

    Public Function FormatNewBulkBOM(ByRef NewArray As Object, ByRef OldArray As Object, ByRef FileToFormat As Object, ByRef BOMSheet As String) As Object
        Dim Range As Object, iC As Object
        Dim jC As Short, LineNo As Short
        Dim MultiLineMatl As Boolean
        Dim Test, FileToOpen, Test3 As String

        On Error GoTo ERR_FormatNewBulkBOM

        FileToFormat.Activate()
        Test = UBound(NewArray, 2)

        For iC = 1 To UBound(NewArray, 2)
            Test2 = NewArray(13, iC)

            Select Case Test2
                Case "REVISED"
                    '-------Do nothing
                Case "NEW"
                    '-------Do nothing
                Case "NO CHANGE"
                    '-------Do nothing
                Case "BOMNumber"
                    '-------Do nothing
                Case Else
                    Test3 = NewArray(14, iC)
            End Select

            Select Case Test3
                Case "REVISED"
                    Test2 = Test3
                Case "NEW"
                    Test2 = Test3
                Case "NO CHANGE"
                    Test2 = Test3
                Case "BOMNumber"
                    Test2 = Test3
            End Select

            Select Case Test2
                Case "REVISED"
                    HighlightLine(iC + 4, "Y", BOMSheet)
                Case "NEW"
                    HighlightLine(iC + 4, "G", BOMSheet)
                Case "NO CHANGE"
                    HighlightLine(iC + 4, "N", BOMSheet)
                Case "BOMNumber"
                    HighlightLine(iC + 4, "X", BOMSheet)
                Case Else
                    HighlightLine(iC + 4, "G", BOMSheet)
            End Select
        Next iC

        LineNo = UBound(NewArray, 2) + 4
        Test = UBound(OldArray, 2)
        Dim Test1 As String

        For iC = 1 To UBound(OldArray, 2)                                   'For some reason some parts are not being set to FOUND.
            If OldArray(0, iC) = vbNullString Then                          'If part was not FOUND then write info back to sheet from previous spreadsheet.
                MultiLineMatl = False
                LineNo = LineNo + 1
                For jC = 1 To UBound(OldArray, 1) - 1
                    Select Case BOMSheet
                        Case "Bulk BOM"
                            With NewBulkBOM
                                Test = .Range(Chr(64 + jC) & LineNo).Value
                                Test1 = OldArray(jC, iC)
                                .Range(Chr(64 + jC) & LineNo).Value = OldArray(jC, iC)                          'Write value from array to Spreadsheet.

                                Select Case jC
                                    Case 9
                                        If InStr(1, OldArray(jC, iC), Chr(10)) <> 0 Then
                                            MultiLineMatl = True
                                        End If
                                End Select
                            End With
                        Case "Plate BOM"
                            With NewPlateBOM
                                .Range(Chr(64 + jC) & LineNo).Value = OldArray(jC, iC)
                                Select Case jC
                                    Case 9
                                        If InStr(1, OldArray(jC, iC), Chr(10)) <> 0 Then
                                            MultiLineMatl = True
                                        End If
                                End Select
                            End With
                        Case "Stick BOM"
                            With NewStickBOM
                                .Range(Chr(64 + jC) & LineNo).Value = OldArray(jC, iC)
                                Select Case jC
                                    Case 9
                                        If InStr(1, OldArray(jC, iC), Chr(10)) <> 0 Then
                                            MultiLineMatl = True
                                        End If
                                End Select
                            End With
                        Case "Other BOM"
                            With NewPurchaseBOM
                                .Range(Chr(64 + jC) & LineNo).Value = OldArray(jC, iC)
                                Select Case jC
                                    Case 9
                                        If InStr(1, OldArray(jC, iC), Chr(10)) <> 0 Then
                                            MultiLineMatl = True
                                        End If
                                End Select
                            End With
                    End Select
                Next jC

                FileToOpen = BOMSheet
                FormatLine(LineNo, FileToOpen, MultiLineMatl)
                HighlightLine(LineNo, "R", BOMSheet)
            End If
        Next iC
ERR_FormatNewBulkBOM:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Function

    Public Function FindStdsBOM() As Object
        '------------------------------------------------------------------------------------------------
        '-------Creator:        Dennis J. Long
        '-------Date:           Sometime before 4/2/2015    ?2013?
        '-------Description:    Find material used on Standard drawings, and add to Bulk BOM
        '-------
        '-------Updates:        Description:
        '-------    4/2/2015    Fab has requested to remove some Standard Drawings from being broke down        
        '-------                to all parts.
        '-------                
        '------------------------------------------------------------------------------------------------
        Dim NewBulkBOM As Worksheet
        Dim xlShiftUp As Object, Columns As Object, xlTopToBottom As Object, xlGuess As Object, xlDescending As Object
        Dim xlToRight As Object
        Dim xlAscending As Object, xlCenter As Object, Selection As Object, Range As Object, Worksheets As Object
        Dim VarSelArray As Object, Excel As Object, BlockData(1) As Object, DwgItem As Object, BomItem As Object
        Dim TempAttributes As Object, Temparray As Object, gvntSDIvar As Object, InsertionPT As Object
        Dim Title, Msg, Style, Response As Object
        Dim TagInsPnt1 As Object, TagInsPnt2 As Object, xlMinimized As Object, ExcelWorkbook As Object
        Dim BlockSel As AutoCAD.AcadSelectionSet
        Dim AMWdisabled As Boolean, AcadOpen As Boolean, MultiLineMatl As Boolean
        Dim BatchYN As Short, GroupCode(1) As Short
        Dim AcadPref As AutoCAD.AcadPreferencesSystemClass
        Dim CompareX1 As Double, CompareX2 As Double, Dimscale As Double
        Dim i, j, k, i1, x, Count, Shopwatch, CntWorkbook, CntWrkShts, CountVal, CutCount, Testi As Integer
        Dim SeeNotePos, ChkPos, SeeDwgPos, ExceptPos, CntExcept, RevPos, ExtPos, jA, FoundPart As Integer
        Dim CntOldStdItems, CntNewBulkBOM, Startj, l, GetNewjA, StartjA, Totalj, NewCount, TotaljA As Integer
        Dim Note2Pos, NewSeeNotePos, NewChkPos, NewSeeDwgPos, NewNote2Pos, NewBOMPos, StartCnt As Integer
        Dim FoundFoot, FoundInch, FoundSpace, CntTest, HoldCnt, SeeDwg2Pos, OldQtyInt, NewQtyInt As Integer
        Dim FullJobNo, CurrentDwgRev, CurrentDwgNo, FilePath, CurrentDWG, PrgName, WorkBookName As String
        Dim WrkBookName, WorkShtName, NextSht, BomWrkShtNam, FileSaveAS, OldFileNam, SearchDwg2 As String
        Dim LookForStd, LookForShipMk, FoundLast, LineNo, LineNo2, LineNo3, LineNo4, FoundRev As String
        Dim AdeptPrg, AdeptStd, Dwg, ExistSTD, Test, SearchException, FindRev, FindRev1, FindRev2 As String
        Dim ShpM, ShpM2, ShpQ, ShpQ2, Desc, Desc2, Ref1, Ref2, Matl, Matl2, Matl3, Wght, NewItem As String
        Dim OldDwg, OldRev, OldShpMk, OldPcMk, OldQty, OldDesc, OldDesc2, OldInv, OldStd, OldMatl As String
        Dim OldWht, OldReq, OldProd, OldDesc3, NewDesc3, GetRecNo, OldRecNo As String
        Dim NewDwg, NewRev, NewShpMk, NewPcMk, NewQty, NewDesc, NewDesc2, NewInv, NewStd, NewMatl, NewWht As String
        Dim NewReq, NewProd As String
        Dim FoundItem, SearchSeeNote, SearchNote, SearchNote2, SearchDwg, CompDesc, FirstTimeThru As String
        Dim OldRef, MxPcMk As String
        Dim NTest, NTest1, NTest2, NTest3, Ntest4, NTest5, Ntest6, NTest7, NTest8, NTest9, NTest10 As String
        Dim NTest11, NTest12, DescFixed As String
        Dim OTest, OTest1, OTest2, OTest3, Otest4, OTest5, Otest6, OTest7, OTest8, OTest9, OTest10 As String
        Dim OTest11, OTest12, pattern, FirstPart, SecondPart, NPds, OPds As String
        Dim Workbooks As Microsoft.Office.Interop.Excel.Workbooks
        Dim WorkSht As Worksheet, BOMWrkSht As Worksheet            ', ShpCutWrkSht As Worksheet, StdsWrkSht As Worksheet
        Dim BOMSTDsSht As Worksheet
        Dim StdItemsWrkSht As Worksheet
        Dim FileToOpen As String
        'Dim ExcelApp As Excel.Application       'Dim ExcelApp As Object     Duplicate ExcelApp causing problems   RW 8/17/2023
        Dim BOMMnu As BOM_Menu3D
        BOMMnu = Me
        PrgName = "FindStdsBOM"
        HoldCnt = 0

        On Error GoTo Err_FindStdsBOM

        If ManwayInfo3134.RevNo = Nothing Then
            ManwayInfo3134.RevNo = Me.ComboBxRev.Text
        End If

        BOMMnu.LblProgress.Text = "Copy Standards to Bulk BOM........Please Wait"
        BOMMnu.Refresh()
        Workbooks = ExcelApp.Workbooks
        WorkShtName = "STDs BOM"
        BOMSTDsSht = Workbooks.Application.Worksheets(WorkShtName)
        BOMSTDsSht.Activate()
        WorkShtName = "STD Items"
        StdItemsWrkSht = Workbooks.Application.Worksheets(WorkShtName)
        LineNo2 = BOMSTDsSht.Range("A4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row

        LineNo4 = StdItemsWrkSht.Range("A4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row

        Count = 0
        CountVal = 0
        i = 1
        SearchSeeNote = "(SEE NOTE"
        SearchNote = " ("
        SearchDwg = "(SEE DWG"
        SearchDwg2 = "(DWG"
        SearchNote2 = "NOTE"

RptGetData: Testi = (i)
        If Testi > (LineNo2 + CountVal) Then
            BOMMnu.ProgressBar1.Maximum = Testi
        Else
            BOMMnu.ProgressBar1.Maximum = (LineNo2 + CountVal)
        End If

        For i = Testi To (LineNo2 + CountVal)
            If i > 1 Then
                GoTo GetDataNew
            End If

            RowNo = i + 4
            NewBulkBOM = MainBOMFile.Application.ActiveWorkbook.Sheets("Bulk BOM")
            FindStdsBOM = MainBOMFile.Application.ActiveWorkbook.Sheets("STDs BOM")
            OldStdItems = MainBOMFile.Application.ActiveWorkbook.Sheets("STD Items")
            NewBOM = Nothing
            OldBOM = Nothing
            FindSTD = Nothing

            NewBOM = GenInfo3233.BOMList           'Comparison31_142.InputType3.ReadBulkBOM(NewBOM, NewBulkBOM)        'Already Done
            FindSTD = GenInfo3233.STDsList          'Comparison31_142.InputType3.ReadFindSTDs(FindSTD, FindStdsBOM)     'Already Done
            OldBOM = GenInfo3233.StdsBOMList        'Comparison31_142.InputType3.ReadBOM(OldBOM, OldStdItems)     'Already Done

            OldDesc = ""
            OldInv = ""
            OldStdDwg = ""
            OTest = ""
            OTest2 = ""
            NTest = ""
            NTest2 = ""
            Dim CntFindStds As String

            If HoldCnt = 0 Then
                HoldCnt = UBound(NewBOM, 2)
            End If

            CntNewBulkBOM = UBound(NewBOM, 2)
            CntOldStdItems = UBound(OldBOM, 2)
            CntFindStds = UBound(FindSTD, 2)
GetDataNew:
            If GetNewjA < 1 Then
                GetNewjA = 1
            Else
                GetNewjA = (GetNewjA + 1)
            End If

            If GetNewjA > BOMMnu.ProgressBar1.Maximum Then
                BOMMnu.ProgressBar1.Maximum = (GetNewjA + CountVal + 4)
                BOMMnu.ProgressBar1.Value = GetNewjA
            Else
                BOMMnu.ProgressBar1.Value = GetNewjA
            End If

            DescFixed = "No"
            TotaljA = UBound(FindSTD, 2)

            If GetNewjA > TotaljA Then
                GoTo FoundAllParts
            End If

            For jA = GetNewjA To UBound(FindSTD, 2)
                NewStdDwg = FindSTD(10, jA)          'NewStdDwg = FindSTD(8, jA)

                If Mid(NewStdDwg, 1, 2) = "MX" Or Mid(NewStdDwg, 1, 2) = "CH" Then
                    'NTest1 = FindSTD(0, jA)                    '?X Position
                    'NTest1 = FindSTD(1, jA)               'A   'Dwg
                    'NTest2 = FindSTD(2, jA)               'B   'Rev
                    'NTest2 = FindSTD(3, jA)               'D   'Piece Mark
                    NewQty = FindSTD(4, jA)                'E   'Qty               'NewQty = FindSTD(5, jA) 
                    'NTest3 = FindSTD(5, jA)               'C   'Ship Mark
                    'NTest3 = FindSTD(6, jA)               '
                    NewDesc = FindSTD(7, jA)               'F   'Description       'NewDesc = FindSTD(6, jA)
                    NewDesc = RTrim(NewDesc)
                    NewDesc2 = NewDesc

                    NewInv = FindSTD(9, jA)                'G   'INV-1               'NewInv = FindSTD(7, jA)  
                    NewStdDwg = FindSTD(10, jA)            'H   'Std Dwg No.        'NewStdDwg = FindSTD(8, jA)
                    GetMat = FindSTD(11, jA)               'I   'Material       'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                    NPds = FindSTD(12, jA)                 'J   'Weight or pounds   'NPds = FindSTD(10, jA)

                    'NTest12 = FindSTD(12, jA)             'L
                    NewBOMPos = FindSTD(13, jA)             'M
                    GetRecNo = FindSTD(20, jA)             'T
                    Dim FindSc, LookForSC, ItemNo As String

                    If NewInv = Nothing Then
                        FindSc = Nothing
                    Else
                        FindSc = NewInv & NewStdDwg
                    End If

                    For x = 0 To UBound(ManwayInfo3134.SubMFGData, 2)          'Do not need to look up Part numbers anymore.
                        LookForSC = ManwayInfo3134.SubMFGData(1, x)

                        If FindSc = LookForSC Then
                            ItemNo = ManwayInfo3134.SubMFGData(0, x)

                            If IsNothing(BOMWrkSht) = True Then
                                WorkShtName = "Bulk BOM"
                                BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
                            End If

                            Count = BOMWrkSht.Range("A4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row
                            Totalj = UBound(NewBOM, 2)

                            If HoldCnt <> Totalj Then
                                Count = (Count - HoldCnt)
                                Count = (Count - 4)
                            Else
                                Count = (Count - UBound(NewBOM, 2))
                                Count = (Count - 4)
                            End If

                            With BOMWrkSht
                                .Range("M" & (NewBOMPos + Count)).Value = "SUB-MFG Part, Per FAB Do Not break down to BOM parts."
                                OldQtyInt = OldQty
                                NewQtyInt = NewQty
                                .Range("L" & (NewBOMPos + Count)).Value = NewQtyInt

                                'With .Range("A" & (NewBOMPos + Count) & ":M" & (NewBOMPos + Count))
                                '    With .Interior
                                '        .ColorIndex = 8
                                '        .Pattern = Constants.xlSolid
                                '    End With
                                'End With

                                '.Range("N" & (NewBOMPos + Count)).Value = ItemNo
                                'With .Range("N" & (NewBOMPos + Count) & ":O" & (NewBOMPos + Count))
                                '    With .Interior
                                '        .ColorIndex = 4
                                '        .Pattern = Constants.xlSolid
                                '    End With
                                'End With

                                If ManwayInfo3134.RevNo = 0 Then
                                    .Range("Q" & (NewBOMPos + Count)).Value = "1"
                                    .Range("A" & (NewBOMPos + Count) & ":L" & (NewBOMPos + Count)).Interior.ColorIndex = 4
                                End If

                                If ManwayInfo3134.GetMatLen = 0 Or ManwayInfo3134.GetMatLen = Nothing Then
                                    .Range("L" & (NewBOMPos + Count)).Value = NewQty
                                Else
                                    .Range("L" & (NewBOMPos + Count)).Value = ManwayInfo3134.GetMatLen
                                End If
                            End With

                            GoTo GetDataNew
                        End If
                    Next x

                    GoTo GetStdInfo
                End If

            Next jA

GetStdInfo:
            Totalj = UBound(OldBOM, 2)

            '--------------------------------------------------------------------
            For j = GetRecNo To UBound(OldBOM, 2)          'For j = 0 To UBound(OldBOM, 2)         '-------DJL-12-27-2023
                LookForStd = OldBOM(1, j)
                OldRecNo = OldBOM(20, j)                    'T
                'May want to look at modifing program to look for Standard match before checking every line in Spreadsheet see example below:   (Hold for now.)<---Has Been Done
                '(Program needs to find second line before getting parts on Standard.
                '24"x12" FLAT BOTTOM SUMP (TYPE-A)
                '24"x10" DISHED BOTTOM SUMP (TYPE-B)

                If LookForStd = NewStdDwg And OldRecNo = GetRecNo Then                          'If Mid(LookForStd, 1) = NewStdDwg Then     '-------DJL-12-27-2023
                    'OTest1 = OldBOM(1, j)               'A
                    'OTest2 = OldBOM(2, j)               'B
                    'OTest3 = OldBOM(3, j)               'C
                    'OTest5 = OldBOM(4, j)               'D
                    OldQty = OldBOM(5, j)               'E          "Looking at list of Standards found here.
                    OldDesc = OldBOM(6, j)              'F  'Description
                    OldDesc2 = OldDesc
                    OldInv = OldBOM(7, j)               'G  'INV-1
                    OldStdDwg = OldBOM(8, j)            'H  'Std Dwg No.
                    'OTest9 = OldBOM(9, j)               'I
                    OPds = OldBOM(10, j)                'J     'Weight or Pounds
                    'OTest11 = OldBOM(11, j)             'K
                    'OTest12 = OldBOM(12, j)             'L

                    If IsNothing(OldInv) = True Then
                        GoTo GetData4
                    Else
                        If OldInv <> NewInv Then
                            GoTo GetData4
                        End If
                    End If

                    SeeNotePos = 0
                    ChkPos = 0
                    SeeDwgPos = 0
                    Note2Pos = 0
                    SeeNotePos = InStr(1, OldDesc, SearchSeeNote)
                    ChkPos = InStr(1, OldDesc, SearchNote)
                    SeeDwgPos = InStr(1, OldDesc, SearchDwg)                            '-------(SEE DWG
                    SeeDwg2Pos = InStr(1, OldDesc, SearchDwg2)                          '-------(DWG
                    Note2Pos = InStr(1, OldDesc, SearchNote2)

                    Select Case 0
                        Case Is < SeeNotePos
                            OldDesc = Mid(OldDesc, 1, (SeeNotePos - 2))         'Question should this be minus 1
                        Case Is < ChkPos
                            OldDesc2 = Mid(OldDesc, 1, (ChkPos - 1))
                        Case Is < SeeDwgPos
                            GoTo GetData4
                        Case Is < SeeDwg2Pos
                            GoTo GetData4
                        Case Is < Note2Pos
                            OldDesc2 = Mid(OldDesc, 1, (Note2Pos - 1))
                    End Select

                    NewDesc = NewDesc
                    OldDesc2 = OldDesc2
                    NewInv = NewInv
                    Dim NewSeeDwg2Pos As Integer
                    NewSeeNotePos = 0
                    NewChkPos = 0
                    NewSeeDwgPos = 0
                    NewSeeDwg2Pos = 0
                    NewNote2Pos = 0
                    NewSeeNotePos = InStr(1, NewDesc, SearchSeeNote)
                    NewChkPos = InStr(1, NewDesc, SearchNote)
                    NewSeeDwgPos = InStr(1, NewDesc, SearchDwg)
                    NewSeeDwg2Pos = InStr(1, NewDesc, SearchDwg2)
                    NewNote2Pos = InStr(1, NewDesc, SearchNote2)

                    Select Case 0
                        Case Is < NewSeeNotePos
                            NewDesc = Mid(NewDesc, 1, (NewSeeNotePos - 2))
                            NewDesc = RTrim(NewDesc)
                        Case Is < NewChkPos
                            NewDesc2 = Mid(NewDesc, 1, (NewChkPos - 1))
                            NewDesc2 = RTrim(NewDesc2)
                        Case Is < NewSeeDwgPos
                            GoTo GetData4
                        Case Is < NewSeeDwg2Pos
                            GoTo GetData4
                        Case Is < NewNote2Pos
                            NewDesc2 = Mid(NewDesc, 1, (NewNote2Pos - 2))
                            NewDesc2 = RTrim(NewDesc2)
                    End Select

                    NewDesc = NewDesc
                    NewDesc2 = NewDesc2
                    OldDesc2 = OldDesc2
                    NewInv = NewInv

                    If OldInv = NewInv Then
                        NewDesc3 = NewDesc2
                        OldDesc3 = OldDesc2

                        If NewDesc2 <> OldDesc2 Then
                            FoundFoot = InStr(1, NewDesc3, SearchFoot)
                            While FoundFoot > 0
                                FirstPart = Mid(NewDesc3, 1, (FoundFoot - 1))
                                SecondPart = Mid(NewDesc3, (FoundFoot + 1), (Len(NewDesc3) - FoundFoot))
                                NewDesc3 = FirstPart & SecondPart
                                FoundFoot = InStr(1, NewDesc3, SearchFoot)
                            End While

                            FoundInch = InStr(1, NewDesc3, SearchInch)
                            While FoundInch > 0
                                FirstPart = Mid(NewDesc3, 1, (FoundInch - 1))
                                SecondPart = Mid(NewDesc3, (FoundInch + 1), (Len(NewDesc3) - FoundInch))
                                NewDesc3 = FirstPart & SecondPart
                                FoundInch = InStr(1, NewDesc3, SearchInch)
                            End While

                            FoundSpace = InStr(1, NewDesc3, SearchSpace)
                            While FoundSpace > 0
                                FirstPart = Mid(NewDesc3, 1, (FoundSpace - 1))
                                SecondPart = Mid(NewDesc3, (FoundSpace + 1), (Len(NewDesc3) - FoundSpace))
                                NewDesc3 = FirstPart & SecondPart
                                FoundSpace = InStr(1, NewDesc3, SearchSpace)
                            End While

                            FoundFoot = InStr(1, OldDesc3, SearchFoot)
                            While FoundFoot > 0
                                FirstPart = Mid(OldDesc3, 1, (FoundFoot - 1))
                                SecondPart = Mid(OldDesc3, (FoundFoot + 1), (Len(OldDesc3) - FoundFoot))
                                OldDesc3 = FirstPart & SecondPart
                                FoundFoot = InStr(1, OldDesc3, SearchFoot)
                            End While

                            FoundInch = InStr(1, OldDesc3, SearchInch)
                            While FoundInch > 0
                                FirstPart = Mid(OldDesc3, 1, (FoundInch - 1))
                                SecondPart = Mid(OldDesc3, (FoundInch + 1), (Len(OldDesc3) - FoundInch))
                                OldDesc3 = FirstPart & SecondPart
                                FoundInch = InStr(1, OldDesc3, SearchInch)
                            End While

                            FoundSpace = InStr(1, OldDesc3, SearchSpace)
                            While FoundSpace > 0
                                FirstPart = Mid(OldDesc3, 1, (FoundSpace - 1))
                                SecondPart = Mid(OldDesc3, (FoundSpace + 1), (Len(OldDesc3) - FoundSpace))
                                OldDesc3 = FirstPart & SecondPart
                                FoundSpace = InStr(1, OldDesc3, SearchSpace)
                            End While
                        End If
                    End If

                    NewDesc3 = NewDesc3
                    OldDesc3 = OldDesc3

                    Select Case NewDesc
                        Case OldDesc
                            If OldInv = NewInv Then
                                Startj = j
                                StartCnt = 0
                                GoTo GetData5
                            Else
                                GoTo GetData4
                            End If
                        Case OldDesc2
                            If OldInv = NewInv Then
                                Startj = j
                                GoTo GetData5
                            Else
                                GoTo GetData4
                            End If
                        Case Else
                            Select Case NewDesc2
                                Case OldDesc
                                    If OldInv = NewInv Then
                                        Startj = j
                                        GoTo GetData5
                                    Else
                                        GoTo GetData4
                                    End If
                                Case OldDesc2
                                    If OldInv = NewInv Then
                                        Startj = j
                                        GoTo GetData5
                                    Else
                                        GoTo GetData4
                                    End If
                                Case Else
                                    If NewDesc3 = OldDesc3 Then
                                        If OldInv = NewInv Then
                                            Startj = j
                                            GoTo GetData5
                                        Else
                                            GoTo GetData4
                                        End If
                                    Else
                                        j = (UBound(OldBOM, 2) + 1)
                                        GoTo GetData6
                                    End If
                            End Select
                    End Select
                Else
                    GoTo GetData4
                End If

                pattern = NTest
                If pattern <> "" Then
                    Dim matches As MatchCollection = Regex.Matches(OTest, pattern)
                    If Regex.IsMatch(OTest, pattern) Then
                        For Each match As Match In matches
                            FoundPart = match.Value
                        Next
                    End If
                End If
GetData5:
                FirstTimeThru = "Yes"
                OldQty = NewQty
                CountNewItems = (CountNewItems + 1)

                For l = (Startj + 1) To UBound(OldBOM, 2)       '-------Found Part Now get Items for Standard.
                    NewDwg = OldBOM(1, l)               'A      'Dwg
                    NewRev = OldBOM(2, l)               'B      'Rev
                    NewShpMk = OldBOM(3, l)             'C      'Ship Mark
                    NewPcMk = OldBOM(4, l)              'D      'New Piece Mark
                    NewPcMk = LTrim(NewPcMk)            '----------New Problem found NewPcMk's with blank spaces...........
                    NewPcMk = RTrim(NewPcMk)

                    NewQty = OldBOM(5, l)               'E      'Qty
                    NewDesc = OldBOM(6, l)              'F      'Description
                    NewInv = OldBOM(7, l)               'G      'Inv-1
                    NewStd = OldBOM(8, l)               'H      'Standard Number Example:MX1001A
                    NewMatl = OldBOM(9, l)              'I      'Material
                    NewWht = OldBOM(10, l)              'J      'Weight
                    NewReq = OldBOM(11, l)              'K      'Required Type
                    'NewProd = OldBOM(12, l)             'L         'Index Out of Bounds OldBOM only looks at first 11 columns.

                    If IsNothing(BOMWrkSht) = True Then
                        WorkShtName = "Bulk BOM"
                        BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
                    End If

                    If NewPcMk = Nothing Then       '--Question is there a mistake here"If IsNothing(NewPcMk) = True Then".
                        If CompDesc <> "" Then
                            With BOMWrkSht
                                If FirstTimeThru = "Yes" Then
                                    If CompDesc = "" Then
                                        .Range("M" & (jA + 4)).Value = "Standard was not found."
                                        With .Range("A" & (jA + 4) & ":M" & (jA + 4))
                                            With .Interior
                                                .ColorIndex = 7
                                                .Pattern = Constants.xlSolid
                                            End With
                                        End With
                                    Else
                                        .Range("M" & (jA + 4)).Value = "Standard Reference only, No additional parts. " & CompDesc
                                        With .Range("A" & (jA + 4) & ":M" & (jA + 4))
                                            With .Interior
                                                .ColorIndex = 45
                                                .Pattern = Constants.xlSolid
                                            End With
                                        End With
                                    End If

                                    If ManwayInfo3134.RevNo = 0 Then
                                        .Range("Q" & (jA + 4)).Value = "1"
                                        .Range("A" & (jA + 4) & ":L" & (jA + 4)).Interior.ColorIndex = 4
                                    End If
                                Else
                                    .Range("M" & (jA + 4)).Value = CompDesc
                                    With .Range("A" & (jA + 4) & ":M" & (jA + 4))
                                        With .Interior
                                            .ColorIndex = 45
                                            .Pattern = Constants.xlSolid
                                        End With
                                    End With

                                    If ManwayInfo3134.RevNo = 0 Then
                                        .Range("Q" & (jA + 4)).Value = "1"
                                        .Range("A" & (jA + 4) & ":L" & (jA + 4)).Interior.ColorIndex = 4
                                    End If
                                End If
                            End With
                        Else
                            If IsNothing(BOMWrkSht) = True Then
                                WorkShtName = "Bulk BOM"
                                BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
                            End If

                            If FirstTimeThru = "Yes" Then
                                Count = BOMWrkSht.Range("A4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row
                                Totalj = UBound(NewBOM, 2)

                                If HoldCnt <> Totalj Then
                                    Count = (Count - HoldCnt)
                                    Count = (Count - 4)
                                Else
                                    Count = (Count - UBound(NewBOM, 2))
                                    Count = (Count - 4)
                                End If

                                With BOMWrkSht
                                    .Range("M" & (NewBOMPos + Count)).Value = "Standard Reference only, No additional parts."
                                    OldQtyInt = OldQty
                                    NewQtyInt = NewQty

                                    If InStr(OldDesc, "SHT") = 0 Then
                                        If OldQtyInt > 0 Then
                                            If NewQtyInt > 0 Then
                                                .Range("L" & (NewBOMPos + Count)).Value = (OldQtyInt * NewQtyInt)
                                            Else
                                                .Range("L" & (NewBOMPos + Count)).Value = OldQtyInt
                                            End If
                                        Else
                                            .Range("L" & (NewBOMPos + Count)).Value = NewQtyInt
                                        End If
                                    Else
                                        .Range("L" & (NewBOMPos + Count)).Value = OldWht
                                    End If

                                    With .Range("A" & (NewBOMPos + Count) & ":M" & (NewBOMPos + Count))
                                        With .Interior
                                            .ColorIndex = 8
                                            .Pattern = Constants.xlSolid
                                        End With
                                    End With

                                    If ManwayInfo3134.RevNo = 0 Then
                                        .Range("Q" & (NewBOMPos + Count)).Value = "1"
                                        .Range("A" & (NewBOMPos + Count) & ":L" & (NewBOMPos + Count)).Interior.ColorIndex = 4
                                    End If
                                End With

                                GoTo GetDataNew
                            End If
                        End If
                        CompDesc = ""
                        FirstTimeThru = "No"
                        GetNewjA = jA
                        GoTo GetDataNew
                    End If

                    WorkShtName = "Bulk BOM"
                    BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
                    Count = BOMWrkSht.Range("A4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row
                    Totalj = UBound(NewBOM, 2)

                    If HoldCnt <> Totalj Then
                        Count = (Count - HoldCnt)
                        Count = (Count - 4)
                    Else
                        Count = (Count - UBound(NewBOM, 2))
                        Count = (Count - 4)
                    End If

                    With BOMWrkSht
                        FirstTimeThru = "No"

                        If FoundItem = "Yes" Then
                            LineNo = jA
                        Else
                            LineNo = jA
                            FoundItem = "Yes"
                        End If

                        If Count <> NewCount Then
                            If DescFixed = "No" Then
                                LineNo = (LineNo + Count + 3)
                            Else
                                LineNo = (LineNo + Count + 2)
                            End If
                        Else
                            If Startj > LineNo Then
                                LineNo = (Startj + Count + 4)
                            Else
                                LineNo = (LineNo + Count + 3)
                            End If
                        End If

                        OldDesc = OldDesc

                        'Found problem here were program is inserting duplicates due to LineNo is wrong above for new part which is the same part on different drawing.
                        With BOMWrkSht                          ' Standard Found.
                            If Count > 0 Then                   'Make sure to format all lines inserted if not you will have no lines.
                                LineNo = (NewBOMPos + Count + 1)
                                CntTest = (Totalj - HoldCnt)

                                If CntTest > 0 Then
                                    LineNo = LineNo + CntTest
                                End If

                                FileToOpen = "Bulk BOM"
                                FormatLine3(LineNo, FileToOpen)  'This inserts a line and formats the line replaced above insert
                            Else
                                LineNo = (NewBOMPos + 1)
                                CntTest = (Totalj - HoldCnt)                'Then this is used everytime after.

                                If CntTest > 0 Then
                                    LineNo = LineNo + CntTest
                                End If

                                FileToOpen = "Bulk BOM"
                                FormatLine3(LineNo, FileToOpen)
                            End If
                        End With

                        .Range("A" & LineNo).Value = NewDwg
                        .Range("B" & LineNo).Value = NewRev
                        .Range("C" & LineNo).Value = NewShpMk
                        .Range("D" & LineNo).Value = NewPcMk

                        If InStr(OldQty, "?") > 0 Then
                            OldQty = 0
                        End If

                        If OldQty = 0 Then
                            .Range("E" & LineNo).Value = NewQty
                        Else
                            .Range("E" & LineNo).Value = (NewQty * OldQty)
                        End If

                        .Range("F" & LineNo).Value = NewDesc
                        .Range("G" & LineNo).Value = NewInv
                        .Range("H" & LineNo).Value = NewStd
                        .Range("I" & LineNo).Value = NewMatl

                        Select Case NewWht
                            Case "-"
                                .Range("J" & LineNo).Value = NewWht
                            Case "??"
                                .Range("J" & LineNo).Value = "0.000"
                            Case Else
                                If OldQty = 0 Then
                                    .Range("J" & LineNo).Value = (NewWht * NewQty)
                                Else
                                    .Range("J" & LineNo).Value = (NewWht * (NewQty * OldQty))
                                End If
                        End Select

                        .Range("K" & LineNo).Value = NewReq
                        '.Range("L" & LineNo).Value = NewProd

                        If CompDesc <> "" Then
                            .Range("M" & RowNo).Value = CompDesc
                            With .Range("A" & RowNo & ":M" & RowNo)
                                With .Interior
                                    .ColorIndex = 45
                                    .Pattern = Constants.xlSolid
                                End With
                            End With

                            If ManwayInfo3134.RevNo = 0 Then
                                .Range("Q" & RowNo).Value = "1"
                                .Range("A" & RowNo & ":L" & RowNo).Interior.ColorIndex = 4
                            End If

                            With .Range("A" & (RowNo + 1) & ":M" & (RowNo + 1))
                                With .Interior
                                    .ColorIndex = 45
                                    .Pattern = Constants.xlSolid
                                End With
                            End With

                            If ManwayInfo3134.RevNo = 0 Then
                                .Range("Q" & (RowNo + 1)).Value = "1"
                                .Range("A" & (RowNo + 1) & ":L" & (RowNo + 1)).Interior.ColorIndex = 4
                            End If
                        Else
                            If DescFixed = "Yes" Then
                                With .Range("A" & LineNo & ":M" & LineNo)
                                    With .Interior
                                        .ColorIndex = 8
                                        .Pattern = Constants.xlSolid
                                    End With
                                End With

                                If ManwayInfo3134.RevNo = 0 Then
                                    .Range("Q" & LineNo).Value = "1"
                                    .Range("A" & LineNo & ":L" & LineNo).Interior.ColorIndex = 4
                                End If
                            Else
                                .Range("M" & (LineNo - 1)).Value = "Found Standard Information"
                                With .Range("A" & (LineNo - 1) & ":M" & (LineNo - 1))
                                    With .Interior
                                        .ColorIndex = 8
                                        .Pattern = Constants.xlSolid
                                    End With
                                End With

                                If ManwayInfo3134.RevNo = 0 Then
                                    .Range("Q" & (LineNo - 1)).Value = "1"
                                    .Range("A" & (LineNo - 1) & ":L" & (LineNo - 1)).Interior.ColorIndex = 4
                                End If

                                DescFixed = "Yes"
                                With .Range("A" & LineNo & ":M" & LineNo)
                                    With .Interior
                                        .ColorIndex = 8
                                        .Pattern = Constants.xlSolid
                                    End With
                                End With

                                If ManwayInfo3134.RevNo = 0 Then
                                    .Range("Q" & LineNo).Value = "1"
                                    .Range("A" & LineNo & ":L" & LineNo).Interior.ColorIndex = 4
                                End If
                            End If
                        End If
                    End With
                    NewCount = (Count + 1)
                    Count = (Count + 1)

                Next l

                '-------------Check if all parts were found then go to next part, instead of looking for part again.
                If DescFixed = "Yes" Then
                    GoTo GetDataNew
                End If
GetData4:
            Next j
GetData6:
            With BOMWrkSht
                If j > UBound(OldBOM, 2) Then
                    Totalj = UBound(OldBOM, 2)          'Description does not match
                    CompDesc = ""

                    For j = 0 To UBound(OldBOM, 2)
                        LookForStd = OldBOM(1, j)

                        If Mid(LookForStd, 1) = NewStdDwg Then
                            'OTest1 = OldBOM(1, j)               'A
                            'OTest2 = OldBOM(2, j)               'B
                            'OTest3 = OldBOM(3, j)               'C
                            'Otest4 = OldBOM(4, j)               'D
                            'OTest5 = OldBOM(5, j)               'E

                            OldDesc = OldBOM(6, j)              'F  'Description
                            OldInv = OldBOM(7, j)               'G  'INV-1
                            OldStdDwg = OldBOM(8, j)            'H  'Std Dwg No.

                            'OTest9 = OldBOM(9, j)               'I
                            'OTest10 = OldBOM(10, j)             'J
                            'OTest11 = OldBOM(11, j)             'K
                            'OTest12 = OldBOM(12, j)             'L

                            If OldInv = Nothing Then
                                'Do nothing except go to next line
                            Else
                                If OldInv = NewInv Then
                                    CompDesc = NewDesc & " and " & OldDesc & " --Description Did Not Match double check Item"
                                    Startj = j
                                    StartjA = (jA + 4)
                                    OldQty = NewQty
                                    GetStdInfo(CompDesc, Startj, StartjA, OldQty, FuncGetDataNew, NewBOMPos, HoldCnt)   'GoTo GetData5  'GoTo GetData
                                    DescFixed = "Yes"
                                    CompDesc = ""
                                    FirstTimeThru = "No"
                                    GetNewjA = jA
                                    GoTo GetDataNew
                                End If
                            End If
                        End If

                    Next j

                    If IsNothing(BOMWrkSht) = True Then
                        WorkShtName = "Bulk BOM"
                        BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
                    End If

                    With BOMWrkSht                  '----------Insert Items into Bulk BOM.
                        DescFixed = DescFixed
                        If DescFixed = "No" Then
                            OldDesc = OldDesc
                            NewDesc = NewDesc
                            Count = BOMWrkSht.Range("A4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row
                            Totalj = UBound(NewBOM, 2)

                            If HoldCnt <> Totalj Then
                                Count = (Count - HoldCnt)
                                Count = (Count - 4)
                            Else
                                Count = (Count - UBound(NewBOM, 2))
                                Count = (Count - 4)
                            End If

                            '----------------------First time to find part missing
                            .Range("M" & (NewBOMPos + Count)).Value = "Standard was not found."
                            If OldQty = "" Then
                                OldQty = 1
                            End If

                            OldQtyInt = OldQty

                            If InStr(NewQty, "?") > 0 Then
                                NewQtyInt = 0
                            Else
                                NewQtyInt = NewQty
                            End If

                            If OldQtyInt > 0 Then
                                .Range("L" & (NewBOMPos + Count)).Value = (OldQtyInt * NewQtyInt)
                            Else
                                .Range("L" & (NewBOMPos + Count)).Value = NewQtyInt
                            End If

                            With .Range("A" & (NewBOMPos + Count) & ":M" & (NewBOMPos + Count))
                                With .Interior
                                    .ColorIndex = 7
                                    .Pattern = Constants.xlSolid
                                End With
                            End With

                            If ManwayInfo3134.RevNo = 0 Then
                                .Range("Q" & (NewBOMPos + Count)).Value = "1"
                                .Range("A" & (NewBOMPos + Count) & ":L" & (NewBOMPos + Count)).Interior.ColorIndex = 4
                            End If
                        End If
                    End With
                    If jA > 1 Then
                        GoTo GetDataNew
                    Else
                        GoTo GetData2
                    End If
                End If

                If NewPcMk = Nothing Then
                    NewPcMk = "GetData"
                End If
GetData:
                FirstTimeThru = "Yes"

                For j = (RowNo2 + 1) To LineNo4
                    With StdItemsWrkSht
                        NewDwg = .Range("A" & j).Value         'Dwg
                        NewRev = .Range("B" & j).Value         'Rev
                        NewShpMk = .Range("C" & j).Value       'Ship Mark
                        NewPcMk = .Range("D" & j).Value        'New Piece Mark
                        NewPcMk = LTrim(NewPcMk)            '----------New Problem found NewPcMk's with blank spaces...........
                        NewPcMk = RTrim(NewPcMk)

                        NewQty = .Range("E" & j).Value         'Qty
                        NewDesc = .Range("F" & j).Value        'Description
                        NewInv = .Range("G" & j).Value         'Inv-1
                        NewStd = .Range("H" & j).Value         'Standard Number Example:MX1001A
                        NewMatl = .Range("I" & j).Value        'Material
                        NewWht = .Range("J" & j).Value         'Weight
                        NewReq = .Range("K" & j).Value         'Required Type
                        NewProd = .Range("L" & j).Value        'Production Code
                        If NewPcMk = Nothing Then
                            If CompDesc <> "" Then
                                With BOMWrkSht
                                    If FirstTimeThru = "Yes" Then
                                        If CompDesc = "" Then
                                            .Range("M" & RowNo).Value = "Standard was not found."
                                            With .Range("A" & RowNo & ":M" & RowNo)
                                                With .Interior
                                                    .ColorIndex = 7
                                                    .Pattern = Constants.xlSolid
                                                End With
                                            End With

                                            If ManwayInfo3134.RevNo = 0 Then
                                                .Range("Q" & RowNo).Value = "1"
                                                .Range("A" & RowNo & ":L" & RowNo).Interior.ColorIndex = 4
                                            End If
                                        Else
                                            .Range("M" & RowNo).Value = "Standard Reference only, No additional parts. " & CompDesc
                                            With .Range("A" & RowNo & ":M" & RowNo)
                                                With .Interior
                                                    .ColorIndex = 45
                                                    .Pattern = Constants.xlSolid
                                                End With
                                            End With

                                            If ManwayInfo3134.RevNo = 0 Then
                                                .Range("Q" & RowNo).Value = "1"
                                                .Range("A" & RowNo & ":L" & RowNo).Interior.ColorIndex = 4
                                            End If

                                        End If
                                    Else
                                        .Range("M" & RowNo).Value = CompDesc
                                        With .Range("A" & RowNo & ":M" & RowNo)
                                            With .Interior
                                                .ColorIndex = 45
                                                .Pattern = Constants.xlSolid
                                            End With
                                        End With

                                        If ManwayInfo3134.RevNo = 0 Then
                                            .Range("Q" & RowNo).Value = "1"
                                            .Range("A" & RowNo & ":L" & RowNo).Interior.ColorIndex = 4
                                        End If
                                    End If
                                End With
                            Else
                                If FirstTimeThru = "Yes" Then
                                    With BOMWrkSht
                                        .Range("M" & RowNo).Value = "Standard Reference only, No additional parts."
                                        With .Range("A" & RowNo & ":M" & RowNo)
                                            With .Interior
                                                .ColorIndex = 8
                                                .Pattern = Constants.xlSolid
                                            End With
                                        End With

                                        If ManwayInfo3134.RevNo = 0 Then
                                            .Range("Q" & RowNo).Value = "1"
                                            .Range("A" & RowNo & ":L" & RowNo).Interior.ColorIndex = 4
                                        End If

                                    End With
                                End If
                            End If
                            CompDesc = ""
                            FirstTimeThru = "No"
                            GoTo GetData2
                        End If

                    End With

                    With BOMWrkSht                  '----------Insert Items into Bulk BOM.
                        FirstTimeThru = "No"
                        If FoundItem = "Yes" Then
                            LineNo = ((RowNo - 1) + Count)
                        Else
                            LineNo = (RowNo - 1)
                            FoundItem = "Yes"
                        End If

                        FileToOpen = "Bulk BOM"
                        FormatLine(LineNo, FileToOpen)
                        .Range("A" & ((RowNo + 1) + Count)).Value = NewDwg
                        .Range("B" & ((RowNo + 1) + Count)).Value = NewRev
                        .Range("C" & ((RowNo + 1) + Count)).Value = NewShpMk
                        .Range("D" & ((RowNo + 1) + Count)).Value = NewPcMk

                        If OldQty = 0 Then
                            .Range("E" & ((RowNo + 1) + Count)).Value = NewQty
                        Else
                            .Range("E" & ((RowNo + 1) + Count)).Value = (NewQty * OldQty)
                        End If

                        .Range("F" & ((RowNo + 1) + Count)).Value = NewDesc
                        .Range("G" & ((RowNo + 1) + Count)).Value = NewInv
                        .Range("H" & ((RowNo + 1) + Count)).Value = NewStd
                        .Range("I" & ((RowNo + 1) + Count)).Value = NewMatl
                        If NewWht = "-" Then
                            .Range("J" & ((RowNo + 1) + Count)).Value = NewWht
                        Else
                            .Range("J" & ((RowNo + 1) + Count)).Value = (NewWht * OldQty)
                        End If
                        .Range("K" & ((RowNo + 1) + Count)).Value = NewReq
                        .Range("L" & ((RowNo + 1) + Count)).Value = NewProd

                        If CompDesc <> "" Then
                            .Range("M" & RowNo).Value = CompDesc
                            With .Range("A" & RowNo & ":M" & RowNo)
                                With .Interior
                                    .ColorIndex = 45
                                    .Pattern = Constants.xlSolid
                                End With
                            End With

                            If ManwayInfo3134.RevNo = 0 Then
                                .Range("Q" & RowNo).Value = "1"
                                .Range("A" & RowNo & ":L" & RowNo).Interior.ColorIndex = 4
                            End If

                            With .Range("A" & (RowNo + 1) & ":M" & (RowNo + 1))
                                With .Interior
                                    .ColorIndex = 45
                                    .Pattern = Constants.xlSolid
                                End With
                            End With

                            If ManwayInfo3134.RevNo = 0 Then
                                .Range("Q" & (RowNo + 1)).Value = "1"
                                .Range("A" & (RowNo + 1) & ":L" & (RowNo + 1)).Interior.ColorIndex = 4
                            End If
                        Else
                            .Range("M" & RowNo).Value = "Found Standard Information"
                            With .Range("A" & RowNo & ":M" & RowNo)
                                With .Interior
                                    .ColorIndex = 8
                                    .Pattern = Constants.xlSolid
                                End With
                            End With

                            If ManwayInfo3134.RevNo = 0 Then
                                .Range("Q" & RowNo).Value = "1"
                                .Range("A" & RowNo & ":L" & RowNo).Interior.ColorIndex = 4
                            End If

                            With .Range("A" & (RowNo + 1) & ":M" & (RowNo + 1))
                                With .Interior
                                    .ColorIndex = 8
                                    .Pattern = Constants.xlSolid
                                End With
                            End With

                            If ManwayInfo3134.RevNo = 0 Then
                                .Range("Q" & (RowNo + 1)).Value = "1"
                                .Range("A" & (RowNo + 1) & ":L" & (RowNo + 1)).Interior.ColorIndex = 4
                            End If
                        End If
                    End With
                    Count = (Count + 1)

                Next j
GetData2:
                CountVal = (CountVal + Count)
                Count = 0
                FoundItem = "No"
                CompDesc = ""
                BOMMnu.ProgressBar1.Value = i
            End With
        Next i

        If (LineNo2 + CountVal) > i Then
            GoTo RptGetData
        End If

FoundAllParts:

Err_FindStdsBOM:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Function

    Public Function GetStdInfo(ByVal CompDesc As String, ByVal Startj As Integer, ByVal StartjA As Integer, ByVal OldQty As Integer, ByVal FuncGetDataNew As String, ByVal NewBOMPos As Integer, ByVal HoldCnt As Integer) As Object
        Dim ExceptPos, jA, l, GetNewjA, TotalOnNewBOM, Totalj, CntTest, OldQtyInt, NewQtyInt As Integer
        Dim WorkShtName, FoundLast, LineNo, SearchException, FoundItem, SearchSeeNote As String
        Dim SearchNote2, SearchNote, SearchDwg, pattern As String
        Dim FileToOpen, NewDwg, NewRev, NewShpMk, NewPcMk, NewQty, NewDesc, NewInv, NewStd As String
        Dim NewProd, DescFixed, NewMatl, NewWht, NewReq As String
        Dim Workbooks As Microsoft.Office.Interop.Excel.Workbooks
        Dim BOMWrkSht As Worksheet
        Dim ExcelApp As Object
        Dim BOMMnu As BOM_Menu3D
        BOMMnu = Me

        jA = StartjA
        PrgName = "GetStdInfo"
        DescFixed = "No"

        On Error Resume Next

        ExcelApp = GetObject(, "Excel.Application")

        If Err.Number Then
            Information.Err.Clear()
            ExcelApp = CreateObject("Excel.Application")
            If Err.Number Then
                MsgBox(Err.Description)
                Exit Function
            End If
        End If

        On Error GoTo Err_GetStdInfo

        Workbooks = ExcelApp.Workbooks
        WorkShtName = "Bulk BOM"
        BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
        BOMWrkSht.Activate()
        Count = BOMWrkSht.Range("A4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row
        Totalj = Count
        TotalOnNewBOM = UBound(NewBOM, 2)
        Count = (Count - UBound(NewBOM, 2))
        Count = (Count - 4)

        Dim OldCount As Integer
        OldCount = UBound(OldBOM, 2)
        FirstTimeThru = "Yes"
        Startj = 4

        For l = (Startj + 1) To UBound(OldBOM, 2)                           'For l = (Startj + 1) To UBound(OldBOM, 2)
            '                                   With StdItemsWrkSht
            NewDwg = OldBOM(1, l)               'A  'NewDwg = .Range("A" & j).Value         'Dwg
            NewRev = OldBOM(2, l)               'B  'NewRev = .Range("B" & j).Value         'Rev
            NewShpMk = OldBOM(3, l)             'C  'NewShpMk = .Range("C" & j).Value       'Ship Mark
            NewPcMk = OldBOM(4, l)              'D  'NewPcMk = .Range("D" & j).Value        'New Piece Mark
            NewPcMk = LTrim(NewPcMk)            '----------New Problem found NewPcMk's with blank spaces...........
            NewPcMk = RTrim(NewPcMk)

            NewQty = OldBOM(5, l)               'E  'NewQty = .Range("E" & j).Value         'Qty
            NewDesc = OldBOM(6, l)              'F  'NewDesc = .Range("F" & j).Value        'Description
            NewInv = OldBOM(7, l)               'G  'NewInv = .Range("G" & j).Value         'Inv-1
            NewStd = OldBOM(8, l)               'H  'NewStd = .Range("H" & j).Value         'Standard Number Example:MX1001A
            NewMatl = OldBOM(9, l)              'I  'NewMatl = .Range("I" & j).Value        'Material
            NewWht = OldBOM(10, l)              'J  'NewWht = .Range("J" & j).Value         'Weight
            NewReq = OldBOM(11, l)              'K  'NewReq = .Range("K" & j).Value         'Required Type
            'NewProd = OldBOM(12, l)            'L  'Index Out of Bounds OldBOM only looks at first 11 columns.     'Production Code

            If NewPcMk = Nothing Then
                If CompDesc <> "" Then
                    With BOMWrkSht
                        If FirstTimeThru = "Yes" Then
                            If CompDesc = "" Then
                                .Range("M" & (NewBOMPos + Count)).Value = "Standard was not found."
                                With .Range("A" & (NewBOMPos + Count) & ":M" & (NewBOMPos + Count))
                                    With .Interior
                                        .ColorIndex = 7
                                        .Pattern = Constants.xlSolid
                                    End With
                                End With

                                If ManwayInfo3134.RevNo = 0 Then
                                    .Range("Q" & (NewBOMPos + Count)).Value = "1"
                                    .Range("A" & (NewBOMPos + Count) & ":L" & (NewBOMPos + Count)).Interior.ColorIndex = 4
                                End If
                            Else
                                .Range("M" & (NewBOMPos + Count)).Value = "Standard Reference only, No additional parts. " & CompDesc
                                OldQtyInt = OldQty
                                NewQtyInt = NewQty

                                If OldQtyInt > 0 Then
                                    If NewQtyInt = 0 Then
                                        .Range("L" & (NewBOMPos + Count)).Value = OldQtyInt
                                    Else
                                        .Range("L" & (NewBOMPos + Count)).Value = (OldQtyInt * NewQtyInt)
                                    End If
                                Else
                                    .Range("L" & (NewBOMPos + Count)).Value = NewQtyInt
                                End If

                                With .Range("A" & (NewBOMPos + Count) & ":M" & (NewBOMPos + Count))
                                    With .Interior
                                        .ColorIndex = 45
                                        .Pattern = Constants.xlSolid
                                    End With
                                End With

                                If ManwayInfo3134.RevNo = 0 Then
                                    .Range("Q" & (NewBOMPos + Count)).Value = "1"
                                    .Range("A" & (NewBOMPos + Count) & ":L" & (NewBOMPos + Count)).Interior.ColorIndex = 4
                                End If
                            End If
                        Else
                            If FoundItem <> "Yes" Then
                                .Range("M" & NewBOMPos).Value = CompDesc
                                With .Range("A" & NewBOMPos & ":M" & NewBOMPos)
                                    With .Interior
                                        .ColorIndex = 45
                                        .Pattern = Constants.xlSolid
                                    End With
                                End With

                                If ManwayInfo3134.RevNo = 0 Then
                                    .Range("Q" & NewBOMPos).Value = "1"
                                    .Range("A" & NewBOMPos & ":L" & NewBOMPos).Interior.ColorIndex = 4
                                End If
                            End If
                        End If
                    End With
                Else
                    If FirstTimeThru = "Yes" Then
                        With BOMWrkSht
                            .Range("M" & NewBOMPos).Value = "Standard Reference only, No additional parts."
                            With .Range("A" & NewBOMPos & ":M" & NewBOMPos)
                                With .Interior
                                    .ColorIndex = 8
                                    .Pattern = Constants.xlSolid
                                End With
                            End With

                            If ManwayInfo3134.RevNo = 0 Then
                                .Range("Q" & NewBOMPos).Value = "1"
                                .Range("A" & NewBOMPos & ":L" & NewBOMPos).Interior.ColorIndex = 4
                            End If
                        End With
                    End If
                End If
                CompDesc = ""
                FirstTimeThru = "No"
                GetNewjA = jA
                FuncGetDataNew = "GetDataNew"
                GoTo Err_GetStdInfo
            End If

            RowNo = StartjA

            With BOMWrkSht
                FirstTimeThru = "No"
                If FoundItem = "Yes" Then
                    LineNo = (NewBOMPos - 1)
                Else
                    LineNo = (NewBOMPos - 1)
                    FoundItem = "Yes"
                End If

                FileToOpen = "Bulk BOM"
                LineNo = (LineNo + Count)
                FormatLine(LineNo, FileToOpen)
                .Range("A" & ((NewBOMPos + 1) + Count)).Value = NewDwg
                .Range("B" & ((NewBOMPos + 1) + Count)).Value = NewRev
                .Range("C" & ((NewBOMPos + 1) + Count)).Value = NewShpMk
                .Range("D" & ((NewBOMPos + 1) + Count)).Value = NewPcMk

                If OldQty = 0 Then
                    .Range("E" & ((NewBOMPos + 1) + Count)).Value = NewQty
                Else
                    .Range("E" & ((NewBOMPos + 1) + Count)).Value = (NewQty * OldQty)
                End If

                .Range("F" & ((NewBOMPos + 1) + Count)).Value = NewDesc     '
                .Range("G" & ((NewBOMPos + 1) + Count)).Value = NewInv      '
                .Range("H" & ((NewBOMPos + 1) + Count)).Value = NewStd      '
                .Range("I" & ((NewBOMPos + 1) + Count)).Value = NewMatl     '
                If NewWht = "-" Then
                    .Range("J" & ((NewBOMPos + 1) + Count)).Value = NewWht
                Else
                    .Range("J" & ((NewBOMPos + 1) + Count)).Value = (NewWht * OldQty)
                End If
                .Range("K" & ((NewBOMPos + 1) + Count)).Value = NewReq

                If CompDesc <> "" Then
                    If DescFixed = "No" Then
                        .Range("M" & (NewBOMPos + Count)).Value = CompDesc
                        OldQtyInt = OldQty
                        NewQtyInt = NewQty

                        If OldQtyInt > 0 Then
                            If NewQtyInt > 0 Then
                                .Range("L" & (NewBOMPos + Count)).Value = (OldQtyInt * NewQtyInt)
                            Else
                                .Range("L" & (NewBOMPos + Count)).Value = OldQtyInt
                            End If
                        Else
                            .Range("L" & (NewBOMPos + Count)).Value = NewQtyInt
                        End If

                        DescFixed = "Yes"
                    End If

                    With .Range("A" & (NewBOMPos + Count) & ":M" & (NewBOMPos + Count))
                        With .Interior
                            .ColorIndex = 45
                            .Pattern = Constants.xlSolid
                        End With
                    End With

                    If ManwayInfo3134.RevNo = 0 Then
                        .Range("Q" & (NewBOMPos + Count)).Value = "1"
                        .Range("A" & (NewBOMPos + Count) & ":L" & (NewBOMPos + Count)).Interior.ColorIndex = 4
                    End If

                    With .Range("A" & ((NewBOMPos + 1) + Count) & ":M" & ((NewBOMPos + 1) + Count))
                        With .Interior
                            .ColorIndex = 45
                            .Pattern = Constants.xlSolid
                        End With
                    End With

                    If ManwayInfo3134.RevNo = 0 Then
                        .Range("Q" & ((NewBOMPos + 1) + Count)).Value = "1"
                        .Range("A" & ((NewBOMPos + 1) + Count) & ":L" & ((NewBOMPos + 1) + Count)).Interior.ColorIndex = 4
                    End If
                Else
                    .Range("M" & NewBOMPos).Value = "Found Standard Information"

                    With .Range("A" & NewBOMPos & ":M" & NewBOMPos)
                        With .Interior
                            .ColorIndex = 8
                            .Pattern = Constants.xlSolid
                        End With
                    End With

                    If ManwayInfo3134.RevNo = 0 Then
                        .Range("Q" & NewBOMPos).Value = "1"
                        .Range("A" & NewBOMPos & ":L" & NewBOMPos).Interior.ColorIndex = 4
                    End If

                    With .Range("A" & (NewBOMPos + 1) & ":M" & (NewBOMPos + 1))
                        With .Interior
                            .ColorIndex = 8
                            .Pattern = Constants.xlSolid
                        End With
                    End With

                    If ManwayInfo3134.RevNo = 0 Then
                        .Range("Q" & (NewBOMPos + 1)).Value = "1"
                        .Range("A" & (NewBOMPos + 1) & ":L" & (NewBOMPos + 1)).Interior.ColorIndex = 4
                    End If
                End If
            End With

            FirstTimeThru = "No"
            Count = (Count + 1)
        Next l

Err_GetStdInfo:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Function

    Public Function ConvertC(ByVal Test As String, ByVal FType As String) As String
        Dim DimSize, DimSize2 As Double
        Dim SearchDiv As String
        Dim FirstPartA, FirstPartAB, FirstPartABB, FirstPartABC, FirstPartABCA, FirstPartABCB As String
        Dim SecondPartA, SecondPartAA, SecondPartAB, SecondPartABB, SecondPartABC As String
        Dim ThirdPartA, ThirdPartAA, ThirdPartAB, ThirdPartB, ThirdPartBB, ThirdPartBC As String
        Dim ThirdPartBBA, ThirdPartBBB, ThirdPartBBC, SecondPartABBB, SecondPartABBC As String
        Dim SecondPartABCB, SecondPartABCA As String
        Dim ThirdPartBBCA, ThirdPartBBCB, ThirdPartABB, ThirdPartABC As String
        Dim SecondPartABBCC, SecondPartABBCA, SearchRoll, SearchRoll2, SearchBracket, LFound As String
        Dim DivPos, IDPos, ODPos, WBeamLen, ChannelLen, MMPos As Integer
        Dim SearchBBE, SearchBBL, SearchBOE, SearchBW, SearchCBE, SearchCOE As String
        Dim SearchG, SearchGAL, SearchMBE, SearchMOE, SearchNPT, SearchPBE As String
        Dim SearchSOL, SearchTBE, SearchTOE, SearchTOL, SearchTS, SearchWOL As String
        Dim SearchNOTE, SearchSee, SearchShip, SearchBuy, SearchMM, EndAdd As String
        Dim FoundBBE, FoundBBL, FoundBOE, FoundBW, FoundCBE, FoundCOE, FoundG As Integer
        Dim FoundGAL, FoundMBE, FoundMOE, FoundNPT, FoundPBE, FoundSOL, FoundTBE As Integer
        Dim FoundTOE, FoundTOL, FoundTS, FoundWOL, FoundNote, FoundSee, FoundShip, FoundPipe, FoundTube As Integer
        Dim FoundBuy, FoundMM, FoundInch, FoundSecFoot, StdWtPos, FoundRoll, FoundRoll2, FoundBracket As Integer
        PrgName = "ConvertBeams"

        On Error GoTo Err_ConvertBeams

        SearchBBE = " BBE"
        SearchBBL = " BBL"
        SearchBOE = " BOE"
        SearchBW = " BW"
        SearchCBE = " CBE"
        SearchCOE = " COE"
        SearchG = " G"
        SearchGAL = " GAL"
        SearchMBE = " MBE"
        SearchMOE = " MOE"
        SearchNPT = " NPT"
        SearchPBE = " PBE"
        SearchSOL = " SOL"
        SearchTBE = " TBE"
        SearchTOE = " TOE"
        SearchTOL = " TOL"
        SearchTS = " TS"
        SearchWOL = " WOL"
        SearchNOTE = " NOTE"
        SearchSee = " SEE"
        SearchShip = " SHIP"
        SearchBuy = " BUY"
        SearchMM = "MM"
        SearchRoll = " ROLL"
        SearchRoll2 = " (COLD ROLLED)"
        SearchBracket = " ("

        SearchDiv = "/"
        FootPos = InStr(Test, SearchFoot)
        InchPos = InStr(Test, SearchInch)
        SearchPos = InStr(Test, SearchSpace)
        XPos = InStr(Test, SearchX)
        PrevXPos = 0

        While XPos > 0
            If PrevXPos > 0 Then
                FirstPart = Mid(Test, 1, ((XPos - 1) + PrevXPos))
                SecondPart = Mid(Test, (XPos + PrevXPos + 3), (Len(Test) - (XPos + PrevXPos + 2)))
                PrevXPos = (PrevXPos + (XPos + 2))
                XPos = InStr(SecondPart, SearchX)
            Else
                FirstPart = Mid(Test, 1, (XPos - 1))
                SecondPart = Mid(Test, (XPos + 3), (Len(Test) - (XPos + 2)))
                PrevXPos = (XPos + 2)
                XPos = InStr(SecondPart, SearchX)
            End If
        End While

        Select Case FirstPart                   'Standard Channel--->Metric Parts start at C75
            Case "C3 x 4.1"
                CFound = "Standard"
            Case "C3 x 5"
                CFound = "Standard"
            Case "C3 x 6"
                CFound = "Standard"
            Case "C4 x 5.4"
                CFound = "Standard"
            Case "C4 x 6.25"
                CFound = "Standard"
            Case "C4 x 7.25"
                CFound = "Standard"
            Case "C5 x 6.7"
                CFound = "Standard"
            Case "C5 x 9"
                CFound = "Standard"
            Case "C5 x 11.5"
                CFound = "Standard"
            Case "C6 x 8.2"
                CFound = "Standard"
            Case "C6 x 10.5"
                CFound = "Standard"
            Case "C6 x 13"
                CFound = "Standard"
            Case "C7 x 9.8"
                CFound = "Standard"
            Case "C7 x 12.25"
                CFound = "Standard"
            Case "C7 x 14.75"
                CFound = "Standard"
            Case "C8 x 11.5"
                CFound = "Standard"
            Case "C8 x 13.75"
                CFound = "Standard"
            Case "C8 x 18.75"
                CFound = "Standard"
            Case "C9 x 13.4"
                CFound = "Standard"
            Case "C9 x 15"
                CFound = "Standard"
            Case "C9 x 20"
                CFound = "Standard"
            Case "C10 x 15.3"
                CFound = "Standard"
            Case "C10 x 20"
                CFound = "Standard"
            Case "C10 x 25"
                CFound = "Standard"
            Case "C10 x 30"
                CFound = "Standard"
            Case "C12 x 20.7"
                CFound = "Standard"
            Case "C12 x 25"
                CFound = "Standard"
            Case "C12 x 30"
                CFound = "Standard"
            Case "C15 x 33.9"
                CFound = "Standard"
            Case "C15 x 40"
                CFound = "Standard"
            Case "C15 x 50"
                CFound = "Standard"
            Case "M4 x 13"                  'Standard M Channel
                CFound = "Standard"
            Case "M5 x 18.9"
                CFound = "Standard"
            Case "M6 x 4.4"
                CFound = "Standard"
            Case "M6 x 20"
                CFound = "Standard"
            Case "M8 x 6.5"
                CFound = "Standard"
            Case "M10 x 9"
                CFound = "Standard"
            Case "M12 x 11.8"
                CFound = "Standard"
            Case "MC3 x 7.1"                    'Standard MC Channel
                CFound = "Standard"
            Case "MC3 x 9.0"
                CFound = "Standard"
            Case "MC6 x 12.0"
                CFound = "Standard"
            Case "MC6 x 15.1"
                CFound = "Standard"
            Case "MC6 x 15.3"
                CFound = "Standard"
            Case "MC6 x 16.3"
                CFound = "Standard"
            Case "MC6 x 18.0"
                CFound = "Standard"
            Case "MC7 x 17.6"
                CFound = "Standard"
            Case "MC7 x 19.1"
                CFound = "Standard"
            Case "MC7 x 22.7"
                CFound = "Standard"
            Case "MC8 x 8.5"
                CFound = "Standard"
            Case "MC8 x 18.7"
                CFound = "Standard"
            Case "MC8 x 20.0"
                CFound = "Standard"
            Case "MC8 x 21.4"
                CFound = "Standard"
            Case "MC8 x 22.8"
                CFound = "Standard"
            Case "MC9 x 23.9"
                CFound = "Standard"
            Case "MC9 x 25.4"
                CFound = "Standard"
            Case "MC10 x 6.5"
                CFound = "Standard"
            Case "MC10 x 8.4"
                CFound = "Standard"
            Case "MC10 x 21.9"
                CFound = "Standard"
            Case "MC10 x 22"
                CFound = "Standard"
            Case "MC10 x 24.9"
                CFound = "Standard"
            Case "MC10 x 25"
                CFound = "Standard"
            Case "MC10 x 25.3"
                CFound = "Standard"
            Case "MC10 x 28.3"
                CFound = "Standard"
            Case "MC10 x 28.5"
                CFound = "Standard"
            Case "MC10 x 33.6"
                CFound = "Standard"
            Case "MC10 x 41.1"
                CFound = "Standard"
            Case "MC12 x 10.6"
                CFound = "Standard"
            Case "MC12 x 30.9"
                CFound = "Standard"
            Case "MC12 x 32.9"
                CFound = "Standard"
            Case "MC12 x 35.0"
                CFound = "Standard"
            Case "MC12 x 37.0"
                CFound = "Standard"
            Case "MC12 x 40.0"
                CFound = "Standard"
            Case "MC12 x 45.0"
                CFound = "Standard"
            Case "MC12 x 50.0"
                CFound = "Standard"
            Case "MC13 x 31.8"
                CFound = "Standard"
            Case "MC13 x 35.0"
                CFound = "Standard"
            Case "MC13 x 40.0"
                CFound = "Standard"
            Case "MC13 x 50.0"
                CFound = "Standard"
            Case "MC18 x 42.7"
                CFound = "Standard"
            Case "HP8 x 36"                         'Standard HP Channel 
                CFound = "Standard"
            Case "HP10 x 42"
                CFound = "Standard"
            Case "HP10 x 57"
                CFound = "Standard"
            Case "HP12 x 53"
                CFound = "Standard"
            Case "HP12 x 63"
                CFound = "Standard"
            Case "HP12 x 74"
                CFound = "Standard"
            Case "HP12 x 89"
                CFound = "Standard"
            Case "HP12 x 102"
                CFound = "Standard"
            Case "HP12 x 117"
                CFound = "Standard"
            Case "HP14 x 73"
                CFound = "Standard"
            Case "HP14 x 89"
                CFound = "Standard"
            Case "HP14 x 102"
                CFound = "Standard"
            Case "HP14 x 117"
                CFound = "Standard"
            Case "S3 x 5.7"                         'HBeam Standard
                CFound = "Standard"
            Case "S3 x 7.5"
                CFound = "Standard"
            Case "S4 x 7.7"
                CFound = "Standard"
            Case "S4 x 9.5"
                CFound = "Standard"
            Case "S5 x 10.0"
                CFound = "Standard"
            Case "S5 x 14.75"
                CFound = "Standard"
            Case "S6 x 12.5"
                CFound = "Standard"
            Case "S6 x 17.25"
                CFound = "Standard"
            Case "S7 x 15.3"
                CFound = "Standard"
            Case "S7 x 20.0"
                CFound = "Standard"
            Case "S8 x 18.4"
                CFound = "Standard"
            Case "S8 x 23.0"
                CFound = "Standard"
            Case "S10 x 25.4"
                CFound = "Standard"
            Case "S10 x 35.0"
                CFound = "Standard"
            Case "S12 x 31.8"
                CFound = "Standard"
            Case "S12 x 35.0"
                CFound = "Standard"
            Case "S12 x 40.8"
                CFound = "Standard"
            Case "S12 x 50.0"
                CFound = "Standard"
            Case "S15 x 42.9"
                CFound = "Standard"
            Case "S15 x 50.0"
                CFound = "Standard"
            Case "S18 x 54.7"
                CFound = "Standard"
            Case "S18 x 70.00"
                CFound = "Standard"
            Case "S20 x 66.0"
                CFound = "Standard"
            Case "S20 x 75.0"
                CFound = "Standard"
            Case "S20 x 86.0"
                CFound = "Standard"
            Case "S20 x 96.0"
                CFound = "Standard"
            Case "S24 x 80.0"
                CFound = "Standard"
            Case "S24 x 90.0"
                CFound = "Standard"
            Case "S24 x 100.0"
                CFound = "Standard"
            Case "S24 x 106.0"
                CFound = "Standard"
            Case "S24 x 121.0"
                CFound = "Standard"
            Case "W4 x 13"                          'HBeam      W       Standard
                CFound = "Standard"
            Case "W5 x 16"
                CFound = "Standard"
            Case "W5 x 19"
                CFound = "Standard"
            Case "W6 x 9"
                CFound = "Standard"
            Case "W6 x 12"
                CFound = "Standard"
            Case "W6 x 16"
                CFound = "Standard"
            Case "W6 x 15"
                CFound = "Standard"
            Case "W6 x 20"
                CFound = "Standard"
            Case "W6 x 25"
                CFound = "Standard"
            Case "W8 x 10"
                CFound = "Standard"
            Case "W8 x 13"
                CFound = "Standard"
            Case "W8 x 14"
                CFound = "Standard"
            Case "W8 x 15"
                CFound = "Standard"
            Case "W8 x 18"
                CFound = "Standard"
            Case "W8 x 21"
                CFound = "Standard"
            Case "W8 x 24"
                CFound = "Standard"
            Case "W8 x 28"
                CFound = "Standard"
            Case "W8 x 31"
                CFound = "Standard"
            Case "W8 x 35"
                CFound = "Standard"
            Case "W8 x 40"
                CFound = "Standard"
            Case "W8 x 48"
                CFound = "Standard"
            Case "W8 x 58"
                CFound = "Standard"
            Case "W8 x 67"
                CFound = "Standard"
            Case "W10 x 12"
                CFound = "Standard"
            Case "W10 x 15"
                CFound = "Standard"
            Case "W10 x 16"
                CFound = "Standard"
            Case "W10 x 17"
                CFound = "Standard"
            Case "W10 x 19"
                CFound = "Standard"
            Case "W10 x 22"
                CFound = "Standard"
            Case "W10 x 26"
                CFound = "Standard"
            Case "W10 x 30"
                CFound = "Standard"
            Case "W10 x 33"
                CFound = "Standard"
            Case "W10 x 39"
                CFound = "Standard"
            Case "W10 x 40"
                CFound = "Standard"
            Case "W10 x 49"
                CFound = "Standard"
            Case "W10 x 54"
                CFound = "Standard"
            Case "W10 x 60"
                CFound = "Standard"
            Case "W10 x 68"
                CFound = "Standard"
            Case "W10 x 77"
                CFound = "Standard"
            Case "W10 x 88"
                CFound = "Standard"
            Case "W10 x 100"
                CFound = "Standard"
            Case "W10 x 112"
                CFound = "Standard"
            Case "W12 x 14"
                CFound = "Standard"
            Case "W12 x 16"
                CFound = "Standard"
            Case "W12 x 19"
                CFound = "Standard"
            Case "W12 x 21"
                CFound = "Standard"
            Case "W12 x 22"
                CFound = "Standard"
            Case "W12 x 26"
                CFound = "Standard"
            Case "W12 x 30"
                CFound = "Standard"
            Case "W12 x 35"
                CFound = "Standard"
            Case "W12 x 40"
                CFound = "Standard"
            Case "W12 x 45"
                CFound = "Standard"
            Case "W12 x 50"
                CFound = "Standard"
            Case "W12 x 53"
                CFound = "Standard"
            Case "W12 x 58"
                CFound = "Standard"
            Case "W12 x 65"
                CFound = "Standard"
            Case "W12 x 72"
                CFound = "Standard"
            Case "W12 x 79"
                CFound = "Standard"
            Case "W12 x 87"
                CFound = "Standard"
            Case "W12 x 96"
                CFound = "Standard"
            Case "W12 x 106"
                CFound = "Standard"
            Case "W12 x 120"
                CFound = "Standard"
            Case "W12 x 136"
                CFound = "Standard"
            Case "W12 x 152"
                CFound = "Standard"
            Case "W12 x 170"
                CFound = "Standard"
            Case "W12 x 190"
                CFound = "Standard"
            Case "W14 x 22"
                CFound = "Standard"
            Case "W14 x 26"
                CFound = "Standard"
            Case "W14 x 30"
                CFound = "Standard"
            Case "W14 x 34"
                CFound = "Standard"
            Case "W14 x 38"
                CFound = "Standard"
            Case "W14 x 43"
                CFound = "Standard"
            Case "W14 x 48"
                CFound = "Standard"
            Case "W14 x 53"
                CFound = "Standard"
            Case "W14 x 61"
                CFound = "Standard"
            Case "W14 x 68"
                CFound = "Standard"
            Case "W14 x 74"
                CFound = "Standard"
            Case "W14 x 82"
                CFound = "Standard"
            Case "W14 x 90"
                CFound = "Standard"
            Case "W14 x 99"
                CFound = "Standard"
            Case "W14 x 109"
                CFound = "Standard"
            Case "W14 x 120"
                CFound = "Standard"
            Case "W14 x 132"
                CFound = "Standard"
            Case "W14 x 145"
                CFound = "Standard"
            Case "W14 x 159"
                CFound = "Standard"
            Case "W14 x 176"
                CFound = "Standard"
            Case "W14 x 193"
                CFound = "Standard"
            Case "W14 x 211"
                CFound = "Standard"
            Case "W14 x 233"
                CFound = "Standard"
            Case "W14 x 257"
                CFound = "Standard"
            Case "W14 x 283"
                CFound = "Standard"
            Case "W14 x 311"
                CFound = "Standard"
            Case "W14 x 342"
                CFound = "Standard"
            Case "W14 x 370"
                CFound = "Standard"
            Case "W14 x 398"
                CFound = "Standard"
            Case "W14 x 426"
                CFound = "Standard"
            Case "W14 x 455"
                CFound = "Standard"
            Case "W14 x 500"
                CFound = "Standard"
            Case "W14 x 550"
                CFound = "Standard"
            Case "W14 x 605"
                CFound = "Standard"
            Case "W14 x 665"
                CFound = "Standard"
            Case "W14 x 730"
                CFound = "Standard"
            Case "W16 x 26"
                CFound = "Standard"
            Case "W16 x 31"
                CFound = "Standard"
            Case "W16 x 36"
                CFound = "Standard"
            Case "W16 x 40"
                CFound = "Standard"
            Case "W16 x 45"
                CFound = "Standard"
            Case "W16 x 50"
                CFound = "Standard"
            Case "W16 x 57"
                CFound = "Standard"
            Case "W16 x 67"
                CFound = "Standard"
            Case "W16 x 77"
                CFound = "Standard"
            Case "W16 x 89"
                CFound = "Standard"
            Case "W16 x 100"
                CFound = "Standard"
            Case "W18 x 35"
                CFound = "Standard"
            Case "W18 x 40"
                CFound = "Standard"
            Case "W18 x 46"
                CFound = "Standard"
            Case "W18 x 41"
                CFound = "Standard"
            Case "W18 x 45"
                CFound = "Standard"
            Case "W18 x 50"
                CFound = "Standard"
            Case "W18 x 55"
                CFound = "Standard"
            Case "W18 x 60"
                CFound = "Standard"
            Case "W18 x 65"
                CFound = "Standard"
            Case "W18 x 71"
                CFound = "Standard"
            Case "W18 x 76"
                CFound = "Standard"
            Case "W18 x 86"
                CFound = "Standard"
            Case "W18 x 97"
                CFound = "Standard"
            Case "W18 x 106"
                CFound = "Standard"
            Case "W18 x 119"
                CFound = "Standard"
            Case "W21 x 44"
                CFound = "Standard"
            Case "W21 x 48"
                CFound = "Standard"
            Case "W21 x 50"
                CFound = "Standard"
            Case "W21 x 57"
                CFound = "Standard"
            Case "W21 x 55"
                CFound = "Standard"
            Case "W21 x 62"
                CFound = "Standard"
            Case "W21 x 68"
                CFound = "Standard"
            Case "W21 x 73"
                CFound = "Standard"
            Case "W21 x 83"
                CFound = "Standard"
            Case "W21 x 93"
                CFound = "Standard"
            Case "W21 x 101"
                CFound = "Standard"
            Case "W21 x 111"
                CFound = "Standard"
            Case "W21 x 122"
                CFound = "Standard"
            Case "W21 x 132"
                CFound = "Standard"
            Case "W21 x 147"
                CFound = "Standard"
            Case "W24 x 55"
                CFound = "Standard"
            Case "W24 x 56"
                CFound = "Standard"
            Case "W24 x 60"
                CFound = "Standard"
            Case "W24 x 61"
                CFound = "Standard"
            Case "W24 x 68"
                CFound = "Standard"
            Case "W24 x 76"
                CFound = "Standard"
            Case "W24 x 84"
                CFound = "Standard"
            Case "W24 x 94"
                CFound = "Standard"
            Case "W24 x 104"
                CFound = "Standard"
            Case "W24 x 117"
                CFound = "Standard"
            Case "W24 x 131"
                CFound = "Standard"
            Case "W24 x 146"
                CFound = "Standard"
            Case "W24 x 162"
                CFound = "Standard"
            Case "W27 x 84"
                CFound = "Standard"
            Case "W27 x 94"
                CFound = "Standard"
            Case "W27 x 102"
                CFound = "Standard"
            Case "W27 x 114"
                CFound = "Standard"
            Case "W27 x 146"
                CFound = "Standard"
            Case "W27 x 161"
                CFound = "Standard"
            Case "W27 x 178"
                CFound = "Standard"
            Case "W30 x 99"
                CFound = "Standard"
            Case "W30 x 108"
                CFound = "Standard"
            Case "W30 x 116"
                CFound = "Standard"
            Case "W30 x 124"
                CFound = "Standard"
            Case "W30 x 132"
                CFound = "Standard"
            Case "W30 x 173"
                CFound = "Standard"
            Case "W30 x 191"
                CFound = "Standard"
            Case "W30 x 211"
                CFound = "Standard"
            Case "W33 x 118"
                CFound = "Standard"
            Case "W33 x 130"
                CFound = "Standard"
            Case "W33 x 141"
                CFound = "Standard"
            Case "W33 x 152"
                CFound = "Standard"
            Case "W33 x 201"
                CFound = "Standard"
            Case "W33 x 221"
                CFound = "Standard"
            Case "W33 x 241"
                CFound = "Standard"
            Case "W36 x 135"
                CFound = "Standard"
            Case "W36 x 150"
                CFound = "Standard"
            Case "W36 x 160"
                CFound = "Standard"
            Case "W36 x 170"
                CFound = "Standard"
            Case "W36 x 182"
                CFound = "Standard"
            Case "W36 x 194"
                CFound = "Standard"
            Case "W36 x 210"
                CFound = "Standard"
            Case "W36 x 230"
                CFound = "Standard"
            Case "W36 x 245"
                CFound = "Standard"
            Case "W36 x 260"
                CFound = "Standard"
            Case "W36 x 280"
                CFound = "Standard"
            Case "W36 x 300"
                CFound = "Standard"
            Case "WWF14 x 92"                   'HBeam   WWF            Standard
                CFound = "Standard"
            Case "WWF14 x 104"
                CFound = "Standard"
            Case "WWF14 x 118"
                CFound = "Standard"
            Case "WWF14 x 128"
                CFound = "Standard"
            Case "WWF14 x 142"
                CFound = "Standard"
            Case "WWF14 x 159"
                CFound = "Standard"
            Case "WWF14 x 177"
                CFound = "Standard"
            Case "WWF14 x 211"
                CFound = "Standard"
            Case "WWF14 x 258"
                CFound = "Standard"
            Case "WWF16 x 105"
                CFound = "Standard"
            Case "WWF16 x 119"
                CFound = "Standard"
            Case "WWF16 x 135"
                CFound = "Standard"
            Case "WWF16 x 147"
                CFound = "Standard"
            Case "WWF16 x 163"
                CFound = "Standard"
            Case "WWF16 x 183"
                CFound = "Standard"
            Case "WWF16 x 203"
                CFound = "Standard"
            Case "WWF16 x 243"
                CFound = "Standard"
            Case "WWF16 x 298"
                CFound = "Standard"
            Case "WWF18 x 119"
                CFound = "Standard"
            Case "WWF18 x 134"
                CFound = "Standard"
            Case "WWF18 x 152"
                CFound = "Standard"
            Case "WWF18 x 166"
                CFound = "Standard"
            Case "WWF18 x 184"
                CFound = "Standard"
            Case "WWF18 x 207"
                CFound = "Standard"
            Case "WWF18 x 229"
                CFound = "Standard"
            Case "WWF18 x 275"
                CFound = "Standard"
            Case "WWF18 x 337"
                CFound = "Standard"
            Case "WWF20 x 132"
                CFound = "Standard"
            Case "WWF20 x 150"
                CFound = "Standard"
            Case "WWF20 x 170"
                CFound = "Standard"
            Case "WWF20 x 185"
                CFound = "Standard"
            Case "WWF20 x 205"
                CFound = "Standard"
            Case "WWF20 x 230"
                CFound = "Standard"
            Case "WWF20 x 256"
                CFound = "Standard"
            Case "WWF20 x 306"
                CFound = "Standard"
            Case "WWF20 x 377"
                CFound = "Standard"
            Case "WWF20 x 437"
                CFound = "Standard"
            Case "WWF22 x 146"
                CFound = "Standard"
            Case "WWF22 x 282"
                CFound = "Standard"
            Case "WWF22 x 338"
                CFound = "Standard"
            Case "WWF22 x 416"
                CFound = "Standard"
            Case "WWF22 x 484"
                CFound = "Standard"
            Case "WWF27 x 95"
                CFound = "Standard"
            Case "WWF27 x 101"
                CFound = "Standard"
            Case "WWF27 x 110"
                CFound = "Standard"
            Case "WWF27 x 124"
                CFound = "Standard"
            Case "WWF27 x 136"
                CFound = "Standard"
            Case "WWF27 x 149"
                CFound = "Standard"
            Case "WWF31 x 103"
                CFound = "Standard"
            Case "WWF31 x 109"
                CFound = "Standard"
            Case "WWF31 x 133"
                CFound = "Standard"
            Case "WWF31 x 157"
                CFound = "Standard"
            Case "WWF31 x 187"
                CFound = "Standard"
            Case "WWF31 x 223"
                CFound = "Standard"
            Case "WWF35 x 113"
                CFound = "Standard"
            Case "WWF35 x 128"
                CFound = "Standard"
            Case "WWF35 x 142"
                CFound = "Standard"
            Case "WWF35 x 167"
                CFound = "Standard"
            Case "WWF35 x 197"
                CFound = "Standard"
            Case "WWF35 x 233"
                CFound = "Standard"
            Case "WWF35 x 279"
                CFound = "Standard"
            Case "WWF39 x 134"
                CFound = "Standard"
            Case "WWF39 x 163"
                CFound = "Standard"
            Case "WWF39 x 188"
                CFound = "Standard"
            Case "WWF39 x 217"
                CFound = "Standard"
            Case "WWF39 x 253"
                CFound = "Standard"
            Case "WWF39 x 300"
                CFound = "Standard"
            Case "WWF43 x 147"
                CFound = "Standard"
            Case "WWF43 x 171"
                CFound = "Standard"
            Case "WWF43 x 195"
                CFound = "Standard"
            Case "WWF43 x 225"
                CFound = "Standard"
            Case "WWF43 x 260"
                CFound = "Standard"
            Case "WWF43 x 307"
                CFound = "Standard"
            Case "WWF47 x 437"
                CFound = "Standard"
            Case "WWF47 x 437"
                CFound = "Standard"
            Case "WWF47 x 437"
                CFound = "Standard"
            Case "WWF47 x 437"
                CFound = "Standard"
            Case "WWF47 x 437"
                CFound = "Standard"
            Case "L 3/4 x 3/4 x 1/8"                    'Standard Angle
                CFound = "Standard"
            Case "L 1 x 1 x 1/8"
                CFound = "Standard"
            Case "L 1 x 1 x 3/16"
                CFound = "Standard"
            Case "L 1 x 1 x 1/4"
                CFound = "Standard"
            Case "L 1 1/4 x 1 1/4 x 1/8"
                CFound = "Standard"
            Case "L 1 1/4 x 1 1/4 x 3/16"
                CFound = "Standard"
            Case "L 1 1/4 x 1 1/4 x 1/4"
                CFound = "Standard"
            Case "L 1 1/2 x 1 1/2 x 1/8"
                CFound = "Standard"
            Case "L 1 1/2 x 1 1/2 x 3/16"
                CFound = "Standard"
            Case "L 1 1/2 x 1 1/2 x 1/4"
                CFound = "Standard"
            Case "L 1 3/4 x 1 3/4 x 1/8"
                CFound = "Standard"
            Case "L 1 3/4 x 1 3/4 x 3/16"
                CFound = "Standard"
            Case "L 1 3/4 x 1 3/4 x 1/4"
                CFound = "Standard"
            Case "L 2 x 2 x 1/8"
                CFound = "Standard"
            Case "L 2 x 2 x 3/16"
                CFound = "Standard"
            Case "L 2 x 2 x 1/4"
                CFound = "Standard"
            Case "L 2 x 2 x 5/16"
                CFound = "Standard"
            Case "L 2 x 2 x 3/8"
                CFound = "Standard"
            Case "L 2 1/2 x 2 1/2 x 1/8"
                CFound = "Standard"
            Case "L 2 1/2 x 2 1/2 x 3/16"
                CFound = "Standard"
            Case "L 2 1/2 x 2 1/2 x 1/4"
                CFound = "Standard"
            Case "L 2 1/2 x 2 1/2 x 5/16"
                CFound = "Standard"
            Case "L 2 1/2 x 2 1/2 x 3/8"
                CFound = "Standard"
            Case "L 2 1/2 x 2 1/2 x 1/2"
                CFound = "Standard"
            Case "L 3 x 3 x 3/16"
                CFound = "Standard"
            Case "L 3 x 3 x 1/4"
                CFound = "Standard"
            Case "L 3 x 3 x 5/16"
                CFound = "Standard"
            Case "L 3 x 3 x 3/8"
                CFound = "Standard"
            Case "L 3 x 3 x 7/16"
                CFound = "Standard"
            Case "L 3 x 3 x 1/2"
                CFound = "Standard"
            Case "L 3 1/2 x 3 1/2 x 1/4"
                CFound = "Standard"
            Case "L 3 1/2 x 3 1/2 x 5/16"
                CFound = "Standard"
            Case "L 3 1/2 x 3 1/2 x 3/8"
                CFound = "Standard"
            Case "L 3 1/2 x 3 1/2 x 7/16"
                CFound = "Standard"
            Case "L 3 1/2 x 3 1/2 x 1/2"
                CFound = "Standard"
            Case "L 4 x 4 x 1/4"
                CFound = "Standard"
            Case "L 4 x 4 x 5/16"
                CFound = "Standard"
            Case "L 4 x 4 x 3/8"
                CFound = "Standard"
            Case "L 4 x 4 x 7/16"
                CFound = "Standard"
            Case "L 4 x 4 x 1/2"
                CFound = "Standard"
            Case "L 4 x 4 x 5/8"
                CFound = "Standard"
            Case "L 4 x 4 x 3/4"
                CFound = "Standard"
            Case "L 5 x 5 x 5/16"
                CFound = "Standard"
            Case "L 5 x 5 x 3/8"
                CFound = "Standard"
            Case "L 5 x 5 x 7/16"
                CFound = "Standard"
            Case "L 5 x 5 x 1/2"
                CFound = "Standard"
            Case "L 5 x 5 x 5/8"
                CFound = "Standard"
            Case "L 5 x 5 x 3/4"
                CFound = "Standard"
            Case "L 5 x 5 x 7/8"
                CFound = "Standard"
            Case "L 6 x 6 x 5/16"
                CFound = "Standard"
            Case "L 6 x 6 x 3/8"
                CFound = "Standard"
            Case "L 6 x 6 x 7/16"
                CFound = "Standard"
            Case "L 6 x 6 x 1/2"
                CFound = "Standard"
            Case "L 6 x 6 x 9/16"
                CFound = "Standard"
            Case "L 6 x 6 x 5/8"
                CFound = "Standard"
            Case "L 6 x 6 x 3/4"
                CFound = "Standard"
            Case "L 6 x 6 x 7/8"
                CFound = "Standard"
            Case "L 6 x 6 x 1"
                CFound = "Standard"
            Case "L 8 x 8 x 1/2"
                CFound = "Standard"
            Case "L 8 x 8 x 9/16"
                CFound = "Standard"
            Case "L 8 x 8 x 5/8"
                CFound = "Standard"
            Case "L 8 x 8 x 3/4"
                CFound = "Standard"
            Case "L 8 x 8 x 7/8"
                CFound = "Standard"
            Case "L 8 x 8 x 1"
                CFound = "Standard"
            Case "L 8 x 8 x 1 1/8"
                CFound = "Standard"
            Case "L 2 x 1 1/4 x 3/16"                             '----------------------------------Unequal Leg Angles.
                CFound = "Standard"
            Case "L 2 x 1 1/2 x 3/16"
                CFound = "Standard"
            Case "L 2 x 1 1/2 x 1/4"
                CFound = "Standard"
            Case "L 2 1/2 x 2 x 3/16"
                CFound = "Standard"
            Case "L 2 1/2 x 2 x 1/4"
                CFound = "Standard"
            Case "L 2 1/2 x 2 x 5/16"
                CFound = "Standard"
            Case "L 2 1/2 x 2 x 3/8"
                CFound = "Standard"
            Case "L 2 1/2 x 2 1/2 x 1/4"
                CFound = "Standard"
            Case "L 3 x 2 x 3/16"
                CFound = "Standard"
            Case "L 3 x 2 x 1/4"
                CFound = "Standard"
            Case "L 3 x 2 x 5/16"
                CFound = "Standard"
            Case "L 3 x 2 x 3/8"
                CFound = "Standard"
            Case "L 3 x 2 x 7/16"
                CFound = "Standard"
            Case "L 3 x 2 x 1/2"
                CFound = "Standard"
            Case "L 3 x 2 1/2 x 3/16"
                CFound = "Standard"
            Case "L 3 x 2 1/2 x 1/4"
                CFound = "Standard"
            Case "L 3 x 2 1/2 x 5/16"
                CFound = "Standard"
            Case "L 3 x 2 1/2 x 3/8"
                CFound = "Standard"
            Case "L 3 x 2 1/2 x 1/2"
                CFound = "Standard"
            Case "L 3 1/2 x 2 1/2 x 1/4"
                CFound = "Standard"
            Case "L 3 1/2 x 2 1/2 x 5/16"
                CFound = "Standard"
            Case "L 3 1/2 x 2 1/2 x 3/8"
                CFound = "Standard"
            Case "L 3 1/2 x 2 1/2 x 1/2"
                CFound = "Standard"
            Case "L 3 1/2 x 3 x 1/4"
                CFound = "Standard"
            Case "L 3 1/2 x 3 x 5/16"
                CFound = "Standard"
            Case "L 3 1/2 x 3 x 3/8"
                CFound = "Standard"
            Case "L 3 1/2 x 3 x 7/16"
                CFound = "Standard"
            Case "L 3 1/2 x 3 x 1/2"
                CFound = "Standard"
            Case "L 4 x 3 x 1/4"
                CFound = "Standard"
            Case "L 4 x 3 x 5/16"
                CFound = "Standard"
            Case "L 4 x 3 x 3/8"
                CFound = "Standard"
            Case "L 4 x 3 x 1/2"
                CFound = "Standard"
            Case "L 4 x 3 x 5/8"
                CFound = "Standard"
            Case "L 4 x 3 1/2 x 1/4"
                CFound = "Standard"
            Case "L 4 x 3 1/2 x 5/16"
                CFound = "Standard"
            Case "L 4 x 3 1/2 x 3/8"
                CFound = "Standard"
            Case "L 4 x 3 1/2 x 7/16"
                CFound = "Standard"
            Case "L 4 x 3 1/2 x 1/2"
                CFound = "Standard"
            Case "L 4 x 3 1/2 x 5/8"
                CFound = "Standard"
            Case "L 5 x 3 x 1/4"
                CFound = "Standard"
            Case "L 5 x 3 x 5/16"
                CFound = "Standard"
            Case "L 5 x 3 x 3/8"
                CFound = "Standard"
            Case "L 5 x 3 x 7/16"
                CFound = "Standard"
            Case "L 5 x 3 x 1/2"
                CFound = "Standard"
            Case "L 5 x 3 1/2 x 1/4"
                CFound = "Standard"
            Case "L 5 x 3 1/2 x 5/16"
                CFound = "Standard"
            Case "L 5 x 3 1/2 x 3/8"
                CFound = "Standard"
            Case "L 5 x 3 1/2 x 7/16"
                CFound = "Standard"
            Case "L 5 x 3 1/2 x 1/2"
                CFound = "Standard"
            Case "L 5 x 3 1/2 x 5/8"
                CFound = "Standard"
            Case "L 5 x 3 1/2 x 3/4"
                CFound = "Standard"
            Case "L 6 x 3 1/2 x 5/16"
                CFound = "Standard"
            Case "L 6 x 3 1/2 x 3/8"
                CFound = "Standard"
            Case "L 6 x 3 1/2 x 1/2"
                CFound = "Standard"
            Case "L 6 x 4 x 1/4"
                CFound = "Standard"
            Case "L 6 x 4 x 5/16"
                CFound = "Standard"
            Case "L 6 x 4 x 3/8"
                CFound = "Standard"
            Case "L 6 x 4 x 7/16"
                CFound = "Standard"
            Case "L 6 x 4 x 1/2"
                CFound = "Standard"
            Case "L 6 x 4 x 9/16"
                CFound = "Standard"
            Case "L 6 x 4 x 5/8"
                CFound = "Standard"
            Case "L 6 x 4 x 3/4"
                CFound = "Standard"
            Case "L 6 x 4 x 7/8"
                CFound = "Standard"
            Case "L 6 x 4 x 1"
                CFound = "Standard"
            Case "L 7 x 4 x 3/8"
                CFound = "Standard"
            Case "L 7 x 4 x 1/2"
                CFound = "Standard"
            Case "L 8 x 4 x 1/2"
                CFound = "Standard"
            Case "L 8 x 4 x 5/8"
                CFound = "Standard"
            Case "L 8 x 4 x 3/4"
                CFound = "Standard"
            Case "L 8 x 4 x 7/8"
                CFound = "Standard"
            Case "L 8 x 4 x 1"
                CFound = "Standard"
            Case "C75 x 6"                      '---------------This part is Metric Inserted on Standard BOM Block.
                CFound = "Metric"               '---------------Channel
            Case "C75 x 7"
                CFound = "Metric"
            Case "C75 x 9"
                CFound = "Metric"
            Case "C100 x 8"
                CFound = "Metric"
            Case "C100 x 9"
                CFound = "Metric"
            Case "C100 x 11"
                CFound = "Metric"
            Case "C130 x 10"
                CFound = "Metric"
            Case "C130 x 13"
                CFound = "Metric"
            Case "C130 x 17"
                CFound = "Metric"
            Case "C150 x 12"
                CFound = "Metric"
            Case "C150 x 16"
                CFound = "Metric"
            Case "C150 x 19"
                CFound = "Metric"
            Case "C180 x 15"
                CFound = "Metric"
            Case "C180 x 18"
                CFound = "Metric"
            Case "C180 x 22"
                CFound = "Metric"
            Case "C200 x 17"
                CFound = "Metric"
            Case "C200 x 21"
                CFound = "Metric"
            Case "C200 x 28"
                CFound = "Metric"
            Case "C230 x 20"
                CFound = "Metric"
            Case "C230 x 22"
                CFound = "Metric"
            Case "C230 x 30"
                CFound = "Metric"
            Case "C250 x 23"
                CFound = "Metric"
            Case "C350 x 30"
                CFound = "Metric"
            Case "C350 x 37"
                CFound = "Metric"
            Case "C350 x 45"
                CFound = "Metric"
            Case "C310 x 31"
                CFound = "Metric"
            Case "C310 x 37"
                CFound = "Metric"
            Case "C310 x 45"
                CFound = "Metric"
            Case "C380 x 50"
                CFound = "Metric"
            Case "C380 x 60"
                CFound = "Metric"
            Case "C380 x 74"
                CFound = "Metric"
            Case "M100 x 19"                        'Standard M Channel
                CFound = "Metric"
            Case "M130 x 28.1"
                CFound = "Metric"
            Case "M150 x 6.5"
                CFound = "Metric"
            Case "M150 x 29.8"
                CFound = "Metric"
            Case "M200 x 9.7"
                CFound = "Metric"
            Case "M250 x 13.4"
                CFound = "Metric"
            Case "M310 x 17.6"
                CFound = "Metric"
            Case "MC75 x 10.6"                      'Metric MC Channel
                CFound = "Metric"
            Case "MC75 x 13.4"
                CFound = "Metric"
            Case "MC150 x 17.9"
                CFound = "Metric"
            Case "MC150 x 22.5"
                CFound = "Metric"
            Case "MC150 x 22.8"
                CFound = "Metric"
            Case "MC150 x 24.3"
                CFound = "Metric"
            Case "MC150 x 26.8"
                CFound = "Metric"
            Case "MC180 x 26.2"
                CFound = "Metric"
            Case "MC180 x 28.4"
                CFound = "Metric"
            Case "MC180 x 33.8"
                CFound = "Metric"
            Case "MC200 x 12.6"
                CFound = "Metric"
            Case "MC200 x 27.8"
                CFound = "Metric"
            Case "MC200 x 29.8"
                CFound = "Metric"
            Case "MC200 x 31.8"
                CFound = "Metric"
            Case "MC200 x 33.9"
                CFound = "Metric"
            Case "MC230 x 35.6"
                CFound = "Metric"
            Case "MC230 x 37.8"
                CFound = "Metric"
            Case "MC250 x 9.7"
                CFound = "Metric"
            Case "MC250 x 12.5"
                CFound = "Metric"
            Case "MC250 x 32.6"
                CFound = "Metric"
            Case "MC250 x 32.6"
                CFound = "Metric"
            Case "MC250 x 37.1"
                CFound = "Metric"
            Case "MC250 x 37.1"
                CFound = "Metric"
            Case "MC250 x 37.7"
                CFound = "Metric"
            Case "MC250 x 42.1"
                CFound = "Metric"
            Case "MC250 x 42.4"
                CFound = "Metric"
            Case "MC250 x 50.0"
                CFound = "Metric"
            Case "MC250 x 61.2"
                CFound = "Metric"
            Case "MC310 x 15.8"
                CFound = "Metric"
            Case "MC310 x 46.0"
                CFound = "Metric"
            Case "MC310 x 49.0"
                CFound = "Metric"
            Case "MC310 x 52.0"
                CFound = "Metric"
            Case "MC310 x 55.0"
                CFound = "Metric"
            Case "MC310 x 60.0"
                CFound = "Metric"
            Case "MC310 x 67.0"
                CFound = "Metric"
            Case "MC310 x 74.0"
                CFound = "Metric"
            Case "MC330 x 47.3"
                CFound = "Metric"
            Case "MC330 x 52.0"
                CFound = "Metric"
            Case "MC330 x 60.0"
                CFound = "Metric"
            Case "MC330 x 74.0"
                CFound = "Metric"
            Case "MC460 x 63.5"
                CFound = "Metric"
            Case "MC460 x 68.2"
                CFound = "Metric"
            Case "MC460 x 77.2"
                CFound = "Metric"
            Case "MC460 x 86.0"
                CFound = "Metric"
            Case "HP200 x 54"                   'HP Channel Metric
                CFound = "Metric"
            Case "HP250 x 62"
                CFound = "Metric"
            Case "HP250 x 85"
                CFound = "Metric"
            Case "HP310 x 79"
                CFound = "Metric"
            Case "HP310 x 94"
                CFound = "Metric"
            Case "HP310 x 110"
                CFound = "Metric"
            Case "HP310 x 132"
                CFound = "Metric"
            Case "HP310 x 152"
                CFound = "Metric"
            Case "HP310 x 174"
                CFound = "Metric"
            Case "HP360 x 108"
                CFound = "Metric"
            Case "HP360 x 132"
                CFound = "Metric"
            Case "HP360 x 152"
                CFound = "Metric"
            Case "HP360 x 174"
                CFound = "Metric"
            Case "S75 x 8"                  ' HBeam     Metric
                CFound = "Metric"
            Case "S75 x 11"
                CFound = "Metric"
            Case "S100 x 11"
                CFound = "Metric"
            Case "S100 x 14.1"
                CFound = "Metric"
            Case "S130 x 15"
                CFound = "Metric"
            Case "S130 x 22"
                CFound = "Metric"
            Case "S150 x 19"
                CFound = "Metric"
            Case "S150 x 26"
                CFound = "Metric"
            Case "S180 x 22.8"
                CFound = "Metric"
            Case "S180 x 30"
                CFound = "Metric"
            Case "S200 x 27"
                CFound = "Metric"
            Case "S200 x 34"
                CFound = "Metric"
            Case "S250 x 38"
                CFound = "Metric"
            Case "S250 x 52"
                CFound = "Metric"
            Case "S310 x 47"
                CFound = "Metric"
            Case "S310 x 52"
                CFound = "Metric"
            Case "S310 x 60.7"
                CFound = "Metric"
            Case "S310 x 74"
                CFound = "Metric"
            Case "S380 x 64"
                CFound = "Metric"
            Case "S380 x 74"
                CFound = "Metric"
            Case "S460 x 81.4"
                CFound = "Metric"
            Case "S460 x 104"
                CFound = "Metric"
            Case "S510 x 98"
                CFound = "Metric"
            Case "S510 x 112"
                CFound = "Metric"
            Case "S510 x 128"
                CFound = "Metric"
            Case "S510 x 143"
                CFound = "Metric"
            Case "S610 x 119"
                CFound = "Metric"
            Case "S610 x 134"
                CFound = "Metric"
            Case "S610 x 149"
                CFound = "Metric"
            Case "S610 x 158"
                CFound = "Metric"
            Case "S610 x 180"
                CFound = "Metric"
            Case "W100 x 19"                          'HBeam      W       Metric
                CFound = "Metric"
            Case "W130 x 24"
                CFound = "Metric"
            Case "W130 x 28"
                CFound = "Metric"
            Case "W150 x 14"
                CFound = "Metric"
            Case "W150 x 18"
                CFound = "Metric"
            Case "W150 x 24"
                CFound = "Metric"
            Case "W150 x 22"
                CFound = "Metric"
            Case "W150 x 30"
                CFound = "Metric"
            Case "W150 x 37"
                CFound = "Metric"
            Case "W200 x 15"
                CFound = "Metric"
            Case "W200 x 19"
                CFound = "Metric"
            Case "W200 x 21"
                CFound = "Metric"
            Case "W200 x 22"
                CFound = "Metric"
            Case "W200 x 27"
                CFound = "Metric"
            Case "W200 x 31"
                CFound = "Metric"
            Case "W200 x 36"
                CFound = "Metric"
            Case "W200 x 42"
                CFound = "Metric"
            Case "W200 x 46"
                CFound = "Metric"
            Case "W200 x 52"
                CFound = "Metric"
            Case "W200 x 59"
                CFound = "Metric"
            Case "W200 x 71"
                CFound = "Metric"
            Case "W200 x 86"
                CFound = "Metric"
            Case "W200 x 100"
                CFound = "Metric"
            Case "W250 x 18"
                CFound = "Metric"
            Case "W250 x 22"
                CFound = "Metric"
            Case "W250 x 24"
                CFound = "Metric"
            Case "W250 x 25"
                CFound = "Metric"
            Case "W250 x 28"
                CFound = "Metric"
            Case "W250 x 33"
                CFound = "Metric"
            Case "W250 x 39"
                CFound = "Metric"
            Case "W250 x 45"
                CFound = "Metric"
            Case "W250 x 49"
                CFound = "Metric"
            Case "W250 x 58"
                CFound = "Metric"
            Case "W250 x 67"
                CFound = "Metric"
            Case "W250 x 73"
                CFound = "Metric"
            Case "W250 x 80"
                CFound = "Metric"
            Case "W250 x 89"
                CFound = "Metric"
            Case "W250 x 101"
                CFound = "Metric"
            Case "W250 x 115"
                CFound = "Metric"
            Case "W250 x 131"
                CFound = "Metric"
            Case "W250 x 149"
                CFound = "Metric"
            Case "W250 x 167"
                CFound = "Metric"
            Case "W310 x 21"
                CFound = "Metric"
            Case "W310 x 24"
                CFound = "Metric"
            Case "W310 x 28"
                CFound = "Metric"
            Case "W310 x 31"
                CFound = "Metric"
            Case "W310 x 33"
                CFound = "Metric"
            Case "W310 x 39"
                CFound = "Metric"
            Case "W310 x 45"
                CFound = "Metric"
            Case "W310 x 52"
                CFound = "Metric"
            Case "W310 x 60"
                CFound = "Metric"
            Case "W310 x 67"
                CFound = "Metric"
            Case "W310 x 74"
                CFound = "Metric"
            Case "W310 x 79"
                CFound = "Metric"
            Case "W310 x 86"
                CFound = "Metric"
            Case "W310 x 97"
                CFound = "Metric"
            Case "W310 x 107"
                CFound = "Metric"
            Case "W310 x 118"
                CFound = "Metric"
            Case "W310 x 129"
                CFound = "Metric"
            Case "W310 x 143"
                CFound = "Metric"
            Case "W310 x 158"
                CFound = "Metric"
            Case "W310 x 179"
                CFound = "Metric"
            Case "W310 x 202"
                CFound = "Metric"
            Case "W310 x 226"
                CFound = "Metric"
            Case "W310 x 253"
                CFound = "Metric"
            Case "W310 x 283"
                CFound = "Metric"
            Case "W360 x 33"
                CFound = "Metric"
            Case "W360 x 39"
                CFound = "Metric"
            Case "W360 x 45"
                CFound = "Metric"
            Case "W360 x 51"
                CFound = "Metric"
            Case "W360 x 57"
                CFound = "Metric"
            Case "W360 x 64"
                CFound = "Metric"
            Case "W360 x 72"
                CFound = "Metric"
            Case "W360 x 79"
                CFound = "Metric"
            Case "W360 x 91"
                CFound = "Metric"
            Case "W360 x 101"
                CFound = "Metric"
            Case "W360 x 110"
                CFound = "Metric"
            Case "W360 x 122"
                CFound = "Metric"
            Case "W360 x 134"
                CFound = "Metric"
            Case "W360 x 147"
                CFound = "Metric"
            Case "W360 x 162"
                CFound = "Metric"
            Case "W360 x 179"
                CFound = "Metric"
            Case "W360 x 196"
                CFound = "Metric"
            Case "W360 x 216"
                CFound = "Metric"
            Case "W360 x 237"
                CFound = "Metric"
            Case "W360 x 262"
                CFound = "Metric"
            Case "W360 x 287"
                CFound = "Metric"
            Case "W360 x 314"
                CFound = "Metric"
            Case "W360 x 347"
                CFound = "Metric"
            Case "W360 x 382"
                CFound = "Metric"
            Case "W360 x 421"
                CFound = "Metric"
            Case "W360 x 463"
                CFound = "Metric"
            Case "W360 x 509"
                CFound = "Metric"
            Case "W360 x 551"
                CFound = "Metric"
            Case "W360 x 592"
                CFound = "Metric"
            Case "W360 x 634"
                CFound = "Metric"
            Case "W360 x 677"
                CFound = "Metric"
            Case "W360 x 744"
                CFound = "Metric"
            Case "W360 x 818"
                CFound = "Metric"
            Case "W360 x 900"
                CFound = "Metric"
            Case "W360 x 990"
                CFound = "Metric"
            Case "W360 x 1086"
                CFound = "Metric"
            Case "W410 x 39"
                CFound = "Metric"
            Case "W410 x 46"
                CFound = "Metric"
            Case "W410 x 54"
                CFound = "Metric"
            Case "W410 x 60"
                CFound = "Metric"
            Case "W410 x 67"
                CFound = "Metric"
            Case "W410 x 74"
                CFound = "Metric"
            Case "W410 x 85"
                CFound = "Metric"
            Case "W410 x 100"
                CFound = "Metric"
            Case "W410 x 114"
                CFound = "Metric"
            Case "W410 x 132"
                CFound = "Metric"
            Case "W410 x 149"
                CFound = "Metric"
            Case "W460 x 52"
                CFound = "Metric"
            Case "W460 x 60"
                CFound = "Metric"
            Case "W460 x 68"
                CFound = "Metric"
            Case "W460 x 61"
                CFound = "Metric"
            Case "W460 x 67"
                CFound = "Metric"
            Case "W460 x 74"
                CFound = "Metric"
            Case "W460 x 82"
                CFound = "Metric"
            Case "W460 x 89"
                CFound = "Metric"
            Case "W460 x 97"
                CFound = "Metric"
            Case "W460 x 106"
                CFound = "Metric"
            Case "W460 x 113"
                CFound = "Metric"
            Case "W460 x 128"
                CFound = "Metric"
            Case "W460 x 144"
                CFound = "Metric"
            Case "W460 x 158"
                CFound = "Metric"
            Case "W460 x 177"
                CFound = "Metric"
            Case "W530 x 66"
                CFound = "Metric"
            Case "W530 x 72"
                CFound = "Metric"
            Case "W530 x 74"
                CFound = "Metric"
            Case "W530 x 85"
                CFound = "Metric"
            Case "W530 x 82"
                CFound = "Metric"
            Case "W530 x 92"
                CFound = "Metric"
            Case "W530 x 101"
                CFound = "Metric"
            Case "W530 x 109"
                CFound = "Metric"
            Case "W530 x 123"
                CFound = "Metric"
            Case "W530 x 138"
                CFound = "Metric"
            Case "W530 x 150"
                CFound = "Metric"
            Case "W530 x 165"
                CFound = "Metric"
            Case "W530 x 182"
                CFound = "Metric"
            Case "W530 x 196"
                CFound = "Metric"
            Case "W530 x 219"
                CFound = "Metric"
            Case "W610 x 82"
                CFound = "Metric"
            Case "W610 x 84"
                CFound = "Metric"
            Case "W610 x 92"
                CFound = "Metric"
            Case "W610 x 91"
                CFound = "Metric"
            Case "W610 x 101"
                CFound = "Metric"
            Case "W610 x 113"
                CFound = "Metric"
            Case "W610 x 125"
                CFound = "Metric"
            Case "W610 x 140"
                CFound = "Metric"
            Case "W610 x 155"
                CFound = "Metric"
            Case "W610 x 174"
                CFound = "Metric"
            Case "W610 x 195"
                CFound = "Metric"
            Case "W610 x 217"
                CFound = "Metric"
            Case "W610 x 241"
                CFound = "Metric"
            Case "W690 x 125"
                CFound = "Metric"
            Case "W690 x 140"
                CFound = "Metric"
            Case "W690 x 152"
                CFound = "Metric"
            Case "W690 x 170"
                CFound = "Metric"
            Case "W690 x 217"
                CFound = "Metric"
            Case "W690 x 240"
                CFound = "Metric"
            Case "W690 x 265"
                CFound = "Metric"
            Case "W760 x 147"
                CFound = "Metric"
            Case "W760 x 161"
                CFound = "Metric"
            Case "W760 x 173"
                CFound = "Metric"
            Case "W760 x 185"
                CFound = "Metric"
            Case "W760 x 196"
                CFound = "Metric"
            Case "W760 x 257"
                CFound = "Metric"
            Case "W760 x 284"
                CFound = "Metric"
            Case "W760 x 314"
                CFound = "Metric"
            Case "W840 x 176"
                CFound = "Metric"
            Case "W840 x 193"
                CFound = "Metric"
            Case "W840 x 210"
                CFound = "Metric"
            Case "W840 x 226"
                CFound = "Metric"
            Case "W840 x 299"
                CFound = "Metric"
            Case "W840 x 329"
                CFound = "Metric"
            Case "W840 x 359"
                CFound = "Metric"
            Case "W920 x 201"
                CFound = "Metric"
            Case "W920 x 223"
                CFound = "Metric"
            Case "W920 x 238"
                CFound = "Metric"
            Case "W920 x 253"
                CFound = "Metric"
            Case "W920 x 271"
                CFound = "Metric"
            Case "W920 x 289"
                CFound = "Metric"
            Case "W920 x 313"
                CFound = "Metric"
            Case "W920 x 342"
                CFound = "Metric"
            Case "W920 x 365"
                CFound = "Metric"
            Case "W920 x 387"
                CFound = "Metric"
            Case "W920 x 417"
                CFound = "Metric"
            Case "W920 x 446"
                CFound = "Metric"
            Case "WWF350 x 137"                     'WWF   Metric
                CFound = "Metric"
            Case "WWF350 x 155"
                CFound = "Metric"
            Case "WWF350 x 176"
                CFound = "Metric"
            Case "WWF350 x 192"
                CFound = "Metric"
            Case "WWF350 x 212"
                CFound = "Metric"
            Case "WWF350 x 238"
                CFound = "Metric"
            Case "WWF350 x 263"
                CFound = "Metric"
            Case "WWF350 x 315"
                CFound = "Metric"
            Case "WWF350 x 385"
                CFound = "Metric"
            Case "WWF400 x 157"
                CFound = "Metric"
            Case "WWF400 x 178"
                CFound = "Metric"
            Case "WWF400 x 202"
                CFound = "Metric"
            Case "WWF400 x 220"
                CFound = "Metric"
            Case "WWF400 x 243"
                CFound = "Metric"
            Case "WWF400 x 273"
                CFound = "Metric"
            Case "WWF400 x 303"
                CFound = "Metric"
            Case "WWF400 x 362"
                CFound = "Metric"
            Case "WWF400 x 444"
                CFound = "Metric"
            Case "WWF450 x 177"
                CFound = "Metric"
            Case "WWF450 x 201"
                CFound = "Metric"
            Case "WWF450 x 228"
                CFound = "Metric"
            Case "WWF450 x 248"
                CFound = "Metric"
            Case "WWF450 x 274"
                CFound = "Metric"
            Case "WWF450 x 308"
                CFound = "Metric"
            Case "WWF450 x 342"
                CFound = "Metric"
            Case "WWF450 x 409"
                CFound = "Metric"
            Case "WWF450 x 503"
                CFound = "Metric"
            Case "WWF500 x 197"
                CFound = "Metric"
            Case "WWF500 x 223"
                CFound = "Metric"
            Case "WWF500 x 254"
                CFound = "Metric"
            Case "WWF500 x 276"
                CFound = "Metric"
            Case "WWF500 x 306"
                CFound = "Metric"
            Case "WWF500 x 343"
                CFound = "Metric"
            Case "WWF500 x 381"
                CFound = "Metric"
            Case "WWF500 x 456"
                CFound = "Metric"
            Case "WWF500 x 561"
                CFound = "Metric"
            Case "WWF500 x 651"
                CFound = "Metric"
            Case "WWF550 x 217"
                CFound = "Metric"
            Case "WWF550 x 420"
                CFound = "Metric"
            Case "WWF550 x 503"
                CFound = "Metric"
            Case "WWF550 x 620"
                CFound = "Metric"
            Case "WWF550 x 721"
                CFound = "Metric"
            Case "WWF700 x 141"
                CFound = "Metric"
            Case "WWF700 x 151"
                CFound = "Metric"
            Case "WWF700 x 164"
                CFound = "Metric"
            Case "WWF700 x 185"
                CFound = "Metric"
            Case "WWF700 x 203"
                CFound = "Metric"
            Case "WWF700 x 222"
                CFound = "Metric"
            Case "WWF800 x 154"
                CFound = "Metric"
            Case "WWF800 x 164"
                CFound = "Metric"
            Case "WWF800 x 198"
                CFound = "Metric"
            Case "WWF800 x 235"
                CFound = "Metric"
            Case "WWF800 x 279"
                CFound = "Metric"
            Case "WWF800 x 332"
                CFound = "Metric"
            Case "WWF900 x 169"
                CFound = "Metric"
            Case "WWF900 x 192"
                CFound = "Metric"
            Case "WWF900 x 213"
                CFound = "Metric"
            Case "WWF900 x 249"
                CFound = "Metric"
            Case "WWF900 x 293"
                CFound = "Metric"
            Case "WWF900 x 347"
                CFound = "Metric"
            Case "WWF900 x 417"
                CFound = "Metric"
            Case "WWF900 x 250"
                CFound = "Metric"
            Case "WWF900 x 244"
                CFound = "Metric"
            Case "WWF900 x 280"
                CFound = "Metric"
            Case "WWF1000 x 324"
                CFound = "Metric"
            Case "WWF1000 x 377"
                CFound = "Metric"
            Case "WWF1000 x 447"
                CFound = "Metric"
            Case "WWF1100 x 220"
                CFound = "Metric"
            Case "WWF1100 x 255"
                CFound = "Metric"
            Case "WWF1100 x 291"
                CFound = "Metric"
            Case "WWF1100 x 335"
                CFound = "Metric"
            Case "WWF1100 x 388"
                CFound = "Metric"
            Case "WWF1100 x 458"
                CFound = "Metric"
            Case "WWF1200 x 263"
                CFound = "Metric"
            Case "WWF1200 x 302"
                CFound = "Metric"
            Case "WWF1200 x 364"
                CFound = "Metric"
            Case "WWF1200 x 403"
                CFound = "Metric"
            Case "WWF1200 x 487"
                CFound = "Metric"
            Case "L 19 x 19 x 3"                'Metric Angle
                CFound = "Metric"
            Case "L 25 x 25 x 3"
                CFound = "Metric"
            Case "L 25 x 25 x 5"
                CFound = "Metric"
            Case "L 25 x 25 x 6"
                CFound = "Metric"
            Case "L 31.75 x 31.75 x 3"
                CFound = "Metric"
            Case "L 31.75 x 31.75 x 5"
                CFound = "Metric"
            Case "L 31.75 x 31.75 x 6"
                CFound = "Metric"
            Case "L 38.1 x 38.1 x 3"
                CFound = "Metric"
            Case "L 38.1 x 38.1 x 5"
                CFound = "Metric"
            Case "L 38.1 x 38.1 x 6"
                CFound = "Metric"
            Case "L 45 x 45 x 3"
                CFound = "Metric"
            Case "L 45 x 45 x 5"
                CFound = "Metric"
            Case "L 45 x 45 x 6"
                CFound = "Metric"
            Case "L 55 x 55 x 3"
                CFound = "Metric"
            Case "L 55 x 55 x 5"
                CFound = "Metric"
            Case "L 55 x 55 x 6"
                CFound = "Metric"
            Case "L 55 x 55 x 8"
                CFound = "Metric"
            Case "L 55 x 55 x 10"
                CFound = "Metric"
            Case "L 65 x 65 x 3"
                CFound = "Metric"
            Case "L 65 x 65 x 5"
                CFound = "Metric"
            Case "L 65 x 65 x 6"
                CFound = "Metric"
            Case "L 65 x 65 x 8"
                CFound = "Metric"
            Case "L 65 x 65 x 10"
                CFound = "Metric"
            Case "L 65 x 65 x 13"
                CFound = "Metric"
            Case "L 75 x 75 x 5"
                CFound = "Metric"
            Case "L 75 x 75 x 6"
                CFound = "Metric"
            Case "L 75 x 75 x 8"
                CFound = "Metric"
            Case "L 75 x 75 x 10"
                CFound = "Metric"
            Case "L 75 x 75 x 11.1125"
                CFound = "Metric"
            Case "L 75 x 75 x 13"
                CFound = "Metric"
            Case "L 90 x 90 x 6"
                CFound = "Metric"
            Case "L 90 x 90 x 8"
                CFound = "Metric"
            Case "L 90 x 90 x 10"
                CFound = "Metric"
            Case "L 90 x 90 x 11.1125"
                CFound = "Metric"
            Case "L 90 x 90 x 13"
                CFound = "Metric"
            Case "L 100 x 100 x 6"
                CFound = "Metric"
            Case "L 100 x 100 x 8"
                CFound = "Metric"
            Case "L 100 x 100 x 10"
                CFound = "Metric"
            Case "L 100 x 100 x 11.1125"
                CFound = "Metric"
            Case "L 100 x 100 x 13"
                CFound = "Metric"
            Case "L 100 x 100 x 16"
                CFound = "Metric"
            Case "L 100 x 100 x 20"
                CFound = "Metric"
            Case "L 125 x 125 x 8"
                CFound = "Metric"
            Case "L 125 x 125 x 10"
                CFound = "Metric"
            Case "L 125 x 125 x 11.1125"
                CFound = "Metric"
            Case "L 125 x 125 x 13"
                CFound = "Metric"
            Case "L 125 x 125 x 16"
                CFound = "Metric"
            Case "L 125 x 125 x 20"
                CFound = "Metric"
            Case "L 125 x 125 x 22.225"
                CFound = "Metric"
            Case "L 150 x 150 x 8"
                CFound = "Metric"
            Case "L 150 x 150 x 10"
                CFound = "Metric"
            Case "L 150 x 150 x 11.1125"
                CFound = "Metric"
            Case "L 150 x 150 x 13"
                CFound = "Metric"
            Case "L 150 x 150 x 14.2875"
                CFound = "Metric"
            Case "L 150 x 150 x 16"
                CFound = "Metric"
            Case "L 150 x 150 x 20"
                CFound = "Metric"
            Case "L 150 x 150 x 22.225"
                CFound = "Metric"
            Case "L 150 x 150 x 25"
                CFound = "Metric"
            Case "L 200 x 200 x 13"
                CFound = "Metric"
            Case "L 200 x 200 x 14.2875"
                CFound = "Metric"
            Case "L 200 x 200 x 16"
                CFound = "Metric"
            Case "L 200 x 200 x 20"
                CFound = "Metric"
            Case "L 200 x 200 x 22.225"
                CFound = "Metric"
            Case "L 200 x 200 x 25"
                CFound = "Metric"
            Case "L 200 x 200 x 30"
                CFound = "Metric"
            Case "L 50 x 31.75 x 5"                             '----------------------------------Unequal Leg Angles.
                CFound = "Metric"
            Case "L 50 x 38.1 x 5"
                CFound = "Metric"
            Case "L 50 x 38.1 x 6"
                CFound = "Metric"
            Case "L 65 x 50 x 5"
                CFound = "Metric"
            Case "L 65 x 50 x 6"
                CFound = "Metric"
            Case "L 65 x 50 x 8"
                CFound = "Metric"
            Case "L 65 x 50 x 10"
                CFound = "Metric"
            Case "L 65 x 65 x 6"
                CFound = "Metric"
            Case "L 75 x 50 x 5"
                CFound = "Metric"
            Case "L 75 x 50 x 6"
                CFound = "Metric"
            Case "L 75 x 50 x 8"
                CFound = "Metric"
            Case "L 75 x 50 x 10"
                CFound = "Metric"
            Case "L 75 x 50 x 11.1125"
                CFound = "Metric"
            Case "L 75 x 50 x 13"
                CFound = "Metric"
            Case "L 75 x 65 x 5"
                CFound = "Metric"
            Case "L 75 x 65 x 6"
                CFound = "Metric"
            Case "L 75 x 65 x 8"
                CFound = "Metric"
            Case "L 75 x 65 x 10"
                CFound = "Metric"
            Case "L 75 x 65 x 13"
                CFound = "Metric"
            Case "L 90 x 65 x 6"
                CFound = "Metric"
            Case "L 90 x 65 x 8"
                CFound = "Metric"
            Case "L 90 x 65 x 10"
                CFound = "Metric"
            Case "L 90 x 65 x 13"
                CFound = "Metric"
            Case "L 90 x 75 x 6"
                CFound = "Metric"
            Case "L 90 x 75 x 8"
                CFound = "Metric"
            Case "L 90 x 75 x 10"
                CFound = "Metric"
            Case "L 90 x 75 x 11.1125"
                CFound = "Metric"
            Case "L 90 x 75 x 13"
                CFound = "Metric"
            Case "L 100 x 75 x 6"
                CFound = "Metric"
            Case "L 100 x 75 x 8"
                CFound = "Metric"
            Case "L 100 x 75 x 10"
                CFound = "Metric"
            Case "L 100 x 75 x 13"
                CFound = "Metric"
            Case "L 100 x 75 x 16"
                CFound = "Metric"
            Case "L 100 x 90 x 6"
                CFound = "Metric"
            Case "L 100 x 90 x 8"
                CFound = "Metric"
            Case "L 100 x 90 x 10"
                CFound = "Metric"
            Case "L 100 x 90 x 11.1125"
                CFound = "Metric"
            Case "L 100 x 90 x 13"
                CFound = "Metric"
            Case "L 100 x 90 x 16"
                CFound = "Metric"
            Case "L 125 x 75 x 6"
                CFound = "Metric"
            Case "L 125 x 75 x 8"
                CFound = "Metric"
            Case "L 125 x 75 x 10"
                CFound = "Metric"
            Case "L 125 x 75 x 11.1125"
                CFound = "Metric"
            Case "L 125 x 75 x 13"
                CFound = "Metric"
            Case "L 125 x 90 x 6"
                CFound = "Metric"
            Case "L 125 x 90 x 8"
                CFound = "Metric"
            Case "L 125 x 90 x 10"
                CFound = "Metric"
            Case "L 125 x 90 x 11.1125"
                CFound = "Metric"
            Case "L 125 x 90 x 13"
                CFound = "Metric"
            Case "L 125 x 90 x 16"
                CFound = "Metric"
            Case "L 125 x 90 x 20"
                CFound = "Metric"
            Case "L 150 x 90 x 8"
                CFound = "Metric"
            Case "L 150 x 90 x 10"
                CFound = "Metric"
            Case "L 150 x 90 x 13"
                CFound = "Metric"
            Case "L 150 x 100 x 6"
                CFound = "Metric"
            Case "L 150 x 100 x 8"
                CFound = "Metric"
            Case "L 150 x 100 x 10"
                CFound = "Metric"
            Case "L 150 x 100 x 11.1125"
                CFound = "Metric"
            Case "L 150 x 100 x 13"
                CFound = "Metric"
            Case "L 150 x 100 x 14.2875"
                CFound = "Metric"
            Case "L 150 x 100 x 16"
                CFound = "Metric"
            Case "L 150 x 100 x 20"
                CFound = "Metric"
            Case "L 150 x 100 x 22.225"
                CFound = "Metric"
            Case "L 150 x 100 x 25"
                CFound = "Metric"
            Case "L 180 x 100 x 10"
                CFound = "Metric"
            Case "L 180 x 100 x 13"
                CFound = "Metric"
            Case "L 200 x 100 x 13"
                CFound = "Metric"
            Case "L 200 x 100 x 16"
                CFound = "Metric"
            Case "L 200 x 100 x 20"
                CFound = "Metric"
            Case "L 200 x 100 x 22.225"
                CFound = "Metric"
            Case "L 200 x 100 x 25"
                CFound = "Metric"
            Case Else
                SearchPipe = "PIPE"
                FoundPipe = InStr(FirstPart, SearchPipe)
                SearchTube = "TUBE"
                FoundTube = InStr(FirstPart, SearchTube)

                Select Case 0
                    Case Is < FoundPipe
                        CFound = "Metric"
                        Test2 = Test
                        GoTo EndFunction
                    Case Is < FoundTube
                        CFound = "Metric"
                        Test2 = Test
                        GoTo EndFunction
                    Case Else
                        CFound = InputBox("Conversion was not found please enter Channel type in Metric for " & FirstPart)
                        GoTo BrkDown2ndPart
                End Select
        End Select

        If CFound = "Metric" Then
            GoTo EndFunction
        Else
            FType = CFound
            GoTo BrkDown2ndPart
        End If

BrkDown2ndPart:
        FoundNote = InStr(1, SecondPart, SearchNOTE)
        FoundSee = InStr(1, SecondPart, SearchSee)
        FoundShip = InStr(1, SecondPart, SearchShip)
        FoundBuy = InStr(1, SecondPart, SearchBuy)
        FoundMM = InStr(1, SecondPart, SearchMM)
        FoundBBE = InStr(1, SecondPart, SearchBBE)
        FoundBBL = InStr(1, SecondPart, SearchBBL)
        FoundBOE = InStr(1, SecondPart, SearchBOE)
        FoundBW = InStr(1, SecondPart, SearchBW)
        FoundCBE = InStr(1, SecondPart, SearchCBE)
        FoundCOE = InStr(1, SecondPart, SearchCOE)
        FoundG = InStr(1, SecondPart, SearchG)
        FoundGAL = InStr(1, SecondPart, SearchGAL)
        FoundMBE = InStr(1, SecondPart, SearchMBE)
        FoundMOE = InStr(1, SecondPart, SearchMOE)
        FoundNPT = InStr(1, SecondPart, SearchNPT)
        FoundPBE = InStr(1, SecondPart, SearchPBE)
        FoundSOL = InStr(1, SecondPart, SearchSOL)
        FoundTBE = InStr(1, SecondPart, SearchTBE)
        FoundTOE = InStr(1, SecondPart, SearchTOE)
        FoundTOL = InStr(1, SecondPart, SearchTOL)
        FoundTS = InStr(1, SecondPart, SearchTS)
        FoundWOL = InStr(1, SecondPart, SearchWOL)
        FoundRoll = InStr(1, SecondPart, SearchRoll)
        FoundRoll2 = InStr(1, SecondPart, SearchRoll2)
        FoundBracket = InStr(1, SecondPart, SearchBracket)

        Select Case 0
            Case Is < FoundRoll2
                EndAdd = Mid(SecondPart, FoundRoll2, (Len(SecondPart) - (FoundRoll2 - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundRoll2 - 1))
            Case Is < FoundBracket
                EndAdd = Mid(SecondPart, FoundBracket, (Len(SecondPart) - (FoundBracket - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundBracket - 1))
            Case Is < FoundSee
                EndAdd = Mid(SecondPart, FoundSee, (Len(SecondPart) - (FoundSee - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundSee - 1))
            Case Is < FoundNote
                EndAdd = Mid(SecondPart, FoundNote, (Len(SecondPart) - (FoundNote - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundNote - 1))
            Case Is < FoundBOE
                EndAdd = Mid(SecondPart, FoundBOE, (Len(SecondPart) - (FoundBOE - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundBOE - 1))
            Case Is < FoundBBE
                EndAdd = Mid(SecondPart, FoundBBE, (Len(SecondPart) - (FoundBBE - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundBBE - 1))
            Case Is < FoundMOE
                EndAdd = Mid(SecondPart, FoundMOE, (Len(SecondPart) - (FoundMOE - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundMOE - 1))
            Case Is < FoundMBE
                EndAdd = Mid(SecondPart, FoundMBE, (Len(SecondPart) - (FoundMBE - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundMBE - 1))
            Case Is < FoundCBE
                EndAdd = Mid(SecondPart, FoundCBE, (Len(SecondPart) - (FoundCBE - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundCBE - 1))
            Case Is < FoundCOE
                EndAdd = Mid(SecondPart, FoundCOE, (Len(SecondPart) - (FoundCOE - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundCOE - 1))
            Case Is < FoundTBE
                EndAdd = Mid(SecondPart, FoundTBE, (Len(SecondPart) - (FoundTBE - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundTBE - 1))
            Case Is < FoundTOE
                EndAdd = Mid(SecondPart, FoundTOE, (Len(SecondPart) - (FoundTOE - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundTOE - 1))
            Case Is < FoundTOL
                EndAdd = Mid(SecondPart, FoundTOL, (Len(SecondPart) - (FoundTOL - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundTOL - 1))
            Case Is < FoundShip
                EndAdd = Mid(SecondPart, FoundShip, (Len(SecondPart) - (FoundShip - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundShip - 1))
            Case Is < FoundBuy
                EndAdd = Mid(SecondPart, FoundBuy, (Len(SecondPart) - (FoundBuy - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundBuy - 1))
            Case Is < FoundBBL
                EndAdd = Mid(SecondPart, FoundBBL, (Len(SecondPart) - (FoundBBL - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundBBL - 1))
            Case Is < FoundBW
                EndAdd = Mid(SecondPart, FoundBW, (Len(SecondPart) - (FoundBW - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundBW - 1))
            Case Is < FoundGAL
                EndAdd = Mid(SecondPart, FoundGAL, (Len(SecondPart) - (FoundGAL - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundGAL - 1))
            Case Is < FoundNPT
                EndAdd = Mid(SecondPart, FoundNPT, (Len(SecondPart) - (FoundNPT - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundNPT - 1))
            Case Is < FoundPBE
                EndAdd = Mid(SecondPart, FoundPBE, (Len(SecondPart) - (FoundPBE - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundPBE - 1))
            Case Is < FoundSOL
                EndAdd = Mid(SecondPart, FoundSOL, (Len(SecondPart) - (FoundSOL - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundSOL - 1))
            Case Is < FoundTS
                EndAdd = Mid(SecondPart, FoundTS, (Len(SecondPart) - (FoundTS - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundTS - 1))
            Case Is < FoundWOL
                EndAdd = Mid(SecondPart, FoundWOL, (Len(SecondPart) - (FoundWOL - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundWOL - 1))
            Case Is < FoundRoll
                EndAdd = Mid(SecondPart, FoundRoll, (Len(SecondPart) - (FoundRoll - 1)))
                SecondPart = Mid(SecondPart, 1, (FoundRoll - 1))
            Case Else
                EndAdd = ""
        End Select

        FoundMM = InStr(1, SecondPart, SearchMM)
        If FoundMM > 0 Then
            SecondPart = InputBox("Standard BOM Block has Metric length Example: 10" & Chr(39) & "-1 5/16" & Chr(34) & " , Please enter Feet Inches for " & SecondPart & " .")
            Test2 = FirstPart & " x " & SecondPart & EndAdd
            GoTo EndFunction
        End If
EndFunction:

Err_ConvertBeams:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)

                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < Count Then
                        System.Threading.Thread.Sleep(1000)
                        Resume
                    Else
                        MsgBox(ErrMsg)
                        Stop
                        Resume
                    End If
                Else
                    MsgBox(ErrMsg)
                    Resume
                End If
            Else
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)

                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < Count Then
                        System.Threading.Thread.Sleep(1000)
                        Resume
                    Else
                        If CntExcept < (Count + (Count / 2) + 20) Then
                            System.Threading.Thread.Sleep(1000)
                            Resume
                        End If
                    End If
                End If
            End If
        End If

    End Function

    Sub BulkBom()
        Dim BOMMnu As BOM_Menu3D
        BOMMnu = Me
        BOMMnu.Show()
    End Sub

    Private Sub BtnYes_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.DwgsNotFoundList.Visible = False
    End Sub

    Private Sub BtnNo_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.DwgsNotFoundList.Visible = False
    End Sub

    Private Sub HelpButton_Renamed_Click(sender As Object, e As EventArgs) Handles BtnVideo.Click
        '-------Produce video 
        MsgBox("A Video will be produced soon-------DJL-10-11-2023")
    End Sub

    Private Sub PathBox_Click(sender As Object, e As EventArgs) Handles PathBox.Click
        Dim FileNam2 As String
        Dim lReturn As Int64

        'Test = Environment.CurrentDirectory
        'Test = Environment.SpecialFolder.Recent.GetName(8).ToString
        'Test = Environment.GetFolderPath(Environment.SpecialFolder.Recent)
        'Test = Envirnoment.UserDataPaths.Recent
        'Test = Environment.SpecialFolder.Recent
        'Test = System.Envirnoment.Path.GetTempPath

        'Test = System.IO.Path.GetDirectoryName

        'Get-PublicFolderClientPermission "\My Public Folder"
        'Get-PublicFolderClientPermission -Identity("\My Public Folder" -User Chris , Format-List)


        StartDir = System.Environment.SpecialFolder.Recent

        If StartDir = "0" Then
            StartDir = Me.PathBox.Text                          'StartDir = "C:\AdeptWork\"
        End If

        OpenFileDialog1.InitialDirectory = StartDir
        OpenFileDialog1.Filter = "AutoCAD Drawings(*.dwg)|*.dwg;"
        OpenFileDialog1.Title = "Select file to Open"
        OpenFileDialog1.FileName = "Select Drawing"           '-------DJL-12-18-2024
        lReturn = OpenFileDialog1.ShowDialog()

        FileNam = OpenFileDialog1.FileName                          'Has to be 64 bit Inorder for this to work.
        FileNam2 = OpenFileDialog1.SafeFileName
        NewDir = FileNam.Replace(FileNam2, "")

        GenInfo3233.JobDir = NewDir
        PathBox.Text = NewDir
        Me.PathBox.BackColor = System.Drawing.Color.White
        Me.BtnGetMWInfo.BackColor = System.Drawing.Color.White
        Me.DwgList.BackColor = System.Drawing.Color.GreenYellow

        'BtnGetMWInfo.PerformClick()                         '-------Already done in Pathbox just had to add below
        '-----------------------------------------------------------------------------------------
        sender = "Excel"
        SecondChk = "First"

        If Directory.Exists("K:\AWA\" & System.Environment.UserName & "\AdeptWork\") = False Then                            'DJL 9-17-2024
            'ClosePrg("Adept", "First", StartAdept)                         
            ClosePrg("Excel", "First", StartAdept)
            'ClosePrg("Inventor", "First", StartAdept)
            'ClosePrg("Acad", "First", StartAdept)
            ClosePrg("senddmp", "First", StartAdept)
            ClosePrg("senddmp", "Second", StartAdept)
        End If

        ErrFound = ""
        'Me.TabPageGenInfo.BackColor = System.Drawing.Color.Red

        'Dim DwgList As Array
        Dim Dir1 As DirectoryInfo = New DirectoryInfo(GenInfo3233.JobDir)

        If DwgList.Items.Count = 0 Then
            For Each DwgItem1 In Dir1.GetFiles("*.idw")
                If InStr(DwgItem1.Name, "MX") = 0 And InStr(DwgItem1.Name, "CH") = 0 Then
                    DwgList.Items.Add(DwgItem1)
                End If
            Next DwgItem1
            For Each DwgItem1 In Dir1.GetFiles("*.dwg")
                If InStr(DwgItem1.Name, "MX") = 0 And InStr(DwgItem1.Name, "CH") = 0 Then                           'Remove standards until primary drawings are read.
                    DwgList.Items.Add(DwgItem1)
                End If
            Next DwgItem1
        End If

        If DwgList.Items.Count > 0 Then
            Me.BtnAddAll.Enabled = True
            Me.BtnAdd.Enabled = True
            Me.BtnRemove.Enabled = True
            Me.BtnClear.Enabled = True
            btnNewDir.Enabled = True
        Else
            Me.BtnAddAll.Enabled = False
            Me.BtnAdd.Enabled = False
            Me.BtnRemove.Enabled = False
            Me.BtnClear.Enabled = False
            btnNewDir.Enabled = False
        End If

        DwgList.Sorted = True
        Me.BringToFront()
        Me.Show()

        Me.Refresh()
    End Sub

    '    Private Sub BtnGetMWInfo_Click(sender As Object, e As EventArgs) Handles BtnGetMWInfo.Click
    '        Dim ErrHandler2 As New ErrHandler3233
    '        Dim j As Integer
    '        Dim BadPart, TryYes As String
    '        Dim TestNew
    '        Dim FileNam2 As String
    '        Dim lReturn As Int64

    '        On Error GoTo Err_BtnGetMWInfo

    '        '-----------------------------------------------------------------------------------------
    '        StartDir = System.Environment.SpecialFolder.Recent

    '        If StartDir = "0" Then
    '            StartDir = Me.PathBox.Text                          'StartDir = "C:\AdeptWork\"
    '        End If

    '        OpenFileDialog1.InitialDirectory = StartDir
    '        OpenFileDialog1.Filter = "AutoCAD Drawings(*.dwg)|*.dwg;"
    '        OpenFileDialog1.Title = "Select file to Open"
    '        lReturn = OpenFileDialog1.ShowDialog()

    '        FileNam = OpenFileDialog1.FileName                          'Has to be 64 bit Inorder for this to work.
    '        FileNam2 = OpenFileDialog1.SafeFileName
    '        NewDir = FileNam.Replace(FileNam2, "")

    '        GenInfo3233.JobDir = NewDir
    '        PathBox.Text = NewDir

    '        Me.PathBox.BackColor = System.Drawing.Color.White
    '        Me.BtnGetMWInfo.BackColor = System.Drawing.Color.White
    '        Me.DwgList.BackColor = System.Drawing.Color.GreenYellow
    '        '-----------------------------------------------------------------------------------------
    '        sender = "Excel"
    '        SecondChk = "First"

    '        If Dir("K:\AWA\dlong\AdeptWork\FindCitrix.txt") = vbNullString Then                            'DJL 9-25-2023
    '            'ClosePrg("Adept", "First", StartAdept)                         
    '            ClosePrg("Excel", "First", StartAdept)
    '            'ClosePrg("Inventor", "First", StartAdept)
    '            ClosePrg("Acad", "First", StartAdept)
    '            ClosePrg("senddmp", "First", StartAdept)
    '            ClosePrg("senddmp", "Second", StartAdept)
    '        End If

    '        ErrFound = ""
    '        'Me.TabPageGenInfo.BackColor = System.Drawing.Color.Red

    '        'Dim DwgList As Array
    '        Dim Dir1 As DirectoryInfo = New DirectoryInfo(GenInfo3233.JobDir)

    '        If DwgList.Items.Count = 0 Then
    '            For Each DwgItem1 In Dir1.GetFiles("*.idw")
    '                DwgList.Items.Add(DwgItem1)
    '            Next DwgItem1
    '            For Each DwgItem1 In Dir1.GetFiles("*.dwg")
    '                DwgList.Items.Add(DwgItem1)
    '            Next DwgItem1
    '        End If

    '        DwgList.Sorted = True
    '        Me.BringToFront()
    '        Me.Show()

    'Err_BtnGetMWInfo:
    '        ErrNo = Err.Number

    '        If ErrNo <> 0 Then
    '            PriPrg = "ReadPartsListFindBOMAppServer"
    '            PrgName = "BtnGetMWInfo_Click"
    '            ErrMsg = Err.Description
    '            ErrSource = Err.Source
    '            ErrDll = Err.LastDllError
    '            ErrLastLineX = Err.Erl
    '            ErrException = Err.GetException

    '            If IsNothing(ManwayInfo3134.UserName) = True Then
    '                ManwayInfo3134.UserName = System.Environment.UserName
    '            End If

    '            Select Case ErrNo
    '                Case Is = 13 And InStr(ErrMsg, "Conversion from string") > 0
    '                    MsgBox("Program is having a time converting this item to String Error Msg = " & ErrMsg)
    '                    Stop
    '                    Resume
    '                Case Is = "91" And Mid(ErrMsg, 1, 24) = "Object reference not set"
    '                    Sapi.speak("Please open Primary Assembly in Inventor, and then pick OK on this box.")
    '                    MsgBox("Please open Primary Assembly in Inventor, and then pick OK on this box.")
    '                    ErrFound = "No Manway at Startup"
    '                    Resume Next
    '                Case Is = -2147023170 And InStr(ErrMsg, "The remote procedure call failed") <> 0
    '                    MsgBox("Part " & BadPart & " Needs to be replaced using content center, some how this file is corrupt.")
    '                    Stop
    '                    Resume
    '                Case Else
    '                    If ManwayInfo3134.UserName = "dlong" Then
    '                        MsgBox("Error Number " & ErrNo & ErrMsg & ErrSource)
    '                        Stop
    '                        Resume
    '                    Else
    '                        MsgBox("Program has new error, Error Msg = " & ErrMsg)

    '                        Dim st As New StackTrace(Err.GetException, True)
    '                        CntFrames = st.FrameCount
    '                        GetFramesSrt = st.GetFrames
    '                        PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
    '                        PrgLineNo = PrgLineNo.Replace("@", "at")
    '                        LenPrgLineNo = (Len(PrgLineNo))
    '                        PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

    '                        HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)
    '                        'Stop
    '                    End If
    '            End Select
    '        End If

    'ExitCal:
    '    End Sub

    Public Class ErrHandler3233
        Inherits Exception

        Public ErrException As System.Exception
        Public ErrLastLineX As Integer
    End Class

    Public Function ClosePrg(ByVal sender As System.Object, ByVal SecondChk As String, ByVal StartAdept As Boolean)
        Dim myProcesses() As Process
        Dim instance As Process
        Dim Title, Msg, Style, Response As Object

        'ChkForAdditional:  'For some reason if Application does not close, this thoughs prg into endless loop.

        myProcesses = Process.GetProcessesByName(sender)                '-------Get Process if open example Excel.
        StartAdept = "False"

        If IsNothing(myProcesses) <> True Then
            For Each instance In myProcesses
                Select Case sender & SecondChk
                    Case "Adept" & "First"                            '-----------------------First Check
                        'GenInfo3233.StartAdept = True
                        'GenInfo3233.StartAdept = True
                        GoTo NextInstance
                    Case "acad" & "First"
                        MsgBox("Do you have any AutoCAD files open? If so save and close them then pick ok.")
                    Case "Excel" & "First"
                        '-------Looking for solution to remove message boxes in the back ground. & skip when users want to work on files in excel at the same time.
                        SecondChk = "Second"
                        'MsgBox("Excel was closed due to Issues.")

                        Msg = "Do you have any Excel spreadsheets open? if so please save and close them, Have you saved your work?"
                        Style = MsgBoxStyle.YesNo
                        Title = "Found Excel is open and need to make sure user saves files."
                        Response = MsgBox(Msg, Style, Title)

                        If Response = 6 Then
                            GoTo KillOpenFiles
                        Else
                            GoTo NextInstance
                        End If
                    Case "Word" & "First"
                        MsgBox("Word was closed due to Issues.")
                    Case "WinWord" & "First"
                        MsgBox("Word was closed due to Issues.")
                    Case "BulkBOM" & "First"
                        MsgBox("BulkBOM was closed due to Issues.")
                    Case "Adept" & "Second"                            '-----------------------Second Check
                        GenInfo3233.StartAdept = True
                    Case "acad" & "Second"
                    Case "Excel" & "Second"
                    Case "Word" & "First"
                        MsgBox("Word was closed due to Issues.")
                    Case "MatrixPrograms" & "First"
                        MsgBox("Matrix Programs was closed due to Issues.")
                    Case "Inventor" & "First"
                        SecondChk = "Second"
                        MsgBox("Inventor was closed due to Issues.")
                    Case "senddmp" & "First"
                        MsgBox("Inventor has had a Hard Crash, program will now try to recover.")
                        SecondChk = "Second"
                    Case "senddmp" & "Second"
                        MsgBox("Inventor has had a Hard Crash, program will now try to recover.")
                End Select
KillOpenFiles:
                instance.Kill()
                instance.CloseMainWindow()
                instance.Close()
NextInstance:
            Next instance
        End If

    End Function

    Function HandleErrSQL(ByVal PrgName As String, ByVal ErrNo As String, ByVal ErrMsg As String, ByVal ErrSource As String, ByVal PriPrg As String, ByVal ErrDll As String, ByVal DwgItem As String, ByVal PrgLineNo As String)
        Dim sqlConn As ADODB.Connection
        Dim rs As ADODB.Recordset
        Dim sqlStr As String
        Dim ErrDate As Date
        Dim QuoteMkPos As Integer
        Dim UserName, ProgramNotes, ErrMsgPart1, ErrMsgPart2 As String

        sqlConn = New ADODB.Connection

        ErrDate = Now

        If IsNothing(ManwayInfo3134.UserName) = True Then
            ManwayInfo3134.UserName = System.Environment.UserName()
        End If

        UserName = ManwayInfo3134.UserName
        ProgramNotes = "VB Net 64bit for Inventor Programming Testing"

        QuoteMkPos = InStr(ErrMsg, Chr(39))

        While QuoteMkPos > 0                                        'Remove single quotes that cause database errors.
            ErrMsgPart1 = Mid(ErrMsg, 1, (QuoteMkPos - 1))
            ErrMsgPart2 = Mid(ErrMsg, (QuoteMkPos + 1), Len(ErrMsg))
            ErrMsg = (ErrMsgPart1 & ErrMsgPart2)

            QuoteMkPos = InStr(ErrMsg, Chr(39))
        End While

        '-----------------------------------------------------Save Errors to sql database
        sqlStr = "INSERT  INTO ErrCollection (PrimaryPrg, PrgName, ErrNo, ErrMsg, ErrDate, UserName, ProgramNotes, ErrSource, ErrDll, DwgName, [ProfessionalNotestoManagerson Err]) " &
        "VALUES ('" & PriPrg & "', '" & PrgName & "', '" & ErrNo & "', '" & ErrMsg & "', '" & ErrDate & "', '" & UserName & "', '" & ProgramNotes & "', '" & ErrSource & "', '" & ErrDll & "', '" & DwgItem & "', '" & PrgLineNo & "')"
        db_String = "Server=MTX16SQL09\Engineering;Database=HandleErrors;User=devDennis;Password=d3v3lop3r;Trusted_Connection=False"
        Dim ConJobLog As New SqlClient.SqlConnection
        ConJobLog = New SqlClient.SqlConnection
        ConJobLog.ConnectionString = db_String
        ConJobLog.Open()
        Dim command2 As New SqlCommand(sqlStr, ConJobLog)
        Dim Writer2
        Writer2 = command2.ExecuteReader
        ConJobLog.Close()

        ConJobLog = Nothing
        sqlConn = Nothing
        rs = Nothing
    End Function

    Function SortArrayUsingExcel(BOMList)
        '-------Move to new function-------WritetoExcel-------DJL-10-11-2023            
        '------------------------------------------------------------------------------------------------
        '-------Creator:        Dennis J. Long
        '-------Date:           12/21/2023
        '-------Description:    After putting data on Excel Spreadsheet sort the data
        '-------
        '-------Updates:        Description:
        '-------12-21-2023       Read Array and write to Excel what was collected from AutoCAD.     
        '-------                Remove Spreadsheet formation to speed up array sort.
        '-------                Must find away to sort complex Array's, instead of sorting excel
        '------------------------------------------------------------------------------------------------
        Dim i, j, k As Integer
        Dim DwgItem2, CurrentDwgNo, FirstDwg, GetDwgNo, GetRowNo, GetX, GetY, FoundDwgNo, FoundX, FoundY, FoundItem, TotalCnt As String
        Dim GetShpMK, GetPcMK As String
        Dim CntDwgsNotFound, StrLineNo, PrevCnt, CntStd As Integer
        Dim AcadOpen As Boolean

        On Error GoTo Err_SortArrayUsingExcel

        ProgressBar1.Value = 0
        Me.LblProgress.Text = "Sorting Data Found on your drawings........Please Wait"
        Me.Refresh()

        ProblemAt = "File not found for 2024"

        If Dir("K:\CAD\VBA\AutoCADXLTSheets\BOM.xlt") <> vbNullString Then
            FileToOpen = "K:\CAD\VBA\AutoCADXLTSheets\BOM.xltm"
        Else
            If Dir("K:\CAD\VBA\XLTSheets\BOM-New-1-15-2024.xltm") <> vbNullString Then
                FileToOpen = "K:\CAD\VBA\XLTSheets\BOM-New-1-15-2024.xltm"                      'Found that it was fixed here.      '-------DJL-12-10-2024
            End If
        End If

        If Dir(FileToOpen) <> "" Then
            MainBOMFile = ExcelApp.Application.Workbooks.Open(FileToOpen)
        Else
            If IsNothing(MainBOMFile) = True Then
                ProblemAt = "File not found for 2020"
                FileToOpen = "K:\CAD\VBA\XLTSheets\BOM.xltm"

                If Dir(FileToOpen) <> "" Then
                    MainBOMFile = ExcelApp.Application.Workbooks.Open(FileToOpen)
                Else
                    MsgBox("The following file was not found " & Chr(34) & FileToOpen & Chr(34) & ".")
                End If
            End If
        End If

        FileSaveAS = PathBox.Text & "\" & GenInfo3233.FullJobNo & "BOM.xls"                           'FileSaveAS = File1.Path & "\" & FullJobNo & "BOM.xls"
        Workbooks = ExcelApp.Workbooks

        WorkShtName = "Bulk BOM"
        BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
        WorkSht = Workbooks.Application.ActiveSheet
        WorkShtName = WorkSht.Name

        FileToOpen = "Bulk BOM"
        ExcelApp.Visible = True
        'Test = (UBound(BOMList, 2) - 1)
        TotalCnt = (UBound(BOMList, 2) - 1)

        'Minimize Excel so user can see dialogs from program
        ExcelApp.WindowState = XlWindowState.xlMinimized
        With BOMWrkSht                          'Want to remove this part of writing to excel to sort.-------DJL-2-5-2024

            '-------DJL-10-11-2023-------Need to move this to a later point.
            For i = 1 To (UBound(BOMList, 2) - 1)                           '-------Look at doing this later and using Array's for everything.
                RowNo = i + 4
                ProgressBar1.Maximum = (UBound(BOMList, 2) - 1)

                If RowNo = "5" Then           'Look at speeding up process by coping formatted lines   --- To Speed up Process
                    BOMWrkSht.Activate()
                Else
                    'With BOMWrkSht         '-----------------------Do Not need to format everyline, Speeds up Process.
                    .Rows((RowNo - 1) & ":" & (RowNo - 1)).Select()
                    .Rows(RowNo & ":" & RowNo).Insert()         ' .Rows((RowNo - 1) & ":" & (RowNo - 1)).Insert()   '.Rows((RowNo + 1) & ":" & (RowNo + 1)).Insert()
                    'End With
                End If


                If InStr(BOMList(1, i), "Delete") > 0 Then
                    GoTo DeleteDup
                End If

                GetShpMK = BOMList(5, i)
                GetPcMK = BOMList(3, i)

                If GetShpMK = "" And GetPcMK <> "" Then                'If BOMList(5, i) = "" & BOMList(3, i) <> "" Then
                    .Range("A" & RowNo).Value = BOMList(1, i) & "_" & GetPcMK
                Else
                    If GetShpMK <> "" Then
                        .Range("A" & RowNo).Value = BOMList(1, i) & "_" & GetShpMK
                    Else
                        .Range("A" & RowNo).Value = BOMList(1, i)
                    End If
                End If

                .Range("B" & RowNo).Value = BOMList(1, i)
                .Range("C" & RowNo).Value = BOMList(2, i)
                .Range("D" & RowNo).Value = BOMList(3, i)
                .Range("E" & RowNo).Value = BOMList(5, i)
                .Range("F" & RowNo).Value = BOMList(4, i)                           'Will always be BOMList(4, i)       '-------DJL-10-11-2023

                'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                GetMat = BOMList(11, i)
                GetMat2 = BOMList(12, i)
                GetMat3 = BOMList(13, i)

                '-------Should below be looking at 6 and 7 instead of 7 and 8-------DJL-10-11-2023
                If BOMList(7, i) = vbNullString Or BOMList(7, i) = " " Then
                    If InStr(1, BOMList(6, i), "%%D") <> 0 And BOMList(6, i) <> Nothing Then
                        GetPartDesc = BOMList(6, i)
                        GetPartDesc = GetPartDesc.Replace("%%D", " DEG.")
                    Else
                        GetPartDesc = BOMList(6, i)
                    End If

                    If IsNothing(GetLen) = False And GetLen <> "" Then
                        GetPartDesc = GetPartDesc & " x " & GetLen
                    End If

                    'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                    'If IsNothing(GetMat) = False And GetMat <> "" Then
                    '    GetPartDesc = GetPartDesc & " - " & GetMat
                    'Else
                    '    If GetMat2 = vbNullString And GetMat3 = vbNullString Then
                    '        '---------Do Nothing is already done.       
                    '    Else
                    '        GetPartDesc = GetPartDesc & " - " & GetMat2 & " " & GetMat3
                    '    End If
                    'End If
                Else
                    If InStr(1, BOMList(7, i), "%%D") <> 0 Then
                        GetPartDesc = BOMList(7, i)
                        GetPartDesc = GetPartDesc.Replace("%%D", " DEG.")
                    Else
                        GetPartDesc = BOMList(7, i)
                    End If

                    If IsNothing(GetLen) = False And GetLen <> "" Then
                        GetPartDesc = GetPartDesc & " x " & GetLen
                    End If

                    'Per request from Trevor Ruffin do not need to add Material to Description anymore.-------DJL 4-18-2024
                    'If IsNothing(GetMat) = False And GetMat <> "" Then
                    '    GetPartDesc = GetPartDesc & " - " & GetMat
                    'Else
                    '    If GetMat2 = vbNullString And GetMat3 = vbNullString Then
                    '        '---------Do Nothing is already done.  
                    '    Else
                    '        GetPartDesc = GetPartDesc & " - " & GetMat2 & " " & GetMat3
                    '    End If
                    'End If
                End If

                .Range("G" & RowNo).Value = GetPartDesc
                BOMList(7, i) = GetPartDesc

                Inv1 = BOMList(9, i)                                'Found problem were user are entering a space before the Inventory number not 
                Inv1 = LTrim(Inv1)                                  'allowing the program to find the matching Inventory number on the standards sheet.
                Inv1 = RTrim(Inv1)                                  'Modified the program here to fix issue.   DJL 03/21/2013

                .Range("H" & RowNo).Value = Inv1
                BOMList(9, i) = Inv1

                .Range("I" & RowNo).Value = BOMList(10, i)

                If BOMList(11, i) = vbNullString Or Mid(BOMList(11, i), 1, 1) = " " Then
                    .Range("J" & RowNo).Value = BOMList(12, i) & Chr(10) & BOMList(13, i)
                Else
                    .Range("J" & RowNo).Value = BOMList(11, i)
                End If

                .Range("K" & RowNo).Value = BOMList(14, i)
                .Range("N" & RowNo).NumberFormat = "@"
                .Range("N" & RowNo).Value = BOMList(15, i)
                .Range("O" & RowNo).NumberFormat = "General"
                .Range("O" & RowNo).Value = BOMList(16, i)
                .Range("P" & RowNo).NumberFormat = "General"
                .Range("P" & RowNo).Value = BOMList(0, i)
                .Range("Q" & RowNo).NumberFormat = "General"
                .Range("Q" & RowNo).Value = BOMList(17, i)
                .Range("R" & RowNo).Value = BOMList(8, i)                      'See if Standard needs to be found on some references the parts are all listed out. Example Job 9318-0206_18B parts are simular but not the same is a reference only.
                .Range("W" & RowNo).Value = BOMList(13, i)                          'Length
                .Range("X" & RowNo).Value = BOMList(18, i)                      'Procurement
                .Range("Y" & RowNo).NumberFormat = "@"
                .Range("Y" & RowNo).Value = BOMList(19, i)
                .Range("Z" & RowNo).Value = BOMList(0, i)

                If ChkBoxAutoCAD3D.Checked Then
                    .Range("V" & RowNo).Value = BOMList(12, i)
                End If

                .Range("AA" & RowNo).Value = RowNo           'Below the sort is fixed and the recno must equal the sort order.


DontAddBlankLines:  '---------------Do not Add Blank BOM Lines:
DeleteDup:
                ProgressBar1.Value = i
            Next i

        End With
        ExcelApp.WindowState = XlWindowState.xlNormal

        If IsNothing(RowNo) Then
            MsgBox("There were no BOM blocks found in any of the drawings. Please try again.")
            MainBOMFile.Close(SaveChanges:=False)
            ExcelApp.Quit()
            LblProgress.Text = ""
            Exit Function
        End If

        '-------DJL-10-11-2023
        With BOMWrkSht
            With .Range("A4:AA" & RowNo)                          'With .Range("A4:BN" & RowNo)
                'Should we be using column "A" instead of "N5"?          'Due to we could have many columns of bill of Materials on one drawing example drawing 24A on Job 221-24-00302? 
                '.Sort(Key1:= .Range("N5"), Order1:=XlSortOrder.xlAscending, Key2:= .Range("P5"), Order2:=XlSortOrder.xlDescending, Key3:= .Range("Q5"), Order3:=XlSortOrder.xlDescending, Header:=XlYesNoGuess.xlYes, OrderCustom:=1, MatchCase:=False, Orientation:=XlSortOrientation.xlSortColumns)
                .Sort(Key1:= .Range("N5"), Order1:=XlSortOrder.xlAscending, Key2:= .Range("Q5"), Order2:=XlSortOrder.xlDescending, Key3:= .Range("P5"), Order3:=XlSortOrder.xlDescending, Header:=XlYesNoGuess.xlYes, OrderCustom:=1, MatchCase:=False, Orientation:=XlSortOrientation.xlSortColumns)
            End With
        End With

        Me.LblProgress.Text = "Writing Sorted Data to An Array to speed up process........Please Wait"
        Me.Refresh()

        '-------DJL-------11-27-2023-------New process create sort.
        k = 1
        RowNo = BOMWrkSht.Range("B4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row
        ProgressBar1.Maximum = RowNo + 1
        ReDim BOMList(20, 1)

        With BOMWrkSht
            If PrevCnt = 0 Then
                PrevCnt = 1
            End If

            If .Range("B4").Value = "DWG" Then
                For i = 5 To RowNo                                    'For j = PrevCnt To RowNo
                    BOMList(0, k) = .Range("P" & i).Value
                    BOMList(1, k) = .Range("B" & i).Value                 'ColumnC    'Job Number           'BOMList(1, k) = BOMListColl(1, j)
                    BOMList(2, k) = .Range("C" & i).Value                 'ColumnD    'Dwg No.              'BOMList(2, k) = BOMListColl(2, j)
                    BOMList(3, k) = .Range("D" & i).Value                 'ColumnE    'Rev No.              'BOMList(3, k) = BOMListColl(3, j)
                    BOMList(4, k) = .Range("F" & i).Value                 'ColumnF    'Ship No.             'BOMList(4, k) = BOMListColl(4, j)
                    BOMList(5, k) = .Range("E" & i).Value                 'ColumnG    'Qty                  'BOMList(5, k) = BOMListColl(5, j) 
                    'BOMList(6, k) = .Range("G" & i).Value                'ColumnH   'Desc                  'BOMList(6, k) = BOMListColl(6, j)
                    '
                    BOMList(7, k) = .Range("G" & i).Value                 'ColumnH   'Desc                  'BOMList(7, k) = BOMListColl(7, j)
                    'BOMList(8, k) = BOMListColl(8, j)                  '                                   'BOMList(8, k) = BOMListColl(8, j)
                    BOMList(8, k) = .Range("R" & i).Value    'See if Standard needs to be found on some references the parts are all listed out. Example Job 9318-0206_18B parts are simular but not the same is a reference only.

                    BOMList(9, k) = .Range("H" & i).Value                 'ColumnK    'Inv No.              'BOMList(9, k) = BOMListColl(9, j)
                    BOMList(10, k) = .Range("I" & i).Value                'ColumnL    'Std No.              'BOMList(10, k) = BOMListColl(10, j) 

                    BOMList(11, k) = .Range("J" & i).Value                'ColumnM    'Material             'BOMList(11, k) = BOMListColl(11, j)
                    '.Range("AA" & i).Value = i                'Done below             'Column Z record number after sort.
                    'BOMList(12, k) = .Range("J" & i).Value   'Not used  is used as 11 for I           'Column I   

                    BOMList(13, k) = .Range("A" & i).Value               'Dwg No & Ship Mark or Piece Mark.
                    BOMList(14, k) = .Range("K" & i).Value                'Weight                           'BOMList(14, k) = BOMListColl(14, j)

                    BOMList(15, k) = .Range("N" & i).Value                'ColumnV    'Dwg No               'BOMList(15, k) = BOMListColl(15, j)
                    BOMList(16, k) = .Range("O" & i).Value                'ColumnW    'X                    'BOMList(16, k) = BOMListColl(16, j)
                    BOMList(17, k) = .Range("Q" & i).Value                'ColumnX    'Y                    'BOMList(17, k) = BOMListColl(17, j)
                    BOMList(18, k) = .Range("X" & i).Value               'Need X for Procurement    'Y is the same as N + P  'BOMList(18, k) = .Range("Y" & i).Value  '"Found"    'We know it was found just need row number.
                    'BOMList(19, k) = .Range("Z" & i).Value              'same as column p                'Drawing Number Plus X            'BOMList(19, k) = BOMListColl(19, j)
                    BOMList(20, k) = i                                  'BOMList(20, k) = .Range("Z" & i).Value
                    ReDim Preserve BOMList(20, UBound(BOMList, 2) + 1)

                    '-------Collect Standards here at the start--------DJL-2-9-2024
                    If BOMList(9, k) <> "" And BOMList(10, k) <> "" Then
                        CntStd = CntStd + 1
                        STDsList(0, CntStd) = BOMList(0, k)
                        STDsList(1, CntStd) = BOMList(1, k)
                        STDsList(2, CntStd) = BOMList(2, k)
                        STDsList(3, CntStd) = BOMList(3, k)
                        STDsList(4, CntStd) = BOMList(4, k)
                        STDsList(5, CntStd) = BOMList(5, k)
                        STDsList(6, CntStd) = BOMList(6, k)
                        STDsList(7, CntStd) = BOMList(7, k)
                        STDsList(8, CntStd) = BOMList(8, k)
                        STDsList(9, CntStd) = BOMList(9, k)
                        STDsList(10, CntStd) = BOMList(10, k)
                        STDsList(11, CntStd) = BOMList(11, k)
                        STDsList(12, CntStd) = BOMList(12, k)
                        STDsList(13, CntStd) = BOMList(13, k)
                        STDsList(14, CntStd) = BOMList(14, k)
                        STDsList(15, CntStd) = BOMList(15, k)
                        STDsList(16, CntStd) = BOMList(16, k)
                        STDsList(17, CntStd) = BOMList(17, k)
                        STDsList(18, CntStd) = BOMList(18, k)
                        STDsList(19, CntStd) = BOMList(19, k)
                        STDsList(20, CntStd) = BOMList(20, k)
                        ReDim Preserve STDsList(20, UBound(STDsList, 2) + 1)
                    End If

                    k = (k + 1)
                    ProgressBar1.Value = k
                Next i
            End If
        End With

        GenInfo3233.BOMList = BOMList
        GenInfo3233.STDsList = STDsList

Err_SortArrayUsingExcel:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            DwgItem2 = CurrentDwgNo
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException
            Test = DwgItem2

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ErrNo = 9 And InStr(ErrMsg, "Index was outside the bounds of the array") > 0 Then
                Resume Next
            End If

            If ErrNo = -2147418111 And InStr(ErrMsg, "Call was rejected by callee") Then
                System.Threading.Thread.Sleep(25)
                Resume
            End If

            If ErrNo = -2147417848 And InStr(ErrMsg, "The object invoked has disconnected") > 0 Then
                AcadApp = GetObject(, "AutoCAD.Application")
                System.Threading.Thread.Sleep(25)

                If ProblemAt = "CloseDwg" Then
                    Resume Next
                Else
                    Resume
                End If
            End If

            If ErrNo = -2145320885 And ErrMsg = "Problem in unloading DVB file" Then
                Resume Next                     'Layout.dvb was not found to be loaded
            End If

            If ErrNo = -2145320924 And InStr(ErrMsg, "is not found.") < 0 Then
                'DwgItem = VarSelArray(z)
                Resume
            End If

            CntDwgsNotFound = InStr(ErrMsg, "not a valid drawing")

            If ErrNo = -2145320825 And CntDwgsNotFound > 0 Then
                Sapi.Speak("AutoCAD found a bad Drawing, " & DwgItem & ", Going to next drawing.")
                MsgBox("AutoCAD found a bad Drawing, " & DwgItem & ", Going to next drawing.")
                BadDwgFound = "Yes"
                CntDwgsNotFound = 0
                Resume Next
            End If

            If ErrNo = 91 And ErrMsg = "Problem in unloading DVB file" Then
                Resume Next                     'Layout.dvb was not found to be loaded
            End If

            If ErrNo = 462 And Mid(ErrMsg, 1, 29) = "The RPC server is unavailable" Then
                Information.Err.Clear()
                AcadApp = CreateObject("AutoCAD.Application")
                AcadOpen = False
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            LenPrgLineNo = (Len(PrgLineNo))
            PrgLineNo = Mid(PrgLineNo, 1, (LenPrgLineNo - 2))

            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2, PrgLineNo)                         'DJL-10-11-2023-------HandleErrSQL(PrgName + " @ line " + st.GetFrame(3).GetFileLineNumber().ToString, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem2)

            If ErrNo = -2145320900 And ErrMsg = "Failed to get the Document object" Then
                If FirstDwg = "NotFound" Then
                    AcadApp.Application.Documents.Add()
                    Resume
                End If
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If

                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptPos = 0
                SearchException = "Exception"
                ExceptPos = InStr(ErrMsg, 1)
                If ExceptPos > 0 Then
                    CntExcept = (CntExcept + 1)
                    If CntExcept < 6 Then
                        Resume
                    End If
                End If

                If ErrNo = -2147418113 And ErrMsg = "Internal application error." Then
                    Information.Err.Clear()
                    AcadApp = CreateObject("AutoCAD.Application")
                    AcadOpen = False
                    Resume
                End If
            End If
        End If

    End Function

End Class