﻿Option Strict Off
Option Explicit On
Option Compare Text

Imports System
Imports System.Reflection
'Imports System.Runtime.InteropServices
'Imports System.Runtime.InteropServices.COMException
'Imports System.Text.RegularExpressions
'Imports Microsoft.Office.Interop.Excel
'Imports Misc

Module Conversions31_062
    Public ValidChars As String

    '  sInput -> The feet and inches string to convert
    Public Function FToD(ByVal sInput As String) As Double

        Dim sTemp, foot, inch, Numerator, Denominator As String
        Dim i As Long
        Dim j As Long
        Dim tmpValue As Double
        Dim StepSize As Long

        ValidChars = "0123456789 .'-/" & Chr(34) & Chr(34)

        On Error GoTo Err_FToD
        If sInput = "" Then
            FToD = 0.0#
            Exit Function
        End If

        Denominator = vbNullString
        Numerator = vbNullString
        inch = vbNullString
        foot = vbNullString
        sTemp = sInput
        sTemp = Trim(sTemp)

        For i = 1 To Len(sTemp)
            If InStr(ValidChars, Mid(sTemp, i, 1)) = 0 Then
                FToD = 0
                GoTo Exit_FToD
            End If
        Next i

        If InStr(sTemp, ".") > 0 Then
            If InStr(sTemp, " ") Then
                FToD = 0
                GoTo Exit_FToD
            ElseIf InStr(sTemp, "-") Then
                FToD = 0
                GoTo Exit_FToD
            ElseIf InStr(sTemp, "/") Then
                FToD = 0
                GoTo Exit_FToD
            End If

            If InStr(sTemp, "'") > 0 Then
                FToD = CDbl(Left(sTemp, InStr(sTemp, "'") - 1)) * 12.0#
            Else
                FToD = CDbl(sTemp)
            End If
            Exit Function
        End If

        If InStr(sTemp, "/") > 0 Then
            Denominator = LStrip(Mid(sTemp, InStr(sTemp, "/") + 1, Len(sTemp)))
            Numerator = RStrip(Left(sTemp, InStr(sTemp, "/") - 1))
            StepSize = Len(Numerator) - 1

            If StepSize <= 0 Then StepSize = 1
            For i = InStr(sTemp, "/") - 1 To 0 Step StepSize \ -1
                If Mid(sTemp, i - Len(Numerator) + 1, Len(Numerator)) = Numerator Then
                    j = i - Len(Numerator)
                    Exit For
                End If
            Next i

            If j > 0 Then
                sTemp = Left(sTemp, j)
            Else
                sTemp = ""
            End If
        End If

        If InStr(sTemp, "'") > 0 Then
            foot = Left(sTemp, InStr(sTemp, "'") - 1)
            inch = Mid(sTemp, InStr(sTemp, "'") + 1, Len(sTemp))
        Else
            inch = sTemp
        End If

        'Remove leading and trialing non-numeric characters from the foot and inch values
        If inch <> "" Then inch = RStrip(inch)
        If foot <> "" Then foot = Strip(foot)

        'generate the decimal value by looking at each component. if it is not empty and the is value to the temporaty value
        If Numerator <> "" And Denominator <> "" Then
            tmpValue = CDbl(Numerator) / CDbl(Denominator)
        End If
        If inch <> "" Then tmpValue = tmpValue + CDbl(inch)
        If foot <> "" Then tmpValue = tmpValue + (CDbl(foot) * 12.0#)

        FToD = tmpValue                         'Return the calculated value

Exit_FToD:
        Exit Function

Err_FToD:
        FToD = 0
        Resume Exit_FToD
    End Function

    Private Function Strip(ByVal sStr As String) As String
        Dim i As Long
        Dim sTemp As String
        sTemp = vbNullString

        If sStr <> "" Then
            sStr = Trim(sStr)                   'Remove all leading and trailing spaces

            For i = 1 To Len(sStr)
                If IsNumeric(Mid(sStr, i, 1)) Then
                    sTemp = sTemp & Mid(sStr, i, 1)
                End If
            Next i
        End If
        Strip = sTemp
    End Function

    '    Public Function DtoF(ByVal InDecimal As Double, Optional ByVal inDenominator As VariantType = vbNull, Optional ByVal ShowZeroFeet As VariantType = 1) As String
    '        Dim WorkingDecimal, feet, tmpinch, inch, fraction, Numerator, Denominator As Double
    '        Dim temp As String

    '        On Error GoTo HandleError

    '        If inDenominator = vbNull Then
    '            Denominator = 16.0#
    '        Else : Denominator = inDenominator
    '        End If

    '        WorkingDecimal = InDecimal / 12.0#
    '        feet = Fix(WorkingDecimal)
    '        tmpinch = (WorkingDecimal - feet) * 12.0#
    '        inch = Fix(tmpinch)
    '        fraction = (tmpinch - inch) * Denominator
    '        Numerator = Fix(fraction)

    '        If fraction - Numerator > 0.5 Then Numerator = Numerator + 1
    '        If (Numerator >= Denominator) Then
    '            inch = inch + 1
    '            Numerator = 0
    '        End If
    '        If inch >= 12.0# Then
    '            feet = feet + 1
    '            inch = 0
    '        End If
    '        If (Numerator Mod 2 = 0) And (Numerator <> 0) And (Numerator <> Denominator) Then
    '            While (Numerator Mod 2 = 0) And (Denominator > 1)
    '                Numerator = Numerator / 2.0#
    '                Denominator = Denominator / 2.0#
    '            End While
    '        End If

    '        If Not IsNothing(ShowZeroFeet) Then
    '            temp = CStr(feet) & "'-"
    '        End If

    '        If feet > 0 Then
    '            temp = CStr(feet) & "'-" & CStr(inch)
    '            If Numerator > 0 Then temp = temp & " "
    '        ElseIf inch > 0 Then
    '            temp = temp & CStr(inch)
    '            If Numerator > 0 Then
    '                temp = temp & " " & CStr(Numerator) & "/" & CStr(Denominator)
    '                Numerator = 0
    '            End If
    '        End If

    '        If Numerator > 0 Then
    '            temp = temp & CStr(Numerator) & "/" & CStr(Denominator)
    '        End If

    'ExitFunction:
    '        DtoF = temp
    '        Exit Function

    'HandleError:
    '        temp = ""
    '        Resume ExitFunction
    '    End Function

    '    Public Function DtoI(ByVal InDecimal As Double, Optional ByVal inDenominator As VariantType = 1, Optional ByVal ShowZeroFeet As VariantType = 1) As String
    '        Dim WorkingDecimal, feet, tmpinch, inch, fraction, Numerator, Denominator As Double
    '        Dim temp As String

    '        On Error GoTo HandleError
    '        If IsNothing(inDenominator) Then
    '            Denominator = 16.0#
    '        Else : Denominator = inDenominator
    '        End If
    '        WorkingDecimal = InDecimal / 12.0#
    '        feet = Fix(WorkingDecimal)
    '        tmpinch = (WorkingDecimal - feet) * 12.0#
    '        inch = Fix(tmpinch)
    '        fraction = (tmpinch - inch) * Denominator
    '        Numerator = Fix(fraction)
    '        If fraction - Numerator > 0.5 Then Numerator = Numerator + 1
    '        If (Numerator >= Denominator) Then
    '            inch = inch + 1
    '            Numerator = 0
    '        End If
    '        If inch >= 12.0# Then
    '            feet = feet + 1
    '            inch = 0
    '        End If
    '        If (Numerator Mod 2 = 0) And (Numerator <> 0) And (Numerator <> Denominator) Then
    '            While (Numerator Mod 2 = 0) And (Denominator > 1)
    '                Numerator = Numerator / 2.0#
    '                Denominator = Denominator / 2.0#
    '            End While
    '        End If

    '        If Not IsNothing(ShowZeroFeet) Then
    '            temp = CStr(feet) & "'-"
    '        End If

    '        If feet > 0 Then
    '            temp = CStr(feet * 12 + inch)
    '            If Numerator > 0 Then temp = temp & " "
    '        ElseIf inch > 0 Then
    '            temp = temp & CStr(inch)
    '            If Numerator > 0 Then
    '                temp = temp & " " & CStr(Numerator) & "/" & CStr(Denominator)
    '                Numerator = 0
    '            End If
    '        End If
    '        If Numerator > 0 Then
    '            temp = temp & CStr(Numerator) & "/" & CStr(Denominator)
    '        End If
    'ExitFunction:
    '        DtoI = temp & Chr(34)
    '        Exit Function
    'HandleError:
    '        temp = ""
    '        Resume ExitFunction
    '    End Function

    Private Function RStrip(ByVal sStr As String) As String
        Dim i As Long
        Dim StartPos As Long
        Dim EndPos As Long
        Dim sTemp As String

        sTemp = vbNullString
        If sStr <> "" Then
            StartPos = -1
            EndPos = -1
            sTemp = Trim(sStr)
            For i = Len(sStr) To 0 Step -1
                If i > 0 Then
                    If IsNumeric(Mid(sStr, i, 1)) Then
                        If StartPos = -1 Then StartPos = i
                        If StartPos > -1 Then EndPos = i
                    Else
                        If StartPos > -1 Then
                            Exit For
                        End If
                    End If
                End If
            Next i
            sTemp = Mid(sStr, EndPos, StartPos - EndPos + 1)
        End If

        RStrip = sTemp

    End Function

    Private Function LStrip(ByVal sStr As String) As String
        Dim i As Long
        Dim StartPos As Long
        Dim EndPos As Long
        Dim sTemp As String

        sTemp = vbNullString
        If sStr <> "" Then
            StartPos = -1
            EndPos = -1
            sTemp = Trim(sStr)
            For i = 1 To Len(sStr)
                If IsNumeric(Mid(sStr, i, 1)) Then
                    If StartPos = -1 Then StartPos = i
                    If StartPos > -1 Then EndPos = i
                Else
                    If StartPos > -1 Then
                        Exit For
                    End If
                End If
            Next i
            sTemp = Mid(sStr, StartPos, EndPos - StartPos + 1)
        End If

        LStrip = sTemp
    End Function

    'Public Function FDHigh(ByVal InDecimal As Double, ByVal Rname As String) As Double
    '    Dim S As Object
    '    Dim HtmpValue As Double

    '    If InDecimal = S.Value Then
    '        HtmpValue = S.Value
    '        FDHigh = HtmpValue
    '        Exit Function
    '    End If
    '    If InDecimal < S.Value Then
    '        HtmpValue = S.Value
    '    End If

    '    FDHigh = HtmpValue
    '    Exit Function
    'End Function

    'Public Function FDLow(ByVal InDecimal As Double, ByVal Rname As String) As Double
    '    Dim S As Object
    '    'Dim i As Long
    '    Dim j As Long
    '    Dim LtmpValue As Double

    '    If InDecimal = S.Value Then
    '        LtmpValue = S.Value
    '        FDLow = LtmpValue
    '        Exit Function
    '    End If
    '    If j = 0 Then
    '        If InDecimal > S.Value Then
    '            LtmpValue = S.Value
    '            j = 1
    '        End If
    '    End If

    '    FDLow = LtmpValue
    '    Exit Function
    'End Function

End Module
