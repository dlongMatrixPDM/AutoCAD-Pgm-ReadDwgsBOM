Option Strict Off
Option Explicit On
Option Compare Text

Imports System
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Imports System.Security.Permissions
Imports Microsoft.Office.Interop.Excel
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Module File31_072
    Private Const BFFM_INITIALIZED As Short = 1
    Private Const BFFM_SETSELECTION As Integer = &H466
    Private Const BIF_DONTGOBELOWDOMAIN As Short = 2
    Private Const BIF_RETURNONLYFSDIRS As Short = 1
    Private Const MAX_PATH As Short = 260

    Private Declare Function CreateDirectory Lib "kernel32.dll" Alias "CreateDirectoryA" (ByVal lpPathName As String, ByRef lpSecurityAttributes As BOM_Menu3D.SECURITY_ATTRIBUTES) As Integer           'Misc31_090.InputType2.SECURITY_ATTRIBUTES) As Integer
    Private Declare Function FindClose Lib "kernel32.dll" (ByVal hFindFile As Integer) As Integer
    Private Declare Function FindFirstFile Lib "kernel32.dll" Alias "FindFirstFileA" (ByVal lpFileName As String, ByRef lpFindFileData As WIN32_FIND_DATA) As Integer
    Private Declare Function FindNextFile Lib "kernel32.dll" Alias "FindNextFileA" (ByVal hFindFile As Integer, ByRef lpFindFileData As WIN32_FIND_DATA) As Integer
    Private Declare Function GetPrivateProfileInt Lib "kernel32.dll" Alias "GetPrivateProfileIntA" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal nDefault As Integer, ByVal lpFileName As String) As Integer
    Private Declare Function SHBrowseForFolder Lib "shell32.dll" (ByRef lpbi As BrowseInfo) As Integer
    Private Declare Function SHGetPathFromIDList Lib "shell32.dll" (ByVal pidList As Integer, ByVal lpBuffer As String) As Integer
    Private Declare Function GetCurrentVBAProject Lib "vba332.dll" Alias "EbGetExecutingProj" (ByRef hProject As Integer) As Integer
    Private Declare Function GetAddr Lib "vba332.dll" Alias "TipGetLpfnOfFunctionId" (ByVal hProject As Integer, ByVal strFunctionId As String, ByRef lpfn As Integer) As Integer
    Private Declare Function GetFuncID Lib "vba332.dll" Alias "TipGetFunctionId" (ByVal hProject As Integer, ByVal strFunctionName As String, ByRef strFunctionId As String) As Integer
    Private Declare Function GetOpenFileName Lib "comdlg32.dll" Alias "GetOpenFileNameA" (ByRef pOpenfilename As OPENFILENAME) As Integer

    Dim WorkShtName, PriPrg, ErrNo, ErrMsg, ErrSource, ErrDll, ErrLastLineX, PrgName As String
    Dim ErrException As System.Exception
    Public ExcelApp As Object
    Public FirstTimeThru As String
    Public FuncGetDataNew As String
    Public NewBulkBOM As Object
    Public MainBOMFile As Microsoft.Office.Interop.Excel.Workbook
    Public NewPlateBOM As Object
    Public NewStickBOM As Object
    Public NewPurchaseBOM As Object
    Public OldBOMFile As Microsoft.Office.Interop.Excel.Workbook
    Public OldBulkBOM As Object
    Public OldBulkBOMFile As String
    Public OldPlateBOM As Object
    Public OldStickBOM As Object
    Public OldPurchaseBOM As Object
    Public NewBOM As Object
    Public OldBOM As Object
    Public OldStdItems As Object
    Public BOMType As String
    Public BOMSheet As String
    Public RowNo As String
    Public RowNo2 As String
    Public OldStdDwg As String
    Public NewStdDwg As String
    Public ExceptionPos As Integer
    Public CallPos As Integer
    Public CntExcept As Integer
    Public Count As Integer
    Public PassFilename As String
    Public ReadyToContinue As Boolean
    Public CBclicked As Boolean
    Public errorExist As Boolean
    Public AcadApp As Object
    Public AcadDoc As Object
    Public RevNo As String
    Public RevNo2 As String
    Public Continue_Renamed As Boolean
    Public SortListing As Boolean
    Public MatInch As Double
    Public FoundDir As String
    Public SearchException As String
    Public ExceptPos As Integer
    Public ThisDrawing As AutoCAD.AcadDocument
    Public LytHid As Boolean
    Public DwgItem As String
    Public ErrFound As String
    Public ErrorFoundNew As String
    Public myarray As Object
    Public myarray2 As Object

    Public GetFramesSrt
    Public PrgLineNo As String
    Public CntFrames As Integer
    Public ProblemAt As String                          '-------DJL-12-18-2024

    Private Structure BrowseInfo
        Dim hwndOwner As Integer
        Dim pIDLRoot As Integer
        Dim pszDisplayName As String
        Dim lpszTitle As String
        Dim ulFlags As Integer
        Dim lpfnCallback As Integer
        Dim lParam As Integer
        Dim iImage As Integer
    End Structure

    Private Structure WIN32_FIND_DATA
        Dim dwFileAttributes As Integer
        Dim ftCreationTime As FILETIME
        Dim ftLastAccessTime As FILETIME
        Dim ftLastWriteTime As FILETIME
        Dim nFileSizeHigh As Integer
        Dim nFileSizeLow As Integer
        Dim dwReserved0 As Integer
        Dim dwReserved1 As Integer
        <VBFixedString(MAX_PATH), System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst:=MAX_PATH)> Public cFileName() As Char
        <VBFixedString(14), System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst:=14)> Public cAlternate() As Char
    End Structure

    Private Structure OPENFILENAME
        Dim lStructSize As Integer
        Dim hwndOwner As Integer
        Dim hInstance As Integer
        Dim lpstrFilter As String
        Dim lpstrCustomFilter As String
        Dim nMaxCustFilter As Integer
        Dim nFilterIndex As Integer
        Dim lpstrFile As String
        Dim nMaxFile As Integer
        Dim lpstrFileTitle As String
        Dim nMaxFileTitle As Integer
        Dim lpstrInitialDir As String
        Dim lpstrTitle As String
        Dim flags As Integer
        Dim nFileOffset As Short
        Dim nFileExtension As Short
        Dim lpstrDefExt As String
        Dim lCustData As Integer
        Dim lpfnHook As Integer
        Dim lpTemplateName As String
    End Structure

    Public currentDir As String

    'Public Function AddrOf(ByRef strFuncName As String) As Integer
    '    Dim hProject As Integer
    '    Dim lngResult As Integer
    '    Dim strID As String
    '    Dim lpfn As Integer
    '    Dim strFuncNameUnicode As String

    '    Const NO_ERROR As Short = 0

    '    strFuncNameUnicode = StrConv(strFuncName, VbStrConv.None)
    '    Call GetCurrentVBAProject(hProject)
    '    If hProject <> 0 Then
    '        lngResult = GetFuncID(hProject, strFuncNameUnicode, strID)
    '        If lngResult = NO_ERROR Then
    '            lngResult = GetAddr(hProject, strID, lpfn)
    '            If lngResult = NO_ERROR Then
    '                AddrOf = lpfn
    '            End If
    '        End If
    '    End If
    'End Function

    'Public Function BrowseCallbackProc(ByVal hwnd As Integer, ByVal uMsg As Integer, ByVal lParam As Integer, ByVal lpData As Integer) As Integer
    '    Dim retval As Integer

    '    Select Case uMsg
    '        Case BFFM_INITIALIZED
    '            retval = Misc31_090.InputType2.SendMessage(hwnd, BFFM_SETSELECTION, CInt(1), currentDir)
    '    End Select
    '    BrowseCallbackProc = 0
    'End Function

    'Public Function CreatePath(ByRef DirPath As String) As Object
    '    Dim tempDir As String
    '    Dim tempChar As String
    '    Dim Count As Short
    '    Dim secattr As Misc31_090.InputType2.SECURITY_ATTRIBUTES

    '    Count = Len(DirPath)

    '    If Dir(DirPath) = "" Then
    '        Do
    '            tempChar = Mid(DirPath, Count, 1)
    '            Count = Count - 1
    '        Loop Until tempChar = "\"
    '        tempDir = Left(DirPath, Count)
    '        CreatePath(tempDir)
    '        CreateDirectory(DirPath, secattr)
    '    End If
    'End Function

    'Function GetDir(ByRef szTitle As String) As String
    '    Dim lpIDList As Integer
    '    Dim sBuffer As String
    '    Dim tBrowseInfo As BrowseInfo

    '    With tBrowseInfo
    '        .lpszTitle = szTitle
    '        .ulFlags = BIF_RETURNONLYFSDIRS + BIF_DONTGOBELOWDOMAIN
    '        .lpfnCallback = AddrOf("BrowseCallbackProc")
    '    End With

    '    lpIDList = SHBrowseForFolder(tBrowseInfo)

    '    If (lpIDList) Then
    '        sBuffer = Space(MAX_PATH)
    '        SHGetPathFromIDList(lpIDList, sBuffer)
    '        sBuffer = Left(sBuffer, InStr(sBuffer, vbNullChar) - 1)
    '        If Right(sBuffer, 1) <> "\" Then sBuffer = sBuffer & "\"
    '        GetDir = sBuffer
    '    Else
    '        GetDir = ""
    '    End If
    'End Function

    Function GetFile(ByRef startdir As String) As String

        Dim OpenFile As OPENFILENAME
        Dim lReturn As Integer
        Dim sFilter As String
        Dim s As String

        OpenFile.lStructSize = Len(OpenFile)
        sFilter = "Excel Worksheet(*.xls)" & Chr(0) & "*.xls" & Chr(0)
        OpenFile.lpstrFilter = sFilter
        OpenFile.nFilterIndex = 1
        OpenFile.lpstrFile = New String(Chr(0), 257)
        OpenFile.nMaxFile = Len(OpenFile.lpstrFile) - 1
        OpenFile.lpstrFileTitle = OpenFile.lpstrFile
        OpenFile.nMaxFileTitle = OpenFile.nMaxFile
        OpenFile.lpstrInitialDir = startdir
        OpenFile.lpstrTitle = "Select file to Open"
        lReturn = GetOpenFileName(OpenFile)

        If lReturn = 0 Then
            GetFile = ""
        Else
            s = Trim(OpenFile.lpstrFile)
            If InStr(s, Chr(0)) Then s = Left(s, InStr(s, Chr(0)) - 1)
            GetFile = s
            OldBulkBOMFile = GetFile
        End If
    End Function

    'Function ViewFiles() As Object
    '    Dim colFiles As New Collection
    '    Dim intCnt As Short
    '    Dim lngFile As Integer
    '    Dim lngReturn As Integer
    '    Dim varFileArray As Object
    '    Dim WinDat As WIN32_FIND_DATA
    '    Dim ViewFilesDialog As ViewFilesDialog
    '    ViewFilesDialog = ViewFilesDialog
    '    ViewFilesDialog.Filelist.Items.Clear()
    '    WinDat.cFileName = ""
    '    lngFile = FindFirstFile("*.*" & Chr(0), WinDat)

    '    If lngFile < 0 Then
    '        Exit Function
    '    End If

    '    Do
    '        If UCase(WinDat.cFileName) Like "*BOM*.XLS*" Then
    '            colFiles.Add(Misc31_090.InputType2.vbdApiTrim(UCase(WinDat.cFileName)))
    '        End If
    '        WinDat.cFileName = ""
    '        lngReturn = FindNextFile(lngFile, WinDat)
    '    Loop Until lngReturn = False

    '    lngReturn = FindClose(lngFile)
    '    ReDim varFileArray(colFiles.Count())

    '    For intCnt = 1 To UBound(varFileArray)
    '        varFileArray(intCnt) = colFiles.Item(intCnt)
    '    Next

    '    Misc31_090.InputType2.vbdQsort(varFileArray)

    '    For intCnt = 1 To UBound(varFileArray)
    '        ViewFilesDialog.Filelist.Items.Add(varFileArray(intCnt))
    '    Next

    'End Function

    Function CopyBOMFile(ByVal OldFileNam As String, ByVal RevNo As String) As Object
        '------------------------------------------------------------------------------------------------
        '-------Creator:        Dennis J. Long
        '-------Date:           Sometime before 4/2/2024
        '-------Description:    Copy information collected to Spreadsheet
        '-------
        '-------Updates:        Description:
        '-------12-18-2024      Looking for error Bill Sieg is talking about in Ticket-368442 Ship List/BBOM on Windows 10 machine   
        '-------                
        '-------                
        '------------------------------------------------------------------------------------------------
        'Dim xlNormal As Object
        'Dim Excel As Object
        'Dim Sheets As Object
        'Dim Range As Object                 '-------DJL-12-17-2024     'Removed all of above
        Dim Worksheets As Object
        Dim FileDir, JobNo, BomListRev, BomListFileName, Test, SearchSlash, FirstPart, SecondPart As String
        Dim BOMMnu As BOM_Menu3D
        Dim SaveAsFilename As SaveAsFilename
        Dim BOMWrkSht As Worksheet
        'Dim ShopCutWrkSht As Worksheet
        Dim WorkSht As Worksheet
        Dim Workbooks As Microsoft.Office.Interop.Excel.Workbooks
        Dim SlashPos, PrevSlashPos As Integer

        BOMMnu = BOM_Menu3D
        SaveAsFilename = $safeprojectname$.SaveAsFilename               '-------DJL-12-18-2024     'SaveAsFilename = SaveAsFilename
        PrgName = "CopyBOMFile-StartCopyFile"                            '-------DJL-12-18-2024

        On Error Resume Next

        ExcelApp = GetObject(, "Excel.Application")

        If Err.Number Then
            Information.Err.Clear()
            ExcelApp = CreateObject("Excel.Application")
            If Err.Number Then
                MsgBox(Err.Description)
                Exit Function
            End If
        End If

        On Error GoTo Err_CopyBOMFile

        PrgName = "CopyBOMFile-ExcelHookMade"                            '-------DJL-12-18-2024
        FileDir = OldFileNam
        Workbooks = ExcelApp.Workbooks
        WorkShtName = "Bulk BOM"
        BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
        WorkSht = Workbooks.Application.ActiveSheet
        WorkShtName = WorkSht.Name

        With BOMWrkSht
            JobNo = .Range("B3").Value
        End With

        PrgName = "CopyBOMFile-MakingSpdsht"                            '-------DJL-12-18-2024

        If JobNo = "Job No:" Then
            JobNo = OldFileNam
            Test = JobNo
            SearchSlash = "\"
            SlashPos = InStr(Test, SearchSlash)
            PrevSlashPos = 0

            While SlashPos > 0
                If PrevSlashPos > 0 Then
                    FirstPart = Mid(Test, 1, ((SlashPos - 1) + PrevSlashPos))
                    SecondPart = Mid(Test, (SlashPos + PrevSlashPos + 1), Len(Test))
                    PrevSlashPos = (PrevSlashPos + SlashPos)
                    SlashPos = InStr(SecondPart, SearchSlash)
                Else
                    FirstPart = Mid(Test, 1, (SlashPos - 1))
                    SecondPart = Mid(Test, (SlashPos + 1), (Len(Test) - (SlashPos + 2)))
                    PrevSlashPos = SlashPos
                    SlashPos = InStr(SecondPart, SearchSlash)
                End If
            End While

            JobNo = SecondPart
        End If

        PrgName = "CopyBOMFile-JobNoFound"                            '-------DJL-12-18-2024
        BomListRev = RevNo

        If JobNo = Nothing Then
            JobNo = InputBox("What is your Job Number?")
        End If

        'Select Case BOMMnu.BOMType
        '    Case "Tank"
        BomListFileName = FileDir & JobNo & "-BULKBOM-R" & BomListRev & ".xls"            'BomListFileName = FileDir & "\" & JobNo & "-BULKBOM-R" & BomListRev & ".xls"
        '    Case "Seal"
        '        BomListFileName = FileDir & "\" & JobNo & "-SEALBOM-R" & BomListRev & ".xls"
        '    Case "Intent"
        '        BomListFileName = FileDir & "\" & JobNo & "-INTENTBOM-R" & BomListRev & ".xls"
        'End Select

        PrgName = "CopyBOMFile-ProducingSpdSht"                            '-------DJL-12-18-2024
        BOMMnu.MainBOMFile.Worksheets.Copy()
        NewBulkBOM = BOMWrkSht

CheckFileName:
        Dim Style, Msg, Title As String
        Dim Response As Object

        'MsgBox("After 30 seconds check your spreadsheet make sure it is not waiting on you to pick Save/Continue?")        '-------DJL-12-18-2024      'Moved below is causing problems when user wants to change the file Name.

        If Dir(BomListFileName) <> vbNullString Then
            PrgName = "CopyBOMFile-GettingSpdShtNam"                            '-------DJL-12-18-2024

            Msg = "File " & BomListFileName & " already exists. Do you want to overwrite it?"
            Style = CStr(MsgBoxStyle.YesNo)
            Title = "Save Bulk BOM"

            'Next Look at "ReadyToContinue = False"
            If SaveAsFilename.Focused = False Then                            '-------DJL-12-18-2024      'If SaveAsFilename.Enabled = False Then <> 1 Then    'If SaveAsFilename.AutoValidate = 1
                Response = MsgBox(Msg, CDbl(Style), Title)
            End If

            If Response = MsgBoxResult.Yes Then
                MsgBox("After 30 seconds check your spreadsheet make sure it is not waiting on you to pick Save/Continue?")     '-------DJL-12-18-2024
                Kill((BomListFileName))
                Workbooks.Application.ActiveWorkbook.SaveAs(Filename:=BomListFileName, FileFormat:=XlFileFormat.xlWorkbookNormal, Password:="", WriteResPassword:="", ReadOnlyRecommended:=False, CreateBackup:=False, AddToMru:=True)
                PrgName = "CopyBOMFile-DelExistingSht"                            '-------DJL-12-18-2024
                ProgramFinished()                           '-------DJL-12-19-2024

            ElseIf Response = MsgBoxResult.No Then
                'Replaced below.    
                GenInfo3233.BomListFileName = JobNo & "-BULKBOM-R" & BomListRev & ".xls"            'BomListFileName
                GenInfo3233.FileDir = FileDir
                SaveAsFilename.Show()
                PrgName = "CopyBOMFile-ShowRenameForm"                            '-------DJL-12-18-2024

                '-------Move below to new Module so program can ask user where to put file? and What to Name it? Maybe user are putting the fill in another directory? 
                'BomListFileName = InputBox("What Do you want the file Name to be ?" & "Example: " & JobNo & "-BULKBOM-R" & BomListRev & ".xls")         'BomListFileName = InputBox("What Do you want the file Name to be? " & "Example: " & BomListFileName)
                'BomListFileName = FileDir & BomListFileName
                'PrgName = "CopyBOMFile-ShowRenameForm"                            '-------DJL-12-18-2024

                'If PassFilename <> vbNullString And ReadyToContinue = True Then
                '    If Right(PassFilename, 4) = ".xls" Then
                '        BomListFileName = FileDir & PassFilename
                '        MsgBox("After 30 seconds check your spreadsheet make sure it is not waiting on you to pick Save/Continue?")     '-------DJL-12-18-2024
                '        PrgName = "CopyBOMFile-RenameForm1"                            '-------DJL-12-18-2024
                '        Workbooks.Application.ActiveWorkbook.SaveAs(Filename:=BomListFileName, FileFormat:=XlFileFormat.xlWorkbookNormal, Password:="", WriteResPassword:="", ReadOnlyRecommended:=False, CreateBackup:=False, AddToMru:=True)         '-------DJL-12-17-2024       'Excel.Application.ActiveWorkbook.SaveAs(FileName:=BomListFileName, FileFormat:=XlFileFormat.xlWorkbookNormal, Password:="", WriteResPassword:="", ReadOnlyRecommended:=False, CreateBackup:=False, AddToMru:=True)
                '    Else
                '        BomListFileName = FileDir & PassFilename & ".xls"
                '        PrgName = "CopyBOMFile-RenameForm2"                            '-------DJL-12-18-2024
                '        MsgBox("After 30 seconds check your spreadsheet make sure it is not waiting on you to pick Save/Continue?")     '-------DJL-12-18-2024
                '        Workbooks.Application.ActiveWorkbook.SaveAs(Filename:=BomListFileName, FileFormat:=XlFileFormat.xlWorkbookNormal, Password:="", WriteResPassword:="", ReadOnlyRecommended:=False, CreateBackup:=False, AddToMru:=True)         '-------DJL-12-17-2024       'Excel.Application.ActiveWorkbook.SaveAs(FileName:=BomListFileName, FileFormat:=XlFileFormat.xlWorkbookNormal, Password:="", WriteResPassword:="", ReadOnlyRecommended:=False, CreateBackup:=False, AddToMru:=True)
                '    End If
                'ElseIf PassFilename = "CancelProgram" And ReadyToContinue = False Then
                '    PrgName = "CopyBOMFile-PrgCancelByUser"                            '-------DJL-12-18-2024
                '    Exit Function
                'Else
                '    PrgName = "CopyBOMFile-CheckFileName"                            '-------DJL-12-18-2024
                '    GoTo CheckFileName
                'End If
            End If
        Else
            PrgName = "CopyBOMFile-ShowRenForm3"                            '-------DJL-12-18-2024
            MsgBox("After 30 seconds check your spreadsheet make sure it is not waiting on you to pick Save/Continue?")     '-------DJL-12-18-2024
            Workbooks.Application.ActiveWorkbook.SaveAs(Filename:=BomListFileName, FileFormat:=XlFileFormat.xlWorkbookNormal, Password:="", WriteResPassword:="", ReadOnlyRecommended:=False, CreateBackup:=False, AddToMru:=True)

            ProgramFinished()                           '-------DJL-12-19-2024
        End If

Err_CopyBOMFile:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = "53" And InStr(ErrMsg, "No files found matching") > 0 Then
                Resume Next
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

            BOMMnu.HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Function

    Public Function FinishCopyBOMFile(ByVal PassFileName As String)
        '------------------------------------------------------------------------------------------------
        '-------Creator:        Dennis J. Long
        '-------Date:           12-18-2024
        '-------Description:    Finish program above when the user whats to put the file in a different location, or change the file name.
        '-------
        '-------Updates:        Description:
        '-------12-18-2024      Looking for error Bill Sieg is talking about in Ticket-368442 Ship List/BBOM on Windows 10 machine   
        '-------                
        '-------                'Dim Workbooks As Microsoft.Office.Interop.Excel.Workbooks
        '------------------------------------------------------------------------------------------------
        Dim BomListFileName, SearchSlash, FirstPart, SecondPart, Test, FileDir As String
        Dim SlashPos, PrevSlashPos As Integer
        Dim BOMMnu As BOM_Menu3D
        BOMMnu = BOM_Menu3D
        '-----------------------------------------------------------
        Dim Workbooks2 As Microsoft.Office.Interop.Excel.Workbooks      '-------DJL-12-19-2024

        'On Error Resume Next

        'ExcelApp = GetObject(, "Excel.Application")

        'If Err.Number Then
        '    Information.Err.Clear()
        '    ExcelApp = CreateObject("Excel.Application")
        '    If Err.Number Then
        '        MsgBox(Err.Description)
        '        Exit Function
        '    End If
        'End If

        'On Error GoTo Err_FinishCopyBOMFile

        Workbooks2 = ExcelApp.Workbooks      '-------DJL-12-19-2024
        '-----------------------------------------------------------
        '-----------------------------------------------------------
        '-------DJL-12-19-2024-Check to make sure user has a Valid directory srtuture.
        PrgName = "FinishCopyBOMFile-ChkDir"

        If Dir(PassFileName) = vbNullString Then
            Test = PassFileName
            SearchSlash = "\"
            SlashPos = InStr(Test, SearchSlash)
            PrevSlashPos = 0

            While SlashPos > 0
                If PrevSlashPos > 0 Then
                    FirstPart = Mid(Test, 1, ((SlashPos - 1) + PrevSlashPos))
                    SecondPart = Mid(Test, (SlashPos + PrevSlashPos + 1), Len(Test))
                    PrevSlashPos = (PrevSlashPos + SlashPos)
                    SlashPos = InStr(SecondPart, SearchSlash)
                Else
                    FirstPart = Mid(Test, 1, (SlashPos - 1))
                    SecondPart = Mid(Test, (SlashPos + 1), (Len(Test) - (SlashPos + 2)))
                    PrevSlashPos = SlashPos
                    SlashPos = InStr(SecondPart, SearchSlash)
                End If
            End While

            FileDir = PassFileName.Replace(SecondPart, "")

            If Dir(FileDir) = vbNullString Then

                If System.Environment.UserName = "bsieg" Then
                    PrgName = "FinishCopyBOMFile-DirIssueBillSieg"
                    MsgBox("Bill Sieg Directory does not exist Please create it in Windows exploder then click on the OK button.")
                Else
                    PrgName = "FinishCopyBOMFile-DirIssue"
                    MsgBox("User must create directory before trying to save file. Directory does not exist Please create it in Windows exploder then click on the OK button.")
                End If

                'GenInfo3233.FileDir = FileDir
                'GenInfo3233.BomListFileName = SecondPart
                'SaveAsFilename.Show()
            End If
        End If
        '-----------------------------------------------------------

        PrgName = "FinishCopyBOMFile-Gettingsave"

        On Error GoTo Err_FinishCopyBOMFile

        If PassFileName <> vbNullString And ReadyToContinue = True Then
            If Right(PassFileName, 4) = ".xls" Then
                'BomListFileName = FileDir & PassFileName
                MsgBox("After 30 seconds check your spreadsheet make sure it is not waiting on you to pick Save/Continue?")     '-------DJL-12-18-2024
                PrgName = "FinishCopyBOMFile-Gettingsave1"                             '-------DJL-12-18-2024
                Workbooks2.Application.ActiveWorkbook.SaveAs(Filename:=PassFileName, FileFormat:=XlFileFormat.xlWorkbookNormal, Password:="", WriteResPassword:="", ReadOnlyRecommended:=False, CreateBackup:=False, AddToMru:=True)            '-------DJL-12-19-2024
                ProgramFinished()                           '-------DJL-12-19-2024
            Else
                'BomListFileName = FileDir & PassFileName & ".xls"
                MsgBox("After 30 seconds check your spreadsheet make sure it is not waiting on you to pick Save/Continue?")     '-------DJL-12-18-2024
                PrgName = "FinishCopyBOMFile-Gettingsave2"                             '-------DJL-12-18-2024
                Workbooks2.Application.ActiveWorkbook.SaveAs(Filename:=PassFileName, FileFormat:=XlFileFormat.xlWorkbookNormal, Password:="", WriteResPassword:="", ReadOnlyRecommended:=False, CreateBackup:=False, AddToMru:=True)            '-------DJL-12-19-2024
                ProgramFinished()                           '-------DJL-12-19-2024
            End If
        ElseIf PassFileName = "CancelProgram" And ReadyToContinue = False Then
            PrgName = "CopyBOMFile-PrgCancelByUser"                            '-------DJL-12-18-2024
            Exit Function
        Else
            PrgName = "CopyBOMFile-CheckFileName"                            '-------DJL-12-18-2024
            'GoTo CheckFileName         'Do not do this when user wants to use anothwer file name.  '-------DJL-12-18-2024
        End If

Err_FinishCopyBOMFile:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = "53" And InStr(ErrMsg, "No files found matching") > 0 Then
                Resume Next
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

            BOMMnu.HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Function

    Public Function ProgramFinished()
        '------------------------------------------------------------------------------------------------
        '-------Creator:        Dennis J. Long
        '-------Date:           12-19-2024
        '-------Description:    Finish program above when the user whats to put the file in a different location, or change the file name.
        '-------
        '-------Updates:        Description:
        '-------12-19-2024      Looking for error Bill Sieg is talking about in Ticket-368442 Ship List/BBOM on Windows 10 machine   
        '-------                
        '-------                'Had to move this part and create location to end for three diferent paths.
        '------------------------------------------------------------------------------------------------
        Dim BOMMnu As BOM_Menu3D
        BOMMnu = BOM_Menu3D
        PrgName = "ProgramFinished"

        On Error GoTo Err_ProgramFinished

        PrgName = "StartButton_Click-Part33"
        ExcelApp.Application.Visible = True

        If GenInfo3233.StartAdept = True Then
            OpenPrg("Adept")
        End If

        MsgBox("Your Bulk BOM has been Created.")
        ExcelApp.Application.Visible = True

        PrgName = "StartButton_Click-Part34"
        BOMMnu.MainBOMFile.Close(False)
        PrgName = "StartButton_Click-Part35"
        BOMMnu.Close()

Err_ProgramFinished:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = "53" And InStr(ErrMsg, "No files found matching") > 0 Then
                Resume Next
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

            BOMMnu.HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Function

    Public Function OpenPrg(ByVal sender As System.Object)
        Dim BOMGen As Object

        Select Case sender
            Case "Adept"
                BOMGen = Shell("C:\Program Files (x86)\Synergis\Adept10\Client\Adept.exe", AppWinStyle.NormalFocus)
            Case Else
                MsgBox("Program needs to be added.")
        End Select

    End Function

    'Sub OpenExcelFile(ByRef FileToOpen As String)
    '    Dim Excel As Object
    '    Dim ExcelApp As Object
    '    Dim ExcelWorkbook As Object

    '    On Error Resume Next

    '    ExcelApp = GetObject(, "Excel.Application")

    '    If Err.Number Then
    '        Information.Err.Clear()
    '        ExcelApp = CreateObject("Excel.Application")
    '        If Err.Number Then
    '            MsgBox(Err.Description)
    '            Exit Sub
    '        End If
    '    End If

    '    ExcelWorkbook = ExcelApp.Application.Workbooks.Open(FileToOpen)
    '    ExcelApp.Application.WindowState = XlWindowState.xlMinimized
    'End Sub

    Function ShopCUT(ByVal RevNo As String) As Object
        Dim xlGuess As Object, ActiveSheet As Object, Range As Object, Worksheets As Object
        Dim PIPE As Object, L As Object, W As Object, C As Object, TUBE As Object, PL As Object, SHT As Object
        Dim RB As Object, FB As Object, Purchase As Object
        Dim ic, id, ii, j, k, Fnd, Desc, Ref, Leng, ROD, PipePos, ShellPos, SeeDwgPos, Plug, LenPart, LenRbSize, CntBOMItems As Integer
        Dim LenPipeSize, LenDesc, ShtLen, ShtWid, PlPos, NotePos, PrevI, FoundColdRolled, GetRecNo, PrevCnt As Integer
        Dim FoundSch, FoundStd, FoundInch, FoundFoot, FoundFraction, LenMatPart, PartFoundX As Integer
        Dim FoundDash, FoundSpace, LenPipe, FootPos, FootPos2, FootPos3, LenFoot, TreadWidPos As Integer
        Dim LenPlateNotes, FoundNote, SB, ReturnPos, FoundX, FoundX2, CntFndStdInfo, GratingPos As Integer
        Dim Xpos, PrevXPos, SearchPos, InchPos, PrevInchPos, StudPos, WithPos, HHPos, DashPos, DeltaPos As Integer
        Dim OldDesc, FindSc, FindDesc, GetGratingInfo, FBThk, FBWid, FBLen, FirstPart, SecondPart, NutSize As String
        Dim SearchStud, SearchWith, SearchHH, NutsNo, AddMat, GetMatType1, GetMatType2, FindDesc2, GetDwgNoSpSht As String
        Dim ShtLength, ShtWidth, TreadWid, TreadLen, MatQty, ShellPlateInfo, NoteInfo, PrevShpMk As String
        Dim TreadWidDbl, TreadLenDbl, TreadSqFt, TestGetDesc2, TestGetInvNo2, TestGetStdDwg2, TestGetMatType2 As String
        Dim LenBolt, GetPartNo, AddItem2, TestQty2, TestGetSc, RowNoNew, TestShpMk, TestGetDwgNo, GetPurchaseTyp As String
        Dim Test14, Test15, Test16, Test17, FndStd, FndSc, GetQty, FndStdNote, GetInvStd, GetDescSpSht, EndPart As String
        Dim FoundPl, FoundNotes, FoundLast As Boolean
        Dim MatLengthDbl As Double
        Dim iA, SheetToUse As Object
        Dim jA, LineNo As Short, CutCount As Short, Count As Short
        Dim FullJobNo, FileToOpen, PrgName, PriPrg, ErrNo, ErrMsg, ErrSource, ErrDll, ErrLastLineX, WorkShtName As String
        Dim MatType, PlateRowNo, StickRowNo, GratingRowNo, PurchaseRowNo, ItemFound, AddItem, Test As String
        Dim SearchPipe, SearchX, SearchInch, SearchSch, SearchStd, SearchShell, SearchDwg, SearchFoot As String
        Dim SearchRolled, MatType1, MatType2, GetDwgNo, ItemNum, MaterialNew, GetProdCode As String
        Dim SearchFraction, SearchDash, SearchNote, PipeTest, Test1, FindFoot, FindFoot1, FindFoot2 As String
        Dim PipeSize, PipeLen, PipeSch, Material, MaterialPart, MaterialPart2, MatLength, RbSize As String
        Dim DecInches, SearchSpace, PurchaseItem, GetMatType, GetAngle, PipeFirstPart, PipeSecondPart As String
        Dim GetGrating, PlateNotes, Search, SearchFound, SearchReturn, SearchGalv, SearchX2 As String
        Dim Test0, Test2, Test3, Test4, Test5, Test6, Test7, Test8, Test9, Test10, Test11, Test12, Test13 As String
        Dim ProbPart, GetDesc, GetInvNo, GetStdDwg, ShtMat, Mat, MaterialPart1, OldSc, GetSc As String
        Dim GetCommidity, GetDesc1, GetDesc2, PartFound, FndStdNote2 As String
        Dim FeetLength, FeetTotal, InchFraction, FstFraction, SndFraction, DecFraction, AddRolled As Double
        Dim FoundRolled, GalvPos, n, MatPos, IDPos, LenGetDesc1 As Integer
        Dim ErrException As System.Exception
        Dim BOMMnu As BOM_Menu3D
        BOMMnu = BOM_Menu3D
        Dim BOMWrkSht As Worksheet
        Dim WorkSht As Worksheet
        Dim Workbooks As Microsoft.Office.Interop.Excel.Workbooks
        Dim PurchaseProb As Boolean
        Dim MatData(3, 1) As Object

        PrgName = "ShopCUT"

        On Error Resume Next

        ExcelApp = GetObject(, "Excel.Application")

        If Err.Number Then
            Information.Err.Clear()
            ExcelApp = CreateObject("Excel.Application")
            If Err.Number Then
                MsgBox(Err.Description)
                Exit Function
            End If
        End If

        On Error GoTo Err_ShopCUT

        Workbooks = ExcelApp.Workbooks
        WorkShtName = "Bulk BOM"
        BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
        Workbooks.Application.Worksheets("Bulk BOM").Activate()
        WorkSht = Workbooks.Application.ActiveSheet
        WorkShtName = WorkSht.Name
        SearchRolled = "ROLLED"
        SearchReturn = Chr(13)         'vbCrLF          '----------------------End of Look for Hard return.
        SearchFoot = Chr(39)
        SearchGalv = "GALV"
        SearchSpace = " "
        Dim BOMList(20, 1)

        With BOMWrkSht
            BOM_Menu3D.LblProgress.Text = "Collecting BOM on Spread Sheet to Array since Standards were added.......Please Wait"

            '-------DJL-------11-27-2023-------New process create sort.
            k = 1
            RowNo = BOMWrkSht.Range("B4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row
            BOM_Menu3D.ProgressBar1.Maximum = RowNo + 1

            If PrevCnt = 0 Then
                PrevCnt = 1
            End If

            If .Range("B4").Value = "DWG" Then                          'If .Range("A4").Value = "DWG" Then
                For ic = 5 To RowNo                                    'For j = PrevCnt To RowNo
                    BOMList(0, k) = .Range("P" & ic).Value
                    BOMList(1, k) = .Range("B" & ic).Value                 'ColumnC    'Job Number       
                    BOMList(2, k) = .Range("C" & ic).Value                 'ColumnD    'Dwg No.           
                    BOMList(3, k) = .Range("D" & ic).Value                 'ColumnE    'Rev No.     
                    BOMList(4, k) = .Range("F" & ic).Value                 'ColumnF    'Ship No.  
                    BOMList(5, k) = .Range("E" & ic).Value                 'ColumnG    'Qty         
                    'BOMList(6, k) = .Range("G" & ic).Value                'ColumnH   'Desc        
                    '
                    BOMList(7, k) = .Range("G" & ic).Value                 'ColumnH   'Desc       
                    'BOMList(8, k) = BOMListColl(8, ic)                  '                          
                    BOMList(8, k) = .Range("R" & ic).Value    'See if Standard needs to be found on some references the parts are all listed out. Example Job 9318-0206_18B parts are simular but not the same is a reference only.

                    BOMList(9, k) = .Range("H" & ic).Value                 'ColumnK    'Inv No.            
                    BOMList(10, k) = .Range("I" & ic).Value                'ColumnL    'Std No.          
                    BOMList(11, k) = .Range("J" & ic).Value                'ColumnM    'Material           
                    '.Range("Z" & ic).Value = i                'Done below             'Column Z record number after sort.
                    'BOMList(12, k) = .Range("J" & ic).Value   'Not used  is used as 11 for I           'Column I   

                    BOMList(13, k) = .Range("A" & ic).Value               'V does not exist.          
                    BOMList(14, k) = .Range("K" & ic).Value                'Weight                     

                    BOMList(15, k) = .Range("N" & ic).Value                'ColumnV    'Dwg No           
                    BOMList(16, k) = .Range("O" & ic).Value                'ColumnW    'X             
                    BOMList(17, k) = .Range("Q" & ic).Value                'ColumnX    'Y         
                    BOMList(18, k) = .Range("W" & ic).Value              'Procurement now.  '"Found"    'We know it was found just need row number.              'BOMList(18, k) = .Range("Y" & ic).Value 
                    BOMList(19, k) = .Range("Z" & ic).Value                'Drawing Number Plus X    
                    BOMList(20, k) = ic
                    ReDim Preserve BOMList(20, UBound(BOMList, 2) + 1)
                    k = (k + 1)
                    BOM_Menu3D.ProgressBar1.Value = k
                Next ic
            End If
        End With

        GenInfo3233.BOMList = BOMList

        ItemFound = "No"
        SearchX = " x "
        SearchX2 = "x "
        SearchInch = Chr(34)                'Find " Inch
        SearchFoot = Chr(39)                'Find ' Feet
        SearchSch = "SCH"
        SearchStd = "STD"
        SearchFraction = "/"
        SearchDash = "-"
        SearchSpace = " "
        CntBOMItems = (UBound(BOMList, 2) - 1)
        BOMMnu.ProgressBar1.Maximum = CntBOMItems                            'BOMMnu.ProgressBar1.Maximum = iA

        For ii = 1 To CntBOMItems                        '(iA - 5)
            j = (CntBOMItems - (ii - 1))
            BOMMnu.ProgressBar1.Value = ii
            InchFraction = 0
            DecFraction = 0
            FeetTotal = 0
            FoundFraction = 0
            FstFraction = 0
            SndFraction = 0
            FoundInch = 0
            FeetLength = 0
            FirstPart = Nothing
            SecondPart = Nothing
            NutSize = Nothing
            AddMat = Nothing
            GetPartNo = Nothing
            GetDwgNo = BOMList(1, j)                   'Dwg             'myarray(2, i)
            'ItemNum = BOMList(20, j)                                    'myarray(4, i)
            GetQty = BOMList(4, j)                   'Qty               'myarray(6, i)
            GetDesc = BOMList(7, j)                   'Description
            GetDesc = LTrim(GetDesc)
            GetDesc = RTrim(GetDesc)
            GetDesc = GetDesc.Replace(Chr(34) & Chr(34), "")

            GetInvNo = BOMList(9, j)                   'Inventory Number        'myarray(8, i)
            If GetInvNo = " " Then                     'Found problem were " " was found
                GoTo FindPart
            End If

            GetStdDwg = BOMList(10, j)                   'Standard Number        'myarray(9, i)
            GetMatType = BOMList(11, j)                 'Material Type      'Conflict with line above GetMatType renamed to FndMatType      'myarray(10, i) 
            GetPurchaseTyp = BOMList(6, j)             'Purchase Type      'Plate, Pipe, Purchase Items, Etc..     'GetPurchaseTyp = BOMList(14, i)

            Select Case 0
                Case Is < InStr(GetMatType, "ANY" & Chr(10) & "GRADE")
                    GetMatType = "A36"
                Case Is < InStr(GetMatType, "A36" & Chr(10) & "G2")
                    GetMatType = "A36 G2"
                Case Is < InStr(GetMatType, "A36" & Chr(10))
                    MatPos = InStr(GetMatType, "A36" & Chr(10))

                    If InStr(GetMatType, "SA36") > 0 Then
                        GetMatType = Replace(GetMatType, Chr(10), " ")
                        GoTo SA36Done
                    End If

                    If MatPos = 1 Then
                        GetMatType1 = Mid(GetMatType, 2, Len(GetMatType))
                        GetMatType = GetMatType1
                    Else
                        GetMatType1 = Mid(GetMatType, 1, (MatPos - 1))
                        GetMatType = GetMatType1
                        MatPos = InStr(GetMatType, Chr(10))
                        GetMatType1 = Mid(GetMatType, (MatPos + 1), Len(GetMatType))

                        If InStr(GetMatType, "WB/") > 0 Then
                            TestGetSc = Mid(GetMatType, 1, (MatPos - 1))
                        End If
                        GetMatType = GetMatType1
                    End If
SA36Done:
                Case Is < InStr(GetMatType, Chr(10))
                    MatPos = InStr(GetMatType, Chr(10))

                    If MatPos = 1 Then
                        GetMatType1 = Mid(GetMatType, 2, Len(GetMatType))
                        GetMatType = GetMatType1
                        GoTo FoundMatType
                    Else
                        GetMatType1 = Mid(GetMatType, 1, (MatPos - 1))
                        GetMatType2 = Mid(GetMatType, (MatPos + 1), Len(GetMatType))

                        If InStr(GetMatType, "KLINGER") > 0 Then
                            GetMatType1 = Mid(GetMatType, 1, (MatPos - 1))
                            GetMatType2 = Mid(GetMatType, (MatPos + 1), Len(GetMatType))
                            GetMatType = GetMatType1 & " " & GetMatType2
                            GoTo FoundMatType
                        End If

                        If InStr(GetMatType, "GARLOCK") > 0 Then
                            GetMatType1 = Mid(GetMatType, 1, (MatPos - 1))
                            GetMatType2 = Mid(GetMatType, (MatPos + 1), Len(GetMatType))
                            GetMatType = GetMatType1 & " " & GetMatType2
                            GoTo FoundMatType
                        End If

                        If InStr(GetMatType, "NITRILE") > 0 Then
                            GetMatType1 = Mid(GetMatType, 1, (MatPos - 1))
                            GetMatType2 = Mid(GetMatType, (MatPos + 1), Len(GetMatType))
                            GetMatType = GetMatType1 & " " & GetMatType2
                            GoTo FoundMatType
                        End If

                        If InStr(GetMatType, "NICKEL") > 0 Then
                            GetMatType1 = Mid(GetMatType, 1, (MatPos - 1))
                            GetMatType2 = Mid(GetMatType, (MatPos + 1), Len(GetMatType))
                            GetMatType = GetMatType1 & " " & GetMatType2
                            GoTo FoundMatType
                        End If

                        If InStr(GetMatType, "GALV") > 0 Then
                            If GetMatType1 = "GALV" And GetMatType2 = "STEEL" Then
                                GetMatType = "A36 GALV"
                                GoTo FoundMatType
                            End If

                            GetMatType = GetMatType1 & " " & GetMatType2
                            GoTo FoundMatType
                        End If

                        If GetMatType1 = " " Then
                            GetMatType = GetMatType2
                            GoTo FoundMatType
                        End If

                        If GetMatType2 = "" Then
                            GetMatType = GetMatType1
                            GoTo FoundMatType
                        End If

                        GetMatType = GetMatType1 & " " & GetMatType2
                    End If
                Case Is < InStr(GetMatType, Chr(12))
                    MatPos = InStr(GetMatType, Chr(12))
                    GetMatType = Mid(GetMatType, 1, (MatPos - 1))
                Case Is < InStr(GetMatType, Chr(13))
                    MatPos = InStr(GetMatType, Chr(13))
                    GetMatType = Mid(GetMatType, 1, (MatPos - 1))
                Case Is < InStr(GetMatType, "1018")
                    MatPos = InStr(GetMatType, "C")
                    If MatPos = 0 Then
                        GetMatType = "C" & GetMatType
                    End If

                    If InStr(GetDesc, "COLD ROLLED") > 0 Then
                        GetMatType = GetMatType & " CR"
                    End If
                Case Else
                    If GetMatType = "-" Then
                        GetMatType = ""
                    End If
            End Select

FoundMatType:

            If IsNothing(GetInvNo) = False Then             'GRATING/S 3/16 x 1 x 22 3/4 x 2'-5"
                GetInvStd = GetInvNo & GetStdDwg
            Else
                GetInvStd = Nothing
            End If

            Select Case 0
                    'Case Is < InStr(FndStdNote2, "* None needed")
                    '    'BOMList(14, i) = "PLATE STEEL"
                    '    GoTo NextItem
                    'Case Is < InStr(GetPurchaseTyp, "Found Standard Information")
                    '    GoTo NextItem
                    'Case Is < InStr(GetPurchaseTyp, "Description did not match")
                    '    GoTo NextItem
                Case Is < InStr(GetPurchaseTyp, "SUB-MFG Part")
                    GetPurchaseTyp = BOMList(6, j)                         'GetPurchaseTyp = BOMList(14, i)
                    BOMList(6, j) = "PURCHASE ITEM"                       ''BOMList(14, i) = "PURCHASE ITEM"
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))

                    ItemFound = "Yes"
                    AddItem2 = "Done"
                    GoTo NextItem
                Case Is < InStr(GetDesc, "SEE DRAWING")                  '-------This is only a reference to another drawing.
                    GoTo NextItem
                Case Is < InStr(GetDesc, "SEE DWG")
                    GoTo NextItem
                Case Is < InStr(GetDesc, "DWG")
                    GoTo NextItem
            End Select
FindPart:
StartOver:
            PIPE = 0
            W = 0
            C = 0
            TUBE = 0
            FB = 0
            ROD = 0
            Plug = 0
            SHT = 0
            L = 0
            RB = 0
            PurchaseItem = 0
            PL = 0
            PipeTest = Nothing

            If Mid(GetDesc, 1, 14) = "SHELL PLATE SR" Then
                GoTo FlatPlateItems
            End If

            Select Case UCase(Mid(GetDesc, 1, 1))
                Case "U"                                                        '-------U Bolts
                    If InStr(Left(GetDesc, 6), "U-BOLT") = 1 Then
                        GoTo PurchaseItem
                    Else
                        GoTo PurchaseItem
                    End If
                Case "P"                                                        '------------------------------Pipe
                    Select Case 0
                        Case Is < InStr(GetDesc, "HOSE CLAMP")
                            GoTo PurchaseItem
                        Case Is < InStr(GetDesc, "PIPE NIPPLE")
                            GoTo PurchaseItem
                        Case Is < InStr(GetDesc, "PIPE CAP")
                            GoTo PurchaseItem
                        Case Is < InStr(GetDesc, "PLUG")
                            GoTo PurchaseItem
                        Case Is < InStr(GetDesc, "PLATFORM FRAME")
                            GoTo PurchaseItem
                        Case Is < InStr(GetDesc, "PLATFORM KNEE BRACE")
                            GoTo PurchaseItem
                        Case Is < InStr(GetDesc, "PLATFORM HANDRAIL")
                            GoTo PurchaseItem
                        Case Is < InStr(GetDesc, "POP RIVET")
                            GoTo PurchaseItem
                        Case Is < InStr(Left(GetDesc, 2), "PL")
                            GoTo FlatPlateItems
                        Case Is < InStr(GetDesc, "PIPE 1")
                            GoTo PipeItem
                        Case Is < InStr(GetDesc, "PIPE 2")
                            GoTo PipeItem
                        Case Is < InStr(GetDesc, "PIPE 3")
                            GoTo PipeItem
                        Case Is < InStr(GetDesc, "PIPE 4")
                            GoTo PipeItem
                        Case Is < InStr(GetDesc, "PIPE 5")
                            GoTo PipeItem
                        Case Is < InStr(GetDesc, "PIPE 6")
                            GoTo PipeItem
                        Case Is < InStr(GetDesc, "PIPE 7")
                            GoTo PipeItem
                        Case Is < InStr(GetDesc, "PIPE 8")
                            GoTo PipeItem
                        Case Is < InStr(GetDesc, "PIPE 9")
                            GoTo PipeItem
                        Case Else
                            PIPE = InStr(1, GetDesc, "PIPE")
                            If PIPE > 0 Then
                                GoTo PipeItem
                            End If

                            GoTo PurchaseItem
                    End Select

                Case "W"                '------------------------------Beams
                    Select Case Left(GetDesc, 2)
                        Case "W "
                            GoTo BeamItem
                        Case "W1"
                            GoTo BeamItem
                        Case "W2"
                            GoTo BeamItem
                        Case "W3"
                            GoTo BeamItem
                        Case "W4"
                            GoTo BeamItem
                        Case "W5"
                            GoTo BeamItem
                        Case "W6"
                            GoTo BeamItem
                        Case "W7"
                            GoTo BeamItem
                        Case "W8"
                            GoTo BeamItem
                        Case "W9"
                            GoTo BeamItem
                        Case Else
                            GoTo PurchaseItem
                    End Select
                Case "S"                '------------------------------S Beams
                    Select Case Left(GetDesc, 2)
                        Case "SB"                                   'Square Bar 
                            GoTo SqBarItem
                        Case "S "                                   'S BEAMS 
                            GoTo BeamItem
                        Case "S1"
                            GoTo BeamItem
                        Case "S2"
                            GoTo BeamItem
                        Case "S3"
                            GoTo BeamItem
                        Case "S4"
                            GoTo BeamItem
                        Case "S5"
                            GoTo BeamItem
                        Case "S6"
                            GoTo BeamItem
                        Case "S7"
                            GoTo BeamItem
                        Case "S8"
                            GoTo BeamItem
                        Case "S9"
                            GoTo BeamItem
                        Case "SH"                                   'Gauge Sheet material 
                            SHT = InStr(Mid(GetDesc, 1, 3), "SHT")
                            If SHT > 0 Then
                                GoTo SheetItems
                            Else
                                SHT = InStr(Mid(GetDesc, 1, 3), "SHEET")

                                If SHT > 0 Then
                                    GoTo SheetItems
                                Else
                                    GoTo PurchaseItem
                                End If
                            End If
                        Case Else
                            GoTo PurchaseItem
                    End Select
                Case "M"                '----------------------------------M Beams
                    Select Case Left(GetDesc, 2)
                        Case "M "                               'M BEAMs
                            GoTo BeamItem
                        Case "M1"
                            GoTo BeamItem
                        Case "M2"
                            GoTo BeamItem
                        Case "M3"
                            GoTo BeamItem
                        Case "M4"
                            GoTo BeamItem
                        Case "M5"
                            GoTo BeamItem
                        Case "M6"
                            GoTo BeamItem
                        Case "M7"
                            GoTo BeamItem
                        Case "M8"
                            GoTo BeamItem
                        Case "M9"
                            GoTo BeamItem
                        Case "MC"           '---------------------------MC CHANNELS
                            GoTo ChannelItems
                        Case Else
                            If InStr(GetDesc, "MACHINE BOLT") > 0 Then
                                GoTo BoltItems
                            Else
                                GoTo PurchaseItem
                            End If
                    End Select
                Case "C"                '-------------------------------------Channels
                    Select Case Left(GetDesc, 2)
                        Case "C "                           'Channels
                            GoTo ChannelItems
                        Case "C1"
                            GoTo ChannelItems
                        Case "C2"
                            GoTo ChannelItems
                        Case "C3"
                            GoTo ChannelItems
                        Case "C4"
                            GoTo ChannelItems
                        Case "C5"
                            GoTo ChannelItems
                        Case "C6"
                            GoTo ChannelItems
                        Case "C7"
                            GoTo ChannelItems
                        Case "C8"
                            GoTo ChannelItems
                        Case "C9"
                            GoTo ChannelItems
                        Case Else
                            GoTo PurchaseItem
                    End Select

                Case "L"                    '---------------------------Angle Material
                    GetAngle = Left(GetDesc, 2)              'Many Issues Must Hunt for L2 and L 2 And add Purchase Items

                    Select Case GetAngle
                        Case "L "
                            GoTo AngleItems
                        Case "L1"
                            GoTo AngleItems
                        Case "L2"
                            GoTo AngleItems
                        Case "L3"
                            GoTo AngleItems
                        Case "L4"
                            GoTo AngleItems
                        Case "L5"
                            GoTo AngleItems
                        Case "L6"
                            GoTo AngleItems
                        Case "L7"
                            GoTo AngleItems
                        Case "L8"
                            GoTo AngleItems
                        Case "L9"
                            GoTo AngleItems
                        Case Else
                            GoTo PurchaseItem
                    End Select

                Case "G"                    '---------------------------Grating Material
                    GetGrating = Left(GetDesc, 12)

                    Select Case GetGrating
                        Case "GRATING CLIP"
                            GoTo PurchaseItem
                        Case "GRATING (DWG"
                            GoTo PurchaseItem
                        Case "GRATING STRU"
                            GoTo PurchaseItem
                        Case "GRATING/S 3/"
                            GoTo GratingItem
                        Case Else
                            GetGrating = Left(GetDesc, 7)

                            If GetGrating = "GRATING" Then
                                GoTo GratingItem
                            Else
                                If GetGrating = "GRIP ST" Then
                                    GoTo GripStrut
                                Else
                                    GoTo PurchaseItem
                                End If
                            End If

                    End Select

                Case "T"                '------------------------------Tubbing
                    TUBE = InStr(Left(BOMList(7, j), 4), "TUBE")                            'TUBE = InStr(Left(myarray(7, i), 4), "TUBE")

                    If TUBE > 0 Then
                        'Test1 = GetDesc

                        If PipeTest <> Nothing Then
                            LenDesc = Len(PipeTest)
                            Material = PipeTest
                            BOMList(7, j) = PipeTest                            'myarray(7, i) = PipeTest
                        Else
                            LenDesc = Len(BOMList(7, j))                    'LenMaterial = Len(myarray(7, i))
                            'Material = GetDesc
                        End If

                        FoundRolled = 0                         '-------New request add 30" to all material ROLLED
                        AddRolled = 0
                        FoundRolled = InStr(1, GetDesc, SearchRolled)              'FoundRolled = InStr(1, Material, SearchRolled)
                        FoundColdRolled = InStr(1, GetDesc, "COLD ROLLED")         'FoundColdRolled = InStr(1, Material, "COLD ROLLED")

                        If FoundRolled > 0 And FoundColdRolled = 0 Then
                            AddRolled = 30
                        End If

                        FoundX = InStr(1, GetDesc, SearchX)                        'FoundX = InStr(1, Material, SearchX)
                        'MaterialPart = GetDesc                                     'MaterialPart = Material

                        While FoundX > 0 Or FoundX2 > 0
                            If FoundX > 0 Then
                                LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                                GetDesc = Mid(GetDesc, (FoundX + 3), LenDesc)      'MaterialPart = Mid(MaterialPart, (FoundX + 3), LenMatPart)
                                FoundX = InStr(1, GetDesc, SearchX)                        'FoundX = InStr(1, MaterialPart, SearchX)
                            Else
                                LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                                GetDesc = Mid(GetDesc, (FoundX2 + 2), LenDesc)         'MaterialPart = Mid(MaterialPart, (FoundX2 + 2), LenMatPart)
                                PartFoundX = FoundX2
                                FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                            End If

                            If FoundX = 0 Then
                                FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                            End If
                        End While

                        LenMatPart = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                        GetDesc = LTrim(GetDesc)                          'MaterialPart = LTrim(MaterialPart)
                        GetDesc = RTrim(GetDesc)                          'MaterialPart = RTrim(MaterialPart)

                        If PartFoundX > 0 Then
                            MaterialPart2 = Mid(GetDesc, 1, (LenMatPart - (LenDesc + 2)))
                            PartFoundX = 0
                        Else
                            MaterialPart2 = Mid(GetDesc, 1, (LenMatPart - (LenDesc + 3)))
                        End If

                        If PurchaseProb = True Then
                            GoTo PurchaseItem
                        End If

                        MaterialPart2 = LTrim(MaterialPart2)
                        MaterialPart2 = RTrim(MaterialPart2)

                        If InStr(MaterialPart2, GetMatType) = 0 Then
                            If Len(MaterialPart2) > 0 Then
                                BOMList(12, j) = MaterialPart2 & " - " & GetMatType                 'myarray(12, i) = MaterialPart2 & " - " & GetMatType
                                ReDim Preserve BOMList(20, UBound(BOMList, 2))
                            End If
                        Else
                            BOMList(12, j) = MaterialPart2                          '? Yes          'myarray(12, i) = MaterialPart2
                            ReDim Preserve BOMList(20, UBound(BOMList, 2))
                        End If

                        If InStr(MaterialPart2, GetMatType) = 0 Then
                            MaterialPart2 = MaterialPart2 & " - " & GetMatType
                        End If

                        MaterialPart2 = Replace(MaterialPart2, "   ", " ")
                        MaterialPart2 = Replace(MaterialPart2, "  ", " ")

                        If InStr(MaterialPart2, "TUBE 1 1/2" & Chr(34) & " SCH 40") > 0 Then
                            MaterialPart2 = "TUBING ROUND 1 1/2" & Chr(34) & " SCH 40" & " - " & GetMatType
                        Else
                            If InStr(MaterialPart2, "TUBE 1 1/4" & Chr(34) & " SCH 40") > 0 Then
                                MaterialPart2 = "TUBING ROUND 1 1/4" & Chr(34) & " SCH 40" & " - " & GetMatType
                            End If
                        End If

TubeNotFound:
                        If InStr(GetDesc, GetMatType) > 0 Then
                            MatPos = InStr(GetDesc, " - " & GetMatType)
                            GetDesc = Mid(GetDesc, 1, (MatPos - 1))
                        End If

                        FeetInchesToDecInches(GetDesc, GetDwgNo, ItemNum, ErrFound, FullJobNo)
                        ErrFound = ErrorFoundNew

                        If ErrFound = "Yes" Then
                            MaterialNew = InputBox("Something is wrong with this description please retype " & Material)
                            BOMList(7, j) = MaterialNew                         'myarray(7, i) = MaterialNew
                            ReDim Preserve BOMList(20, UBound(BOMList, 2))

                            GoTo StartOver
                        End If

                        BOMList(19, j) = (MatInch + AddRolled)             'myarray(13, i) = (MatInch + AddRolled)
                        BOMList(6, j) = "TUBE"                            ''myarray(14, i) = "TUBE"
                        ReDim Preserve BOMList(20, UBound(BOMList, 2))

                        ItemFound = "Yes"
                        AddItem2 = "Done"
                        GoTo NextItem
                    Else
                        If InStr(GetDesc, "GRATING") > 0 Then
                            GoTo GratingItem
                        End If
                        If InStr(GetDesc, "TREAD") > 0 Then
                            GoTo GratingItem
                        End If
                        GoTo PurchaseItem
                    End If

                Case "R"
                    RB = InStr(Left(GetDesc, 2), "RB")

                    If RB > 0 Then
                        LenDesc = Len(GetDesc)
                        FoundRolled = 0                         '-------New request add 30" to all material ROLLED
                        AddRolled = 0
                        FoundRolled = InStr(1, GetDesc, SearchRolled)              'FoundRolled = InStr(1, Material, SearchRolled)
                        FoundColdRolled = InStr(1, GetDesc, "COLD ROLLED")         'FoundColdRolled = InStr(1, Material, "COLD ROLLED")

                        If FoundRolled > 0 And FoundColdRolled = 0 Then
                            AddRolled = 30
                        End If

                        FoundX = InStr(1, GetDesc, SearchX)            'FoundX = InStr(1, Material, SearchX)
                        MaterialPart = GetDesc                         'MaterialPart = Material

                        While FoundX > 0 Or FoundX2 > 0
                            If FoundX > 0 Then
                                LenDesc = Len(MaterialPart)                                  'LenDesc= Len(MaterialPart)
                                MaterialPart = Mid(MaterialPart, (FoundX + 3), LenMatPart)      'MaterialPart = Mid(MaterialPart, (FoundX + 3), LenMatPart)
                                FoundX = InStr(1, MaterialPart, SearchX)                        'FoundX = InStr(1, MaterialPart, SearchX)
                            Else
                                LenDesc = Len(MaterialPart)                                  'LenDesc= Len(MaterialPart)
                                GetDesc = Mid(GetDesc, (FoundX2 + 2), LenDesc)
                                PartFoundX = FoundX2
                                FoundX2 = InStr(1, MaterialPart, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                            End If

                            If FoundX = 0 Then
                                FoundX2 = InStr(1, MaterialPart, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                            End If
                        End While

                        LenMatPart = Len(MaterialPart)                                  'LenMatPart = Len(MaterialPart)
                        MaterialPart = LTrim(MaterialPart)                         'MaterialPart = LTrim(MaterialPart)
                        MaterialPart = RTrim(MaterialPart)                         'MaterialPart = RTrim(MaterialPart)

                        If PartFoundX > 0 Then
                            MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 2)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 2)))
                            PartFoundX = 0
                        Else
                            Xpos = InStr(GetDesc, " X ")
                            MaterialPart2 = Mid(GetDesc, 1, (Xpos - 1))
                            'MaterialPart2 = GetDesc.Replace(" - " & GetMatType, "")     'MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 3)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 3)))
                        End If

                        MaterialPart2 = LTrim(MaterialPart2)
                        MaterialPart2 = RTrim(MaterialPart2)
                        Search = "RB "
                        SearchFound = InStr(1, MaterialPart2, Search)

                        If SearchFound = 1 Then
                            MaterialPart2 = Mid(MaterialPart2, 4, (Len(MaterialPart2) - 3))
                            MaterialPart2 = "RB" & MaterialPart2
                        End If

                        MaterialPart2 = LTrim(MaterialPart2)
                        MaterialPart2 = RTrim(MaterialPart2)

                        If InStr(MaterialPart2, GetMatType) = 0 Then                            '-------Found new problem were Material Type already exist-------
                            If Len(MaterialPart2) > 0 Then
                                If GetMatType = "1018" Then
                                    BOMList(12, j) = MaterialPart2 & " - C" & GetMatType                'myarray(12, i) = MaterialPart2 & " - C" & GetMatType
                                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                                Else
                                    BOMList(12, j) = MaterialPart2 & " - " & GetMatType                 'myarray(12, i) = MaterialPart2 & " - " & GetMatType
                                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                                End If
                            End If
                        Else
                            BOMList(12, j) = MaterialPart2                          '? Yes          'myarray(12, i) = MaterialPart2
                            ReDim Preserve BOMList(20, UBound(BOMList, 2))
                        End If

                        Search = "RB"
                        SearchFound = InStr(1, MaterialPart2, Search)

                        If SearchFound = 1 Then
                            MaterialPart2 = Mid(MaterialPart2, 3, Len(MaterialPart2))
                            MaterialPart2 = "RB " & MaterialPart2
                        End If

                        Search = " x "
                        SearchFound = InStr(1, MaterialPart2, Search)

                        If SearchFound > 0 Then
                            MaterialPart1 = Mid(MaterialPart2, (SearchFound + 3), Len(MaterialPart2))
                            MaterialPart2 = Mid(MaterialPart2, 4, (SearchFound - 3))
                            MaterialPart2 = "RB " & MaterialPart1 & " x " & MaterialPart2           'Error RB instead of FB
                        End If

                        MaterialPart2 = LTrim(MaterialPart2)
                        MaterialPart2 = RTrim(MaterialPart2)

                        If InStr(MaterialPart2, GetMatType) = 0 Then
                            If GetMatType = "1018" Then
                                MaterialPart2 = MaterialPart2 & " - C" & GetMatType
                            Else
                                MaterialPart2 = MaterialPart2 & " - " & GetMatType
                            End If
                        End If

RBNotFound:

FoundRB:
                        If InStr(MaterialPart, GetMatType) > 0 Then
                            MatPos = InStr(MaterialPart, " - " & GetMatType)
                            MaterialPart = Mid(MaterialPart, 1, (MatPos - 1))
                        Else
                            If InStr(MaterialPart, "1018") > 0 Then
                                MatPos = InStr(MaterialPart, " - " & "1018")
                                MaterialPart = Mid(MaterialPart, 1, (MatPos - 1))
                            End If
                        End If

                        MatInch = FToD(MaterialPart)
                        BOMList(19, j) = (MatInch + AddRolled)                              'myarray(13, i) = (MatInch + AddRolled)
                        BOMList(6, j) = "ROUND BAR"                                   'myarray(14, i) = "ROUND BAR"
                        ReDim Preserve BOMList(20, UBound(BOMList, 2))

                        ItemFound = "Yes"
                        AddItem2 = "Done"
                        GoTo NextItem
                    End If

                    ROD = InStr(1, GetDesc, "ROD")

                    If ROD > 0 Then
                        LenDesc = Len(GetDesc)
                        GetDesc = LTrim(GetDesc)              'Material = LTrim(Material)
                        GetDesc = RTrim(GetDesc)              'Material = RTrim(Material)
                        FoundRolled = 0
                        AddRolled = 0
                        FoundRolled = InStr(1, GetDesc, SearchRolled)              'FoundRolled = InStr(1, Material, SearchRolled)
                        FoundColdRolled = InStr(1, GetDesc, "COLD ROLLED")         'FoundColdRolled = InStr(1, Material, "COLD ROLLED")

                        If FoundRolled > 0 And FoundColdRolled = 0 Then
                            AddRolled = 30
                        End If

                        FoundX = InStr(1, GetDesc, SearchX)            'FoundX = InStr(1, Material, SearchX)

                        While FoundX > 0 Or FoundX2 > 0
                            If FoundX > 0 Then
                                LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                                GetDesc = Mid(GetDesc, (FoundX + 3), LenDesc)      'MaterialPart = Mid(MaterialPart, (FoundX + 3), LenMatPart)
                                'PartFoundX = FoundX
                                FoundX = InStr(1, GetDesc, SearchX)                        'FoundX = InStr(1, MaterialPart, SearchX)
                            Else
                                LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                                GetDesc = Mid(GetDesc, (FoundX2 + 2), LenDesc)     'MaterialPart = Mid(MaterialPart, (FoundX2 + 2), LenMatPart)
                                PartFoundX = FoundX2
                                FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                            End If

                            If FoundX = 0 Then
                                FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                            End If
                        End While

                        LenMatPart = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                        GetDesc = LTrim(GetDesc)                          'MaterialPart = LTrim(MaterialPart)
                        GetDesc = RTrim(GetDesc)                          'MaterialPart = RTrim(MaterialPart)

                        If PartFoundX > 0 Then
                            MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenDesc + 2)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 2)))
                            PartFoundX = 0
                        Else
                            MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenDesc + 3)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 3)))
                        End If

                        MaterialPart2 = LTrim(MaterialPart2)
                        MaterialPart2 = RTrim(MaterialPart2)
                        GetMatType = GetMatType

                        If GetMatType = "1018" Then
                            GetMatType = "C" & GetMatType
                        End If

                        Search = "ROD "
                        SearchFound = InStr(1, MaterialPart2, Search)

                        If SearchFound = 1 Then
                            MaterialPart2 = Mid(MaterialPart2, 4, (Len(MaterialPart2) - 3))
                            MaterialPart2 = "RB" & MaterialPart2
                        End If

                        If InStr(MaterialPart2, GetMatType) = 0 Then
                            If Len(MaterialPart2) > 0 Then
                                BOMList(12, j) = MaterialPart2 & " - " & GetMatType                 'myarray(12, i) = MaterialPart2 & " - " & GetMatType
                                ReDim Preserve BOMList(20, UBound(BOMList, 2))
                            End If
                        Else
                            BOMList(12, j) = MaterialPart2                          '? Yes          'myarray(12, i) = MaterialPart2
                            ReDim Preserve BOMList(20, UBound(BOMList, 2))
                        End If

                        Search = Chr(34)
                        SearchFound = InStr(1, MaterialPart2, Search)

                        If InStr(MaterialPart2, GetMatType) = 0 Then
                            If SearchFound = Len(MaterialPart2) Then
                                MaterialPart2 = Mid(MaterialPart2, 1, (Len(MaterialPart2) - 1))
                                MaterialPart2 = MaterialPart2 & " - " & GetMatType
                            End If
                        End If

                        MaterialPart2 = Replace(MaterialPart2, "   ", " ")
                        MaterialPart2 = Replace(MaterialPart2, "  ", " ")

RodNotFound:

FoundRod:
                        If InStr(MaterialPart, GetMatType) > 0 Then
                            MatPos = InStr(MaterialPart, " - " & GetMatType)
                            MaterialPart = Mid(MaterialPart, 1, (MatPos - 1))
                        End If

                        FeetInchesToDecInches(MaterialPart, GetDwgNo, ItemNum, ErrFound, FullJobNo)
                        ErrFound = ErrorFoundNew

                        If ErrFound = "Yes" Then
                            MaterialNew = InputBox("Something is wrong with this description please retype " & Material)
                            BOMList(7, j) = MaterialNew                 'myarray(7, i) = MaterialNew
                            ReDim Preserve BOMList(20, UBound(BOMList, 2))

                            GoTo StartOver
                        End If

                        BOMList(19, j) = (MatInch + AddRolled)                              'myarray(13, i) = (MatInch + AddRolled)
                        BOMList(6, j) = "ROUND BAR"                                       ''myarray(14, i) = "ROUND BAR"
                        ReDim Preserve BOMList(20, UBound(BOMList, 2))

                        ItemFound = "Yes"
                        AddItem2 = "Done"
                        GoTo NextItem
                    Else
                        GoTo PurchaseItem
                    End If
                Case "S"
                    GetMatType = (BOMList(11, j))           'GetMatType = (myarray(10, i))
                    FB = InStr(GetDesc, "SHELL MANWAY")

                    If FB > 0 Then
                        If InStr(GetDesc, " - " & GetMatType) > 0 Then
                            MaterialPart2 = Replace(GetDesc, " - " & GetMatType, "")
                        Else
                            MaterialPart2 = GetDesc
                        End If

                        If InStr(MaterialPart2, " (SEE DWG") > 0 Then
                            SearchPos = InStr(MaterialPart2, " (SEE DWG")

                            MaterialPart2 = Mid(MaterialPart2, 1, (SearchPos - 1))
                        End If

FoundShellMW:
                        BOMList(19, j) = GetQty                             'myarray(13, i) = GetQty
                        BOMList(6, j) = "PURCHASE ITEM"                   ''myarray(14, i) = "PURCHASE ITEM"
                        ReDim Preserve BOMList(20, UBound(BOMList, 2))

                        ItemFound = "Yes"
                        AddItem2 = "Done"
                        GoTo NextItem
                    Else
                        GoTo PurchaseItem
                    End If

                Case "F"
                    FB = InStr(Mid(GetDesc, 1, 2), "FB")

                    If FB > 0 Then
                        LenDesc = Len(GetDesc)
                        FoundRolled = 0                         '----------------------------------------New request add 30" to all material ROLLED
                        AddRolled = 0
                        FoundRolled = InStr(1, GetDesc, SearchRolled)              'FoundRolled = InStr(1, Material, SearchRolled)
                        FoundColdRolled = InStr(1, GetDesc, "COLD ROLLED")         'FoundColdRolled = InStr(1, Material, "COLD ROLLED")

                        If FoundRolled > 0 And FoundColdRolled = 0 Then
                            AddRolled = 30
                        End If

                        Xpos = InStr(GetDesc, SearchX)
                        PrevXPos = 0

                        While Xpos > 0
                            If PrevXPos > 0 Then
                                FBLen = Mid(FBThk, (Xpos + 3), Len(FBThk))
                                FBThk = Mid(FBThk, 1, (Xpos - 1))
                                Xpos = InStr(FBLen, SearchX)
                                If Xpos > 0 Then
                                    Stop
                                End If
                            Else
                                FBWid = Mid(GetDesc, 4, (Xpos - 4))
                                FBThk = Mid(GetDesc, (Xpos + 3), (Len(GetDesc) - (Xpos + 2)))
                                PrevXPos = (Xpos + 2)
                                Xpos = InStr(FBThk, SearchX)
                            End If
                        End While

                        SearchPos = InStr(FBLen, "'-0" & Chr(34))
                        If SearchPos > 0 Then
                            EndPart = Mid(FBLen, (SearchPos + 5), Len(FBLen))
                            FBLen = Mid(FBLen, 1, (SearchPos - 1))
                        End If

                        SearchPos = InStr(FBLen, "'-0 ")
                        If SearchPos > 0 Then
                            EndPart = Mid(FBLen, (SearchPos + 4), Len(FBLen))
                            FBLen = Mid(FBLen, 1, (SearchPos + 3))
                        End If

                        SearchPos = InStr(FBLen, " - ")
                        If SearchPos > 0 Then
                            EndPart = Mid(FBLen, SearchPos, Len(FBLen))
                            FBLen = Mid(FBLen, 1, (SearchPos - 1))
                        End If

                        SearchPos = InStr(FBThk, Chr(34))
                        If SearchPos > 0 Then
                            FBThk = Mid(FBThk, 1, (SearchPos - 1))
                        End If

                        MaterialPart2 = "FB " & FBThk & " x " & FBWid & " - " & GetMatType
FoundFB:
                        MaterialPart = FBLen

                        If InStr(MaterialPart, GetMatType) > 0 Then
                            MatPos = InStr(MaterialPart, " - " & GetMatType)
                            MaterialPart = Mid(MaterialPart, 1, (MatPos - 1))
                        End If

                        If InStr(MaterialPart, Chr(39)) > 0 Or InStr(MaterialPart, Chr(34)) > 0 Then
                            MatInch = FToD(MaterialPart)                           'MaterialPart = FToD(MaterialPart)
                        End If

                        BOMList(19, j) = (MatInch + AddRolled)                              'myarray(13, i) = (MatInch + AddRolled)
                        BOMList(6, j) = "FLAT BAR"                                        ''myarray(14, i) = "FLAT BAR"
                        ReDim Preserve BOMList(20, UBound(BOMList, 2))

                        ItemFound = "Yes"
                        AddItem2 = "Done"
                        GoTo NextItem
                    Else
                        GoTo PurchaseItem
                    End If
                Case Else

                    Select Case 0
                        Case Is < InStr(GetDesc, "HOSE CLAMP")
                            GoTo PurchaseItem
                        Case Is < InStr(GetDesc, "PIPE") And InStr(GetDesc, "U-BOLT") = 0
                            PIPE = InStr(1, GetDesc, "PIPE")
                            LenPipe = Len(GetDesc)
                            PipeFirstPart = Mid(GetDesc, 1, (PIPE - 1))
                            PipeSecondPart = Mid(GetDesc, (PIPE + 4), Len(GetDesc))
                            PipeTest = "PIPE " & PipeFirstPart & PipeSecondPart
                            GoTo PipeItem
                        Case Is < InStr(GetDesc, "STUD BOLT")
                            GoTo StudBoltItems
                        Case Is < InStr(GetDesc, "TAP BOLT")
                            GoTo TapBoltItems
                        Case Is < InStr(GetDesc, "MACHINE BOLT")
                            GoTo MachineBoltItems
                        Case Is < InStr(GetDesc, "HEX NUT")
                            GoTo HexNutItems
                        Case Is < InStr(GetDesc, "NYLON INSERT LOCK NUTS")
                            GoTo NylonNutItems
                        Case Is < InStr(GetDesc, "MACHINE SCREW")
                            GoTo MachineScrewItems
                        Case Is < InStr(GetDesc, "BOLT") And InStr(GetDesc, "GASKET") = 0
                            GoTo BoltItems
                        Case Is < InStr(GetDesc, "GASKET")
                            GoTo PurchaseItem
                        Case Is < InStr(GetDesc, "SCREW")
                            GoTo MachineScrewItems
                        Case Else
                            GoTo PurchaseItem
                    End Select
            End Select
SheetItems:
            If GetInvNo = Nothing Then
                GetSc = Nothing
            Else
                GetSc = GetInvNo & GetStdDwg
            End If

            MaterialPart = GetDesc
            LenDesc = Len(MaterialPart)
            MaterialPart = LTrim(MaterialPart)
            MaterialPart = RTrim(MaterialPart)
            FoundX = InStr(1, MaterialPart, SearchX)

            While FoundX > 0 Or FoundX2 > 0
                If FoundX > 0 Then
                    LenMatPart = Len(MaterialPart)
                    MaterialPart = Mid(MaterialPart, (FoundX + 3), LenMatPart)
                    FoundX = InStr(1, MaterialPart, SearchX)
                Else
                    LenMatPart = Len(MaterialPart)
                    MaterialPart = Mid(MaterialPart, (FoundX2 + 2), LenMatPart)
                    PartFoundX = FoundX2
                    FoundX2 = InStr(1, MaterialPart, SearchX2)
                End If

                If FoundX = 0 Then
                    FoundX2 = InStr(1, MaterialPart, SearchX2)
                End If
            End While

            LenMatPart = Len(MaterialPart)
            MaterialPart = LTrim(MaterialPart)
            MaterialPart = RTrim(MaterialPart)
            ShtLength = MaterialPart

            If LenDesc = LenMatPart Then
                MaterialPart2 = Material
            Else
                If PartFoundX > 0 Then
                    MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 2)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 2)))
                    PartFoundX = 0
                Else
                    MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 3)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 3)))
                End If
            End If

            FoundX = InStr(1, MaterialPart2, SearchX)

            While FoundX > 0
                MaterialPart1 = Mid(MaterialPart2, (FoundX + 3), Len(MaterialPart2))
                MaterialPart2 = Mid(MaterialPart2, 1, (FoundX - 1))
                FoundX = InStr(1, MaterialPart2, SearchX)
            End While

            ShtWidth = MaterialPart1
            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)
            Search = "SHT "
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 5, (Len(MaterialPart2) - 4))
            End If

            Search = " "
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 5, (Len(MaterialPart2) - 4))
                MaterialPart2 = "SHT " & MaterialPart2
            Else
                If SearchFound > 1 Then
                    MaterialPart1 = Mid(MaterialPart2, 1, (SearchFound - 1))
                    MaterialPart2 = Mid(MaterialPart2, (SearchFound + 1), Len(MaterialPart2))
                    MaterialPart2 = "SHT " & MaterialPart1 & MaterialPart2
                End If
            End If

            Search = "SHEET "
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 5, (Len(MaterialPart2) - 4))
                MaterialPart2 = "SHT" & MaterialPart2
            End If

            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)
            ShtWid = FToD(ShtWidth)

            If InStr(MaterialPart2, "10GA") > 0 Then
                Select Case ShtWid
                    Case Is > 60
                        MaterialPart2 = MaterialPart2 & " x 96"
                    Case Is > 48
                        MaterialPart2 = MaterialPart2 & " x 60"
                    Case Is > 36
                        MaterialPart2 = MaterialPart2 & " x 48"
                    Case Is > 24
                        MaterialPart2 = MaterialPart2 & " x 48"
                    Case Else
                        MaterialPart2 = MaterialPart2 & " x 48"
                End Select
            End If

            If InStr(MaterialPart2, "11GA") > 0 Then
                Select Case ShtWid
                    Case Is > 60
                        MaterialPart2 = MaterialPart2 & " x 96"
                    Case Is > 48
                        MaterialPart2 = MaterialPart2 & " x 60"
                    Case Is > 36
                        MaterialPart2 = MaterialPart2 & " x 48"
                    Case Is > 24
                        MaterialPart2 = MaterialPart2 & " x 48"
                    Case Else
                        MaterialPart2 = MaterialPart2 & " x 48"
                End Select
            End If

            If InStr(MaterialPart2, "12GA") > 0 Then
                Select Case ShtWid
                    Case Is > 60
                        MaterialPart2 = MaterialPart2 & " x 96"
                    Case Is > 48
                        MaterialPart2 = MaterialPart2 & " x 60"
                    Case Is > 36
                        MaterialPart2 = MaterialPart2 & " x 48"
                    Case Is > 24
                        MaterialPart2 = MaterialPart2 & " x 48"
                    Case Else
                        MaterialPart2 = MaterialPart2 & " x 48"
                End Select
            End If

            If InStr(MaterialPart2, "16GA") > 0 Then
                Select Case ShtWid
                    Case Is > 60
                        MaterialPart2 = MaterialPart2 & " x 96"
                    Case Is > 48
                        MaterialPart2 = MaterialPart2 & " x 60"
                    Case Is > 36
                        MaterialPart2 = MaterialPart2 & " x 48"
                    Case Is > 24
                        MaterialPart2 = MaterialPart2 & " x 36"
                    Case Else
                        MaterialPart2 = MaterialPart2 & " x 36"
                End Select
            End If

            If InStr(MaterialPart2, "18GA") > 0 Then
                Select Case ShtWid
                    Case Is > 60
                        MaterialPart2 = MaterialPart2 & " x 96"
                    Case Is > 48
                        MaterialPart2 = MaterialPart2 & " x 60"
                    Case Is > 36
                        MaterialPart2 = MaterialPart2 & " x 48"
                    Case Is > 24
                        MaterialPart2 = MaterialPart2 & " x 36"
                    Case Else
                        MaterialPart2 = MaterialPart2 & " x 36"
                End Select
            End If

            ShtLen = FToD(ShtLength)

            With BOMWrkSht
                GetDwgNo = .Range("B" & (j + 4)).Value
            End With

            Select Case ShtLen
                Case Is > 144
                    MaterialPart2 = MaterialPart2 & " x " & ShtLen & Chr(34)
                Case Is > 139
                    MaterialPart2 = MaterialPart2 & " x 144" & Chr(34)
                Case Is > 120
                    MaterialPart2 = MaterialPart2 & " x 139" & Chr(34)
                Case Else
                    MaterialPart2 = MaterialPart2 & " x 120" & Chr(34)
            End Select

            If InStr(MaterialPart2, GetMatType) = 0 Then
                If Len(MaterialPart2) > 0 Then
                    BOMList(12, j) = MaterialPart2 & " - " & GetMatType                 'myarray(12, i) = MaterialPart2 & " - " & GetMatType
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                End If
            Else
                BOMList(12, j) = MaterialPart2                          '? Yes          'myarray(12, i) = MaterialPart2
                ReDim Preserve BOMList(20, UBound(BOMList, 2))
            End If

            'GetPartNo = BOMList(15, j)                          'GetPartNo = myarray(15, i)

            'If GetPartNo <> Nothing Then
            '    GoTo FoundSheet
            'End If

            'For n = 0 To UBound(MatData, 2)
            '    Mat = MatData(2, n)
            '    Mat = Replace(Mat, "   ", " ")
            '    Mat = Replace(Mat, "   ", " ")

            '    If Mid(Mat, 1, 3) = "SHT" Or Mid(Mat, 1, 4) = "SHEET" Then
            '        If InStr(Mat, MaterialPart2) > 0 Or InStr(MaterialPart2, Mat) > 0 Then
            '            If Mat = Nothing Then
            '                GoTo ShtNotFound
            '            End If
            '            'myarray(15, j) = MatData(0, n)
            '            GoTo FoundSheet
            '        Else
            '            If Mat = MaterialPart2 Then
            '                If Mat = Nothing Then
            '                    GoTo ShtNotFound
            '                End If
            '                'myarray(15, j) = MatData(0, n)
            '                GoTo FoundSheet
            '            End If
            '        End If
            '    End If
            'Next n
ShtNotFound:

FoundSheet:
            LenPlateNotes = Len(BOMList(7, j))                          'LenPlateNotes = Len(myarray(7, i))
            PlateNotes = BOMList(7, j)                                  'PlateNotes = myarray(7, i)
            SearchNote = "NOTE"
            FoundNote = InStr(1, PlateNotes, SearchNote)

            If FoundNote > 0 Then
                LenPlateNotes = Len(PlateNotes)
                PlateNotes = Mid(PlateNotes, FoundNote, (LenPlateNotes - (FoundNote - 1)))
                PlateNotes = LTrim(PlateNotes)
                PlateNotes = RTrim(PlateNotes)
            Else
                PlateNotes = ""
            End If

            BOMList(19, j) = PlateNotes                            'myarray(13, i) = PlateNotes
            BOMList(6, j) = "SHEET STEEL-GA"                      ''myarray(14, i) = "SHEET STEEL-GA"
            ReDim Preserve BOMList(20, UBound(BOMList, 2))

            ItemFound = "Yes"
            AddItem2 = "Done"
            GoTo NextItem
AngleItems:
            LenDesc = Len(BOMList(7, j))            'LenDesc = Len(myarray(7, i))
            Material = BOMList(7, j)
            FoundRolled = 0                         '----------------------------------------New request add 30" to all material ROLLED
            AddRolled = 0
            FoundRolled = InStr(1, GetDesc, SearchRolled)              'FoundRolled = InStr(1, Material, SearchRolled)
            FoundColdRolled = InStr(1, GetDesc, "COLD ROLLED")         'FoundColdRolled = InStr(1, Material, "COLD ROLLED")

            If FoundRolled > 0 And FoundColdRolled = 0 Then
                AddRolled = 30
            End If

            FoundX = InStr(1, GetDesc, SearchX)            'FoundX = InStr(1, Material, SearchX)

            While FoundX > 0 Or FoundX2 > 0
                If FoundX > 0 Then
                    LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                    GetDesc = Mid(GetDesc, (FoundX + 3), LenDesc)      'MaterialPart = Mid(MaterialPart, (FoundX + 3), LenMatPart)
                    FoundX = InStr(1, GetDesc, SearchX)                        'FoundX = InStr(1, MaterialPart, SearchX)
                Else
                    LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                    GetDesc = Mid(GetDesc, (FoundX2 + 2), LenDesc)     'MaterialPart = Mid(MaterialPart, (FoundX2 + 2), LenMatPart)
                    PartFoundX = FoundX2
                    FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                End If

                If FoundX = 0 Then
                    FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                End If
            End While

            LenMatPart = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
            GetDesc = LTrim(GetDesc)                          'MaterialPart = LTrim(MaterialPart)
            GetDesc = RTrim(GetDesc)                          'MaterialPart = RTrim(MaterialPart)

            If LenDesc = LenMatPart Then
                MaterialPart2 = Material
            Else
                If PartFoundX > 0 Then
                    MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 2)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 2)))
                    PartFoundX = 0
                Else
                    MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 3)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 3)))
                End If
            End If

            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)
            Search = "L "
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 3, (Len(MaterialPart2) - 2))
                MaterialPart2 = "L" & MaterialPart2
            End If

            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)

            If InStr(MaterialPart2, GetMatType) = 0 Then
                If Len(MaterialPart2) > 0 Then
                    BOMList(12, j) = MaterialPart2 & " - " & GetMatType                 'myarray(12, i) = MaterialPart2 & " - " & GetMatType
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                End If
            Else
                BOMList(12, j) = MaterialPart2                          '? Yes          'myarray(12, i) = MaterialPart2
                ReDim Preserve BOMList(20, UBound(BOMList, 2))
            End If

            Search = "L"
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 2, Len(MaterialPart2))
                MaterialPart2 = "L " & MaterialPart2
            End If

            If InStr(MaterialPart2, GetMatType) = 0 Then
                MaterialPart2 = MaterialPart2 & " - " & GetMatType
            End If

AngleNotFound:

FoundAngle:
            If InStr(MaterialPart, GetMatType) > 0 Then
                MatPos = InStr(MaterialPart, " - " & GetMatType)
                MaterialPart = Mid(MaterialPart, 1, (MatPos - 1))
            End If

            FeetInchesToDecInches(MaterialPart, GetDwgNo, ItemNum, ErrFound, FullJobNo)
            ErrFound = ErrorFoundNew

            If ErrFound = "Yes" Then
                MaterialNew = InputBox("Something is wrong with this description please retype " & Material)
                BOMList(7, j) = MaterialNew                         'myarray(7, i) = MaterialNew
                ReDim Preserve BOMList(20, UBound(BOMList, 2))

                GoTo StartOver
            End If

            BOMList(19, j) = (MatInch + AddRolled)                              'myarray(13, i) = (MatInch + AddRolled)
            BOMList(6, j) = "ANGLE"                                           ''myarray(14, i) = "ANGLE"
            ReDim Preserve BOMList(20, UBound(BOMList, 2))

            ItemFound = "Yes"
            AddItem2 = "Done"
            GoTo NextItem
BoltItems:
            LenDesc = Len(GetDesc)
            FoundX = InStr(1, GetDesc, SearchX)

            While FoundX > 0 Or FoundX2 > 0
                If FoundX > 0 Then
                    LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                    GetDesc = Mid(GetDesc, (FoundX + 3), LenDesc)      'MaterialPart = Mid(MaterialPart, (FoundX + 3), LenMatPart)
                    FoundX = InStr(1, GetDesc, SearchX)                        'FoundX = InStr(1, MaterialPart, SearchX)
                Else
                    LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                    GetDesc = Mid(GetDesc, (FoundX2 + 2), LenDesc)     'MaterialPart = Mid(MaterialPart, (FoundX2 + 2), LenMatPart)
                    PartFoundX = FoundX2
                    FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                End If

                If FoundX = 0 Then
                    FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                    Dim FoundHexNut As Integer
                    FoundHexNut = InStr(1, MaterialPart, "HEX NUT")

                    If FoundHexNut < FoundX2 Then
                        FoundX2 = 0

                        If PartFoundX = 0 Then
                            PartFoundX = InStr(GetDesc, " x ")
                        End If

                        NutSize = Mid(GetDesc, 1, (PartFoundX - 1))

                        If InStr(NutSize, "MACHINE BOLT") > 0 Then
                            NutSize = Mid(NutSize, 13, Len(NutSize))
                        End If

                        NutSize = LTrim(NutSize)
                        NutSize = RTrim(NutSize)
                    End If
                End If
            End While

            LenMatPart = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
            GetDesc = LTrim(GetDesc)                          'MaterialPart = LTrim(MaterialPart)
            GetDesc = RTrim(GetDesc)                          'MaterialPart = RTrim(MaterialPart)

            If LenDesc = LenMatPart Then
                MaterialPart2 = Material
            Else
                If PartFoundX > 0 Then
                    MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 2)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 2)))
                    PartFoundX = 0
                Else
                    MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 3)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 3)))
                End If
            End If

            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)

            SearchDash = "-"
            DashPos = InStr(GetMatType, SearchDash)

            If DashPos > 0 Then
                GetMatType1 = Mid(GetMatType, 1, (DashPos - 1))
                GetMatType2 = Mid(GetMatType, (DashPos + 1), Len(GetMatType))
                GetMatType = GetMatType1 & " " & GetMatType2
            End If

            SearchSpace = " "
            Dim SpacePos As Integer
            Dim SearchMat As String
            SpacePos = InStr(GetMatType, SearchSpace)

            If SpacePos > 0 Then
                If InStr(GetMatType, "ZINC PL") > 0 Then
                    GetMatType1 = "ZINC PLATE"
                    GetMatType2 = "ZINC PLATE"
                    GetMatType = "ZINC PLATE"
                Else
                    If InStr(GetMatType, "ZINC PLATE") > 0 Then
                        GetMatType1 = "ZINC PLATE"
                        GetMatType2 = "ZINC PLATE"
                        GetMatType = "ZINC PLATE"
                    Else
                        GetMatType1 = Mid(GetMatType, 1, (SpacePos - 1))
                        GetMatType2 = Mid(GetMatType, (SpacePos + 1), Len(GetMatType))
                    End If
                End If
            Else
                SearchMat = Chr(10)
                MatPos = InStr(GetMatType, SearchMat)

                If MatPos > 0 Then
                    If InStr(GetMatType, "ZINC") > 0 And InStr(GetMatType, "PLATE") > 0 Then
                        GetMatType1 = Mid(GetMatType, 1, (MatPos - 1))
                        GetMatType2 = Mid(GetMatType, (MatPos + 1), Len(GetMatType))

                        GetMatType = GetMatType1 & " " & GetMatType2
                        GetMatType1 = GetMatType
                        GetMatType2 = GetMatType
                    Else
                        GetMatType1 = Mid(GetMatType, 1, (MatPos - 1))
                        GetMatType2 = Mid(GetMatType, (MatPos + 1), Len(GetMatType))
                    End If
                Else
                    GetMatType1 = GetMatType
                    GetMatType2 = GetMatType
                End If
            End If

            NutsNo = MaterialPart

            If GetMatType1 = "GALV" And GetMatType2 = "STEEL" Then
                GetMatType1 = "CS " & GetMatType1
                GetMatType2 = GetMatType1
                GetMatType = GetMatType1
            End If

            If InStr(GetDesc, " - GALV") > 0 Then
                SearchPos = InStr(GetDesc, " - GALV")
                GetDesc = Mid(GetDesc, 1, (SearchPos - 1))
            End If

            If InStr(GetDesc, "w/") > 0 Then
                SearchPos = InStr(GetDesc, "w/")
                GetDesc = Mid(GetDesc, 1, (SearchPos - 1))
            End If

            If InStr(AddMat, "3013T45") > 0 Then
                GetDesc = GetDesc & " #3013T45"
            End If

            If InStr(AddMat, "3013T913") > 0 Then
                GetDesc = GetDesc & " #3013T913"
            End If

            If GetDesc <> MaterialPart2 Then
                MaterialPart2 = GetDesc
            End If

            If NutsNo > 0 Then
                ManwayInfo3134.OldDesc = MaterialPart2 & " - " & GetMatType1
                ManwayInfo3134.GetDesc = GetDesc
                ManwayInfo3134.AddMat = AddMat & " - " & GetMatType2
                ManwayInfo3134.AddMatSize = NutSize
                ManwayInfo3134.AddMatQty = NutsNo
            Else
                ManwayInfo3134.OldDesc = MaterialPart2 & " - " & GetMatType
                ManwayInfo3134.GetDesc = GetDesc
                ManwayInfo3134.AddMat = Nothing
                ManwayInfo3134.AddMatSize = Nothing
                ManwayInfo3134.AddMatQty = Nothing
            End If

            If InStr(MaterialPart2, GetMatType1) = 0 Then
                If Len(MaterialPart2) > 0 Then
                    If IsNothing(LenBolt) = False Then
                        If InStr(LenBolt, "EYE BOLT") = 0 Then
                            BOMList(12, j) = MaterialPart2 & " - " & GetMatType1                 'myarray(12, i) = MaterialPart2 & " - " & GetMatType1
                            ReDim Preserve BOMList(20, UBound(BOMList, 2))
                        End If
                    Else
                        BOMList(12, j) = MaterialPart2 & " - " & GetMatType                 'myarray(12, i) = MaterialPart2 & " - " & GetMatType
                        ReDim Preserve BOMList(20, UBound(BOMList, 2))
                    End If
                End If
            Else
                BOMList(12, j) = MaterialPart2                          '? Yes          'myarray(12, i) = MaterialPart2
                ReDim Preserve BOMList(20, UBound(BOMList, 2))
            End If

            If InStr(MaterialPart2, GetMatType1) = 0 Then
                If InStr(ManwayInfo3134.GetDesc, "PLAIN FINISH") > 0 Then
                    MaterialPart2 = MaterialPart2 & " x " & LenBolt & " - PLAIN"
                Else
                    If InStr(LenBolt, "EYE BOLT") = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType1
                    End If
                End If
            End If

            MaterialPart2 = Replace(MaterialPart2, "   ", " ")
            MaterialPart2 = Replace(MaterialPart2, "  ", " ")

FoundBolts:
            BOMList(6, j) = "PURCHASE ITEM"                         'myarray(14, i) = "PURCHASE"
            ReDim Preserve BOMList(20, UBound(BOMList, 2))

            ItemFound = "Yes"
            AddItem2 = "Done"
            GoTo NextItem
StudBoltItems:
            SearchInch = Chr(34)
            InchPos = InStr(GetDesc, SearchInch)
            PrevInchPos = 0

            While InchPos > 0
                If PrevInchPos > 0 Then
                    FirstPart = Mid(GetDesc, 1, (InchPos + PrevInchPos))
                    SecondPart = Mid(GetDesc, (InchPos + PrevInchPos + 1), Len(GetDesc))
                    PrevInchPos = (PrevInchPos + (InchPos + 1))
                    InchPos = InStr(SecondPart, SearchInch)
                Else
                    FirstPart = Mid(GetDesc, 1, (InchPos - 1))
                    SecondPart = Mid(GetDesc, (InchPos + 1), Len(GetDesc))
                    PrevInchPos = InchPos
                    InchPos = InStr(SecondPart, SearchInch)
                    SearchStud = "STUD BOLT "
                    StudPos = InStr(FirstPart, SearchStud)
                    Xpos = InStr(FirstPart, " x ")

                    If Xpos = 0 Then
                        NutSize = Mid(FirstPart, (StudPos + 9), Len(FirstPart))
                    Else
                        If Xpos = 1 Then
                            NutSize = Mid(FirstPart, (StudPos + 9), Len(FirstPart))
                        Else
                            NutSize = Mid(FirstPart, (StudPos + 9), (Xpos - (StudPos + 9)))
                        End If
                    End If

                    NutSize = LTrim(NutSize)
                    NutSize = RTrim(NutSize)
                End If
            End While

            SearchPos = InStr(NutSize, " x ")
            PrevXPos = 0

            If SearchPos > 0 Then
                NutSize = Mid(NutSize, 1, (SearchPos - 1))
                NutSize = LTrim(NutSize)
                NutSize = RTrim(NutSize)
            End If

            NutsNo = SecondPart
            SearchWith = "w/ "
            WithPos = InStr(NutsNo, SearchWith)

            If WithPos > 0 Then
                NutsNo = Mid(SecondPart, (WithPos + 3), Len(NutsNo))
            Else
                SearchWith = "w/"
                WithPos = InStr(NutsNo, SearchWith)

                If WithPos > 0 Then
                    NutsNo = Mid(SecondPart, (WithPos + 2), Len(NutsNo))
                End If
            End If

            SearchHH = "HH"
            HHPos = InStr(NutsNo, SearchHH)

            Select Case 0
                Case Is < HHPos
                    NutsNo = Mid(NutsNo, 1, (HHPos - 1))
                    NutsNo = LTrim(NutsNo)
                    NutsNo = RTrim(NutsNo)
                    AddMat = "HEX NUT" & " " & NutSize & Chr(34)
                Case Else
                    Stop
            End Select

            ManwayInfo3134.OldDesc = FirstPart
            ManwayInfo3134.GetDesc = GetDesc
            ManwayInfo3134.AddMat = AddMat
            ManwayInfo3134.AddMatSize = NutSize
            ManwayInfo3134.AddMatQty = NutsNo

            SearchDash = "-"
            DashPos = InStr(GetMatType, SearchDash)

            If DashPos > 0 Then
                GetMatType1 = Mid(GetMatType, 1, (DashPos - 1))
                GetMatType2 = Mid(GetMatType, (DashPos + 1), Len(GetMatType))
                GetMatType = GetMatType1 & " " & GetMatType2
            Else
                GetMatType1 = GetMatType
                GetMatType2 = GetMatType
            End If

            SearchPos = InStr(FirstPart, " x ")
            PrevXPos = 0
            Dim BoltLen As String

            If SearchPos > 0 Then
                BoltLen = Mid(FirstPart, (SearchPos + 3), Len(FirstPart))
                BoltLen = LTrim(BoltLen)
                BoltLen = RTrim(BoltLen)
            End If

            FindDesc = "STUD BOLT " & NutSize & Chr(34) & " x " & BoltLen & Chr(34) & " - " & GetMatType1
            FindDesc2 = ManwayInfo3134.AddMat & " - " & GetMatType2

TapBoltItems:
            SearchInch = Chr(34)
            InchPos = InStr(GetDesc, SearchInch)
            PrevInchPos = 0

            While InchPos > 0
                If PrevInchPos > 0 Then
                    FirstPart = Mid(GetDesc, 1, (InchPos + PrevInchPos))
                    SecondPart = Mid(GetDesc, (InchPos + PrevInchPos + 1), Len(GetDesc))
                    PrevInchPos = (PrevInchPos + (InchPos + 1))
                    InchPos = InStr(SecondPart, SearchInch)
                Else
                    FirstPart = Mid(GetDesc, 1, (InchPos - 1))
                    SecondPart = Mid(GetDesc, (InchPos + 1), Len(GetDesc))
                    PrevInchPos = InchPos
                    InchPos = InStr(SecondPart, SearchInch)
                    SearchStud = "TAP BOLT "

                    StudPos = InStr(FirstPart, SearchStud)
                    Xpos = InStr(FirstPart, " x ")

                    If Xpos = 0 Then
                        NutSize = Mid(FirstPart, (StudPos + 9), Len(FirstPart))
                    Else
                        If Xpos = 1 Then
                            NutSize = Mid(FirstPart, (StudPos + 9), Len(FirstPart))
                        Else
                            NutSize = Mid(FirstPart, (StudPos + 9), (Xpos - (StudPos + 9)))
                        End If
                    End If
                    NutSize = LTrim(NutSize)
                    NutSize = RTrim(NutSize)
                End If
            End While

            SearchPos = InStr(NutSize, " x ")
            PrevXPos = 0

            If SearchPos > 0 Then
                NutSize = Mid(NutSize, 1, (SearchPos - 1))
                NutSize = LTrim(NutSize)
                NutSize = RTrim(NutSize)
            End If

            NutsNo = SecondPart
            SearchWith = "w/ "
            WithPos = InStr(NutsNo, SearchWith)

            If WithPos > 0 Then
                NutsNo = Mid(SecondPart, (WithPos + 3), Len(NutsNo))
            Else
                SearchWith = "w/"
                WithPos = InStr(NutsNo, SearchWith)

                If WithPos > 0 Then
                    NutsNo = Mid(SecondPart, (WithPos + 2), Len(NutsNo))
                End If
            End If

            SearchHH = "HH"
            HHPos = InStr(NutsNo, SearchHH)

            Select Case 0
                Case Is < HHPos
                    NutsNo = Mid(NutsNo, 1, (HHPos - 1))
                    NutsNo = LTrim(NutsNo)
                    NutsNo = RTrim(NutsNo)
                    AddMat = "HEX NUT" & " " & NutSize & Chr(34)
                Case Is < InStr(NutsNo, "HEX NUT")
                    HHPos = InStr(NutsNo, "HEX NUT")
                    NutsNo = Mid(NutsNo, 1, (HHPos - 1))
                    NutsNo = LTrim(NutsNo)
                    NutsNo = RTrim(NutsNo)
                    AddMat = "HEX NUT" & " " & NutSize & Chr(34)
                Case Is < InStr(NutsNo, "NYLON INSERT LOCK NUTS")
                    NutsNo = 1
                    AddMat = "HEX LOCK NUT " & NutSize & Chr(34) & " W/ NYL. INS."
                    FirstPart = "HHMB " & Mid(FirstPart, 13, Len(FirstPart))
                    FirstPart = LTrim(FirstPart)
                    FirstPart = RTrim(FirstPart)
                Case Else
                    If NutsNo = "" Then
                        NutsNo = 0
                        GoTo NoNuts2
                    End If

                    If NutsNo = 0 Then
                        GoTo NoNuts2
                    End If

                    Stop
            End Select
NoNuts2:
            ManwayInfo3134.OldDesc = FirstPart
            ManwayInfo3134.GetDesc = GetDesc

            If NutsNo = "0" Then
                AddMat = Nothing
                ManwayInfo3134.AddMat = AddMat
                ManwayInfo3134.AddMatSize = NutSize
                ManwayInfo3134.AddMatQty = NutsNo
            Else
                ManwayInfo3134.AddMat = AddMat
                ManwayInfo3134.AddMatSize = NutSize
                ManwayInfo3134.AddMatQty = NutsNo
            End If

            SearchDash = "-"
            DashPos = InStr(GetMatType, SearchDash)

            If DashPos > 0 Then
                If GetMatType = "18-8-SS" Then
                    GetMatType1 = GetMatType
                    GetMatType2 = GetMatType
                    GoTo EndGetMat
                End If
                GetMatType1 = Mid(GetMatType, 1, (DashPos - 1))
                GetMatType2 = Mid(GetMatType, (DashPos + 1), Len(GetMatType))
                GetMatType = GetMatType1 & " " & GetMatType2
            Else
                GetMatType1 = GetMatType
                GetMatType2 = GetMatType
            End If
EndGetMat:
            SearchPos = InStr(FirstPart, " x ")
            PrevXPos = 0

            If SearchPos > 0 Then
                BoltLen = Mid(FirstPart, (SearchPos + 3), Len(FirstPart))
                BoltLen = LTrim(BoltLen)
                BoltLen = RTrim(BoltLen)
            End If

            If InStr(BoltLen, Chr(34)) Then
                SearchPos = InStr(BoltLen, Chr(34))

                If SearchPos > 0 Then
                    BoltLen = Mid(BoltLen, 1, (SearchPos - 1))
                    BoltLen = LTrim(BoltLen)
                    BoltLen = RTrim(BoltLen)
                End If
            End If

            If NutsNo = "0" Then
                FindDesc = "TAP BOLT " & NutSize & Chr(34) & " x " & BoltLen & Chr(34) & " - " & GetMatType
                FindDesc2 = ManwayInfo3134.AddMat
            Else
                FindDesc = "TAP BOLT " & NutSize & Chr(34) & " x " & BoltLen & Chr(34) & " - " & GetMatType1
                FindDesc2 = ManwayInfo3134.AddMat & " - " & GetMatType2
            End If

MachineBoltItems:
            Dim SearchMBolt As String
            InchPos = InStr(GetDesc, SearchInch)
            Xpos = InStr(GetDesc, SearchX)
            PrevInchPos = 0
            Dim MBoltPos As Integer

            If InchPos > 0 Then
                While InchPos > 0
                    If PrevInchPos > 0 Then
                        SearchPos = InStr(GetDesc, "MACHINE BOLT")
                        FirstPart = Mid(GetDesc, (12 + SearchPos), (InchPos + PrevInchPos - (12 + SearchPos)))
                        FirstPart = "HHMB " & FirstPart
                        SecondPart = Mid(GetDesc, (InchPos + PrevInchPos + 1), Len(GetDesc))
                        PrevInchPos = (PrevInchPos + (InchPos + 1))
                        InchPos = InStr(SecondPart, SearchInch)
                    Else
                        FirstPart = Mid(GetDesc, 1, (InchPos - 1))
                        SecondPart = Mid(GetDesc, (InchPos + 1), Len(GetDesc))
                        PrevInchPos = InchPos
                        InchPos = InStr(SecondPart, SearchInch)
                        SearchMBolt = "MACHINE BOLT "
                        MBoltPos = InStr(FirstPart, SearchMBolt)

                        If MBoltPos > 0 Then
                            NutSize = Mid(FirstPart, (MBoltPos + 12), Len(FirstPart))
                            NutSize = LTrim(NutSize)
                            NutSize = RTrim(NutSize)
                        End If
                    End If
                End While
            Else
                While Xpos > 0
                    If PrevInchPos > 0 Then
                        FirstPart = Mid(GetDesc, 1, (InchPos + PrevInchPos))
                        SecondPart = Mid(GetDesc, (InchPos + PrevInchPos + 1), Len(GetDesc))
                        PrevInchPos = (PrevInchPos + (InchPos + 1))
                        InchPos = InStr(SecondPart, SearchInch)
                    Else
                        FirstPart = Mid(GetDesc, 1, (InchPos - 1))
                        SecondPart = Mid(GetDesc, (InchPos + 1), Len(GetDesc))
                        PrevInchPos = InchPos
                        InchPos = InStr(SecondPart, SearchInch)
                        SearchMBolt = "MACHINE BOLT "
                        MBoltPos = InStr(FirstPart, SearchMBolt)

                        If MBoltPos > 0 Then
                            NutSize = Mid(FirstPart, (MBoltPos + 12), Len(FirstPart))
                            NutSize = LTrim(NutSize)
                            NutSize = RTrim(NutSize)
                        End If
                    End If
                End While
            End If

            NutsNo = SecondPart
            SearchWith = "w/ "
            WithPos = InStr(NutsNo, SearchWith)

            If WithPos > 0 Then
                NutsNo = Mid(SecondPart, (WithPos + 3), Len(NutsNo))
            Else
                NutsNo = 0
            End If

            SearchX = " x "
            Xpos = InStr(NutSize, SearchX)

            If Xpos > 0 Then
                NutSize = Mid(NutSize, 1, Xpos)
                NutSize = LTrim(NutSize)
                NutSize = RTrim(NutSize)
            End If

            Dim DescPos As Integer

            Select Case 0
                Case Is < InStr(NutsNo, "HH")
                    DescPos = InStr(NutsNo, "HH")
                    NutsNo = Mid(NutsNo, 1, (DescPos - 1))
                    NutsNo = LTrim(NutsNo)
                    NutsNo = RTrim(NutsNo)

                    AddMat = "HEX NUT " & NutSize & Chr(34)

                    If InStr(FirstPart, "HHMB") = 0 Then
                        FirstPart = "HHMB " & Mid(FirstPart, 16, Len(FirstPart))
                    End If

                    FirstPart = LTrim(FirstPart)
                    FirstPart = RTrim(FirstPart)
                Case Is < InStr(NutsNo, "HEX NUT")
                    DescPos = InStr(NutsNo, "HEX NUT")
                    NutsNo = Mid(NutsNo, 1, (DescPos - 1))
                    NutsNo = LTrim(NutsNo)
                    NutsNo = RTrim(NutsNo)
                    AddMat = "HEX NUT " & NutSize & Chr(34)
                    FirstPart = "HHMB " & Mid(FirstPart, 14, Len(FirstPart))
                    FirstPart = LTrim(FirstPart)
                    FirstPart = RTrim(FirstPart)

                    If Mid(FirstPart, Len(FirstPart), 1) = Chr(34) Then
                        '               -------Do Nothing
                    Else
                        FirstPart = FirstPart & Chr(34)
                    End If

                    Dim FirstPart1, FirstPart2 As String
                    SearchX = " x "
                    Xpos = InStr(FirstPart, SearchX)

                    If Xpos > 0 Then
                        FirstPart1 = Mid(FirstPart, 1, (Xpos - 1))
                        FirstPart2 = Mid(FirstPart, Xpos, Len(FirstPart))

                        If Mid(FirstPart1, Len(FirstPart1), 1) = Chr(34) Then
                            '               -------Do Nothing
                        Else
                            FirstPart = FirstPart1 & Chr(34) & FirstPart2
                        End If
                    End If
                Case Is < InStr(NutsNo, "NYLON INSERT LOCK NUTS")
                    NutsNo = 1
                    AddMat = "HEX LOCK NUT " & NutSize & Chr(34) & " W/ NYL. INS."
                    FirstPart = "HHMB " & Mid(FirstPart, 13, Len(FirstPart))
                    FirstPart = LTrim(FirstPart)
                    FirstPart = RTrim(FirstPart)
                Case Else
                    If NutsNo = 0 Then
                        GoTo NoNuts
                    End If
            End Select
NoNuts:
            ManwayInfo3134.OldDesc = FirstPart
            ManwayInfo3134.GetDesc = GetDesc
            ManwayInfo3134.AddMat = AddMat
            ManwayInfo3134.AddMatSize = NutSize
            ManwayInfo3134.AddMatQty = NutsNo
            SearchDash = "-"
            DashPos = InStr(GetMatType, SearchDash)

            If DashPos > 0 Then
                GetMatType1 = Mid(GetMatType, 1, (DashPos - 1))
                GetMatType2 = Mid(GetMatType, (DashPos + 1), Len(GetMatType))
                GetMatType = GetMatType1 & " " & GetMatType2
            End If

            FindDesc = ManwayInfo3134.OldDesc & " - " & GetMatType1
            MaterialPart2 = FindDesc

            If NutsNo = 0 Then
                FindDesc2 = Nothing
            Else
                FindDesc2 = ManwayInfo3134.AddMat & " - " & GetMatType2
            End If

            If GetPartNo <> Nothing Then
                GoTo NextItem
            End If

BoltNotFound2:

HexNutItems:
            GoTo NextItem
NylonNutItems:
            GoTo NextItem
MachineScrewItems:
            Dim HHMS As String
            FirstPart = Nothing
            SecondPart = Nothing
            NutSize = Nothing
            InchPos = InStr(GetDesc, SearchInch)
            Xpos = InStr(GetDesc, SearchX)
            PrevInchPos = 0
            PrevXPos = 0

            If InchPos > 0 Then
                While InchPos > 0
                    If PrevInchPos > 0 Then
                        FirstPart = Mid(GetDesc, 1, (InchPos + PrevInchPos))
                        SecondPart = Mid(GetDesc, (InchPos + PrevInchPos + 1), Len(GetDesc))
                        PrevInchPos = (PrevInchPos + (InchPos + 1))
                        InchPos = InStr(SecondPart, SearchInch)
                    Else
                        FirstPart = Mid(GetDesc, 1, (InchPos - 1))
                        SecondPart = Mid(GetDesc, (InchPos + 1), Len(GetDesc))
                        PrevInchPos = InchPos
                        InchPos = InStr(SecondPart, SearchInch)
                        SearchMBolt = "MACHINE SCREW "
                        MBoltPos = InStr(FirstPart, SearchMBolt)

                        If MBoltPos > 0 Then
                            NutSize = Mid(FirstPart, (MBoltPos + 13), Len(FirstPart))
                            NutSize = LTrim(NutSize)
                            NutSize = RTrim(NutSize)
                        End If
                    End If
                End While
            Else
                While Xpos > 0
                    If PrevXPos > 0 Then
                        WithPos = InStr(GetDesc, "w/ ")      '"w/ " 
                        FirstPart = Mid(GetDesc, 1, (WithPos - 1))
                        SecondPart = Mid(GetDesc, (Xpos + 3), Len(GetDesc))
                        PrevInchPos = (PrevXPos + (Xpos + 1))
                        Xpos = InStr(SecondPart, SearchX)
                    Else
                        FirstPart = Mid(GetDesc, 1, (Xpos - 1))
                        SecondPart = Mid(GetDesc, (Xpos + 3), Len(GetDesc))
                        PrevXPos = Xpos
                        Xpos = InStr(SecondPart, SearchX)

                        Select Case 0
                            Case Is < InStr(FirstPart, "MACHINE SCREW (FH)")
                                HHMS = "MACHINE SCREW (FH)"
                                NutSize = Mid(FirstPart, 19, Len(FirstPart))
                                NutSize = LTrim(NutSize)
                                NutSize = RTrim(NutSize)
                            Case Is < InStr(FirstPart, "MACHINE SCREW FLT HD")
                                HHMS = "MACHINE SCREW FLT HD"
                                NutSize = Mid(FirstPart, 20, Len(FirstPart))
                                NutSize = LTrim(NutSize)
                                NutSize = RTrim(NutSize)
                            Case Is < InStr(FirstPart, "MACHINE SCREW NUT")
                                HHMS = "MACHINE SCREW NUT"
                                NutSize = Mid(FirstPart, 17, Len(FirstPart))
                                NutSize = LTrim(NutSize)
                                NutSize = RTrim(NutSize)
                        End Select
                    End If
                End While
            End If

            If FirstPart = Nothing Then
                FirstPart = GetDesc
            Else
                If Mid(FirstPart, Len(FirstPart), 1) <> Chr(34) Then
                    FirstPart = FirstPart & Chr(34)
                End If
            End If

            NutsNo = SecondPart
            SearchWith = "w/ "
            WithPos = InStr(NutsNo, SearchWith)

            If WithPos > 0 Then
                NutsNo = Mid(SecondPart, (WithPos + 3), Len(NutsNo))
                SecondPart = Mid(SecondPart, 1, (WithPos - 1))
                SecondPart = LTrim(SecondPart)
                SecondPart = RTrim(SecondPart)
            End If

            If SecondPart <> Nothing And Xpos > 0 Then
                If Mid(SecondPart, Len(SecondPart), 1) <> Chr(34) Then
                    If InStr(SecondPart, "CARR #") > 0 Then
                        '-------Do Nothing is not bolt length
                    Else
                        SecondPart = SecondPart & Chr(34)
                    End If
                End If
            End If

            SearchX = " x "
            Xpos = InStr(NutSize, SearchX)

            If Xpos > 0 Then
                NutSize = Mid(NutSize, 1, Xpos)
                NutSize = LTrim(NutSize)
                NutSize = RTrim(NutSize)
            End If

            Select Case 0
                Case Is < InStr(NutsNo, "HH")
                    DescPos = InStr(NutsNo, "HH")
                    NutsNo = Mid(NutsNo, 1, (DescPos - 1))
                    NutsNo = LTrim(NutsNo)
                    NutsNo = RTrim(NutsNo)
                    AddMat = "HEX NUT " & NutSize & Chr(34)
                    FirstPart = "HHMB " & Mid(FirstPart, 16, Len(FirstPart))
                    FirstPart = LTrim(FirstPart)
                    FirstPart = RTrim(FirstPart)
                Case Is < InStr(NutsNo, "HEX NUT")
                    DescPos = InStr(NutsNo, "HEX NUT")
                    NutsNo = Mid(NutsNo, 1, (DescPos - 1))
                    NutsNo = LTrim(NutsNo)
                    NutsNo = RTrim(NutsNo)
                    AddMat = "HEX NUT " & NutSize & Chr(34)
                    FirstPart = "HHMB " & Mid(FirstPart, 14, Len(FirstPart))
                    FirstPart = LTrim(FirstPart)
                    FirstPart = RTrim(FirstPart)

                    If Mid(FirstPart, Len(FirstPart), 1) = Chr(34) Then
                        '               -------Do Nothing
                    Else
                        FirstPart = FirstPart & Chr(34)
                    End If

                    Dim FirstPart1, FirstPart2 As String
                    SearchX = " x "
                    Xpos = InStr(FirstPart, SearchX)

                    If Xpos > 0 Then
                        FirstPart1 = Mid(FirstPart, 1, (Xpos - 1))
                        FirstPart2 = Mid(FirstPart, Xpos, Len(FirstPart))

                        If Mid(FirstPart1, Len(FirstPart1), 1) = Chr(34) Then
                            '               -------Do Nothing
                        Else
                            FirstPart = FirstPart1 & Chr(34) & FirstPart2
                        End If
                    End If
                Case Is < InStr(NutsNo, "NYLON INSERT LOCK NUT")
                    NutsNo = 1
                    AddMat = "HEX LOCK NUT " & NutSize & Chr(34) & " W/ NYL. INS."
                    FirstPart = LTrim(FirstPart)
                    FirstPart = RTrim(FirstPart)
            End Select

            If SecondPart = Nothing Then
                MaterialPart2 = FirstPart
            Else
                If Xpos > 0 Then
                    MaterialPart2 = FirstPart & " x " & SecondPart
                Else
                    MaterialPart2 = FirstPart & SecondPart
                End If
            End If

            If InStr(MaterialPart2, "McMASTER CARR") > 0 Then
                FirstPart = "MCMASTER CARR "
                MaterialPart2 = Replace(MaterialPart2, "McMASTER CARR", "")
                MaterialPart2 = Replace(MaterialPart2, "McMASTER-CARR", "")
                MaterialPart2 = Replace(MaterialPart2, "McMASTER/CARR", "")
                MaterialPart2 = FirstPart & MaterialPart2
            End If

            If InStr(MaterialPart2, " - " & GetMatType) = 0 Then
                MaterialPart2 = MaterialPart2 & " - " & GetMatType
            End If

            If InStr(MaterialPart2, "(ITEM #") > 0 Then
                MaterialPart2 = Replace(MaterialPart2, "(ITEM #", "#")
                MaterialPart2 = Replace(MaterialPart2, ")", "")
            End If

            ManwayInfo3134.OldDesc = MaterialPart2
            ManwayInfo3134.GetDesc = GetDesc
            ManwayInfo3134.AddMat = AddMat
            ManwayInfo3134.AddMatSize = NutSize
            ManwayInfo3134.AddMatQty = NutsNo
            MaterialPart2 = Replace(MaterialPart2, "   ", " ")
            MaterialPart2 = Replace(MaterialPart2, "  ", " ")

MachSrcewNotFound:

FoundMachScrew:
            If InStr(MaterialPart2, GetMatType) > 0 Then
                MatPos = InStr(MaterialPart2, " - " & GetMatType)
                MaterialPart2 = Mid(MaterialPart2, 1, (MatPos - 1))
            End If

            If Xpos > 0 Then
                FeetInchesToDecInches(SecondPart, GetDwgNo, ItemNum, ErrFound, FullJobNo)
            End If

            ErrFound = ErrorFoundNew

            If ErrFound = "Yes" Then
                MaterialNew = InputBox("Something is wrong with this description please retype " & Material)
                BOMList(7, j) = MaterialNew                         'myarray(7, i) = MaterialNew
                ReDim Preserve BOMList(20, UBound(BOMList, 2))

                GoTo StartOver
            End If

            BOMList(19, j) = GetQty                             'myarray(13, i) = GetQty
            BOMList(6, j) = "PURCHASE ITEM"                         'myarray(14, j) = "PURCHASE"
            ReDim Preserve BOMList(20, UBound(BOMList, 2))
            ItemFound = "Yes"
            AddItem2 = "Done"
            GoTo NextItem

FlatPlateItems:
            FoundPl = False
            LenDesc = Len(GetDesc)
            FoundRolled = 0                         '-------New request add 30" to all material ROLLED
            AddRolled = 0
            FoundRolled = InStr(1, GetDesc, SearchRolled)          'FoundRolled = InStr(1, Material, SearchRolled)
            FoundColdRolled = InStr(1, GetDesc, "COLD ROLLED")     'FoundColdRolled = InStr(1, Material, "COLD ROLLED")

            If FoundRolled > 0 And FoundColdRolled = 0 Then
                AddRolled = 30
            End If

            PlPos = InStr(GetDesc, " PL ")                         'PlPos = InStr(Material, " PL ")

            If PlPos > 0 Then
                FoundPl = True
                ShellPlateInfo = Mid(GetDesc, 1, (PlPos - 1))          'ShellPlateInfo = Mid(Material, 1, (PlPos - 1))
                GetDesc = Mid(GetDesc, (PlPos + 1), Len(GetDesc))    'Material = Mid(Material, (PlPos + 1), Len(Material))
            End If

            NotePos = InStr(GetDesc, "NOTE")                       'NotePos = InStr(Material, "NOTE")

            If NotePos > 0 Then
                FoundNotes = True
                NoteInfo = Mid(GetDesc, NotePos, Len(GetDesc))        'NoteInfo = Mid(Material, NotePos, Len(Material))
                GetDesc = Mid(GetDesc, 1, (NotePos - 1))              'Material = Mid(Material, 1, (NotePos - 1))

                NotePos = InStr(GetDesc, " - ")                       ' - NOTEA    remove " - " at end now.
                Test = Len(GetDesc)

                If NotePos = (Len(GetDesc) - 2) Then
                    GetDesc = Mid(GetDesc, 1, (NotePos - 1))              'Material = Mid(Material, 1, (NotePos - 1))
                End If
            End If

            GetDesc = RTrim(GetDesc)              'Material = RTrim(Material)

            FoundX = InStr(1, GetDesc, SearchX)    'FoundX = InStr(1, Material, SearchX)
            MaterialPart = GetDesc                 'MaterialPart = Material

            While FoundX > 0 Or FoundX2 > 0
                If FoundX > 0 Then
                    LenMatPart = Len(MaterialPart)                                  'LenMatPart = Len(MaterialPart)
                    MaterialPart = Mid(MaterialPart, (FoundX + 3), LenMatPart)      'MaterialPart = Mid(MaterialPart, (FoundX + 3), LenMatPart)
                    'PartFoundX = FoundX
                    FoundX = InStr(1, MaterialPart, SearchX)                        'FoundX = InStr(1, MaterialPart, SearchX)
                Else
                    LenMatPart = Len(MaterialPart)                                  'LenMatPart = Len(MaterialPart)
                    MaterialPart = Mid(MaterialPart, (FoundX2 + 2), LenMatPart)     'MaterialPart = Mid(MaterialPart, (FoundX2 + 2), LenMatPart)
                    PartFoundX = FoundX2
                    FoundX2 = InStr(1, MaterialPart, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                End If

                If FoundX = 0 Then
                    FoundX2 = InStr(1, MaterialPart, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                End If
            End While

            LenMatPart = Len(MaterialPart)                                          'LenMatPart = Len(MaterialPart)
            MaterialPart = LTrim(MaterialPart)                                      'MaterialPart = LTrim(MaterialPart)
            MaterialPart = RTrim(MaterialPart)                                      'MaterialPart = RTrim(MaterialPart)

            If LenDesc = LenMatPart Then
                MaterialPart2 = Material                                            'MaterialPart2 = Material
            Else
                If PartFoundX > 0 Then
                    MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 2)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 2)))
                    PartFoundX = 0
                Else
                    MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 3)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 3)))
                End If
            End If

            FoundX = InStr(1, MaterialPart2, SearchX)

            While FoundX > 0
                MaterialPart2 = Mid(MaterialPart2, 1, (FoundX - 1))
                FoundX = InStr(1, MaterialPart2, SearchX)
            End While

            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)
            Search = "PL "
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 4, (Len(MaterialPart2) - 3))
                MaterialPart2 = "PL" & MaterialPart2
            End If

            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)

            If InStr(MaterialPart2, GetMatType) = 0 Then
                MaterialPart2 = MaterialPart2 & " - " & GetMatType
            End If

            LenPlateNotes = Len(GetDesc)
            PlateNotes = GetDesc
            SearchNote = "NOTE"
            FoundNote = InStr(1, PlateNotes, SearchNote)

            If FoundNote > 0 Then
                LenPlateNotes = Len(PlateNotes)
                PlateNotes = Mid(PlateNotes, FoundNote, (LenPlateNotes - (FoundNote - 1)))
                PlateNotes = LTrim(PlateNotes)
                PlateNotes = RTrim(PlateNotes)
            Else
                PlateNotes = ""
            End If

            BOMList(12, j) = MaterialPart2
            BOMList(19, j) = PlateNotes                                 'myarray(13, i) = PlateNotes
            BOMList(6, j) = "PLATE STEEL"                             ''myarray(14, i) = "PLATE STEEL"
            ReDim Preserve BOMList(20, UBound(BOMList, 2))

            ItemFound = "Yes"
            AddItem2 = "Done"
            GoTo NextItem
ChannelItems:
            LenDesc = Len(GetDesc)
            FoundRolled = 0                     '-------New request add 30" to all material ROLLED
            AddRolled = 0
            FoundRolled = InStr(1, GetDesc, SearchRolled)              'FoundRolled = InStr(1, Material, SearchRolled)
            FoundColdRolled = InStr(1, GetDesc, "COLD ROLLED")         'FoundColdRolled = InStr(1, Material, "COLD ROLLED")

            If FoundRolled > 0 And FoundColdRolled = 0 Then
                AddRolled = 30
            End If

            FoundX = InStr(1, GetDesc, SearchX)            'FoundX = InStr(1, Material, SearchX)

            While FoundX > 0 Or FoundX2 > 0
                If FoundX > 0 Then
                    LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                    GetDesc = Mid(GetDesc, (FoundX + 3), LenDesc)      'MaterialPart = Mid(MaterialPart, (FoundX + 3), LenMatPart)
                    FoundX = InStr(1, GetDesc, SearchX)                        'FoundX = InStr(1, MaterialPart, SearchX)
                Else
                    LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                    GetDesc = Mid(GetDesc, (FoundX2 + 2), LenDesc)     'MaterialPart = Mid(MaterialPart, (FoundX2 + 2), LenMatPart)
                    PartFoundX = FoundX2
                    FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                End If

                If FoundX = 0 Then
                    FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                End If
            End While

            LenMatPart = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
            GetDesc = LTrim(GetDesc)                          'MaterialPart = LTrim(MaterialPart)
            GetDesc = RTrim(GetDesc)                          'MaterialPart = RTrim(MaterialPart)

            If PartFoundX > 0 Then
                MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 2)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 2)))
                PartFoundX = 0
            Else
                MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 3)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 3)))
            End If

            Search = "C "
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 3, (Len(MaterialPart2) - 2))
                MaterialPart2 = "C" & MaterialPart2
            End If

            Search = "MC "
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 4, (Len(MaterialPart2) - 3))
                MaterialPart2 = "MC" & MaterialPart2
            End If

            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)

            If InStr(MaterialPart2, GetMatType) = 0 Then
                MaterialPart2 = MaterialPart2 & " - " & GetMatType
            End If

            If Len(MaterialPart2) > 0 Then
                BOMList(12, j) = MaterialPart2                          '? Yes          'myarray(12, i) = MaterialPart2
                ReDim Preserve BOMList(20, UBound(BOMList, 2))
            End If

            Search = "C "
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 0 And InStr(MaterialPart2, "MC") = 0 Then
                MaterialPart2 = Mid(MaterialPart2, 2, Len(MaterialPart2))
                MaterialPart2 = "C " & MaterialPart2
            End If

            Search = "MC"
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 3, Len(MaterialPart2))
                MaterialPart2 = "MC " & MaterialPart2
            End If

            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)

ChannelNotFound:

FoundChannel:
            If InStr(MaterialPart, GetMatType) > 0 Then
                MatPos = InStr(MaterialPart, " - " & GetMatType)
                MaterialPart = Mid(MaterialPart, 1, (MatPos - 1))
            End If

            FeetInchesToDecInches(MaterialPart, GetDwgNo, ItemNum, ErrFound, FullJobNo)
            ErrFound = ErrorFoundNew

            If ErrFound = "Yes" Then
                MaterialNew = InputBox("Something is wrong with this description please retype " & Material)
                BOMList(7, j) = MaterialNew                         'myarray(7, i) = MaterialNew
                ReDim Preserve BOMList(20, UBound(BOMList, 2))

                GoTo StartOver
            End If

            BOMList(19, j) = (MatInch + AddRolled)                              'myarray(13, i) = (MatInch + AddRolled)
            BOMList(6, j) = "CHANNEL"                                         ''myarray(14, i) = "CHANNEL"
            ReDim Preserve BOMList(20, UBound(BOMList, 2))

            ItemFound = "Yes"
            AddItem2 = "Done"
            GoTo NextItem

SqBarItem:
            SB = InStr(Left(GetDesc, 2), "SB")

            If SB > 0 Then
                LenDesc = Len(GetDesc)
                FoundRolled = 0                         '-------New request add 30" to all material ROLLED
                AddRolled = 0
                FoundRolled = InStr(1, GetDesc, SearchRolled)              'FoundRolled = InStr(1, Material, SearchRolled)
                FoundColdRolled = InStr(1, GetDesc, "COLD ROLLED")         'FoundColdRolled = InStr(1, Material, "COLD ROLLED")

                If FoundRolled > 0 And FoundColdRolled = 0 Then
                    AddRolled = 30
                End If

                FoundX = InStr(1, GetDesc, SearchX)            'FoundX = InStr(1, Material, SearchX)

                While FoundX > 0 Or FoundX2 > 0
                    If FoundX > 0 Then
                        LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                        GetDesc = Mid(GetDesc, (FoundX + 3), LenDesc)      'MaterialPart = Mid(MaterialPart, (FoundX + 3), LenMatPart)
                        FoundX = InStr(1, GetDesc, SearchX)                        'FoundX = InStr(1, MaterialPart, SearchX)
                    Else
                        LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                        GetDesc = Mid(GetDesc, (FoundX2 + 2), LenDesc)     'MaterialPart = Mid(MaterialPart, (FoundX2 + 2), LenMatPart)
                        PartFoundX = FoundX2
                        FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                    End If

                    If FoundX = 0 Then
                        FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                    End If
                End While

                LenMatPart = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                GetDesc = LTrim(GetDesc)                          'MaterialPart = LTrim(MaterialPart)
                GetDesc = RTrim(GetDesc)                          'MaterialPart = RTrim(MaterialPart)

                If PartFoundX > 0 Then
                    MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenDesc + 2)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 2)))
                    PartFoundX = 0
                Else
                    MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenDesc + 3)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 3)))
                End If

                MaterialPart2 = LTrim(MaterialPart2)
                MaterialPart2 = RTrim(MaterialPart2)

                Search = "SB "
                SearchFound = InStr(1, MaterialPart2, Search)

                If SearchFound = 1 Then
                    MaterialPart2 = Mid(MaterialPart2, 4, (Len(MaterialPart2) - 3))
                    MaterialPart2 = "SB" & MaterialPart2
                End If

                MaterialPart2 = LTrim(MaterialPart2)
                MaterialPart2 = RTrim(MaterialPart2)

                If InStr(MaterialPart2, GetMatType) = 0 Then
                    If Len(MaterialPart2) > 0 Then
                        BOMList(12, j) = MaterialPart2 & " - " & GetMatType                 'myarray(12, i) = MaterialPart2 & " - " & GetMatType
                        ReDim Preserve BOMList(20, UBound(BOMList, 2))
                    End If
                Else
                    BOMList(12, j) = MaterialPart2                          '? Yes          'myarray(12, i) = MaterialPart2
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                End If

                If InStr(MaterialPart2, GetMatType) = 0 Then
                    MaterialPart2 = MaterialPart2 & " - " & GetMatType
                End If

                Search = "SB "
                SearchFound = InStr(1, MaterialPart2, Search)

                If SearchFound = 0 Then
                    MaterialPart2 = Mid(MaterialPart2, 3, Len(MaterialPart2))
                    MaterialPart2 = "SB " & MaterialPart2
                End If

                MaterialPart2 = LTrim(MaterialPart2)
                MaterialPart2 = RTrim(MaterialPart2)
                MaterialPart2 = Replace(MaterialPart2, "   ", " ")
                MaterialPart2 = Replace(MaterialPart2, "   ", " ")

SBNotFound:

FoundSB:
                If InStr(MaterialPart, GetMatType) > 0 Then
                    MatPos = InStr(MaterialPart, " - " & GetMatType)
                    MaterialPart = Mid(MaterialPart, 1, (MatPos - 1))
                End If

                FeetInchesToDecInches(MaterialPart, GetDwgNo, ItemNum, ErrFound, FullJobNo)
                ErrFound = ErrorFoundNew

                If ErrFound = "Yes" Then
                    MaterialNew = InputBox("Something is wrong with this description please retype " & Material)
                    BOMList(7, j) = MaterialNew                         'myarray(7, i) = MaterialNew
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))

                    GoTo StartOver
                End If

                BOMList(19, j) = (MatInch + AddRolled)                              'myarray(13, i) = (MatInch + AddRolled)
                BOMList(6, j) = "SQUARE BAR"                                      ''myarray(14, i) = "SQUARE BAR"
                ReDim Preserve BOMList(20, UBound(BOMList, 2))

                ItemFound = "Yes"
                AddItem2 = "Done"
                GoTo NextItem
            Else
                GoTo PurchaseItem
            End If
BeamItem:
            LenDesc = Len(GetDesc)                            'LenDesc = Len(myarray(7, i))
            LenPipeSize = InStr(1, GetDesc, " ")              'LenPipeSize = InStr(1, myarray(7, i), " ")
            PipeSize = Mid(GetDesc, 1, 7)                     'PipeSize = Mid(myarray(7, i), 1, 7)
            BOMList(6, j) = PipeSize                          ''myarray(14, i) = PipeSize
            ReDim Preserve BOMList(20, UBound(BOMList, 2))

            LenPart = Len(GetDesc)                            'LenPart = Len(myarray(7, i))
            PipeLen = Mid(GetDesc, (7 + 1), LenPart)          'PipeLen = Mid(myarray(7, i), (7 + 1), LenPart)
            FoundX = InStr(1, PipeLen, SearchX)

            While FoundX > 0
                PipeLen = Mid(PipeLen, (FoundX + 3), LenPart)
                FoundX = InStr(1, PipeLen, SearchX)
            End While

            FoundInch = InStr(1, PipeLen, SearchInch)
            LenMatPart = Len(PipeLen)
            MaterialPart = Mid(BOMList(7, j), 1, LenPart)       'MaterialPart = Mid(myarray(7, i), 1, LenPart)
            GetDesc = LTrim(GetDesc)                          'MaterialPart = LTrim(MaterialPart)
            GetDesc = RTrim(GetDesc)                          'MaterialPart = RTrim(MaterialPart)
            FoundRolled = 0 '----------------------------------------New request add 30" to all material ROLLED
            AddRolled = 0
            FoundRolled = InStr(1, GetDesc, SearchRolled)              'FoundRolled = InStr(1, Material, SearchRolled)
            FoundColdRolled = InStr(1, GetDesc, "COLD ROLLED")         'FoundColdRolled = InStr(1, Material, "COLD ROLLED")

            If FoundRolled > 0 And FoundColdRolled = 0 Then
                AddRolled = 30
            End If

            LenDesc = Len(MaterialPart)
            MaterialPart2 = Mid(MaterialPart, 1, (LenDesc - (LenMatPart + 1)))
            Search = "W "
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 3, Len(MaterialPart2))
                MaterialPart2 = "W" & MaterialPart2
            End If

            Search = "S "
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 3, Len(MaterialPart2))
                MaterialPart2 = "S" & MaterialPart2
            End If

            Search = "M "
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 3, Len(MaterialPart2))
                MaterialPart2 = "M" & MaterialPart2
            End If

            Search = Mid(MaterialPart2, Len(MaterialPart2), 1)

            Select Case Search
                Case "x"
                    MaterialPart2 = Mid(MaterialPart2, 1, (Len(MaterialPart2) - 1))
                Case "X"
                    MaterialPart2 = Mid(MaterialPart2, 1, (Len(MaterialPart2) - 1))
            End Select

            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)

            If InStr(MaterialPart, GetMatType) = 0 Then
                BOMList(7, j) = (MaterialPart2 & " - " & GetMatType)           'myarray(12, i) = (MaterialPart2 & " - " & GetMatType)
            End If

            If InStr(MaterialPart, GetMatType) = 0 Then
                MaterialPart2 = (MaterialPart2 & " - " & GetMatType)
            End If

            Search = "W"
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 2, Len(MaterialPart2))
                MaterialPart2 = "W " & MaterialPart2
            End If

            Search = "S"
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then
                MaterialPart2 = Mid(MaterialPart2, 2, Len(MaterialPart2))
                MaterialPart2 = "S " & MaterialPart2
            End If

            Search = "M"
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound = 1 Then                       'Look at possible Machine Bolts
                MaterialPart2 = Mid(MaterialPart2, 2, Len(MaterialPart2))
                MaterialPart2 = "M " & MaterialPart2
            End If

            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)

IBeamNotFound:

FoundBeam:
            If InStr(MaterialPart, GetMatType) > 0 Then
                MatPos = InStr(MaterialPart, "-" & GetMatType)
                MaterialPart = Mid(MaterialPart, 1, (MatPos - 1))
            End If

            FeetInchesToDecInches(MaterialPart, GetDwgNo, ItemNum, ErrFound, FullJobNo)
            ErrFound = ErrorFoundNew

            If ErrFound = "Yes" Then
                MaterialNew = InputBox("Something is wrong with this description please retype " & Material)
                BOMList(7, j) = MaterialNew                         'myarray(7, i) = MaterialNew
                ReDim Preserve BOMList(20, UBound(BOMList, 2))

                GoTo StartOver
            End If

            BOMList(19, j) = (MatInch + AddRolled)                              'myarray(13, i) = (MatInch + AddRolled)
            BOMList(6, j) = "IBEAM"                                               'myarray(14, i) = "IBEAM"
            ReDim Preserve BOMList(20, UBound(BOMList, 2))
            ItemFound = "Yes"
            AddItem2 = "Done"
            GoTo NextItem
PipeItem:
            Material = GetDesc
            'Search = "PIPE NIPPLE"
            'SearchPos = InStr(GetDesc, Search)

            If InStr(GetDesc, "PIPE NIPPLE") > 0 Or InStr(GetDesc, "PIPE CAP") > 0 Then
                GoTo PurchaseItem
            Else
                If InStr(GetDesc, "PIPE SUPPORT") > 0 Or InStr(GetDesc, "PIPE HOSE CLAMP") > 0 Then
                    GoTo PurchaseItem
                Else
                    If InStr(GetDesc, "PIPE NU_BOLT") > 0 Or InStr(GetDesc, "PIPE HANGER") > 0 Then
                        GoTo PurchaseItem
                    Else
                        If InStr(GetDesc, "PIPE UNION") > 0 Then 'Or InStr(GetDesc, "PIPE CAP") > 0 Then
                            GoTo PurchaseItem
                        End If
                    End If
                End If
            End If

            'Search = "PIPE CAP"
            'SearchPos = InStr(GetDesc, Search)

            'If SearchPos > 0 Then
            '    GoTo PurchaseItem
            'End If

            'Search = "PIPE SUPPORT"
            'SearchPos = InStr(GetDesc, Search)

            'If SearchPos > 0 Then
            '    GoTo PurchaseItem
            'End If

            If PipeTest <> Nothing Then
                LenDesc = Len(PipeTest)
                Material = PipeTest
                BOMList(7, j) = PipeTest                            'myarray(7, i) = PipeTest
            Else
                LenDesc = Len(GetDesc)                        ' LenDesc = Len(myarray(7, i))
                Material = BOMList(7, j)                        'Material = myarray(7, i)
            End If

            FoundRolled = 0 '----------------------------------------New request add 30" to all material ROLLED
            AddRolled = 0
            FoundRolled = InStr(1, GetDesc, SearchRolled)              'FoundRolled = InStr(1, Material, SearchRolled)
            FoundColdRolled = InStr(1, GetDesc, "COLD ROLLED")         'FoundColdRolled = InStr(1, Material, "COLD ROLLED")

            If FoundRolled > 0 And FoundColdRolled = 0 Then
                AddRolled = 30
            End If

            FoundX = InStr(1, Material, SearchX)
            MaterialPart = Material

            While FoundX > 0 Or FoundX2 > 0
                If FoundX > 0 Then
                    LenMatPart = Len(MaterialPart)
                    MaterialPart = Mid(MaterialPart, (FoundX + 3), LenMatPart)
                    FoundX = InStr(1, MaterialPart, SearchX)
                Else
                    LenMatPart = Len(MaterialPart)                                  '
                    MaterialPart = Mid(MaterialPart, (FoundX2 + 2), LenMatPart)     '
                    PartFoundX = FoundX2
                    FoundX2 = InStr(1, MaterialPart, SearchX2)                      '
                End If

                If FoundX = 0 Then
                    FoundX2 = InStr(1, MaterialPart, SearchX2)                      '
                End If
            End While

            LenMatPart = Len(MaterialPart)                                  '
            MaterialPart = LTrim(MaterialPart)                          '
            MaterialPart = RTrim(MaterialPart)                         '

            If PartFoundX > 0 Then
                MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 2)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 2)))
                PartFoundX = 0
            Else
                If LenDesc < (LenMatPart + 3) Then
                    MaterialPart2 = Material
                Else
                    MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 3)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 3)))
                End If
            End If

            If PurchaseProb = True Then
                GoTo PurchaseItem
            End If

            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)

            If InStr(MaterialPart2, GetMatType) = 0 Then
                If Len(MaterialPart2) > 0 Then
                    BOMList(12, j) = MaterialPart2 & " - " & GetMatType                 'myarray(12, i) = MaterialPart2 & " - " & GetMatType
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                End If
            Else
                If Len(MaterialPart2) > 0 Then
                    BOMList(12, j) = MaterialPart2                          '? Yes          'myarray(12, i) = MaterialPart2
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                End If
            End If

            Search = " STD WT"
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound > 0 Then
                MaterialPart1 = Mid(MaterialPart2, 1, (SearchFound - 1))

                If Len(MaterialPart2) > (SearchFound + 7) Then
                    MaterialPart2 = Mid(MaterialPart2, (SearchFound + 7), Len(MaterialPart2))
                    MaterialPart2 = MaterialPart1 & " STD WT" & MaterialPart2
                Else
                    MaterialPart2 = MaterialPart1 & " STD WT"
                End If
            End If

            Search = "XS"
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound > 0 Then
                MaterialPart1 = Mid(MaterialPart2, 1, (SearchFound - 1))

                If Len(MaterialPart2) > (SearchFound + 1) Then
                    MaterialPart2 = Mid(MaterialPart2, (SearchFound + 1), Len(MaterialPart2))
                    MaterialPart2 = MaterialPart1 & "XH" & MaterialPart2
                Else
                    MaterialPart2 = MaterialPart1 & "XH"
                End If
            End If

            Search = "SCH 80"
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound > 0 Then
                MaterialPart1 = Mid(MaterialPart2, 1, (SearchFound - 1))

                If Len(MaterialPart2) > (SearchFound + 6) Then
                    MaterialPart2 = Mid(MaterialPart2, (SearchFound + 1), Len(MaterialPart2))
                    MaterialPart2 = MaterialPart1 & "XH" & MaterialPart2
                Else
                    MaterialPart2 = MaterialPart1 & "XH"
                End If
            End If

            Search = "SCH 40"
            SearchFound = InStr(1, MaterialPart2, Search)

            If SearchFound > 0 Then
                MaterialPart1 = Mid(MaterialPart2, 1, (SearchFound - 1))

                If Len(MaterialPart2) > (SearchFound + 6) Then
                    MaterialPart2 = Mid(MaterialPart2, (SearchFound + 6), Len(MaterialPart2))
                    MaterialPart2 = MaterialPart1 & "STD WT" & MaterialPart2
                Else
                    MaterialPart2 = MaterialPart1 & "STD WT"
                End If
            End If

            If InStr(MaterialPart2, GetMatType) = 0 Then
                MaterialPart2 = MaterialPart2 & " - " & GetMatType
            End If

            MaterialPart2 = Replace(MaterialPart2, "   ", " ")
            MaterialPart2 = Replace(MaterialPart2, "  ", " ")

FoundPipe:
            If InStr(MaterialPart, GetMatType) > 0 And GetMatType <> "" Then
                MatPos = InStr(MaterialPart, " - " & GetMatType)
                MaterialPart = Mid(MaterialPart, 1, (MatPos - 1))
            End If

            'ManwayInfo3134.MWElev = BOMList(15, 1)                          'ManwayInfo3134.MWElev = myarray(15, 1)
            MaterialPart = Replace(MaterialPart, "O" & Chr(39), "0" & Chr(39))
            MatInch = FToD(MaterialPart)

            'If InStr(MaterialPart, "HOSE CLAMP") = 0 And InStr(MaterialPart, "ASSEMBLY") = 0 Then
            '    If InStr(MaterialPart, "PIPE SUPPORT") = 0 And InStr(MaterialPart, "PIPE NU-BOLT") = 0 Then
            '        If InStr(MaterialPart, "PIPE HANGER SUPPORT") = 0 And InStr(MaterialPart, "PIPE UNION") = 0 Then
            '            FeetInchesToDecInches(MaterialPart, GetDwgNo, ItemNum, ErrFound, FullJobNo)
            '        End If
            '    End If
            'End If
            'ErrFound = ErrorFoundNew

            'If ErrFound = "Yes" Then
            '    MaterialNew = InputBox("Something is wrong with this description please retype " & Material)
            '    BOMList(7, j) = MaterialNew                         'myarray(7, i) = MaterialNew
            '    ReDim Preserve BOMList(20, UBound(BOMList, 2))

            '    GoTo StartOver
            'End If

            BOMList(19, j) = (MatInch + AddRolled)                              'myarray(13, i) = (MatInch + AddRolled)
            BOMList(6, j) = "PIPE"                                            ''myarray(14, i) = "PIPE"
            ReDim Preserve BOMList(20, UBound(BOMList, 2))

            ItemFound = "Yes"
            AddItem2 = "Done"
            GoTo NextItem

GratingItem:
            TreadSqFt = 0
            TreadLen = 0
            TreadWid = 0
            LenDesc = Len(GetDesc)

            If InStr(GetDesc, "(DWG") Then
                GoTo NextItem
            End If

            FoundRolled = 0                         '-------New request add 30" to all material ROLLED
            AddRolled = 0
            FoundRolled = InStr(1, GetDesc, SearchRolled)              'FoundRolled = InStr(1, Material, SearchRolled)
            FoundColdRolled = InStr(1, GetDesc, "COLD ROLLED")         'FoundColdRolled = InStr(1, Material, "COLD ROLLED")

            If FoundRolled > 0 And FoundColdRolled = 0 Then
                AddRolled = 30
            End If
GratingNotFound2:   '--------------------------------Fix Description to Read TREAD 10 15/16 x 3-0"/GRATING3/16" x
            Select Case 0
                Case Is < InStr(GetDesc, "TREAD/GRTG/S 3/16 x 1 x ")
                    GetDesc1 = Mid(GetDesc, 25, Len(GetDesc))
                    GetDesc = GetDesc1
                    GetGratingInfo = "/GRATING 3/16" & Chr(34) & " x 1"
                Case Is < InStr(GetDesc, "GRATING/S 3/16 x 1 x ")
                    GetDesc1 = Mid(GetDesc, 22, Len(GetDesc))
                    GetDesc = GetDesc1
                    GetGratingInfo = "3/16" & Chr(34) & " x 1" & Chr(34) & " x"
            End Select

            Select Case 0
                Case Is < InStr(GetDesc, "2'-5 5/8")
                    TreadLen = "2'-6" & Chr(34)
                    TreadWidPos = InStr(GetDesc, "2'-5 5/8")
                    GetDesc1 = Mid(GetDesc, 1, (TreadWidPos - 1))

                    If InStr(GetDesc1, SearchX) > 0 Then
                        Xpos = InStr(GetDesc1, SearchX)
                        If (Xpos + 2) = Len(GetDesc1) Then
                            TreadWid = Mid(GetDesc1, 1, (Xpos - 1))
                        End If
                    End If

                    GetDesc2 = Mid(GetDesc, (TreadWidPos + 9), Len(GetDesc))
                    GetDesc = "TREAD " & TreadWid & " x " & TreadLen & GetGratingInfo & " " & GetDesc2
                    TreadWidDbl = FToD(TreadWid)
                    TreadLenDbl = FToD(TreadLen)

                    Select Case 0
                        Case TreadLenDbl
                            TreadSqFt = TreadWidDbl
                        Case Else
                            TreadSqFt = (TreadWidDbl * TreadLenDbl)
                    End Select

                Case Is < InStr(GetDesc, SearchX)
                    Select Case 0
                        Case Is < InStr(GetDesc, "GRATING SERRATED 3/16" & Chr(34) & " x 1" & Chr(34) & " x 36" & Chr(34) & " x")
                            GetDesc = ("GRATING SERRATED 3/16" & Chr(34) & " x 1" & Chr(34) & " x 36" & Chr(34) & " x")
                            If InStr(GetMatType, Chr(10)) > 0 Then
                                SearchPos = InStr(GetMatType, Chr(10))
                                GetMatType = Mid(GetMatType, (SearchPos + 1), Len(GetMatType))
                            End If

                            If InStr(GetDesc, " - " & GetMatType) > 0 Then
                                SearchPos = InStr(GetDesc, " - " & GetMatType)
                                GetDesc = Mid(GetDesc, 1, (SearchPos - 1))
                            End If

                            GoTo GratingIsCorrect
                        Case Is < InStr(GetDesc, "GRATING SERRATED 3/16" & Chr(34) & " x 1" & " x 36" & Chr(34) & " x")
                            GetDesc = ("GRATING SERRATED 3/16" & Chr(34) & " x 1" & Chr(34) & " x 36" & Chr(34) & " x")
                            If InStr(GetMatType, Chr(10)) > 0 Then
                                SearchPos = InStr(GetMatType, Chr(10))
                                GetMatType = Mid(GetMatType, (SearchPos + 1), Len(GetMatType))
                            End If

                            If InStr(GetDesc, " - " & GetMatType) > 0 Then
                                SearchPos = InStr(GetDesc, " - " & GetMatType)
                                GetDesc = Mid(GetDesc, 1, (SearchPos - 1))
                            End If
                            GoTo GratingIsCorrect
                    End Select

                    Xpos = InStr(GetDesc, SearchX)
                    TreadLen = Mid(GetDesc, (Xpos + 3), Len(GetDesc))
                    TreadWid = Mid(GetDesc, 1, (Xpos - 1))
                    TreadWidDbl = FToD(TreadWid)

                    If TreadWidDbl <= 36 Then
                        GetDesc = "GRATING SERRATED " & GetGratingInfo & " 36" & Chr(34) & " x"
                    Else
                        Stop
                        GetDesc = "GRATING SERRATED " & GetGratingInfo & "36" & Chr(34) & " x"
                    End If

                    TreadLenDbl = FToD(TreadLen)

                    Select Case 0
                        Case TreadLenDbl
                            TreadSqFt = TreadWidDbl
                        Case Else
                            TreadSqFt = (TreadWidDbl * TreadLenDbl)
                    End Select
            End Select

            If InStr(MaterialPart2, GetMatType) = 0 Then
                MaterialPart2 = GetDesc & " - " & GetMatType
            End If

            If GetInvNo = Nothing Then
                If TestGetSc <> Nothing Then
                    GetSc = TestGetSc
                Else
                    GetSc = Nothing
                End If
            Else
                GetSc = GetInvNo & GetStdDwg
            End If

GratingIsCorrect:
            If GetDesc <> MaterialPart2 Then
                MaterialPart2 = GetDesc
            End If

FoundGrating:
            BOMList(19, j) = TreadSqFt                            'myarray(13, i) = TreadSqFt
            BOMList(6, j) = "GRATING"                             ''myarray(14, i) = "GRATING"
            ReDim Preserve BOMList(20, UBound(BOMList, 2))

            ItemFound = "Yes"
            AddItem2 = "Done"
            GoTo NextItem
GripStrut:
            Dim FabPart1, FabPart2, FabPart3 As String
            LenDesc = Len(GetDesc)                            'LenDesc = Len(myarray(7, i))
            MatInch = 0
            FabPart1 = Nothing
            FabPart2 = Nothing
            FabPart3 = Nothing
            FoundRolled = 0
            AddRolled = 0
            FoundRolled = InStr(1, GetDesc, SearchRolled)              'FoundRolled = InStr(1, Material, SearchRolled)
            FoundColdRolled = InStr(1, GetDesc, "COLD ROLLED")         'FoundColdRolled = InStr(1, Material, "COLD ROLLED")

            If FoundRolled > 0 And FoundColdRolled = 0 Then
                AddRolled = 30
            End If

            FoundX = InStr(1, GetDesc, SearchX)            'FoundX = InStr(1, Material, SearchX)

            While FoundX > 0 Or FoundX2 > 0
                If FoundX > 0 Then
                    LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                    GetDesc = Mid(GetDesc, (FoundX + 3), LenDesc)      'MaterialPart = Mid(MaterialPart, (FoundX + 3), LenMatPart)
                    FoundX = InStr(1, GetDesc, SearchX)                        'FoundX = InStr(1, MaterialPart, SearchX)
                Else
                    LenDesc = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
                    GetDesc = Mid(GetDesc, (FoundX2 + 2), LenDesc)     'MaterialPart = Mid(MaterialPart, (FoundX2 + 2), LenMatPart)
                    PartFoundX = FoundX2
                    FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                End If

                If FoundX = 0 Then
                    FoundX2 = InStr(1, GetDesc, SearchX2)                      'FoundX2 = InStr(1, MaterialPart, SearchX2)
                End If
            End While

            LenMatPart = Len(GetDesc)                                  'LenMatPart = Len(MaterialPart)
            GetDesc = LTrim(GetDesc)                          'MaterialPart = LTrim(MaterialPart)
            GetDesc = RTrim(GetDesc)                          'MaterialPart = RTrim(MaterialPart)

            If PartFoundX > 0 Then
                MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 2)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 2)))
                PartFoundX = 0
            Else
                If InStr(Material, "(T-") > 0 Then
                    MaterialPart2 = Material
                Else
                    MaterialPart2 = Mid(GetDesc, 1, (LenDesc - (LenMatPart + 3)))      'MaterialPart2 = Mid(Material, 1, (LenMaterial - (LenMatPart + 3)))
                End If
            End If

            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)

            If Len(MaterialPart2) > 0 Then
                BOMList(12, j) = MaterialPart2                          '? Yes          'myarray(12, i) = MaterialPart2
                ReDim Preserve BOMList(20, UBound(BOMList, 2))
            End If

            If InStr(MaterialPart2, "GRIP STRUT 10 GA") > 0 Then
                FabPart1 = "GRIP STRUT 10GA"
            Else
                If InStr(MaterialPart2, "GRIP STRUT 10GA") > 0 Then
                    FabPart1 = "GRIP STRUT 10GA"
                End If
            End If

            If InStr(MaterialPart2, "GRIP STRUT 12 GA") > 0 Then
                FabPart1 = "GRIP STRUT 12GA"
            Else
                If InStr(MaterialPart2, "GRIP STRUT 12GA") > 0 Then
                    FabPart1 = "GRIP STRUT 12GA"
                End If
            End If

            If InStr(MaterialPart2, "x 1 1\2") > 0 Then
                FabPart2 = "x 1 1\2"
                SearchPos = InStr(MaterialPart2, "x 1 1\2")
                FabPart3 = Mid(MaterialPart2, SearchPos, Len(MaterialPart2))
            Else
                If InStr(MaterialPart2, "x 1 1/2") > 0 Then
                    FabPart2 = " x 1 1/2"
                    SearchPos = InStr(MaterialPart2, "x 1 1/2")
                    FabPart3 = Mid(MaterialPart2, (SearchPos + 7), Len(MaterialPart2))
                Else
                    SearchPos = InStr(MaterialPart2, SearchX)

                    If SearchPos > 0 Then
                        FabPart2 = Mid(MaterialPart2, (SearchPos + 3), Len(MaterialPart2))
                        FabPart3 = Nothing
                    End If
                End If
            End If

            If InStr(FabPart3, SearchX) = 1 Then
                FabPart3 = Mid(FabPart3, 4, Len(FabPart3))
            End If

            If InStr(FabPart3, Chr(34)) = 0 And FabPart3 <> Nothing Then
                FabPart3 = FabPart3 & Chr(34)
            End If

            If FabPart1 <> Nothing And FabPart3 <> Nothing And FabPart2 <> Nothing Then
                MaterialPart2 = FabPart1 & "  x " & FabPart3 & FabPart2
            Else
                If FabPart1 <> Nothing And FabPart3 = Nothing And FabPart2 <> Nothing Then
                    MaterialPart2 = FabPart1 & "  x " & FabPart2
                End If
            End If

            If InStr(MaterialPart2, GetMatType) = 0 Then
                MaterialPart2 = MaterialPart2 & " - " & GetMatType
            End If

            If GetInvNo = Nothing Then
                GetSc = Nothing
            Else
                GetSc = GetInvNo & GetStdDwg
            End If

FoundGrip:
            ErrFound = "No"

            If InStr(MaterialPart, GetMatType) > 0 Then
                MatPos = InStr(MaterialPart, " - " & GetMatType)
                MaterialPart = Mid(MaterialPart, 1, (MatPos - 1))
            End If

            FeetInchesToDecInches(MaterialPart, GetDwgNo, ItemNum, ErrFound, FullJobNo)
            ErrFound = ErrorFoundNew

            If ErrFound = "Yes" Then
                MaterialNew = InputBox("Something is wrong with this description please retype " & Material)
                BOMList(7, j) = MaterialNew                         'myarray(7, i) = MaterialNew
                ReDim Preserve BOMList(20, UBound(BOMList, 2))

                GoTo StartOver
            End If

            BOMList(19, j) = (MatInch + AddRolled)                              'myarray(13, i) = (MatInch + AddRolled)
            BOMList(6, j) = "PURCHASE ITEM"                                   ''myarray(14, i) = "PURCHASE ITEM"
            ReDim Preserve BOMList(20, UBound(BOMList, 2))

            ItemFound = "Yes"
            AddItem2 = "Done"
            GoTo NextItem
PurchaseItem:
            MaterialPart2 = GetDesc
            MaterialPart2 = LTrim(MaterialPart2)
            MaterialPart2 = RTrim(MaterialPart2)

            Dim PdsPos As Integer
            Dim MaterialPart3 As String

            Select Case 0
                Case Is < InStr(MaterialPart2, "COUPLING")
                    Select Case 0
                        Case Is < InStr(MaterialPart2, "FULL COUPLING")
                            MatPos = InStr(MaterialPart2, "FULL COUPLING")
                            PdsPos = InStr(MaterialPart2, "#")
                            LenDesc = Len(MaterialPart2)

                            If Len(MaterialPart2) = (MatPos + 12) Then
                                MaterialPart1 = "COUPLING FULL " & Mid(MaterialPart2, 1, PdsPos)
                                MaterialPart3 = Mid(MaterialPart2, (PdsPos + 1), (MatPos - 12))
                                MaterialPart3 = LTrim(MaterialPart3)
                                MaterialPart3 = RTrim(MaterialPart3)
                                MaterialPart2 = MaterialPart1 & " - " & GetMatType & " " & MaterialPart3
                            End If
                        Case Is < InStr(MaterialPart2, "COUPLING HALF")
                            MaterialPart2 = MaterialPart2 & " - " & GetMatType
                        Case Is < InStr(MaterialPart2, "HALF COUPLING")
                            MatPos = InStr(MaterialPart2, "HALF COUPLING")
                            PdsPos = InStr(MaterialPart2, "#")
                            LenDesc = Len(MaterialPart2)

                            If Len(MaterialPart2) = (MatPos + 12) Then
                                MaterialPart1 = "COUPLING HALF " & Mid(MaterialPart2, 1, PdsPos)
                                MaterialPart3 = Mid(MaterialPart2, (PdsPos + 1), (MatPos - 13))
                                MaterialPart3 = LTrim(MaterialPart3)
                                MaterialPart3 = RTrim(MaterialPart3)
                                MaterialPart2 = MaterialPart1 & " - " & GetMatType & " " & MaterialPart3
                            Else
                                If MatPos = 1 Then
                                    MaterialPart2 = Replace(MaterialPart2, "HALF COUPLING", "COUPLING HALF")
                                    MaterialPart2 = MaterialPart2 & " - " & GetMatType
                                End If
                            End If
                    End Select

                    Search = "XS"
                    SearchFound = InStr(1, MaterialPart2, Search)

                    If SearchFound > 0 Then
                        MaterialPart1 = Mid(MaterialPart2, 1, (SearchFound - 1))

                        If Len(MaterialPart2) > (SearchFound + 1) Then
                            MaterialPart2 = Mid(MaterialPart2, (SearchFound + 1), Len(MaterialPart2))
                            MaterialPart2 = MaterialPart1 & "XH" & MaterialPart2
                        Else
                            MaterialPart2 = MaterialPart1 & "XH"
                        End If
                    End If

                    Search = "SCH 80"
                    SearchFound = InStr(1, MaterialPart2, Search)

                    If SearchFound > 0 Then
                        MaterialPart1 = Mid(MaterialPart2, 1, (SearchFound - 1))

                        If Len(MaterialPart2) > (SearchFound + 6) Then
                            MaterialPart2 = Mid(MaterialPart2, (SearchFound + 1), Len(MaterialPart2))
                            MaterialPart2 = MaterialPart1 & "XH" & MaterialPart2
                        Else
                            MaterialPart2 = MaterialPart1 & "XH"
                        End If
                    End If

                    Search = "SCH 40"
                    SearchFound = InStr(1, MaterialPart2, Search)

                    If SearchFound > 0 Then
                        MaterialPart1 = Mid(MaterialPart2, 1, (SearchFound - 1))

                        If Len(MaterialPart2) > (SearchFound + 6) Then
                            MaterialPart2 = Mid(MaterialPart2, (SearchFound + 1), Len(MaterialPart2))
                            MaterialPart2 = MaterialPart1 & "STD WT" & MaterialPart2
                        Else
                            MaterialPart2 = MaterialPart1 & "STD WT"
                        End If
                    End If

CouplingNotFound:

                Case Is < InStr(MaterialPart2, "FLANGE")
                    Search = "XS"
                    SearchFound = InStr(1, MaterialPart2, Search)

                    If SearchFound > 0 Then                                 '-------Find XS replace with XH-------
                        MaterialPart1 = Mid(MaterialPart2, 1, (SearchFound - 1))

                        If Len(MaterialPart2) > (SearchFound + 1) Then
                            MaterialPart2 = Mid(MaterialPart2, (SearchFound + 2), Len(MaterialPart2))
                            MaterialPart2 = RTrim(MaterialPart2)
                            MaterialPart2 = MaterialPart1 & "XH" & MaterialPart2
                        Else
                            MaterialPart2 = MaterialPart1 & "XH"
                        End If
                    End If

                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

                    MaterialPart2 = Replace(MaterialPart2, "   - ", " - ")
                    MaterialPart2 = Replace(MaterialPart2, "  - ", " - ")

                    Search = "STD BORE"                     '-------Find STD BORE replace with STD WT BORE-------
                    SearchFound = InStr(1, MaterialPart2, Search)

                    If SearchFound > 0 Then
                        MaterialPart1 = Mid(MaterialPart2, 1, (SearchFound - 1))

                        If Len(MaterialPart2) > (SearchFound + 1) Then
                            MaterialPart2 = Mid(MaterialPart2, (SearchFound + 8), Len(MaterialPart2))
                            MaterialPart3 = MaterialPart1 & "STD WT BORE" & MaterialPart2
                        Else
                            MaterialPart3 = MaterialPart1 & "STD WT BORE"
                        End If
                    End If

                    Search = "BLIND"
                    SearchFound = InStr(1, MaterialPart2, Search)

                    If SearchFound > 1 Then
                        MaterialPart1 = Mid(MaterialPart2, 1, (SearchFound - 2))

                        If Len(MaterialPart2) > (SearchFound + 1) Then
                            MaterialPart3 = Mid(MaterialPart2, (SearchFound + 5), Len(MaterialPart2))
                            MaterialPart2 = "BLIND " & MaterialPart1 & MaterialPart3
                        Else
                            MaterialPart3 = GetMatType
                            MaterialPart2 = "BLIND " & MaterialPart1 & MaterialPart3
                        End If
                    End If

                    If InStr(MaterialPart2, " - " & GetMatType) > 0 Then
                        MaterialPart2 = Replace(MaterialPart2, " - " & GetMatType, "")
                    End If

                    BOMList(19, j) = GetQty                             'myarray(13, i) = GetQty
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
FlangeNotFound:

                Case Is < InStr(MaterialPart2, "SHELL MANWAY")

                    If InStr(MaterialPart2, "A516-70") > 0 Then
                        MaterialPart2 = Replace(MaterialPart2, " - A516-70", "")
                    End If

                    If InStr(MaterialPart2, "HINGED SHELL MANWAY") > 0 Then
                        MaterialPart2 = Replace(MaterialPart2, "HINGED SHELL MANWAY", "SHELL MANWAY HINGED")
                    End If

                    MaterialPart2 = Replace(MaterialPart2, "   ", " ")
                    MaterialPart2 = Replace(MaterialPart2, "  ", " ")

                    BOMList(19, j) = GetQty                             'myarray(13, i) = GetQty
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))

SubMFGDataNotFound:

                Case Is < InStr(MaterialPart2, "SHELL MIXER MANWAY")
                    If InStr(GetDesc, "A516-70") > 0 Then
                        GetDesc = Replace(GetDesc, " - A516-70", "")
                    End If

                    If InStr(GetDesc, "G40.21") > 0 Then
                        GetDesc = Replace(GetDesc, " - G40.21", "")
                    End If

                    If InStr(GetDesc, "SHELL MIXER MANWAY") > 0 Then
                        GetDesc = Replace(GetDesc, "SHELL MIXER MANWAY", "SHELL MANWAY MIXER")
                    End If

                    MaterialPart2 = Replace(MaterialPart2, "   ", " ")
                    MaterialPart2 = Replace(MaterialPart2, "  ", " ")

                    BOMList(19, j) = GetQty                             'myarray(13, i) = GetQty
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
MixerManwayNotFound:

                Case Is < InStr(MaterialPart2, "HINGE")
                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If
                Case Is < InStr(MaterialPart2, "WELD CONNECTOR")
                    TestGetDesc2 = GetDesc                  'TestGetDesc2 = (myarray(7, i))
                    GetInvNo = (BOMList(9, j))                 'TestGetInvNo2 = (myarray(8, i))
                    GetStdDwg = (BOMList(10, j))                'TestGetStdDwg2 = (myarray(9, i))
                    TestGetMatType2 = (BOMList(11, j))              'TestGetMatType2 = (myarray(10, i))

                    If TestGetDesc2 <> GetDesc Then
                        Stop
                    End If
                    If TestGetInvNo2 <> GetInvNo Then
                        Stop
                    End If
                    If TestGetStdDwg2 <> GetStdDwg Then
                        Stop
                    End If
                    If TestGetMatType2 <> GetMatType Then
                        Stop
                    End If

                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

                    Select Case 0
                        Case Is < InStr(MaterialPart2, "WAGNER-1033")
                            GetSc = "WAGNER-1033"
                        Case Is < InStr(MaterialPart2, "WAGNER-1023")
                            GetSc = "WAGNER-1023"
                        Case Is < InStr(MaterialPart2, "WAGNER-1043")
                            GetSc = "WAGNER-1043"
                    End Select

WeldConNotFound:

                    GoTo WeldConNotFound

                Case Is < InStr(MaterialPart2, "TREAD/GRTG")
                    PartFound = "No"
                    BOMList(6, j) = "GRATING"                     ''myarray(14, i) = "GRATING"
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))

                    Dim MatPartTest, GetInvNoTest, GetStdDwgTest As String
                    MaterialPart2 = GetDesc

                    If GetInvNo = Nothing Then                  'TREAD 9 3/4 x 2-6"/GRATING3/16" x 1
                        GetInvNo = (BOMList(9, (j - 1)))        'GetInvNo = (myarray(8, (i - 1)))
                    End If

                    If GetStdDwg = Nothing Then
                        GetStdDwg = (BOMList(10, (j - 1)))       'GetStdDwg = (myarray(9, (i - 1)))
                    End If

                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

                    If GetInvNo = Nothing Then
                        GetSc = Nothing
                    Else
                        GetSc = GetInvNo & GetStdDwg
                    End If
GratingNotFound:
                    GetGrating = Mid(GetDesc, 1, 12)                'GetGrating = Left(myarray(7, i), 12)

                    '--------------------------------Fix Description to Read TREAD 10 15/16 x 3-0"/GRATING3/16" x
                    If InStr(GetDesc, "TREAD/GRTG/S 3/16 x 1 x ") Then
                        GetDesc1 = Mid(GetDesc, 25, Len(GetDesc))
                        GetDesc = GetDesc1
                        GetGratingInfo = "/GRATING 3/16" & Chr(34) & " x 1"
                    Else
                        If InStr(GetDesc, "TREAD/GRTG/S 3/16 x 1 1/2 x ") Then
                            GetDesc1 = Mid(GetDesc, 28, Len(GetDesc))
                            GetDesc = GetDesc1
                            GetGratingInfo = "/GRATING 3/16" & Chr(34) & " x 1 1/2"
                        End If
                    End If

                    Select Case 0
                        Case Is < InStr(GetDesc, "2'-5 5/8")
                            TreadLen = "2'-6" & Chr(34)
                            TreadWidPos = InStr(GetDesc, "2'-5 5/8")
                            GetDesc1 = Mid(GetDesc, 1, (TreadWidPos - 1))

                            If InStr(GetDesc1, SearchX) > 0 Then
                                Xpos = InStr(GetDesc1, SearchX)
                                If (Xpos + 2) = Len(GetDesc1) Then
                                    TreadWid = Mid(GetDesc1, 1, (Xpos - 1))
                                End If
                            End If

                            GetDesc2 = Mid(GetDesc, (TreadWidPos + 9), Len(GetDesc))
                            GetDesc = "TREAD " & TreadWid & " x " & TreadLen & GetGratingInfo & " " & GetDesc2
                            TreadWidDbl = FToD(TreadWid)
                            TreadLenDbl = FToD(TreadLen)

                            Select Case 0
                                Case TreadLenDbl
                                    TreadSqFt = TreadWidDbl
                                Case Else
                                    TreadSqFt = (TreadWidDbl * TreadLenDbl)
                            End Select

                        Case Is < InStr(GetDesc, "3'-5 5/8")
                            TreadLen = "3'-6" & Chr(34)
                            TreadWidPos = InStr(GetDesc, "3'-5 5/8")
                            GetDesc1 = Mid(GetDesc, 1, (TreadWidPos - 1))
                            If InStr(GetDesc1, SearchX) > 0 Then
                                Xpos = InStr(GetDesc1, SearchX)
                                If (Xpos + 2) = Len(GetDesc1) Then
                                    TreadWid = Mid(GetDesc1, 1, (Xpos - 1))
                                End If
                            End If
                            GetDesc2 = Mid(GetDesc, (TreadWidPos + 9), Len(GetDesc))
                            GetDesc = "TREAD " & TreadWid & " x " & TreadLen & GetGratingInfo & " " & GetDesc2
                            TreadWidDbl = FToD(TreadWid)
                            TreadLenDbl = FToD(TreadLen)

                            Select Case 0
                                Case TreadLenDbl
                                    TreadSqFt = TreadWidDbl
                                Case Else
                                    TreadSqFt = (TreadWidDbl * TreadLenDbl)
                            End Select
                    End Select

                    For n = 0 To (UBound(ManwayInfo3134.SubMFGData, 2) - 2)
                        FindSc = ManwayInfo3134.SubMFGData(1, n)
                        FindDesc = ManwayInfo3134.SubMFGData(2, n)

                        If PartFound = "No" Then
                            Select Case 0
                                Case Is < InStr(GetSc, "TW2MX1102B")
                                    'myarray(16, j) = "Not on Spreadsheet"
                                    BOMList(19, j) = (MatInch + AddRolled)                              'myarray(13, i) = (MatInch + AddRolled)
                                    BOMList(6, j) = "GRATING"                                         ''myarray(14, i) = "GRATING"
                                    ReDim Preserve BOMList(20, UBound(BOMList, 2))


                                    PartFound = "Yes"
                                    GoTo FindGrating

                                Case Is < InStr(GetSc, "TW3/GMX1102G")
                                    'myarray(16, j) = "Not on Spreadsheet"
                                    BOMList(19, j) = ((TreadSqFt * ManwayInfo3134.GetMatQty) / 12)      'myarray(13, i) = ((TreadSqFt * ManwayInfo3134.GetMatQty) / 12)
                                    BOMList(6, j) = "GRATING"                                         ''myarray(14, i) = "GRATING"
                                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                                    PartFound = "Yes"
                                    GoTo FindGrating
                            End Select
                        End If
FindGrating:
                        ItemFound = "Yes"
                        AddItem2 = "Done"
                        GoTo NextItem

                        If InStr(MaterialPart2, "TREAD/GRTG") > 0 Then
                            GratingPos = InStr(MaterialPart2, "TREAD/GRTG/S ")

                            If GratingPos > 0 Then
                                MaterialPart1 = Mid(MaterialPart2, (GratingPos + 12), Len(MaterialPart2))
                            End If
                            MaterialPart2 = "GRATING SERRATED" & MaterialPart1
                        End If

                        If ManwayInfo3134.SubMFGData(2, n) = MaterialPart2 Or InStr(MaterialPart2, ManwayInfo3134.SubMFGData(2, n)) > 0 Then
                            If ManwayInfo3134.SubMFGData(0, n) = Nothing Then
                                GoTo GratingNotFnd2
                            End If
                            GoTo FoundMat
                        End If
NextN:
                    Next n
GratingNotFnd2:

                Case Is < InStr(MaterialPart2, "CABLE GROUND LUG")
                    If InStr(MaterialPart, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

GrdLugNotFound:
                    BOMList(6, j) = "PURCHASE ITEM"                           'myarray(14, i) = "PURCHASE ITEM"
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                Case Is < InStr(MaterialPart2, "GROUND CABLE") 'GROUND CABLE (4' STANDARD CABLE AWG 2/0 McMASTER CARR PN-6948K76)
                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

GrdCableNotFound:
                    BOMList(6, j) = "PURCHASE ITEM"                           ''myarray(14, i) = "PURCHASE ITEM"
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                Case Is < InStr(MaterialPart2, "COTTER PIN")
                    MaterialPart2 = GetDesc

                    If InStr(MaterialPart2, " - " & GetMatType) > 0 Then
                        MaterialPart2 = Replace(MaterialPart2, " - " & GetMatType, "")
                    End If

                    GetInvStd = GetInvStd
CotterPinNotFound:
                    BOMList(6, j) = "PURCHASE ITEM"                           ''myarray(14, i) = "PURCHASE ITEM"
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))

                Case Is < InStr(MaterialPart2, "LEG PIN")
                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

                    If GetInvNo = Nothing Then
                        GetSc = Nothing
                    Else
                        GetSc = GetInvNo & GetStdDwg
                    End If

LegPinNotFound:
                    BOMList(6, j) = "PURCHASE ITEM"                           'myarray(14, i) = "PURCHASE ITEM"
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                Case Is < InStr(MaterialPart2, "GASKET")
                    GetInvStd = GetInvStd

                    If GetInvNo = Nothing Then
                        GetSc = Nothing
                    Else
                        GetSc = GetInvNo & GetStdDwg
                    End If

                    SearchDash = "-"
                    DashPos = InStr(GetMatType, SearchDash)

                    If DashPos > 0 Then
                        GetMatType1 = Mid(GetMatType, 1, (DashPos - 1))
                        GetMatType2 = Mid(GetMatType, (DashPos + 1), Len(GetMatType))
                        GetMatType = GetMatType1 & " " & GetMatType2
                    End If

                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

                    SearchFound = "THK "                            '-------Remove Thk fro Desc
                    SearchPos = InStr(MaterialPart2, SearchFound)

                    If SearchPos > 0 Then
                        MaterialPart1 = Mid(MaterialPart2, 1, (SearchPos - 1))
                        MaterialPart3 = Mid(MaterialPart2, (SearchPos + 4), Len(MaterialPart2))
                        MaterialPart2 = MaterialPart1 & " " & MaterialPart3
                    End If

                    MaterialPart2 = Replace(MaterialPart2, "BUNA N", "BUNAN")
                    MaterialPart2 = Replace(MaterialPart2, "ID 1", "ID x 1")
                    MaterialPart2 = Replace(MaterialPart2, "ID 4", "ID x 4")
                    MaterialPart2 = Replace(MaterialPart2, "ID 5", "ID x 5")
                    MaterialPart2 = Replace(MaterialPart2, "   ", " ")
                    MaterialPart2 = Replace(MaterialPart2, "  ", " ")

                    If InStr(MaterialPart2, "- NITRILE VINYL") > 2 Then
                        SearchPos = InStr(MaterialPart2, "- NITRILE VINYL")

                        While SearchPos > 0
                            MaterialPart2 = Mid(MaterialPart2, 1, SearchPos)
                            SearchPos = InStr(MaterialPart2, "- NITRILE VINYL")
                        End While

                        If InStr(MaterialPart2, "OD -") > 0 Then
                            MaterialPart2 = Replace(MaterialPart2, "OD -", "OD")
                            MaterialPart2 = RTrim(MaterialPart2)
                        End If

                        If InStr(MaterialPart2, "15 1/4") = 0 Then
                            MaterialPart2 = (MaterialPart2 & " - NITRILE VINYL")
                        End If
                    End If

                    MaterialPart2 = Replace(MaterialPart2, "GASKET 1/4" & Chr(34), "GASKET 1/4")
                    MaterialPart2 = Replace(MaterialPart2, "GASKET 1/4 " & Chr(34), "GASKET 1/4")
                    MaterialPart2 = Replace(MaterialPart2, "   ", " ")
                    MaterialPart2 = Replace(MaterialPart2, "  ", " ")
                    MaterialPart2 = Replace(MaterialPart2, "FLEXITALIC", "FLEXITALLIC")

GasketNotFound2:
                    BOMList(6, j) = "PURCHASE ITEM"                           'myarray(14, i) = "PURCHASE ITEM"
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))

                        'myarray(16, j) = "**Need Number**" & "--" & MaterialPart2

                Case Is < InStr(MaterialPart2, "ELL BW")
                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If
FittingNotFound:

                Case Is < InStr(MaterialPart2, "TEE BW")
                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

TeeNotFound:

                Case Is < InStr(MaterialPart2, "TEE")
                    MaterialPart2 = GetDesc

                    If InStr(MaterialPart2, " - " & GetMatType) > 0 Then
                        SearchPos = InStr(MaterialPart2, " - " & GetMatType)

                        MaterialPart2 = Mid(MaterialPart2, 1, (SearchPos - 1))
                    End If

                    MaterialPart2 = Replace(MaterialPart2, "   ", " ")
                    MaterialPart2 = Replace(MaterialPart2, "  ", " ")
                    MaterialPart2 = Replace(MaterialPart2, Chr(39) & Chr(39), Chr(34))

                    If InStr(MaterialPart2, Chr(34)) = 0 Then
                        Select Case 0
                            Case Is < InStr(MaterialPart2, " STD WT")
                                SearchPos = InStr(MaterialPart2, " STD WT")

                                MaterialPart2 = Mid(MaterialPart2, 1, (SearchPos - 1))
                                MaterialPart2 = MaterialPart2 & Chr(34) & " STD WT"
                        End Select
                    End If

Tee2NotFound:

                Case Is < InStr(MaterialPart2, "REDUCING ELL BW")
                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

                    Test1 = GetInvStd

ReducingELLBWNotFound:

                Case Is < InStr(MaterialPart2, "REDUCER ECC BW")
                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

                    Test1 = GetInvStd
                    MaterialPart2 = Replace(MaterialPart2, "   ", " ")
                    MaterialPart2 = Replace(MaterialPart2, "  ", " ")

ReducingECCBWNotFound:
                Case Is < InStr(MaterialPart2, "UNION")
                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

                    Test1 = GetInvStd

UnionNotFound:

                Case Is < InStr(MaterialPart2, "PIPE NIPPLE")
                    Test1 = GetInvStd
                    Dim ErrPos As Integer

                    Select Case 0
                        Case Is < InStr(MaterialPart2, " x CLOSE TBE")
                            ErrPos = InStr(MaterialPart2, " x CLOSE TBE")
                            MaterialPart2 = Mid(MaterialPart2, 1, ErrPos)
                        Case Is < InStr(MaterialPart2, " x ")
                            ErrPos = InStr(MaterialPart2, " x ")
                            MaterialPart2 = Mid(MaterialPart2, 1, ErrPos)
                        Case Else
                            Stop
                    End Select

                    MaterialPart2 = RTrim(MaterialPart2)

                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

PipeNippleNotFound:

                Case Is < InStr(MaterialPart2, "TRIM SEAL")
                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

                    Test1 = GetInvStd
                    Dim TrimPos, Pos3100 As Integer
                    TrimPos = InStr(MaterialPart2, "TRIM SEAL")
                    Pos3100 = InStr(MaterialPart2, "3100")

                    If TrimPos > 0 And Pos3100 > 0 Then
                        GetSc = "TRMSEAL3100"
                    End If

TrimSealNotFound:

FoamTape:
                Case Is < InStr(MaterialPart2, "FOAM TAPE")
                    If InStr(MaterialPart2, GetMatType) > 0 Then
                        MaterialPart2 = Replace(MaterialPart2, " - " & GetMatType, "")
                        MaterialPart2 = RTrim(MaterialPart2)
                    End If

                    MaterialPart2 = Replace(MaterialPart2, "TAPE 1", "TAPE1")

                    SearchPos = InStr(MaterialPart2, "WIDE")
                    If SearchPos > 0 Then
                        MaterialPart2 = Mid(MaterialPart2, 1, (SearchPos + 4))
                    End If

FoamTapeNotFound:

GaugeItems:
                Case Is < InStr(MaterialPart2, "GAUGE")
                    If InStr(MaterialPart2, GetMatType) > 0 Then
                        MaterialPart2 = Replace(MaterialPart2, " - " & GetMatType, "")
                        MaterialPart2 = RTrim(MaterialPart2)
                    End If

                    If InStr(MaterialPart2, "SENTINEL MODEL AP") > 0 Then
                        MaterialPart2 = Replace(MaterialPart2, "SENTINEL MODEL AP", "AP")
                        MaterialPart2 = RTrim(MaterialPart2)
                    End If

                    If GetMatType = "ALUM" Then
                        MaterialPart2 = MaterialPart2 & " - 150# ALUM"
                    End If

GaugeNotFound:

                Case Is < InStr(MaterialPart2, "U-BOLT")
                    InchPos = InStr(GetDesc, SearchInch)
                    Xpos = InStr(GetDesc, SearchX)
                    PrevInchPos = 0

                    If InchPos > 0 Then
                        While InchPos > 0
                            If PrevInchPos > 0 Then
                                FirstPart = Mid(GetDesc, 14, (InchPos + PrevInchPos - 14))
                                FirstPart = "HHMB " & FirstPart
                                SecondPart = Mid(GetDesc, (InchPos + PrevInchPos + 1), Len(GetDesc))
                                PrevInchPos = (PrevInchPos + (InchPos + 1))
                                InchPos = InStr(SecondPart, SearchInch)
                            Else
                                FirstPart = Mid(GetDesc, 1, (InchPos - 1))
                                SecondPart = Mid(GetDesc, (InchPos + 1), Len(GetDesc))
                                PrevInchPos = InchPos
                                InchPos = InStr(SecondPart, SearchInch)
                                SearchMBolt = "MACHINE BOLT "
                                MBoltPos = InStr(FirstPart, SearchMBolt)

                                If MBoltPos > 0 Then
                                    NutSize = Mid(FirstPart, (MBoltPos + 12), Len(FirstPart))
                                    NutSize = LTrim(NutSize)
                                    NutSize = RTrim(NutSize)
                                End If
                            End If
                        End While
                    Else
                        While Xpos > 0
                            If PrevInchPos > 0 Then
                                FirstPart = Mid(GetDesc, 1, (InchPos + PrevInchPos))
                                SecondPart = Mid(GetDesc, (InchPos + PrevInchPos + 1), Len(GetDesc))
                                PrevInchPos = (PrevInchPos + (InchPos + 1))
                                InchPos = InStr(SecondPart, SearchInch)
                            Else
                                FirstPart = Mid(GetDesc, 1, (InchPos - 1))
                                SecondPart = Mid(GetDesc, (InchPos + 1), Len(GetDesc))
                                PrevInchPos = InchPos
                                InchPos = InStr(SecondPart, SearchInch)
                                SearchMBolt = "MACHINE BOLT "
                                MBoltPos = InStr(FirstPart, SearchMBolt)

                                If MBoltPos > 0 Then
                                    NutSize = Mid(FirstPart, (MBoltPos + 12), Len(FirstPart))
                                    NutSize = LTrim(NutSize)
                                    NutSize = RTrim(NutSize)
                                End If

                            End If
                        End While
                    End If

                    NutsNo = SecondPart
                    SearchWith = "w/ "
                    WithPos = InStr(NutsNo, SearchWith)

                    If WithPos > 0 Then
                        NutsNo = Mid(SecondPart, (WithPos + 3), Len(NutsNo))
                    Else
                        NutsNo = 0
                    End If

                    SearchX = " x "
                    Xpos = InStr(NutSize, SearchX)

                    If Xpos > 0 Then
                        NutSize = Mid(NutSize, 1, Xpos)
                        NutSize = LTrim(NutSize)
                        NutSize = RTrim(NutSize)
                    End If

                    Select Case 0
                        Case Is < InStr(NutsNo, "HH")
                            DescPos = InStr(NutsNo, "HH")
                            NutsNo = Mid(NutsNo, 1, (DescPos - 1))
                            NutsNo = LTrim(NutsNo)
                            NutsNo = RTrim(NutsNo)
                            AddMat = "HEX NUT " & NutSize & Chr(34)
                            FirstPart = "HHMB " & Mid(FirstPart, 16, Len(FirstPart))
                            FirstPart = LTrim(FirstPart)
                            FirstPart = RTrim(FirstPart)
                        Case Is < InStr(NutsNo, "HEX NUT")
                            DescPos = InStr(NutsNo, "HEX NUT")
                            NutsNo = Mid(NutsNo, 1, (DescPos - 1))
                            NutsNo = LTrim(NutsNo)
                            NutsNo = RTrim(NutsNo)
                            AddMat = "HEX NUT " & NutSize & Chr(34)
                            FirstPart = "HHMB " & Mid(FirstPart, 14, Len(FirstPart))
                            FirstPart = LTrim(FirstPart)
                            FirstPart = RTrim(FirstPart)

                            If Mid(FirstPart, Len(FirstPart), 1) = Chr(34) Then
                                '               -------Do Nothing
                            Else
                                FirstPart = FirstPart & Chr(34)
                            End If

                            Dim FirstPart1, FirstPart2 As String
                            SearchX = " x "
                            Xpos = InStr(FirstPart, SearchX)

                            If Xpos > 0 Then
                                FirstPart1 = Mid(FirstPart, 1, (Xpos - 1))
                                FirstPart2 = Mid(FirstPart, Xpos, Len(FirstPart))

                                If Mid(FirstPart1, Len(FirstPart1), 1) = Chr(34) Then
                                    '               -------Do Nothing
                                Else
                                    FirstPart = FirstPart1 & Chr(34) & FirstPart2
                                End If
                            End If
                        Case Is < InStr(NutsNo, "NYLON INSERT LOCK NUTS")
                            NutsNo = 1
                            AddMat = "HEX LOCK NUT " & NutSize & Chr(34) & " W/ NYL. INS."
                            FirstPart = "HHMB " & Mid(FirstPart, 13, Len(FirstPart))
                            FirstPart = LTrim(FirstPart)
                            FirstPart = RTrim(FirstPart)

                        Case Else
                            If NutsNo = 0 Then
                                GoTo NoNuts3
                            End If
                    End Select
NoNuts3:
                    ManwayInfo3134.OldDesc = FirstPart
                    ManwayInfo3134.GetDesc = GetDesc
                    ManwayInfo3134.AddMat = AddMat
                    ManwayInfo3134.AddMatSize = NutSize
                    ManwayInfo3134.AddMatQty = NutsNo
                    SearchDash = "-"
                    DashPos = InStr(GetMatType, SearchDash)

                    If DashPos > 0 Then
                        GetMatType1 = Mid(GetMatType, 1, (DashPos - 1))
                        GetMatType2 = Mid(GetMatType, (DashPos + 1), Len(GetMatType))
                        GetMatType = GetMatType1 & " " & GetMatType2
                    Else
                        GetMatType1 = GetMatType
                        GetMatType2 = GetMatType
                    End If

                    FindDesc = ManwayInfo3134.OldDesc & " - " & GetMatType1

                    If NutsNo = 0 Then
                        FindDesc2 = Nothing
                    Else
                        FindDesc2 = ManwayInfo3134.AddMat & " - " & GetMatType2
                    End If

UBoltsNotFound:

                Case Is < InStr(MaterialPart2, "STUD BOLT")
                    InchPos = InStr(GetDesc, SearchInch)
                    Xpos = InStr(GetDesc, SearchX)
                    PrevInchPos = 0

                    If InchPos > 0 Then
                        While InchPos > 0
                            If PrevInchPos > 0 Then
                                'FirstPart = Mid(GetDesc, 14, (InchPos + PrevInchPos - 14))
                                SecondPart = Mid(GetDesc, (InchPos + PrevInchPos + 1), Len(GetDesc))
                                FirstPart = GetDesc.Replace(SecondPart, "")

                                PrevInchPos = (PrevInchPos + (InchPos + 1))
                                InchPos = InStr(SecondPart, SearchInch)
                            Else
                                FirstPart = Mid(GetDesc, 1, (InchPos - 1))
                                SecondPart = Mid(GetDesc, (InchPos + 1), Len(GetDesc))
                                PrevInchPos = InchPos
                                InchPos = InStr(SecondPart, SearchInch)
                                SearchMBolt = "STUD BOLT "
                                MBoltPos = InStr(FirstPart, SearchMBolt)

                                If MBoltPos > 0 Then
                                    NutSize = Mid(FirstPart, (MBoltPos + 10), Len(FirstPart))
                                    NutSize = LTrim(NutSize)
                                    NutSize = RTrim(NutSize)
                                End If

                            End If
                        End While
                    Else
                        While Xpos > 0
                            If PrevInchPos > 0 Then
                                FirstPart = Mid(GetDesc, 1, (InchPos + PrevInchPos))
                                SecondPart = Mid(GetDesc, (InchPos + PrevInchPos + 1), Len(GetDesc))
                                PrevInchPos = (PrevInchPos + (InchPos + 1))
                                InchPos = InStr(SecondPart, SearchInch)
                            Else
                                FirstPart = Mid(GetDesc, 1, (Xpos - 1))
                                SecondPart = Mid(GetDesc, (Xpos + 3), Len(GetDesc))
                                PrevInchPos = InchPos
                                InchPos = InStr(SecondPart, SearchInch)
                                SearchMBolt = "STUD BOLT"
                                Xpos = InStr(SecondPart, SearchX)
                                MBoltPos = InStr(FirstPart, SearchMBolt)

                                If MBoltPos > 0 Then
                                    NutSize = Mid(FirstPart, (MBoltPos + 9), Len(FirstPart))
                                    NutSize = LTrim(NutSize)
                                    NutSize = RTrim(NutSize)
                                End If

                            End If
                        End While
                    End If

                    NutsNo = SecondPart
                    SearchWith = "w/ "
                    WithPos = InStr(NutsNo, SearchWith)

                    If WithPos > 0 Then
                        NutsNo = Mid(SecondPart, (WithPos + 3), Len(NutsNo))
                    Else
                        NutsNo = 0
                    End If

                    SearchX = " x "
                    Xpos = InStr(NutSize, SearchX)

                    If Xpos > 0 Then
                        NutSize = Mid(NutSize, 1, Xpos)
                        NutSize = LTrim(NutSize)
                        NutSize = RTrim(NutSize)
                    End If

                    Select Case 0
                        Case Is < InStr(NutsNo, "HH")
                            DescPos = InStr(NutsNo, "HH")
                            NutsNo = Mid(NutsNo, 1, (DescPos - 1))
                            NutsNo = LTrim(NutsNo)
                            NutsNo = RTrim(NutsNo)
                            AddMat = "HEX NUT " & NutSize & Chr(34)

                            If PrevInchPos > 0 Then                         '-------Something is not right here.
                                'FirstPart = "STUD BOLT " & Mid(FirstPart, 11, Len(FirstPart))
                                FirstPart = FirstPart & SecondPart.Replace(" - " & GetMatType, "")
                            Else
                                FirstPart = "STUD BOLT " & NutSize & " x " & SecondPart
                            End If

                            FirstPart = LTrim(FirstPart)
                            FirstPart = RTrim(FirstPart)
                        Case Is < InStr(NutsNo, "HEX NUT")
                            DescPos = InStr(NutsNo, "HEX NUT")
                            NutsNo = Mid(NutsNo, 1, (DescPos - 1))
                            NutsNo = LTrim(NutsNo)
                            NutsNo = RTrim(NutsNo)
                            AddMat = "HEX NUT " & NutSize & Chr(34)
                            FirstPart = "HHMB " & Mid(FirstPart, 14, Len(FirstPart))
                            FirstPart = LTrim(FirstPart)
                            FirstPart = RTrim(FirstPart)

                            If Mid(FirstPart, Len(FirstPart), 1) = Chr(34) Then
                                '               -------Do Nothing
                            Else
                                FirstPart = FirstPart & Chr(34)
                            End If

                            Dim FirstPart1, FirstPart2 As String
                            SearchX = " x "
                            Xpos = InStr(FirstPart, SearchX)

                            If Xpos > 0 Then
                                FirstPart1 = Mid(FirstPart, 1, (Xpos - 1))
                                FirstPart2 = Mid(FirstPart, Xpos, Len(FirstPart))

                                If Mid(FirstPart1, Len(FirstPart1), 1) = Chr(34) Then
                                    '               -------Do Nothing
                                Else
                                    FirstPart = FirstPart1 & Chr(34) & FirstPart2
                                End If
                            End If
                        Case Is < InStr(NutsNo, "NYLON INSERT LOCK NUTS")
                            NutsNo = 1
                            AddMat = "HEX LOCK NUT " & NutSize & Chr(34) & " W/ NYL. INS."
                            FirstPart = "HHMB " & Mid(FirstPart, 13, Len(FirstPart))
                            FirstPart = LTrim(FirstPart)
                            FirstPart = RTrim(FirstPart)
                        Case Else
                            If NutsNo = 0 Then
                                GoTo NoNuts4
                            End If
                    End Select
NoNuts4:
                    'ManwayInfo3134.OldDesc = FirstPart
                    'ManwayInfo3134.GetDesc = GetDesc
                    'ManwayInfo3134.AddMat = AddMat
                    'ManwayInfo3134.AddMatSize = NutSize
                    'ManwayInfo3134.AddMatQty = NutsNo

                    SearchDash = "-"
                    DashPos = InStr(GetMatType, SearchDash)
                    SpacePos = InStr(GetMatType, SearchSpace)
                    DeltaPos = InStr(GetMatType, "~")

                    If DashPos > 0 Then
                        GetMatType1 = Mid(GetMatType, 1, (DashPos - 1))
                        GetMatType2 = Mid(GetMatType, (DashPos + 1), Len(GetMatType))
                        GetMatType = GetMatType1 & " " & GetMatType2
                    Else
                        If SpacePos > 0 Then
                            GetMatType1 = Mid(GetMatType, 1, (SpacePos - 1))
                            GetMatType2 = Mid(GetMatType, (SpacePos + 1), Len(GetMatType))
                        Else
                            If DeltaPos > 0 Then
                                GetMatType1 = Mid(GetMatType, 1, (DeltaPos - 1))
                                GetMatType2 = Mid(GetMatType, (DeltaPos + 1), Len(GetMatType))
                            Else
                                GetMatType1 = GetMatType
                                GetMatType2 = GetMatType
                            End If
                        End If
                    End If

                    FindDesc = FirstPart & " - " & GetMatType1         'FindDesc = ManwayInfo3134.OldDesc & " - " & GetMatType1

                    If NutsNo = 0 Then
                        FindDesc2 = Nothing
                    Else
                        AddMat = AddMat & " - " & GetMatType2     'FindDesc2 = ManwayInfo3134.AddMat & " - " & GetMatType2
                    End If

                    If AddMat <> Nothing Then                       'To do this must look at everything in reverse order.
                        GetRecNo = BOMList(20, j)

                        With BOMWrkSht
                            .Range("F" & GetRecNo).Value = FindDesc       'Remove nut material

                            .Rows(GetRecNo & ":" & GetRecNo).Select()
                            .Rows((GetRecNo + 1) & ":" & (GetRecNo + 1)).Insert()         'GetDesc = BOMList(7, j)

                            .Range("A" & (GetRecNo + 1)).Value = BOMList(1, j)                'ColumnC    'Job Number        
                            .Range("B" & (GetRecNo + 1)).Value = BOMList(2, j)                 'ColumnD    'Dwg No.            
                            .Range("C" & (GetRecNo + 1)).Value = BOMList(3, j)                 'ColumnE    'Rev No.             
                            .Range("E" & (GetRecNo + 1)).Value = (GetQty * NutsNo)             'ColumnG    'Qty          'BOMList(4, j)
                            'BOMList(4, j) = (GetQty * NutsNo)                      'Need to find solution to add Items to array in order.

                            .Range("D" & (GetRecNo + 1)).Value = BOMList(5, j)                 'ColumnF    'Ship No.        
                            .Range("F" & (GetRecNo + 1)).Value = AddMat                        'ColumnH   'Desc            
                            'BOMList(4, j) = AddMat                                 'Need to find solution to add Items to array in order.

                            .Range("G" & (GetRecNo + 1)).Value = BOMList(9, j)                'ColumnK    'Inv No.            
                            .Range("H" & (GetRecNo + 1)).Value = BOMList(10, j)              'ColumnL    'Std No.                 
                            .Range("I" & (GetRecNo + 1)).Value = BOMList(11, j)              'ColumnM    'Material                    
                            .Range("T" & (GetRecNo + 1)).Value = BOMList(12, j)              'ColumnN    'Weight                      

                            .Range("V" & (GetRecNo + 1)).Value = BOMList(13, j)
                            .Range("J" & (GetRecNo + 1)).Value = BOMList(14, j)                'Weight                                 

                            .Range("M" & (GetRecNo + 1)).Value = BOMList(15, j)               'ColumnV    'Dwg No                       
                            .Range("N" & (GetRecNo + 1)).Value = BOMList(16, j)              'ColumnW    'X                            
                            .Range("P" & (GetRecNo + 1)).Value = BOMList(17, j)               'ColumnX    'Y                            
                            .Range("X" & (GetRecNo + 1)).Value = BOMList(18, j)              '"Found" 'Was W       'We know it was found just need row number.
                            .Range("Y" & (GetRecNo + 1)).Value = BOMList(19, j)            'Drawing Number Plus 'Was X
                        End With

                        BOMList(6, j) = "PURCHASE ITEM"
                        ReDim Preserve BOMList(20, UBound(BOMList, 2))
                    End If

StudBoltNotFound:
                Case Is < InStr(MaterialPart2, "SCREW")
                    GoTo MachineScrewItems
                Case Is < InStr(MaterialPart2, "CHAIN")
                    MaterialPart2 = GetDesc

                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

                    If InStr(MaterialPart2, "CHAIN 3/16" & Chr(34) & " x 1" & Chr(39) & "-6" & Chr(34)) > 0 Then
                        MaterialPart2 = Replace(MaterialPart2, "CHAIN 3/16" & Chr(34) & " x 1" & Chr(39) & "-6" & Chr(34), "CHAIN 3/16" & Chr(34) & " x 18" & Chr(34))
                    End If

                    If InStr(MaterialPart2, "CHAIN 3/16 x 1" & Chr(39) & "-6" & Chr(34)) > 0 Then
                        MaterialPart2 = Replace(MaterialPart2, "CHAIN 3/16" & " x 1" & Chr(39) & "-6" & Chr(34), "CHAIN 3/16" & Chr(34) & " x 18" & Chr(34))
                    End If

                    SearchPos = InStr(MaterialPart2, "McMASTER")

                    If SearchPos > 1 Then
                        MaterialPart2 = Replace(MaterialPart2, "   ", " ")
                        MaterialPart2 = Replace(MaterialPart2, "  ", " ")
                        MaterialPart2 = Replace(MaterialPart2, "McMASTER-CARR", "")
                        MaterialPart2 = Replace(MaterialPart2, "McMASTER CARR", "")
                        MaterialPart2 = "MCMASTER CARR " & MaterialPart2
                        MaterialPart2 = Replace(MaterialPart2, "  ", " ")
                        MaterialPart2 = Replace(MaterialPart2, "CHAIN 3/16" & Chr(34) & " x 18" & Chr(34), "3/16" & Chr(34) & " x 18 " & Chr(34) & "CHAIN")
                        MaterialPart2 = Replace(MaterialPart2, "(ITEM #", "#")
                        MaterialPart2 = Replace(MaterialPart2, ")", "")
                    End If

ChainNotFound:
                Case Else
                    If InStr(MaterialPart2, GetMatType) = 0 Then
                        MaterialPart2 = MaterialPart2 & " - " & GetMatType
                    End If

                    Select Case 0
                        Case Is < InStr(MaterialPart2, "P-WC17-5020-BXC")
                            'MatData = ManwayInfo3134.MiscData
                            GetSc = "P-WC17-5020-BXC"
                        Case Is < InStr(MaterialPart2, "LECTRA SHIELD LEC")
                            'MatData = ManwayInfo3134.MiscData
                            GetSc = "LECTRA SHIELD LEC"
                        Case Is < InStr(MaterialPart2, "UNION")
                            'GetCommidity = "Fitting"
                            'MatData = ManwayInfo3134.FittingData
                            GetSc = Nothing
                        Case Is < InStr(MaterialPart2, "FLOAT WELL")
                            'GetPurchaseTyp = myarray(14, j)
                            BOMList(6, j) = "Header only"                         ''myarray(14, i) = "Header only"
                            ReDim Preserve BOMList(20, UBound(BOMList, 2))

                            GetSc = Nothing
                            GoTo NextItem
                        Case Is < InStr(MaterialPart2, "GFI GG-1A")
                            'MatData = ManwayInfo3134.FittingData
                            GetSc = "GFI GG-1A"
                        Case Is < InStr(MaterialPart2, "EF-12-1616")            '-------Bushing
                            SearchPos = InStr(MaterialPart2, "EF-12-1616")
                            If SearchPos > 1 Then
                                MaterialPart1 = Mid(MaterialPart2, 1, (SearchPos - 1))
                                MaterialPart3 = Mid(MaterialPart2, (SearchPos + 10), Len(MaterialPart2))
                                MaterialPart2 = MaterialPart1 & "EF-121616" & MaterialPart3
                                MaterialPart2 = UCase(MaterialPart2)
                            End If

                            'MatData = ManwayInfo3134.FittingData
                            GetSc = "BUSH0065"
                        Case Is < InStr(MaterialPart2, "(DWG")
                            GoTo NextItem
                        Case Is < InStr(MaterialPart2, "SEE DRAWING")
                            GoTo NextItem
                        Case Is < InStr(MaterialPart2, "SEE DWG")
                            GoTo NextItem
                        Case Is < InStr(MaterialPart2, "DWG")
                            GoTo NextItem
                        Case Is < InStr(MaterialPart2, "FOAM MAKER")
                            SearchPos = InStr(MaterialPart2, "FOAM MAKER")
                            If SearchPos > 1 Then
                                MaterialPart1 = Mid(MaterialPart2, 1, (SearchPos - 1))
                                MaterialPart3 = Mid(MaterialPart2, (SearchPos + 10), Len(MaterialPart2))
                                MaterialPart2 = "FOAM MAKER, " & MaterialPart1 & MaterialPart3
                                MaterialPart2 = UCase(MaterialPart2)
                            End If

                            SearchPos = InStr(MaterialPart2, "LW-9") Or SearchPos = InStr(MaterialPart2, "LW9")
                            If SearchPos > 1 Then
                                GetSc = "FM-LW9"
                            End If

                            'MatData = ManwayInfo3134.AllMatSortDesc
                        Case Is < InStr(MaterialPart2, "SHELL NOZZLE")
                            GoTo ElseItems
                        Case Is < InStr(MaterialPart2, "ELL") And InStr(MaterialPart2, "GRINNELL") < 1
                            SearchPos = InStr(MaterialPart2, "ELL SCRD")

                            Select Case 0
                                Case Is < InStr(MaterialPart2, "90") And InStr(MaterialPart2, "ELL SCRD") > 0
                                    If SearchPos = 1 Then                           '-------SCREWED ELBOW
                                        MaterialPart1 = Mid(MaterialPart2, 9, Len(MaterialPart2))
                                        MaterialPart1 = LTrim(MaterialPart1)
                                        MaterialPart1 = RTrim(MaterialPart1)
                                        MaterialPart2 = "ELL BW " & MaterialPart1
                                        MaterialPart2 = UCase(MaterialPart2)
                                        SearchPos = InStr(MaterialPart2, (" - " & GetMatType))

                                        If SearchPos > 0 Then
                                            MaterialPart1 = Mid(MaterialPart2, 1, (SearchPos - 1))
                                            MaterialPart2 = MaterialPart1 & " SR" & " - " & GetMatType
                                        End If
                                    End If
                                Case Is < InStr(MaterialPart2, "90") And InStr(MaterialPart2, "ELL REDUCING") > 0
                                    SearchPos = InStr(MaterialPart2, "ELL REDUCING BW")

                                    If SearchPos = 1 Then
                                        MaterialPart1 = Mid(MaterialPart2, 16, Len(MaterialPart2))
                                        MaterialPart1 = LTrim(MaterialPart1)
                                        MaterialPart1 = RTrim(MaterialPart1)
                                        MaterialPart2 = "REDUCING ELL BW " & MaterialPart1
                                        MaterialPart2 = UCase(MaterialPart2)
                                    End If
                                Case Else
                                    MaterialPart2 = MaterialPart2
                            End Select

                                'MatData = ManwayInfo3134.FittingData
                        Case Is < InStr(MaterialPart2, "EXPANDED METAL ")
                            SearchPos = InStr(MaterialPart2, "EXPANDED METAL ")
                            If SearchPos = 1 Then
                                MaterialPart1 = Mid(MaterialPart2, (SearchPos + 15), Len(MaterialPart2))
                                MaterialPart2 = "EXP METAL " & MaterialPart1
                            End If

                            SearchPos = InStr(MaterialPart2, "L 1/2")
                            'If SearchPos > 1 Then
                            '    GetSc = "EXP-112-6S-48"
                            'End If

                            'MatData = ManwayInfo3134.StructureData
                        Case Is < InStr(MaterialPart2, "GREASE FITTING")                '-------Grease Fittings
                            SearchPos = InStr(MaterialPart2, "McMASTER")

                            If SearchPos > 1 Then
                                MaterialPart2 = Replace(MaterialPart2, "McMASTER-CARR", "")
                                MaterialPart2 = Replace(MaterialPart2, "McMASTER CARR", "")
                                MaterialPart2 = "MCMASTER CARR " & MaterialPart2
                                MaterialPart2 = Replace(MaterialPart2, "GREASE FITTING", "STRAIGHT GREASE ZERK")
                            End If

                            'MatData = ManwayInfo3134.HardwareData
                        Case Is < InStr(MaterialPart2, "SOCKET")
                            'MatData = ManwayInfo3134.FittingData
                        Case Is < InStr(MaterialPart2, "MCMASTER CARR")
                            SearchPos = InStr(MaterialPart2, "McMASTER")

                            If SearchPos > 1 Then
                                MaterialPart2 = Replace(MaterialPart2, "   ", " ")
                                MaterialPart2 = Replace(MaterialPart2, "  ", " ")
                                MaterialPart2 = Replace(MaterialPart2, "McMASTER-CARR", "")
                                MaterialPart2 = Replace(MaterialPart2, "McMASTER CARR", "")
                                MaterialPart2 = "MCMASTER CARR " & MaterialPart2
                                MaterialPart2 = Replace(MaterialPart2, "GREASE FITTING", "STRAIGHT GREASE ZERK")
                                MaterialPart2 = Replace(MaterialPart2, "  ", " ")
                                MaterialPart2 = Replace(MaterialPart2, "7-STRAND WIRE 1" & Chr(39) & "-6" & Chr(34) & " #7512K72 - COPPER", "COPPER 7-STRAND WIRE 5-0" & Chr(34) & " #7512K72")
                            End If

                            'MatData = ManwayInfo3134.HardwareData
                        Case Is < InStr(MaterialPart2, "MCMASTER-CARR")                '-------Chain Link
                            SearchPos = InStr(MaterialPart2, "McMASTER")

                            If SearchPos > 1 Then
                                MaterialPart2 = Replace(MaterialPart2, "McMASTER-CARR", "")
                                MaterialPart2 = Replace(MaterialPart2, "McMASTER CARR", "")
                                MaterialPart2 = "MCMASTER CARR " & MaterialPart2
                                MaterialPart2 = Replace(MaterialPart2, "THREADED CONNECTORS", "THREADED CHAIN LINK CONNECTOR")
                            End If

                            MaterialPart2 = Replace(MaterialPart2, "(ITEM #8947T15 )", "#8947T15")
                            MaterialPart2 = Replace(MaterialPart2, "(ITEM #8947T15)", "#8947T15")
                            MaterialPart2 = Replace(MaterialPart2, "   ", " ")
                            MaterialPart2 = Replace(MaterialPart2, "  ", " ")
                            'MatData = ManwayInfo3134.HardwareData
                        Case Is < InStr(MaterialPart2, "MCMASTER/CARR")                '-------Chain Link
                            SearchPos = InStr(MaterialPart2, "McMASTER")

                            If SearchPos > 1 Then
                                MaterialPart2 = Replace(MaterialPart2, "McMASTER/CARR", "")
                                MaterialPart2 = Replace(MaterialPart2, "McMASTER-CARR", "")
                                MaterialPart2 = Replace(MaterialPart2, "McMASTER CARR", "")
                                MaterialPart2 = "MCMASTER CARR " & MaterialPart2
                            End If

                            MaterialPart2 = Replace(MaterialPart2, "(ITEM #91152A033 )", "#91152A033")
                            MaterialPart2 = Replace(MaterialPart2, "(ITEM #91152A033)", "#91152A033")
                            'MatData = ManwayInfo3134.HardwareData
                        Case Else
ElseItems:
                            BOMList(6, j) = "PURCHASE ITEM"
                            ReDim Preserve BOMList(20, UBound(BOMList, 2))

                            'MatData = ManwayInfo3134.AllMatSortDesc
                            'MaterialPart2 = MaterialPart2
                            GetSc = Nothing
                    End Select

                    If GetPartNo <> Nothing Then
                        GoTo FoundMat2
                    End If

                    If InStr(MaterialPart2, "   ") Then
                        MaterialPart2 = Replace(MaterialPart2, "   ", " ")
                    End If

                    If InStr(MaterialPart2, "  ") Then
                        MaterialPart2 = Replace(MaterialPart2, "  ", " ")
                    End If

                    If InStr(MaterialPart2, "  ") Then
                        MaterialPart2 = Replace(MaterialPart2, "  ", " ")
                    End If

                    If InStr(MaterialPart2, "  ") Then
                        MaterialPart2 = Replace(MaterialPart2, "  ", " ")
                    End If

                    '-------This part was looking for Part number in a database to supply Fab's material Number.
PartNotFound:
            End Select

FoundMat2:                         '-------Not required anymore above is not wanted anymore.
            ItemFound = "Yes"
            AddItem2 = "Done"
            PurchaseProb = False

NextItem:
            Dim SeeDwgPos2 As Integer
            Dim SearchDwg2 As String

            If ItemFound = "No" Then
                Fnd = 0
                Desc = 0
                Ref = 0
                SearchDwg = "(SEE DWG"
                SearchShell = "SHELL"
                GetPurchaseTyp = BOMList(6, j)                         ' GetPurchaseTyp = BOMList(14, j)

                If InStr(1, BOMList(6, j), "Not Found") = 0 Then           'If InStr(1, myarray(14, i), "Not Found") = 0 Then
                    Fnd = InStr(1, BOMList(6, j), "Found")                 'Fnd = InStr(1, myarray(14, i), "Found")
                End If

                Desc = InStr(1, BOMList(6, j), "Description")              'Desc = InStr(1, myarray(14, i), "Description")
                Ref = InStr(1, BOMList(6, j), "Reference")                 'Ref = InStr(1, myarray(14, i), "Reference")
                SearchShell = "Shell"
                SearchDwg = "(See Dwg"
                SeeDwgPos = InStr(1, GetDesc, SearchDwg)
                SeeDwgPos2 = InStr(GetDesc, "SEE DRAWING")

                If SeeDwgPos = 0 Then
                    SeeDwgPos = InStr(GetDesc, "SEE DWG")
                End If

                'If SeeDwgPos = 0 Then
                '    SeeDwgPos = InStr(GetDesc, "DWG")
                'End If

                ShellPos = InStr(1, GetDesc, SearchShell)
                Test = GetDesc

                'GetPurchaseTyp = (BOMList(6, j))                          'GetPurchaseTyp = (myarray(14, i))
                'Dim HeaderFound As Integer
                'HeaderFound = InStr(BOMList(6, j), "Header Only")         ''HeaderFound = InStr(myarray(14, i), "Header Only")

                If Fnd > 0 Then
                    AddItem = "No"
                Else
                    If Ref > 0 Then
                        AddItem = "Yes"
                    Else
                        If Desc > 0 Then
                            AddItem = "No"
                        Else
                            If SeeDwgPos > 0 Then
                                AddItem = "No"
                            Else
                                If SeeDwgPos2 > 0 Then
                                    AddItem = "No"
                                Else
                                    'If HeaderFound > 0 Then
                                    '    AddItem = "No"
                                    'Else

                                    AddItem = "Yes"
                                    'End If
                                End If
                            End If
                        End If
                    End If
                End If

                If AddItem = "Yes" And AddItem2 <> "Done" Then
                    GetPurchaseTyp = BOMList(6, j)                         'GetPurchaseTyp = myarray(14, i)
                    GetDesc = BOMList(7, j)                                 'GetDesc = myarray(7, i)

                    If IsNothing(GetPurchaseTyp) = True Then
                        Select Case 0
                            Case Is < InStr(GetDesc, "BOLT")
                                BOMList(6, j) = "PURCHASE ITEM"                           'myarray(14, i) = "PURCHASE ITEM"
                            Case Is < InStr(GetDesc, "NUT")
                                BOMList(6, j) = "PURCHASE ITEM"                           'myarray(14, i) = "PURCHASE ITEM"
                            Case Is < InStr(GetDesc, "GASKET")
                                BOMList(6, j) = "PURCHASE ITEM"                           'myarray(14, i) = "PURCHASE ITEM"
                            Case Else
                                'Stop
                                BOMList(6, j) = "PURCHASE ITEM"                           'myarray(14, i) = "PURCHASE ITEM"
                        End Select
                    Else
                        If InStr(GetPurchaseTyp, "Standard Reference only") > 0 Then
                            Select Case 0
                                Case Is < InStr(GetDesc, "BOLT")
                                    BOMList(6, j) = "PURCHASE ITEM"                           'myarray(14, i) = "PURCHASE ITEM"
                                Case Is < InStr(GetDesc, "NUT")
                                    BOMList(6, j) = "PURCHASE ITEM"                           'myarray(14, i) = "PURCHASE ITEM"
                                Case Is < InStr(GetDesc, "GASKET")
                                    BOMList(6, j) = "PURCHASE ITEM"                           'myarray(14, i) = "PURCHASE ITEM"
                            End Select
                        Else
                            Select Case GetPurchaseTyp
                                Case "PLATE STEEL"
                                            'Do nothing everything is ok.
                                Case "PURCHASE ITEM"
                                            'Do nothing everything is ok.
                                Case "GRATING"
                                    'Do nothing everything is ok.
                            End Select
                        End If
                    End If

                    AddItem2 = "Done"
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                End If
            End If

FoundMat:
            If Fnd > 0 Then
                AddItem = "No"
            Else
                If Ref > 0 Then
                    AddItem = "Yes"
                Else
                    If Desc > 0 Then
                        AddItem = "No"
                    Else
                        If SeeDwgPos > 0 Then
                            AddItem = "No"
                        Else
                            AddItem = "Yes"
                        End If
                    End If
                End If
            End If

            If AddItem = "Yes" And AddItem2 <> "Done" Then
                BOMList(6, j) = "PURCHASE ITEM"                           'myarray(14, i) = "PURCHASE ITEM"
                ReDim Preserve BOMList(20, UBound(BOMList, 2))
            Else
                If BOMList(6, j) = "" Or BOMList(6, j) = Nothing Then
                    BOMList(6, j) = "PURCHASE ITEM"                           'myarray(14, i) = "PURCHASE ITEM"
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                End If
            End If

            Fnd = 0
            Desc = 0
            Ref = 0
            ItemFound = "No"
            MatInch = 0

            'If ManwayInfo3134.RevNo = 0 Then
            '.Range("R" & (i + 4)).Value = "1"
            '.Range("A" & (i + 4) & ":L" & (i + 4)).Interior.ColorIndex = 4
            'End If

            GetSc = Nothing
            AddItem2 = Nothing
        Next ii
        'End With

        BOMMnu.ProgressBar1.Value = 0
        WorkShtName = "Bulk BOM"
        BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
        id = 1

        Dim BOMRowNo, NumSkipped As Integer
        BOMRowNo = (id + 4)
        RowNo = CStr(id + 4)
        PlateRowNo = CStr(id + 4)
        StickRowNo = CStr(id + 4)
        GratingRowNo = CStr(id + 4)
        PurchaseRowNo = CStr(id + 4)
        'Count = BOMWrkSht.Range("E4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row
        Count = UBound(BOMList, 2)

        If ManwayInfo3134.RevNo = Nothing Then
            With BOMWrkSht
                ManwayInfo3134.RevNo = .Range("F3").Value
            End With
        End If

        For i = 1 To Count - 1
            If i = PrevI Then
                BOMMnu.ProgressBar1.Maximum = Count
                i = (i + 1)
            End If

            MatType = BOMList(6, i)                            'MatType = BOMList(14, i)
            BOMMnu.ProgressBar1.Value = i
            FileToOpen = "Bulk BOM"
            BOMWrkSht.Activate()

            GetDesc = BOMList(7, i)
            TestGetDwgNo = BOMList(1, i)                    'TestGetDwgNo = BOMList(2, i)
            TestShpMk = BOMList(3, i)                       'TestShpMk = BOMList(4, i)

            If TestShpMk = Nothing Then
                TestShpMk = BOMList(5, i)                   'TestShpMk = BOMList(1, i)
            End If

            RowNoNew = BOMList(20, i)

            With BOMWrkSht

FindPartNext:
                GetDescSpSht = .Range("G" & BOMRowNo).Value                         'GetDescSpSht = .Range("G" & BOMRowNo).Value
                '-------Problem G = 3/8" STD WT PiPE x 8 5/16"
                '-------GetDesc = PIPE 3/8" STD WT PIPE x 8 5/16"

                Test4 = BOMList(19, i)
                Dim SearchUBolt As String
                Dim UBoltFound As Integer

                Search = "PIPE"
                SearchFound = InStr(1, GetDescSpSht, Search)
                SearchUBolt = "UBOLT"
                UBoltFound = InStr(1, GetDescSpSht, SearchUBolt)

                If UBoltFound = 0 Then
                    SearchUBolt = "U-BOLT"
                    UBoltFound = InStr(1, GetDescSpSht, SearchUBolt)
                End If

                If UBoltFound = 0 Then
                    SearchUBolt = "NU-BOLT"
                    UBoltFound = InStr(1, GetDescSpSht, SearchUBolt)
                End If

                If SearchFound > 1 And UBoltFound = 0 Then
                    Test3 = Mid(GetDescSpSht, 1, (SearchFound - 1))
                    Test4 = Mid(GetDescSpSht, (SearchFound + 5), Len(GetDescSpSht))         'Test4 = Mid(GetDescSpSht, (SearchFound + 4), Len(GetDescSpSht))
                    Test3 = RTrim(Test3)

                    If InStr(GetDescSpSht, "DIFFUSER") = 0 And InStr(GetDescSpSht, "SUPPORT") = 0 Then
                        If InStr(GetDescSpSht, "CONNECTION") = 0 Then
                            GetDescSpSht = "PIPE " & Test3 & Test4

                            If Mid(GetDescSpSht, Len(GetDescSpSht), 1) = Chr(34) Then
                                GetDescSpSht = Mid(GetDescSpSht, 1, (Len(GetDescSpSht) - 1))
                            End If
                        End If
                    End If
                End If

                If GetDesc <> GetDescSpSht Then
                    If InStr(GetDescSpSht, "PIPE") > 0 Then
PipeItemTest2:
                        GetDescSpSht = GetDescSpSht
                        GetDesc = Replace(GetDesc, "   ", " ")
                        GetDesc = Replace(GetDesc, "  ", " ")
                        GetDescSpSht = Replace(GetDescSpSht, "   ", " ")
                        GetDescSpSht = Replace(GetDescSpSht, "  ", " ")
                    End If
                End If

                If GetDesc <> GetDescSpSht Then
                    GetDesc = Replace(GetDesc, " ", "")
                    GetDesc = Replace(GetDesc, Chr(34), "")
                    GetDesc = Replace(GetDesc, Chr(39), "")
                    GetDescSpSht = Replace(GetDescSpSht, " ", "")
                    GetDescSpSht = Replace(GetDescSpSht, Chr(34), "")
                    GetDescSpSht = Replace(GetDescSpSht, Chr(39), "")
                End If

                If GetDesc <> GetDescSpSht And InStr(1, GetDesc, "PL") = 1 Then
                    If InStr(GetDescSpSht, "HOSE CLAMP") > 0 Or InStr(GetDescSpSht, "HOSECLAMP") > 0 Then
                        GetDesc = GetDescSpSht
                    Else
                        If TestShpMk <> PrevShpMk And IsNothing(PrevShpMk) = False Then
                            GetStdDwg = .Range("I" & BOMRowNo).Value

                            If System.Environment.UserName = "dlong" And GetStdDwg <> TestGetDwgNo Then
                                RowNoNew = BOMList(20, i)
                                GetDesc = BOMList(7, i)
                                GetDwgNo = BOMList(1, i)
                                TestGetDwgNo = BOMList(2, i)
                                TestShpMk = BOMList(1, i)

                                If RowNoNew < BOMRowNo Then
                                    GetDescSpSht = .Range("G" & RowNoNew).Value         'GetDescSpSht = .Range("G" & RowNoNew).Value
                                    GetDwgNoSpSht = .Range("B" & RowNoNew).Value
                                End If

                                If GetDesc = GetDescSpSht And GetDwgNoSpSht = GetDwgNo Then
                                    BOMRowNo = RowNoNew
                                    GoTo FindPartNext
                                End If

                                MsgBox("Please Have Dennis J. Long Look at drawing " & TestGetDwgNo & " something is wrong with part " & TestShpMk & ".")
                            End If
                        End If
                    End If
                End If

                PrevShpMk = TestShpMk

                If GetDesc = GetDescSpSht Then
                    Dim TestQty As Integer
                    TestQty2 = BOMList(4, i)

                    If TestQty2 = "-" Then
                        TestQty2 = 0
                    End If

                    If TestQty2 = "TBD" Then
                        TestQty2 = 0
                    End If

                    If Mid(TestQty2, 1, 1) = "?" Or Mid(TestQty2, Len(TestQty), 1) = "?" Then
                        TestQty2 = 0
                    End If

                    TestQty = TestQty2
                    GetProdCode = BOMList(19, i)

                    If GetProdCode = "" Or GetProdCode = Nothing Then
                        GoTo NextLine
                    End If

                    Select Case 0
                        Case Is < InStr(GetProdCode, "True")
                            GoTo NextLine
                        Case Is < InStr(GetProdCode, "False")
                            GoTo NextLine
                        Case Is < InStr(GetProdCode, "NOTE")
                            GoTo NextLine
                        Case Else
                            Dim TotalLeng As Double
                            Dim TestProdCode As String
                            TestProdCode = .Range("M" & BOMRowNo).Value
                            GetDesc = .Range("G" & BOMRowNo).Value
                            GetDesc2 = BOMList(7, i)
                            MatQty = BOMList(4, i)

                            If TestProdCode = Nothing Or TestProdCode = "" Then
                                If GetProdCode = "0" Or TestQty = 0 Then
                                    If TestQty = 0 Then
                                        TotalLeng = GetProdCode
                                        GoTo JustQty
                                    End If

                                    If GetProdCode = "0" Then
                                        Dim DblChkQty As Double
                                        DblChkQty = .Range("F" & BOMRowNo).Value

                                        If DblChkQty <> TestQty Then
                                            Stop
                                            TotalLeng = DblChkQty
                                        Else
                                            TotalLeng = TestQty
                                        End If

                                        GoTo JustQty
                                    End If
                                Else
                                    If GetProdCode = TestQty Then

                                        Select Case 0
                                            Case Is < InStr(MatType, "ANGLE")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(MatType, "FLATBAR")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(MatType, "FLAT BAR")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(MatType, "PIPE")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(MatType, "IBEAM")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(MatType, "ROUND BAR")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(MatType, "SQUARE BAR")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(GetDesc, "FLANGE")
                                                TotalLeng = BOMList(19, i)
                                                GoTo JustQty
                                            Case Is < InStr(GetDesc, "SCREW")
                                                TotalLeng = BOMList(19, i)
                                                GoTo JustQty
                                        End Select

                                        TotalLeng = GetProdCode
                                        GoTo JustQty
                                    Else
                                        Select Case 0
                                            Case Is < InStr(MatType, "ANGLE")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(MatType, "CHANNEL")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(MatType, "FLATBAR")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(MatType, "FLAT BAR")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(MatType, "GRATING")
                                                TotalLeng = BOMList(19, i)
                                                GoTo GratingTotal
                                            Case Is < InStr(MatType, "PIPE")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(MatType, "IBEAM")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(MatType, "ROUND BAR")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Is < InStr(MatType, "SQUARE BAR")
                                                TotalLeng = BOMList(19, i)
                                                GoTo StickTotal
                                            Case Else
                                                TotalLeng = BOMList(19, i)
                                                GoTo JustQty
                                        End Select
                                    End If
                                End If
StickTotal:
                                '.Range("M" & BOMRowNo).Value = ((TotalLeng * MatQty) / 12)      'NOTE REQUIRED PER TREVOR ANYMORE.   'Robert Hubbard requested linear in Feet.
                                GoTo TotalsDone
GratingTotal:
                                Select Case 0
                                    Case Is < InStr(GetDesc, "2'-5 5/8")
                                        TreadLen = "2'-6" & Chr(34)
                                        TreadWidPos = InStr(GetDesc, "2'-5 5/8")
                                        GetDesc1 = Mid(GetDesc, 1, (TreadWidPos - 1))
                                        LenGetDesc1 = Len(GetDesc1)
                                        Test = Mid(GetDesc1, (LenGetDesc1 - 2), 3)

                                        If Test = " x " Then
                                            GetDesc1 = Mid(GetDesc1, 1, (LenGetDesc1 - 3))
                                        End If

                                        If InStr(GetDesc1, SearchX) > 0 Then
                                            Xpos = InStr(GetDesc1, SearchX)
                                            If Xpos > 0 Then
                                                TreadWid = Mid(GetDesc1, (Xpos + 3), Len(GetDesc1))
                                            End If
                                        End If

                                        Xpos = InStr(TreadWid, SearchX)

                                        While Xpos > 0
                                            TreadWid = Mid(TreadWid, (Xpos + 3), Len(TreadWid))
                                            Xpos = InStr(TreadWid, SearchX)
                                        End While

                                    Case Is < InStr(GetDesc, SearchX)
                                        Select Case 0
                                            Case Is < InStr(GetDesc, "GRATING SERRATED 3/16" & Chr(34) & " x 1" & Chr(34) & " x 36" & Chr(34) & " x")
                                                GetDesc = ("GRATING SERRATED 3/16" & Chr(34) & " x 1" & Chr(34) & " x 36" & Chr(34) & " x")
                                                If InStr(GetMatType, Chr(10)) > 0 Then
                                                    SearchPos = InStr(GetMatType, Chr(10))
                                                    GetMatType = Mid(GetMatType, (SearchPos + 1), Len(GetMatType))
                                                End If

                                                If InStr(GetDesc, " - " & GetMatType) > 0 Then
                                                    SearchPos = InStr(GetDesc, " - " & GetMatType)
                                                    GetDesc = Mid(GetDesc, 1, (SearchPos - 1))
                                                End If

                                            Case Is < InStr(GetDesc, "GRATING SERRATED 3/16" & Chr(34) & " x 1" & " x 36" & Chr(34) & " x")
                                                GetDesc = ("GRATING SERRATED 3/16" & Chr(34) & " x 1" & Chr(34) & " x 36" & Chr(34) & " x")
                                                If InStr(GetMatType, Chr(10)) > 0 Then
                                                    SearchPos = InStr(GetMatType, Chr(10))
                                                    GetMatType = Mid(GetMatType, (SearchPos + 1), Len(GetMatType))
                                                End If

                                                If InStr(GetDesc, " - " & GetMatType) > 0 Then
                                                    SearchPos = InStr(GetDesc, " - " & GetMatType)
                                                    GetDesc = Mid(GetDesc, 1, (SearchPos - 1))
                                                End If
                                            Case Is < InStr(GetDesc, "GRATING/S 3/16 x 1 x")
                                                GetDesc = Replace(GetDesc, "GRATING/S 3/16 x 1 x", "")

                                                If InStr(GetDesc, " x ") > 0 Then
                                                    SearchPos = InStr(GetDesc, " x ")
                                                    TreadWid = Mid(GetDesc, 1, (SearchPos - 1))
                                                    TreadLen = Mid(GetDesc, (SearchPos + 3), Len(GetDesc))
                                                    SearchPos = InStr(TreadLen, "2'-5 5/8")

                                                    If SearchPos > 0 Then
                                                        TreadLen = "2'-6" & Chr(34)
                                                    End If
                                                End If
                                        End Select
                                End Select

                                TreadWidDbl = FToD(TreadWid)
                                TreadLenDbl = FToD(TreadLen)
                                TreadSqFt = (TreadLenDbl * TreadWidDbl)
                                TotalLeng = BOMList(19, i)

                                'With BOMList
                                '    BOMList(19, i) = ((TreadSqFt * MatQty) / 12)        '.Range("M" & BOMRowNo).Value = ((TreadSqFt * MatQty) / 12)
                                '    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                                'End With

                                GoTo TotalsDone
JustQty:
                                '.Range("M" & BOMRowNo).Value = TotalLeng
                                GoTo TotalsDone
                            End If
TotalsDone:
                            'With .Range("M" & BOMRowNo & ":M" & BOMRowNo)
                            '    With .Interior
                            '        .ColorIndex = 4
                            '        .Pattern = Constants.xlSolid
                            '    End With
                            'End With

                            TotalLeng = 0
                    End Select
NextLine:
                    NumSkipped = (BOMRowNo - i)
                    'FndStdNote2 = BOMList(19, i)

                    'With BOMWrkSht
                    'Select Case 0
                    '    Case Is < InStr(FndStdNote2, "* None needed")
                    '        .Range("P" & BOMRowNo).Value = FndStdNote2
                    '        With .Range("O" & BOMRowNo & ":P" & BOMRowNo)
                    '            With .Interior
                    '                .ColorIndex = 4
                    '                .Pattern = Constants.xlSolid
                    '            End With
                    '        End With
                    'Case Is < InStr(FndStdNote2, "**Need Number")
                    '    .Range("P" & BOMRowNo).Value = FndStdNote2
                    '    With .Range("O" & BOMRowNo & ":P" & BOMRowNo)
                    '        With .Interior
                    '            .ColorIndex = 7
                    '            .Pattern = Constants.xlSolid
                    '        End With
                    '    End With
                    'Case Is < InStr(FndStdNote2, "Need Part")
                    '    .Range("P" & BOMRowNo).Value = FndStdNote2
                    '    With .Range("O" & BOMRowNo & ":P" & BOMRowNo)
                    '        With .Interior
                    '            .ColorIndex = 7
                    '            .Pattern = Constants.xlSolid
                    '        End With
                    '    End With
                    'Case Else
                    'If FndStdNote2 = Nothing Then
                    '    GetPartNo = BOMList(15, i)

                    '    If GetPartNo = Nothing Then
                    '        With .Range("O" & BOMRowNo & ":P" & BOMRowNo)
                    '            With .Interior
                    '                .ColorIndex = 7
                    '                .Pattern = Constants.xlSolid
                    '            End With
                    '        End With

                    '        If ManwayInfo3134.RevNo = 0 Then
                    '            .Range("R" & BOMRowNo).Value = "1"
                    '            .Range("A" & BOMRowNo & ":L" & BOMRowNo).Interior.ColorIndex = 4
                    '        End If

                    '        GoTo EndFindPart
                    '    End If
                    'End If

                    '.Range("O" & BOMRowNo).Value = GetPartNo                           'NOT REQUIRED ANYMORE.
                    'With .Range("O" & BOMRowNo & ":P" & BOMRowNo)
                    '    With .Interior
                    '        .ColorIndex = 4
                    '        .Pattern = Constants.xlSolid
                    '    End With
                    'End With
                    'End Select

                    'If ManwayInfo3134.RevNo = 0 Then
                    '    If BOMRowNo = 5 Then
                    '        .Range("R" & (BOMRowNo - 1)).Value = "Color Code No"
                    '        .Range("R" & (BOMRowNo - 1)).Font.Bold = True
                    '        .Range("R" & (BOMRowNo - 1)).Font.Size = 12
                    '        .Range("R" & (BOMRowNo - 1)).Orientation = 90
                    '    End If
                    'End If
                    GoTo UpdateNextSht
                    'End With
                    'EndFindPart:

                Else                        'IF ITEM IS NOT FOUND OR SOMETHING HAS BEEN ADDED AND PARTS ARE OUT OF ORDER.
                    If BOMRowNo < (i + (CntFndStdInfo + 1)) Then
                        BOMRowNo = CStr(CDbl(BOMRowNo) + 1)
                        GoTo FindPartNext
                    Else
                        CntFndStdInfo = (CntFndStdInfo + 1)

                        If BOMRowNo < (Count + 1) Then
                            BOMRowNo = CStr(CDbl(BOMRowNo) + 1)
                            GoTo FindPartNext
                        Else
                            RowNoNew = BOMList(20, i)
                            GetDesc = BOMList(7, i)
                            GetDwgNo = BOMList(1, i)
                            TestGetDwgNo = BOMList(2, i)
                            TestShpMk = BOMList(1, i)
                            GetDescSpSht = .Range("G" & RowNoNew).Value         'GetDescSpSht = .Range("G" & RowNoNew).Value
                            GetDwgNoSpSht = .Range("B" & RowNoNew).Value

                            If GetDesc = GetDescSpSht And GetDwgNoSpSht = GetDwgNo Then
                                BOMRowNo = RowNoNew
                                GoTo FindPartNext
                            End If

                            BOMRowNo = ((i + NumSkipped) + 3)
                            CntFndStdInfo = NumSkipped
                            GoTo NextI
                        End If
                    End If
UpdateNextSht:
                End If
            End With

NextI:
            If BOMRowNo < Count Then
                BOMRowNo = (BOMRowNo + 1)
            End If

            MatQty = Nothing
            MatLengthDbl = Nothing
            PrevI = i
        Next i

        BOMMnu.ProgressBar1.Value = 1
        RowNo = CStr(CDbl(RowNo) - 1)
        PlateRowNo = CStr(CDbl(PlateRowNo) - 1)
        StickRowNo = CStr(CDbl(StickRowNo) - 1)
        PurchaseRowNo = CStr(CDbl(PurchaseRowNo) - 1)
        GratingRowNo = CStr(CDbl(GratingRowNo) - 1)
Err_ShopCUT:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

            BOMMnu.HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)
            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                If ErrNo = "5" And InStr(ErrMsg, "must be greater or equal to zero.") > 0 Then
                    ProbPart = (myarray(7, j))          'ProbPart = (myarray(7, i))
                    PurchaseProb = True
                    Resume Next
                End If
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                If ErrNo = "5" And InStr(ErrMsg, "must be greater or equal to zero.") > 0 Then
                    ProbPart = (myarray(7, j))                          'ProbPart = (myarray(7, i))
                    PurchaseProb = True
                    Resume Next
                End If
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Function

    Function FeetInchesToDecInches(ByVal MaterialPart As String, ByVal DwgNum As String, ByVal ItemNum As String, ByVal ErrFound As String, ByVal FullJobNo As String) As Object           'DwgItem
        Dim FoundSch, FoundStd, FoundX, FoundInch, FoundFoot, FoundFraction, LenMatPart, PartFoundX, InchPos, XSpacePos2 As Integer
        Dim FoundDash, FoundSpace, FoundFoot2, XSpacePos, OPos, MMPos, LastCnt, FoundPos, DashPos As Integer
        Dim SearchPipe, SearchX, SearchInch, SearchSch, SearchStd, SearchShell, SearchDwg, SearchFoot As String
        Dim SearchFraction, SearchDash, SearchNote, Test, MaterialPart1st, MaterialPart2nd, EndPart As String
        Dim MatLength, StripMatPart, StripMatPart1st, StripMatPart2nd, LastChr, LastChrFnd, SearchDblFraction As String
        Dim DecInches, SearchSpace, SearchRoll2, SearchBracket, ChkChrBeforeDash, DecInches1, DecInches2 As String
        Dim FeetLength, FeetTotal, InchFraction, FstFraction, SndFraction, DecFraction As Double
        Dim i As Short, i2 As Short
        Dim LastPart, LastPart2, TestChr, FixPart1, FixPart2, FoundChr As String
        Dim SearchBBE, SearchBBL, SearchBOE, SearchBW, SearchCBE, SearchCOE As String
        Dim SearchG, SearchGAL, SearchMBE, SearchMOE, SearchNPT, SearchPBE As String
        Dim SearchSOL, SearchTBE, SearchTOE, SearchTOL, SearchTS, SearchWOL, SearchRoll, SearchSMLS, TestInchMk As String
        Dim LenBBE, Cnt, NotePos As Integer
        Dim FoundBBE, FoundBBL, FoundBOE, FoundBW, FoundCBE, FoundCOE, FoundG As Integer
        Dim FoundGAL, FoundMBE, FoundMOE, FoundNPT, FoundPBE, FoundSOL, FoundTBE, FoundSMLS As Integer
        Dim FoundTOE, FoundTOL, FoundTS, FoundWOL, FoundRoll, FoundRoll2, FoundBracket, ErrCnt As Integer

        PrgName = "FeetInchesToDecInches"
        ErrCnt = 0

        On Error GoTo Err_FeetInchesToDecInches

MaterialPartFixed:
        ErrorFoundNew = "No"
        SearchX = " x "
        SearchInch = Chr(34)                'Find " Inch
        SearchFoot = Chr(39)                'Find ' Feet
        SearchSch = "SCH"
        SearchStd = "STD"
        SearchNote = "Note"
        SearchFraction = "/"
        SearchDblFraction = "//"
        SearchDash = "-"
        SearchSpace = " "
        InchFraction = 0
        DecFraction = 0
        DecInches = 0
        FeetLength = 0
        FeetTotal = 0
        FstFraction = 0
        SndFraction = 0
        FoundInch = 0
        FoundFoot = 0
        FoundFoot2 = 0
        FoundSpace = 0
        FoundFraction = 0
        FoundDash = 0
        FoundSch = 0
        FoundX = 0
        OPos = 0
        NotePos = 0
        MatInch = 0
        FoundSMLS = 0
        TestInchMk = Nothing
        LastPart2 = Nothing

        SearchBBE = " BBE"
        SearchBBL = " BBL"
        SearchBOE = " BOE"
        SearchBW = " BW"
        SearchCBE = " CBE"
        SearchCOE = " COE"
        SearchG = " G"
        SearchGAL = " GAL"
        SearchMBE = " MBE"
        SearchMOE = " MOE"
        SearchNPT = " NPT"
        SearchPBE = " PBE"
        SearchSOL = " SOL"
        SearchTBE = " TBE"
        SearchTOE = " TOE"
        SearchTOL = " TOL"
        SearchTS = " TS"
        SearchWOL = " WOL"
        SearchRoll = " ROLLED"
        SearchRoll2 = " (COLD ROLLED)"
        SearchBracket = " ("
        SearchSMLS = "SMLS"

RestartXPos:
        If InStr(MaterialPart, SearchDblFraction) > 0 Then
            FoundPos = InStr(MaterialPart, SearchDblFraction)
            MaterialPart1st = Mid(MaterialPart, 1, (FoundPos - 1))
            MaterialPart2nd = Mid(MaterialPart, (FoundPos + 2), Len(MaterialPart))
            MaterialPart = MaterialPart1st & "/" & MaterialPart2nd
        End If

        NotePos = InStr(1, MaterialPart, SearchNote)
        If NotePos > 0 Then
            EndPart = Mid(MaterialPart, NotePos, Len(MaterialPart))
            MaterialPart = Mid(MaterialPart, 1, (NotePos - 1))
            MaterialPart = LTrim(MaterialPart)
            MaterialPart = RTrim(MaterialPart)
        End If

        XSpacePos = InStr(1, MaterialPart, " x ")
        While XSpacePos > 0
            MaterialPart = Mid(MaterialPart, (XSpacePos + 3), Len(MaterialPart))
            XSpacePos = InStr(1, MaterialPart, " x ")
        End While

        XSpacePos = InStr(1, MaterialPart, "x ")
        If XSpacePos = 1 Then
            MaterialPart = Mid(MaterialPart, 3, Len(MaterialPart))
        End If

        If InStr(MaterialPart, "(T-") Then
            GoTo ExitFunc
        End If

        XSpacePos = InStr(1, MaterialPart, " x ")
        XSpacePos2 = InStr(1, MaterialPart, " x")
        InchPos = InStr(1, MaterialPart, Chr(34))

        If XSpacePos = 0 Then
            If XSpacePos2 > 1 And InchPos > XSpacePos2 Then
                MaterialPart = MaterialPart.Replace(" x", " x ")
                GoTo RestartXPos
            End If
        End If

        DecInches = MaterialPart
        FoundFoot = InStr(DecInches, SearchFoot)
        FoundInch = InStr(DecInches, SearchInch)
        DashPos = InStr(DecInches, " - ")

        If DashPos > 0 Then
            DecInches = Mid(DecInches, 1, (DashPos - 1))
        End If

        If FoundInch = 0 Then
            FoundInch = InStr(DecInches, Chr(34))
        End If

        If InStr(DecInches, "HANGER") > 0 Then
            GoTo HangerFound
        End If

        If InStr(DecInches, "PIPE UNION") > 0 Then
            GoTo UNIONFound
        End If

        FoundDash = InStr(DecInches, SearchDash)

        If FoundDash > 0 And FoundInch = 0 Then
            Cnt = (FoundDash + 1)
            FoundChr = "No"
            While Cnt <= Len(DecInches)
                TestChr = Mid(DecInches, Cnt, 1)
                ChkChrBeforeDash = Mid(DecInches, (FoundDash - 1), 1)

                If Regex.IsMatch(TestChr, "\b[0-9]\b") Then
                    FoundChr = "Yes"

                    If Regex.IsMatch(ChkChrBeforeDash, "\b[0-9]\b") Or ChkChrBeforeDash = Chr(39) Then        'Make sure Not Characters before dash example: "MCS-9".
                        If Cnt = Len(DecInches) Then
                            DecInches = (DecInches & Chr(34))
                            GoTo MaterialPartFixed2
                        Else
                            If Regex.IsMatch(Mid(DecInches, Len(DecInches), 1), "\b[0-9]\b") Then
                                DecInches = (DecInches & Chr(34))
                                GoTo MaterialPartFixed2
                            Else
                                LastChr = Mid(DecInches, Len(DecInches), 1)
                                LastCnt = 1
                                LastChrFnd = "No"

                                While Regex.IsMatch(LastChr, "\b[A-Z]\b")         '2'-4 7/8 MOE Inches missing
                                    LastChr = Mid(DecInches, (Len(DecInches) - LastCnt), 1)
                                    LastCnt = (LastCnt + 1)

                                    LastChrFnd = "Yes"
                                End While

                                If LastChrFnd = "Yes" Then
                                    DecInches1 = Mid(DecInches, 1, Len(DecInches) - (LastCnt - 1))
                                    DecInches1 = RTrim(DecInches1)
                                    DecInches2 = Mid(DecInches, (Len(DecInches) - (LastCnt - 1)), Len(DecInches))
                                    DecInches2 = LTrim(DecInches2)
                                    DecInches = DecInches1 & Chr(34) & " " & DecInches2
                                    GoTo MaterialPartFixed2
                                Else
                                    If Mid(DecInches, Len(DecInches), 1) = Chr(39) Then     '4'-8 3/4'  Foot mark used for Inches r/p with inches.
                                        DecInches1 = Mid(DecInches, 1, Len(DecInches) - 1)
                                        DecInches = DecInches1 & Chr(34)
                                        GoTo MaterialPartFixed2
                                    End If
                                End If

                            End If
                        End If
                    Else
                        DecInches = DecInches
                        FoundChr = "No"             'No length found
                        GoTo NoDimFound
                    End If
                Else
                    Select Case TestChr
                        Case " "
                            FoundChr = "Yes"
                        Case "/"
                            FoundChr = "Yes"
                        Case Else
                            If FoundChr = "Yes" Then
                                TestChr = Mid(DecInches, (Cnt - 1), 1)

                                If TestChr = " " Then
                                    FixPart1 = Mid(DecInches, 1, (Cnt - 2))
                                    FixPart2 = Mid(DecInches, (Cnt - 1), Len(DecInches))
                                    DecInches = FixPart1 & Chr(34) & FixPart2
                                    GoTo MaterialPartFixed2
                                Else
                                    GoTo FixValue
                                End If
                            Else
FixValue:
                                MaterialPart = InputBox("Please retype " & MaterialPart & ", Please do not use Invalid Characters use / instead of \, use Zero instead of O, and Add Inch marks ?")
                                Err.Clear()
                                ErrNo = 0
                                ErrMsg = ""
                                GoTo MaterialPartFixed
                            End If
                    End Select
                End If
                Cnt = (Cnt + 1)
            End While
        End If

AddedInches2:
        If FoundDash > 0 And FoundFoot = 0 Then
            Cnt = 1
            While Cnt <= FoundDash
                FixPart1 = Mid(DecInches, 1, (FoundDash - 1))
                FixPart2 = Mid(DecInches, FoundDash, Len(DecInches))

                TestChr = Mid(FixPart1, Len(FixPart1), 1)
                If Regex.IsMatch(TestChr, "\b[0-9]\b") Then
                    DecInches = FixPart1 & Chr(39) & FixPart2
                    Err.Clear()
                    ErrNo = 0
                    ErrMsg = ""
                    GoTo MaterialPartFixed2
                Else
                    MaterialPart = InputBox("Please retype " & MaterialPart & ", Please do not use Invalid Characters use / instead of \,and use Zero instead of O ?")
                    Err.Clear()
                    ErrNo = 0
                    ErrMsg = ""
                    GoTo MaterialPartFixed
                End If
                Cnt = (Cnt + 1)
            End While
        End If
        '---------------------------------------------------------------------------------------------------

MaterialPartFixed2:
CheckForAddMBE_Etc:
        Select Case Mid(DecInches, 1, 6)
            Case "PIPE 1"
                If ManwayInfo3134.MWElev = "3" Then
                    GoTo NoDimFound
                End If
            Case "PIPE 2"
                If ManwayInfo3134.MWElev = "3" Then
                    GoTo NoDimFound
                End If
            Case "PIPE 3"
                If ManwayInfo3134.MWElev = "3" Then
                    GoTo NoDimFound
                End If
            Case "PIPE 4"
                If ManwayInfo3134.MWElev = "3" Then
                    GoTo NoDimFound
                End If
            Case "PIPE 5"
                If ManwayInfo3134.MWElev = "3" Then
                    GoTo NoDimFound
                End If
            Case "PIPE 6"
                If ManwayInfo3134.MWElev = "3" Then
                    GoTo NoDimFound
                End If
            Case "PIPE 7"
                If ManwayInfo3134.MWElev = "3" Then
                    GoTo NoDimFound
                End If
            Case "PIPE 8"
                If ManwayInfo3134.MWElev = "3" Then
                    GoTo NoDimFound
                End If
            Case "PIPE 9"
                If ManwayInfo3134.MWElev = "3" Then
                    GoTo NoDimFound
                End If
        End Select

        FoundInch = InStr(1, DecInches, SearchInch)

        If FoundInch = 0 Then
            FoundInch = InStr(1, DecInches, Chr(34))
        End If

        FoundStd = InStr(1, DecInches, SearchStd)
        FoundBBE = InStr(1, DecInches, SearchBBE)
        FoundBBL = InStr(1, DecInches, SearchBBL)
        FoundBOE = InStr(1, DecInches, SearchBOE)
        FoundBW = InStr(1, DecInches, SearchBW)
        FoundCBE = InStr(1, DecInches, SearchCBE)
        FoundCOE = InStr(1, DecInches, SearchCOE)
        FoundG = InStr(1, DecInches, SearchG)
        FoundGAL = InStr(1, DecInches, SearchGAL)
        FoundMBE = InStr(1, DecInches, SearchMBE)
        FoundMOE = InStr(1, DecInches, SearchMOE)
        FoundNPT = InStr(1, DecInches, SearchNPT)
        FoundPBE = InStr(1, DecInches, SearchPBE)
        FoundSOL = InStr(1, DecInches, SearchSOL)
        FoundTBE = InStr(1, DecInches, SearchTBE)
        FoundTOE = InStr(1, DecInches, SearchTOE)
        FoundTOL = InStr(1, DecInches, SearchTOL)
        FoundTS = InStr(1, DecInches, SearchTS)
        FoundWOL = InStr(1, DecInches, SearchWOL)
        FoundRoll = InStr(1, DecInches, SearchRoll)
        FoundRoll2 = InStr(1, DecInches, SearchRoll2)
        FoundBracket = InStr(1, DecInches, SearchBracket)
        FoundSMLS = InStr(1, DecInches, SearchSMLS)

        Select Case 0
            Case Is < FoundStd
                LastPart = Mid(DecInches, FoundStd, Len(DecInches))
                DecInches = Mid(DecInches, 1, (FoundStd - 1))
            Case Is < FoundRoll2
                LastPart = Mid(DecInches, FoundRoll2, Len(DecInches))
                DecInches = Mid(DecInches, 1, (FoundRoll2 - 1))
            Case Is < FoundBBE
                If FoundRoll < FoundBBE And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    If FoundMOE < FoundBBE And FoundMOE > 0 Then
                        LastPart = Mid(DecInches, FoundMOE, Len(DecInches))
                        DecInches = Mid(DecInches, 1, (FoundMOE - 1))
                    Else
                        LastPart = Mid(DecInches, FoundBBE, Len(DecInches))
                        DecInches = Mid(DecInches, 1, (FoundBBE - 1))
                    End If
                End If
            Case Is < FoundBBL
                If FoundRoll < FoundBBL And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundBBL, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundBBL - 1))
                End If
            Case Is < FoundBOE
                If FoundRoll < FoundBOE And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    If FoundMOE < FoundBOE And FoundMOE > 0 Then
                        LastPart = Mid(DecInches, FoundMOE, Len(DecInches))
                        DecInches = Mid(DecInches, 1, (FoundMOE - 1))
                    Else
                        LastPart = Mid(DecInches, FoundBOE, Len(DecInches))
                        DecInches = Mid(DecInches, 1, (FoundBOE - 1))
                    End If
                End If
            Case Is < FoundBW
                If FoundRoll < FoundBW And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundBW, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundBW - 1))
                End If
            Case Is < FoundCBE
                If FoundRoll < FoundCBE And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundCBE, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundCBE - 1))
                End If
            Case Is < FoundCOE
                If FoundRoll < FoundCOE And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    If FoundMOE < FoundCOE And FoundMOE <> 0 Then
                        GoTo FoundMOE
                    Else
                        LastPart = Mid(DecInches, FoundCOE, Len(DecInches))
                        DecInches = Mid(DecInches, 1, (FoundCOE - 1))
                    End If
                End If
            Case Is < FoundG
                If FoundRoll < FoundG And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundG, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundG - 1))
                End If
            Case Is < FoundGAL
                If FoundRoll < FoundGAL And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundGAL, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundGAL - 1))
                End If
            Case Is < FoundMBE
                If FoundRoll < FoundMBE And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundMBE, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundMBE - 1))
                End If
            Case Is < FoundMOE
FoundMOE:
                If FoundRoll < FoundMOE And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundMOE, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundMOE - 1))
                End If
            Case Is < FoundNPT
                If FoundRoll < FoundNPT And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundNPT, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundNPT - 1))
                End If
            Case Is < FoundPBE
                If FoundRoll < FoundPBE And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundPBE, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundPBE - 1))
                End If
            Case Is < FoundSOL
                If FoundRoll < FoundSOL And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundSOL, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundSOL - 1))
                End If
            Case Is < FoundTBE
                If FoundRoll < FoundTBE And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    If Len(LastPart) > 0 Then
                        LastPart2 = Mid(DecInches, FoundTBE, Len(DecInches))
                        LastPart = (LastPart2 & LastPart)
                    Else
                        LastPart = Mid(DecInches, FoundTBE, Len(DecInches))
                    End If

                    DecInches = Mid(DecInches, 1, (FoundTBE - 1))
                End If
            Case Is < FoundTOE
                If FoundRoll < FoundTOE And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundTOE, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundTOE - 1))
                End If
            Case Is < FoundTOL
                If FoundRoll < FoundTOL And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundTOL, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundTOL - 1))
                End If
            Case Is < FoundTS
                If FoundRoll < FoundTS And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundTS, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundTS - 1))
                End If
            Case Is < FoundWOL
                If FoundRoll < FoundWOL And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundWOL, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundWOL - 1))
                End If
            Case Is < FoundBracket
                If FoundRoll < FoundBracket And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    LastPart = Mid(DecInches, FoundBracket, Len(DecInches))
                    DecInches = Mid(DecInches, 1, (FoundBracket - 1))
                End If
            Case Is < FoundRoll
FoundRoll:
                LastPart = Mid(DecInches, FoundRoll, Len(DecInches))
                DecInches = Mid(DecInches, 1, (FoundRoll - 1))
            Case Is < FoundSMLS
                If FoundRoll < FoundSMLS And FoundRoll > 0 Then
                    GoTo FoundRoll
                Else
                    If Len(LastPart) > 0 Then
                        LastPart2 = Mid(DecInches, FoundSMLS, Len(DecInches))
                        LastPart = (LastPart2 & LastPart)
                    Else
                        LastPart = Mid(DecInches, FoundSMLS, Len(DecInches))
                    End If
                    DecInches = Mid(DecInches, 1, (FoundSMLS - 1))
                End If
            Case Else
                If Len(DecInches) > FoundInch And FoundInch > 0 Then
                    LastPart = Mid(DecInches, (FoundInch + 1), (Len(DecInches) - FoundInch))
                    DecInches = Mid(DecInches, 1, FoundInch)
                End If
        End Select

        DecInches = LTrim(DecInches)
        DecInches = RTrim(DecInches)
        FoundSMLS = InStr(1, DecInches, SearchSMLS)

        If FoundSMLS > 0 And InStr(1, DecInches, "TBE") = 0 Then
            If FoundRoll < FoundSMLS And FoundRoll > 0 Then
                GoTo FoundRoll
            Else
                If Len(LastPart) > 0 Then
                    LastPart2 = Mid(DecInches, FoundSMLS, Len(DecInches))
                    LastPart = (LastPart2 & LastPart)
                Else
                    LastPart = Mid(DecInches, FoundSMLS, Len(DecInches))
                End If

                DecInches = Mid(DecInches, 1, (FoundSMLS - 1))
            End If
        End If

        DecInches = LTrim(DecInches)
        DecInches = RTrim(DecInches)
        DecInches = Replace(DecInches, "O" & Chr(39), "0" & Chr(39))
        FoundFoot = InStr(1, DecInches, SearchFoot)
        FoundDash = InStr(1, DecInches, SearchDash)

        If FoundFoot > 0 Then
            If FoundDash > 0 Then
                FeetLength = Mid(DecInches, 1, (FoundFoot - 1))
                FeetTotal = (FeetLength * 12)
                DecInches = Mid(DecInches, (FoundDash + 1), (Len(DecInches) - FoundDash + 1))

                FoundInch = InStr(1, DecInches, SearchInch)
                If FoundInch = 0 Then
                    DecInches = DecInches & Chr(34)
                    FoundInch = InStr(1, DecInches, SearchInch)
                Else
                    DecInches = Mid(DecInches, 1, FoundInch)
                    FoundInch = DecInches
                End If
            Else
                FoundFoot2 = InStr((FoundFoot + 1), DecInches, SearchFoot)

                If FoundFoot2 > 0 Then
                    If FoundFoot2 = (FoundFoot + 1) Then
                        FeetTotal = 0
                        FoundSpace = InStr((FoundFoot - 1), DecInches, SearchSpace)
                        If FoundSpace > 0 Then
                            DecInches = Mid(DecInches, 1, (FoundSpace - 1))
                        Else
                            DecInches = Mid(DecInches, 1, (FoundSpace - 3))
                        End If
                    End If
                Else
                    FoundSpace = InStr(1, DecInches, SearchSpace)
                    DecInches = Mid(DecInches, (FoundFoot + 1), (Len(DecInches) - FoundFoot + 1))
                End If
            End If
        End If

        DecInches = LTrim(DecInches)
        DecInches = RTrim(DecInches)
        FoundFraction = InStr(1, DecInches, SearchFraction)
        FoundSpace = InStr(1, DecInches, SearchSpace)
        FoundInch = InStr(1, DecInches, SearchInch)
        FoundFoot = InStr(1, DecInches, SearchFoot)
        FoundFoot2 = InStr((FoundFoot + 1), DecInches, SearchFoot)

        If FoundFraction > 0 Then
            If FoundSpace > 0 Then
                If FoundInch > 0 Then
                    If FoundSpace = 1 Then
                        DecInches = Mid(DecInches, 2, (Len(DecInches)))
                    End If

                    If Len(DecInches) > 0 Then
                        TestInchMk = Mid(DecInches, (FoundSpace - 1), 1)

                        If TestInchMk = Chr(34) Then
                            If InchFraction = 0 And InStr(DecInches, "/") = 0 Then
                                InchFraction = Mid(DecInches, 1, (FoundSpace - 2))
                            End If
                        Else
                            InchFraction = Mid(DecInches, 1, (FoundSpace - 1))
                        End If
                    End If

                    DecInches = Mid(DecInches, (FoundSpace + 1), Len(DecInches))
                    FoundInch = InStr(1, DecInches, SearchInch)
                    If FoundInch = Len(DecInches) Then
                        DecInches = Mid(DecInches, 1, (Len(DecInches) - 1))
                    End If

                    FoundFraction = InStr(1, DecInches, SearchFraction)
                    FstFraction = Mid(DecInches, 1, (FoundFraction - 1))
                    SndFraction = Mid(DecInches, (FoundFraction + 1), (Len(DecInches)))
                    DecFraction = (FstFraction / SndFraction)
                Else
                    If FoundFoot2 = (FoundFoot + 1) Then
                        InchFraction = Mid(DecInches, 1, (FoundSpace - 1))
                        Test = (Len(DecInches))
                        Test = (Len(DecInches) - FoundFoot)
                        DecInches = Mid(DecInches, (FoundSpace + 1), (Len(DecInches) - (FoundSpace + 1 + Test)))
                        FoundFraction = InStr(1, DecInches, SearchFraction)
                        FstFraction = Mid(DecInches, 1, (FoundFraction - 1))
                        SndFraction = Mid(DecInches, (FoundFraction + 1), (Len(DecInches)))
                        DecFraction = (FstFraction / SndFraction)
                    Else
                        DecInches = LTrim(DecInches)
                        DecInches = RTrim(DecInches)
                        FoundSpace = InStr(DecInches, SearchSpace)
                        FoundFraction = InStr(DecInches, SearchFraction)

                        If FoundSpace > 0 And FoundFraction > 0 Then             '---------------------DecInches = "8 5/16"
                            InchFraction = Mid(DecInches, 1, (FoundSpace - 1))
                            DecInches = Mid(DecInches, (FoundSpace + 1), Len(DecInches))
                        End If

                        DecInches = LTrim(DecInches)
                        DecInches = RTrim(DecInches)
                        FoundFraction = InStr(DecInches, SearchFraction)

                        If FoundFraction > 0 Then                               '---------------------Fraction Found    "5/16"
                            FstFraction = Mid(DecInches, 1, (FoundFraction - 1))
                        Else
                            MsgBox("A programming problem has been found that needs to be looked at, Please create a Ticket. The following is what the program is having a problem with: " & DecInches)
                        End If

                        FoundInch = InStr(DecInches, SearchInch)
                        FoundFraction = InStr(DecInches, SearchFraction)

                        If FoundInch > 0 And FoundFraction > 0 Then
                            LastPart = Mid(DecInches, FoundInch, Len(DecInches))
                            SndFraction = Mid(DecInches, (FoundFraction + 1), Len(DecInches))
                            DecFraction = (FstFraction / SndFraction)
                        Else
                            If FoundInch = 0 And FoundFraction > 0 Then
                                SndFraction = Mid(DecInches, (FoundFraction + 1), (Len(DecInches)))
                                DecFraction = (FstFraction / SndFraction)
                            End If
                        End If
                    End If
                End If
            Else
                If Mid(DecInches, Len(DecInches), 1) = Chr(34) Then
                    DecInches = Mid(DecInches, 1, (Len(DecInches) - 1))
                End If

                FstFraction = Mid(DecInches, 1, (FoundFraction - 1))        'Fraction Only Found 
                SndFraction = Mid(DecInches, (FoundFraction + 1), Len(DecInches))
                DecFraction = (FstFraction / SndFraction)
            End If
        Else
            FoundInch = InStr(1, DecInches, SearchInch)
            If FoundInch > 0 Then
                If InStr(DecInches, "PIPE") > 0 Then
                    DecInches = Mid(DecInches, 5, Len(DecInches))

                    DecInches = LTrim(DecInches)
                    DecInches = RTrim(DecInches)
                End If

                InchFraction = Mid(DecInches, 1, (FoundInch - 1))
            Else
                FoundFoot = InStr(1, DecInches, SearchFoot)
                FoundFoot2 = InStr((FoundFoot + 1), DecInches, SearchFoot)

                If FoundFoot2 = (FoundFoot + 1) Then
                    InchFraction = Mid(DecInches, 1, (FoundFoot - 1))
                Else
                    Select Case Left(MaterialPart, 1)
                        Case 1
                            InchFraction = MaterialPart
                        Case 2
                            InchFraction = MaterialPart
                        Case 3
                            InchFraction = MaterialPart
                        Case 4
                            InchFraction = MaterialPart
                        Case 5
                            InchFraction = MaterialPart
                        Case 6
                            InchFraction = MaterialPart
                        Case 7
                            InchFraction = MaterialPart
                        Case 8
                            InchFraction = MaterialPart
                        Case 9
                            InchFraction = MaterialPart
                        Case 0
                            InchFraction = MaterialPart
                        Case Else
                            InchFraction = 0
                    End Select
                End If
            End If

            FstFraction = 0
            SndFraction = 0
            DecFraction = 0
        End If

        FoundInch = InStr(1, MaterialPart, SearchInch)

        If FoundInch > 0 Then
            MatInch = (InchFraction + DecFraction + FeetTotal)
            MatLength = Mid(MaterialPart, 1, FoundInch)
        Else
            MatInch = (InchFraction + DecFraction + FeetTotal)
            MatLength = MaterialPart
        End If
NoDimFound:
HangerFound:
UNIONFound:

Err_FeetInchesToDecInches:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException
            DwgItem = FullJobNo & "_" & DwgNum

            If ErrNo = "13" And InStr(ErrMsg, "Conversion from string") Then
                FoundFoot = InStr(DecInches, SearchFoot)
                FoundInch = InStr(DecInches, SearchInch)
                FoundDash = InStr(DecInches, SearchDash)
                FoundSpace = InStr(DecInches, SearchSpace)

                If FoundDash > 0 And FoundInch = 0 Then
                    Cnt = (FoundDash + 1)
                    FoundChr = "No"
                    While Cnt <= Len(DecInches)
                        TestChr = Mid(DecInches, Cnt, 1)
                        If Regex.IsMatch(TestChr, "\b[0-9]?\b") Then
                            FoundChr = "Yes"
                            If Cnt = Len(DecInches) Then
                                DecInches = (DecInches & Chr(34))
                                GoTo AddedInches
                            End If
                        Else
                            Select Case TestChr
                                Case " "
                                    FoundChr = "Yes"
                                Case "/"
                                    FoundChr = "Yes"
                                Case Else
                                    If FoundChr = "Yes" Then
                                        TestChr = Mid(DecInches, (Cnt - 1), 1)

                                        If TestChr = " " Then
                                            FixPart1 = Mid(DecInches, 1, (Cnt - 2))
                                            FixPart2 = Mid(DecInches, (Cnt - 1), Len(DecInches))
                                            DecInches = FixPart1 & Chr(34) & FixPart2
                                            GoTo MaterialPartFixed2
                                        Else
                                            GoTo FixValue2
                                        End If
                                    Else
                                        GoTo FixValue2
                                    End If
                            End Select
FixValue2:
                            MaterialPart = InputBox("Please retype " & MaterialPart & ", Please do not use Invalid Characters use / instead of \,and use Zero instead of O ?")
                            Err.Clear()
                            ErrNo = 0
                            ErrMsg = ""
                            GoTo MaterialPartFixed
                        End If
                        Cnt = (Cnt + 1)
                    End While
                End If
AddedInches:
                If FoundDash > 0 And FoundFoot = 0 Then
                    Cnt = 1
                    While Cnt <= FoundDash
                        FixPart1 = Mid(DecInches, 1, (FoundDash - 1))
                        FixPart2 = Mid(DecInches, FoundDash, Len(DecInches))

                        TestChr = Mid(FixPart1, Len(FixPart1), 1)
                        If Regex.IsMatch(TestChr, "\b[0-9]?\b") Then
                            DecInches = FixPart1 & Chr(39) & FixPart2
                            Err.Clear()
                            ErrNo = 0
                            ErrMsg = ""
                            GoTo MaterialPartFixed2
                        Else
                            MaterialPart = InputBox("Please retype " & MaterialPart & ", Please do not use Invalid Characters use / instead of \,and use Zero instead of O ?")
                            Err.Clear()
                            ErrNo = 0
                            ErrMsg = ""
                            GoTo MaterialPartFixed
                        End If
                        Cnt = (Cnt + 1)
                    End While
                End If

                If FoundDash > 0 And FoundFraction > 0 Then
                    If FoundSpace = 0 And FoundFoot > 0 Then
                        FixPart1 = Mid(DecInches, 1, FoundDash)
                        FixPart2 = Mid(DecInches, (FoundDash + 1), Len(DecInches))

                        TestChr = Mid(FixPart2, 1, 1)
                        If Regex.IsMatch(TestChr, "\b[0-9]?\b") Then
                            DecInches = FixPart1 & "0 " & FixPart2
                            Err.Clear()
                            ErrNo = 0
                            ErrMsg = ""
                            GoTo MaterialPartFixed2
                        Else
                            MaterialPart = InputBox("Please retype " & MaterialPart & ", Please do not use Invalid Characters use / instead of \,and use Zero instead of O ?")
                            Err.Clear()
                            ErrNo = 0
                            ErrMsg = ""
                            GoTo MaterialPartFixed
                        End If
                    End If
                End If

                MMPos = InStr(DecInches, "MM")
                If MMPos > 0 Then
                    DecInches = InputBox("Lengths on Standrad BOM Blocks should not have MM used, convert MM to Standard US Lenght for " & DwgItem & " Please type in length for " & MaterialPart & " .")
                    Err.Clear()
                    ErrNo = 0
                    ErrMsg = ""
                Else
                    ErrCnt = (ErrCnt + 1)

                    If ErrCnt < 4 Then
                        Err.Clear()
                        ErrNo = 0
                        ErrMsg = ""
                        GoTo CheckForAddMBE_Etc
                    Else
                        DecInches = InputBox("Program is having problem finding length, on drawing " & DwgItem & " Please type in length for " & MaterialPart & " .")
                        Err.Clear()
                        ErrNo = 0
                        ErrMsg = ""
                        ErrCnt = 0
                    End If
                End If

                InchFraction = 0
                DecFraction = 0
                FeetLength = 0
                FeetTotal = 0
                FstFraction = 0
                SndFraction = 0
                FoundInch = 0
                FoundFoot = 0
                FoundFoot2 = 0
                FoundSpace = 0
                FoundFraction = 0
                FoundDash = 0
                FoundSch = 0
                FoundX = 0
                OPos = 0
                FoundX = InStr(DecInches, SearchX)

                If FoundX > 0 Then
                    GoTo MaterialPartFixed
                Else
                    GoTo MaterialPartFixed2
                End If
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

            BOM_Menu3D.HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If
ExitFunc:
    End Function
End Module