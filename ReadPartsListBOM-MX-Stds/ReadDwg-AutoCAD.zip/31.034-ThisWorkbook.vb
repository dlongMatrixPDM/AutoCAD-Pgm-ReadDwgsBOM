'Option Strict Off
'Option Explicit On
''<System.Runtime.InteropServices.ProgId("ThisWorkbook_NET.ThisWorkbook")> Public Class ThisWorkbook

''    Private Sub Workbook_Open()
''        Dim Excel As Object

''        If UCase(Left(Excel.ActiveWorkbook.Name, 8)) = "BULK BOM" Then
''            Excel.Application.Visible = False
''            BOM_Menu3D.BulkBom()
''        End If

''    End Sub
'End Class