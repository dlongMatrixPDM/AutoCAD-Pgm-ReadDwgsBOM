Option Strict Off
Option Explicit On
Option Compare Text

Imports System
Imports System.Configuration
Imports System.Text.RegularExpressions
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports Microsoft.Office.Interop.Excel

Module Formatting31_078
    Dim WorkShtName, PriPrg, ErrNo, ErrMsg, ErrSource, ErrDll, ErrLastLineX, PrgName As String
    Dim ErrException As System.Exception
    Public ExcelApp As Object
    Public GetShipMk, GetNextShipMk, GetShipMkYesNo As String

    Function HighlightLine(ByRef LineNo As Short, ByRef Highlight As String, ByRef BOMSheet As String) As Object
        Dim xlColorIndexNone As Object
        Dim Range As Object
        Dim RevColor, DescColor As String
        Dim WorkBooks As Workbooks
        PrgName = "HighlightLine"

        On Error GoTo Err_HighlightLine

        WorkBooks = ExcelApp.Workbooks
        NewBulkBOM = WorkBooks.Application.Worksheets(BOMSheet)
        NewBulkBOM.Activate()
        With NewBulkBOM
            With .Range("A" & LineNo & ":L" & LineNo).Interior
                Select Case Highlight
                    Case "Y"                        'color yellow for revised
                        .ColorIndex = 6
                    Case "G"                        'color green for new
                        .ColorIndex = 4
                    Case "R"                        'color red for deleted
                        .ColorIndex = 3
                    Case "N"                        'no color for unchanged cells
                        .ColorIndex = -4142
                    Case "X"
                        GoTo BOMNumOnly
                End Select
            End With
        End With

        GoTo EndFunction
BOMNumOnly:
        With NewBulkBOM
            With .Range("C" & LineNo & ":C" & LineNo).Interior
                .ColorIndex = 6
            End With
        End With

EndFunction:

        With NewBulkBOM
            RevColor = .Range("C" & LineNo).Interior.ColorIndex
            DescColor = .Range("G" & LineNo).Interior.ColorIndex

            If LineNo = 5 Then
                .Range("R" & (LineNo - 1)).Value = "Color Code No"
                .Range("R" & (LineNo - 1)).Font.Bold = True
                .Range("R" & (LineNo - 1)).Font.Size = 12
                .Range("R" & (LineNo - 1)).Orientation = 90
            End If

            If RevColor = DescColor Then
FixColor:
                Select Case RevColor
                    Case 4
                        .Range("R" & LineNo).Value = 1           'Green                        
                    Case 6
                        .Range("R" & LineNo).Value = 2           'Yellow
                    Case 3
                        .Range("R" & LineNo).Value = 3           'Red
                    Case 7
                        .Range("R" & LineNo).Value = 4           'Purple
                    Case 8
                        .Range("R" & LineNo).Value = 5           'Cyan
                    Case 45
                        .Range("R" & LineNo).Value = 6           'Color Orange
                    Case -4142
                        .Range("R" & LineNo).Value = 8           'No Color, No Change
                    Case Else
                        MsgBox("Error has been found in Function ColorToNumber on Program BulkBOM.")
                End Select
            Else
                If DescColor = -4142 And RevColor = 6 Then
                    .Range("R" & LineNo).Value = 7
                Else
                    If DescColor = -4142 Then
                        GoTo FixColor
                    Else
                        If DescColor = 7 And RevColor = 6 Then
                            .Range("R" & LineNo).Value = 7
                        Else
                            If DescColor = 8 And RevColor = 6 Then
                                .Range("R" & LineNo).Value = 7
                            Else
                                If DescColor = 45 And RevColor = 6 Then
                                    .Range("R" & LineNo).Value = 7
                                Else
                                    .Range("R" & LineNo).Value = RevColor
                                    .Range("S" & LineNo).Value = DescColor
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End With

Err_HighlightLine:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            If ErrNo = "20" And ErrMsg = "Resume without error." Then
                Exit Function
            End If

            If ErrNo = "91" And ErrMsg = "" Then
                Resume
            End If

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

            BOM_Menu3D.HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Function

    Function FormatLine(ByRef LineNo As Object, ByRef FileToOpen As String, Optional ByRef MultiLineMatl As Boolean = False) As Object
        Dim xlInsideHorizontal As Object, xlLeft As Object, xlInsideVertical As Object, xlEdgeRight As Object
        Dim xlEdgeBottom As Object, xlEdgeTop As Object, xlAutomatic As Object, xlThin As Object, xlEdgeLeft As Object
        Dim xlContinuous As Object, xlDiagonalUp As Object, xlDiagonalDown As Object, xlNone As Object, xlCenter As Object
        Dim Range As Object, xlDown As Object, Rows As Object, ExcelApp As Object
        Dim CallPos, ExceptionPos As Integer
        Dim WorkBooks As Workbooks
        Dim BOMWrkSht As Worksheet
        Dim WorkSht As Worksheet
        PrgName = "FormatLine"

        On Error Resume Next

        ExcelApp = GetObject(, "Excel.Application")

        If Err.Number Then
            Information.Err.Clear()
            ExcelApp = CreateObject("Excel.Application")
            If Err.Number Then
                MsgBox(Err.Description)
                Exit Function
            End If
        End If

        On Error GoTo Err_FormatLine

        WorkBooks = ExcelApp.Workbooks

        If FileToOpen = "Purchase BOM" Then
            WorkShtName = "Other BOM"
        Else
            WorkShtName = FileToOpen
        End If

        BOMWrkSht = WorkBooks.Application.Worksheets(WorkShtName)

        With BOMWrkSht
            .Rows(LineNo + 2 & ":" & LineNo + 2).Insert()
            .Rows(LineNo & ":" & LineNo).RowHeight = 18

            If LineNo = 5 Then
                .Range("W" & (LineNo - 1)).Value = "PROCUREMENT"
                .Range("W" & (LineNo - 1)).Font.Bold = True
                .Range("W" & (LineNo - 1)).Font.Size = 12

                With .Range("W" & (LineNo - 1) & ":W" & (LineNo - 1))
                    With .Borders.Item(XlBordersIndex.xlEdgeTop)
                        .LineStyle = XlLineStyle.xlContinuous
                        .Weight = XlBorderWeight.xlThin
                        .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                    End With

                    With .Borders.Item(XlBordersIndex.xlEdgeRight)
                        .LineStyle = XlLineStyle.xlContinuous
                        .Weight = XlBorderWeight.xlThin
                        .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                    End With
                End With
            End If

            With .Range("A" & LineNo & ":W" & LineNo)                           'With .Range("A" & LineNo & ":L" & LineNo)      '-------DJL-10-11-2023
                .HorizontalAlignment = XlHAlign.xlHAlignCenter
                .VerticalAlignment = XlVAlign.xlVAlignCenter
                .Font.Name = "Arial"
                .Font.FontStyle = "Regular"
                .Font.Size = 9
                With .Borders.Item(XlBordersIndex.xlDiagonalDown)
                    .LineStyle = XlLineStyle.xlLineStyleNone
                End With
                With .Borders.Item(XlBordersIndex.xlDiagonalUp)
                    .LineStyle = XlLineStyle.xlLineStyleNone
                End With
                With .Borders.Item(XlBordersIndex.xlEdgeLeft)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
                With .Borders.Item(XlBordersIndex.xlEdgeTop)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
                With .Borders.Item(XlBordersIndex.xlEdgeBottom)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
                With .Borders.Item(XlBordersIndex.xlEdgeRight)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
                With .Borders.Item(XlBordersIndex.xlInsideVertical)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
            End With

            With .Range("F" & LineNo)
                .HorizontalAlignment = XlHAlign.xlHAlignLeft
                .VerticalAlignment = XlVAlign.xlVAlignCenter
            End With

            With .Range("C" & LineNo)
                .NumberFormat = "@"
            End With

            With .Range("D" & LineNo)
                .NumberFormat = "@"
            End With

            With .Range("M" & LineNo)
                .NumberFormat = "@"
            End With

            With .Range("N" & LineNo)
                .NumberFormat = "General"
            End With

            With .Range("O" & LineNo)
                .NumberFormat = "General"
            End With

            With .Range("P" & LineNo)
                .NumberFormat = "General"
            End With

            With .Range("I" & LineNo)
                .HorizontalAlignment = XlHAlign.xlHAlignCenter
                .VerticalAlignment = XlVAlign.xlVAlignCenter
                .Font.Name = "Arial"
                .Font.Size = 7
            End With

            'If MultiLineMatl = True Then
            '    With .Range("I" & LineNo)
            '        .HorizontalAlignment = XlHAlign.xlHAlignCenter
            '        .VerticalAlignment = XlVAlign.xlVAlignCenter
            '        .Font.Size = 7
            '    End With
            'End If
        End With

Err_FormatLine:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

            BOM_Menu3D.HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Function

    '    Function FormatLine2(ByRef LineNo As Object, ByRef FileToOpen As String, Optional ByRef MultiLineMatl As Boolean = False) As Object
    '        Dim xlInsideHorizontal As Object, xlLeft As Object, xlInsideVertical As Object, xlEdgeRight As Object
    '        Dim xlEdgeBottom As Object, xlEdgeTop As Object, xlAutomatic As Object, xlThin As Object, xlEdgeLeft As Object
    '        Dim xlContinuous As Object, xlDiagonalUp As Object, xlDiagonalDown As Object, xlNone As Object, xlCenter As Object
    '        Dim Range As Object, xlDown As Object, Rows As Object, ExcelApp As Object
    '        Dim CallPos, ExceptionPos As Integer
    '        Dim WorkBooks As Workbooks
    '        Dim BOMWrkSht As Worksheet
    '        Dim WorkSht As Worksheet
    '        PrgName = "FormatLine2"

    '        On Error Resume Next

    '        ExcelApp = GetObject(, "Excel.Application")

    '        If Err.Number Then
    '            Information.Err.Clear()
    '            ExcelApp = CreateObject("Excel.Application")
    '            If Err.Number Then
    '                MsgBox(Err.Description)
    '                Exit Function
    '            End If
    '        End If

    '        On Error GoTo Err_FormatLine2

    '        WorkBooks = ExcelApp.Workbooks
    '        WorkShtName = FileToOpen
    '        BOMWrkSht = WorkBooks.Application.Worksheets(WorkShtName)

    '        With BOMWrkSht
    '            .Rows(LineNo + 2 & ":" & LineNo + 2).Insert()
    '            .Rows(LineNo & ":" & LineNo).RowHeight = 18
    '            .Range("A" & LineNo).NumberFormat = "@"

    '            With .Range("A" & LineNo & ":W" & LineNo)                           'With .Range("A" & LineNo & ":M" & LineNo)'     --------DJL-10-11-2023
    '                .HorizontalAlignment = XlHAlign.xlHAlignCenter
    '                .VerticalAlignment = XlVAlign.xlVAlignCenter
    '                .Font.Name = "Arial"
    '                .Font.FontStyle = "Regular"
    '                .Font.Size = 9
    '                With .Borders.Item(XlBordersIndex.xlDiagonalDown)
    '                    .LineStyle = XlLineStyle.xlLineStyleNone
    '                End With
    '                With .Borders.Item(XlBordersIndex.xlDiagonalUp)
    '                    .LineStyle = XlLineStyle.xlLineStyleNone
    '                End With
    '                With .Borders.Item(XlBordersIndex.xlEdgeLeft)
    '                    .LineStyle = XlLineStyle.xlContinuous
    '                    .Weight = XlBorderWeight.xlThin
    '                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
    '                End With
    '                With .Borders.Item(XlBordersIndex.xlEdgeTop)
    '                    .LineStyle = XlLineStyle.xlContinuous
    '                    .Weight = XlBorderWeight.xlThin
    '                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
    '                End With
    '                With .Borders.Item(XlBordersIndex.xlEdgeBottom)
    '                    .LineStyle = XlLineStyle.xlContinuous
    '                    .Weight = XlBorderWeight.xlThin
    '                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
    '                End With
    '                With .Borders.Item(XlBordersIndex.xlEdgeRight)
    '                    .LineStyle = XlLineStyle.xlContinuous
    '                    .Weight = XlBorderWeight.xlThin
    '                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
    '                End With
    '                With .Borders.Item(XlBordersIndex.xlInsideVertical)
    '                    .LineStyle = XlLineStyle.xlContinuous
    '                    .Weight = XlBorderWeight.xlThin
    '                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
    '                End With
    '            End With

    '            With .Range("G" & LineNo)
    '                .HorizontalAlignment = XlHAlign.xlHAlignLeft
    '                .VerticalAlignment = XlVAlign.xlVAlignCenter

    '                With .Borders.Item(XlBordersIndex.xlDiagonalDown)
    '                    .LineStyle = XlLineStyle.xlLineStyleNone
    '                End With
    '                With .Borders.Item(XlBordersIndex.xlDiagonalUp)
    '                    .LineStyle = XlLineStyle.xlLineStyleNone
    '                End With
    '                With .Borders.Item(XlBordersIndex.xlEdgeLeft)
    '                    .LineStyle = XlLineStyle.xlContinuous
    '                    .Weight = XlBorderWeight.xlThin
    '                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
    '                End With
    '                With .Borders.Item(XlBordersIndex.xlEdgeTop)
    '                    .LineStyle = XlLineStyle.xlContinuous
    '                    .Weight = XlBorderWeight.xlThin
    '                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
    '                End With
    '                With .Borders.Item(XlBordersIndex.xlEdgeBottom)
    '                    .LineStyle = XlLineStyle.xlContinuous
    '                    .Weight = XlBorderWeight.xlThin
    '                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
    '                End With
    '                With .Borders.Item(XlBordersIndex.xlEdgeRight)
    '                    .LineStyle = XlLineStyle.xlContinuous
    '                    .Weight = XlBorderWeight.xlThin
    '                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
    '                End With
    '                With .Borders.Item(XlBordersIndex.xlInsideVertical)
    '                    .LineStyle = XlLineStyle.xlLineStyleNone
    '                End With
    '                With .Borders.Item(XlBordersIndex.xlInsideHorizontal)
    '                    .LineStyle = XlLineStyle.xlLineStyleNone
    '                End With
    '            End With

    '            If MultiLineMatl = True Then
    '                With .Range("I" & LineNo)
    '                    .HorizontalAlignment = XlHAlign.xlHAlignCenter
    '                    .VerticalAlignment = XlVAlign.xlVAlignCenter
    '                    .Font.Size = 7
    '                End With
    '            End If
    '        End With

    'Err_FormatLine2:
    '        ErrNo = Err.Number

    '        If ErrNo <> 0 Then
    '            PriPrg = "BulkBOMFab3D-Intent"
    '            ErrMsg = Err.Description
    '            ErrSource = Err.Source
    '            ErrDll = Err.LastDllError
    '            ErrLastLineX = Err.Erl
    '            ErrException = Err.GetException

    '            Dim st As New StackTrace(Err.GetException, True)
    '            CntFrames = st.FrameCount
    '            GetFramesSrt = st.GetFrames
    '            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
    '            PrgLineNo = PrgLineNo.Replace("@", "at")
    '            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
    '            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

    '            HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)

    '            If IsNothing(ManwayInfo3134.UserName) = True Then
    '                ManwayInfo3134.UserName = System.Environment.UserName()
    '            End If

    '            If ManwayInfo3134.UserName = "dlong" Then
    '                MsgBox(ErrMsg)
    '                Stop
    '                Resume
    '            Else
    '                ExceptionPos = InStr(1, ErrMsg, "Exception")
    '                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
    '                CntExcept = (CntExcept + 1)

    '                If CntExcept < 20 Then
    '                    If ExceptionPos > 0 Then
    '                        Resume
    '                    End If
    '                    If CallPos > 0 Then
    '                        Resume
    '                    End If
    '                End If
    '            End If

    '        End If

    '    End Function

    Function FormatLine3(ByRef LineNo As Object, ByRef FileToOpen As String, Optional ByRef MultiLineMatl As Boolean = False) As Object
        Dim xlInsideHorizontal As Object, xlLeft As Object, xlInsideVertical As Object, xlEdgeRight As Object
        Dim xlEdgeBottom As Object, xlEdgeTop As Object, xlAutomatic As Object, xlThin As Object, xlEdgeLeft As Object
        Dim xlContinuous As Object, xlDiagonalUp As Object, xlDiagonalDown As Object, xlNone As Object, xlCenter As Object
        Dim Range As Object, xlDown As Object, Rows As Object, ExcelApp As Object
        Dim CallPos, ExceptionPos As Integer
        Dim WorkBooks As Workbooks
        Dim BOMWrkSht As Worksheet
        Dim WorkSht As Worksheet
        PrgName = "FormatLine3"

        On Error Resume Next

        ExcelApp = GetObject(, "Excel.Application")

        If Err.Number Then
            Information.Err.Clear()
            ExcelApp = CreateObject("Excel.Application")
            If Err.Number Then
                MsgBox(Err.Description)
                Exit Function
            End If
        End If

        On Error GoTo Err_FormatLine3

        WorkBooks = ExcelApp.Workbooks

        If FileToOpen = "Purchase BOM" Then
            WorkShtName = "Other BOM"
        Else
            WorkShtName = FileToOpen
        End If

        BOMWrkSht = WorkBooks.Application.Worksheets(WorkShtName)

        With BOMWrkSht
            .Rows(LineNo & ":" & LineNo).Insert()
            .Rows(LineNo & ":" & LineNo).RowHeight = 18

            With .Range("A" & LineNo & ":W" & LineNo)                           'With .Range("A" & LineNo & ":L" & LineNo)      '-------DJL-10-11-2023
                .HorizontalAlignment = XlHAlign.xlHAlignCenter
                .VerticalAlignment = XlVAlign.xlVAlignCenter
                .Font.Name = "Arial"
                .Font.FontStyle = "Regular"
                .Font.Size = 9
                With .Borders.Item(XlBordersIndex.xlDiagonalDown)
                    .LineStyle = XlLineStyle.xlLineStyleNone
                End With
                With .Borders.Item(XlBordersIndex.xlDiagonalUp)
                    .LineStyle = XlLineStyle.xlLineStyleNone
                End With
                With .Borders.Item(XlBordersIndex.xlEdgeLeft)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
                With .Borders.Item(XlBordersIndex.xlEdgeTop)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
                With .Borders.Item(XlBordersIndex.xlEdgeBottom)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
                With .Borders.Item(XlBordersIndex.xlEdgeRight)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
                With .Borders.Item(XlBordersIndex.xlInsideVertical)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
            End With

            With .Range("F" & LineNo)
                .HorizontalAlignment = XlHAlign.xlHAlignLeft
                .VerticalAlignment = XlVAlign.xlVAlignCenter

                With .Borders.Item(XlBordersIndex.xlDiagonalDown)
                    .LineStyle = XlLineStyle.xlLineStyleNone
                End With
                With .Borders.Item(XlBordersIndex.xlDiagonalUp)
                    .LineStyle = XlLineStyle.xlLineStyleNone
                End With
                With .Borders.Item(XlBordersIndex.xlEdgeLeft)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
                With .Borders.Item(XlBordersIndex.xlEdgeTop)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
                With .Borders.Item(XlBordersIndex.xlEdgeBottom)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
                With .Borders.Item(XlBordersIndex.xlEdgeRight)
                    .LineStyle = XlLineStyle.xlContinuous
                    .Weight = XlBorderWeight.xlThin
                    .ColorIndex = XlColorIndex.xlColorIndexAutomatic
                End With
                With .Borders.Item(XlBordersIndex.xlInsideVertical)
                    .LineStyle = XlLineStyle.xlLineStyleNone
                End With
                With .Borders.Item(XlBordersIndex.xlInsideHorizontal)
                    .LineStyle = XlLineStyle.xlLineStyleNone
                End With
            End With

            If MultiLineMatl = True Then
                With .Range("I" & LineNo)
                    .HorizontalAlignment = XlHAlign.xlHAlignCenter
                    .VerticalAlignment = XlVAlign.xlVAlignCenter
                    .Font.Size = 7
                End With
            End If
        End With

Err_FormatLine3:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

            BOM_Menu3D.HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Function

    Function FormatBulkBOM(ByRef BOMList As Object) As Object
        '------------------------------------------------------------------------------------------------
        '-------Creator:        Dennis J. Long
        '-------Date:           10/4/2023       Long Time Ago 
        '-------Description:    Delete Headers for Assembly Names ETC.
        '-------                When drawings are read it collects Assembly names so that it can go find that drawing
        '-------                and afterwards the Assembly name needs deleted.
        '-------
        '-------Updates:        Description:
        '-------10-11-2023       Documenting what program does.     
        '-------02-12-2024      Per Email form Trevor Ruffin leave the headers on.
        '-------                
        '-------                
        '------------------------------------------------------------------------------------------------
        Dim LinesToDelete As Object, AssyMK As Object, DupShipMk As Object, AssyMKtmp As Object
        Dim Test, GetDesc, GetNextShipMk As String
        Dim ExceptionPos, TotalCnt As Integer
        Dim CallPos As Integer

        PrgName = "FormatBulkBOM"

        On Error GoTo Err_FormatBulkBOM

        'ReDim LinesToDelete(1)
        'ReDim DupShipMk(1)
        BOM_Menu3D.ProgressBar1.Maximum = (UBound(BOMList, 2) + 4)
        BOM_Menu3D.LblProgress.Text = "Deleting Assembly Items, and Erection Items"
        TotalCnt = (UBound(BOMList, 2) - 1)

        Dim FCODwgNo As String
        For i = 1 To (UBound(BOMList, 2) - 1)                'For i = 0 To (UBound(BOMList, 2))           '-------DJL-------10-11-2023 Used to delete the headers for assemblies       'For i = 0 To (UBound(BOMList, 2) + 1) 
            'Dim GetShipMk, GetNextShipMk As String
            GetShipMk = BOMList(3, i)
            GetNextShipMk = BOMList(3, (i + 1))
            GetShipMk = LTrim(GetShipMk)
            GetShipMk = RTrim(GetShipMk)
            GetDesc = BOMList(7, i)
            GetShipMKYesNo = BOMList(8, i)

            'If GetShipMk <> "" Then
            '    If BOMList(9, i) = Nothing Then
            '        If InStr(1, BOMList(7, i), "FLUSH CLEAN") <> 0 Then
            '            BOMList(1, i) = "Delete" & BOMList(1, i)
            '            ReDim Preserve BOMList(20, UBound(BOMList, 2))
            '            'MarkForDelete(LinesToDelete, i)
            '            AssyMK = BOMList(3, i)
            '            FCODwgNo = Left(BOMList(1, i), 2)

            '            Do Until Left(BOMList(1, i), 2) <> FCODwgNo
            '                If BOMList(3, i) = Nothing And BOMList(5, i) = Nothing And BOMList(4, i) = Nothing Then
            '                    BOMList(1, i) = "Delete" & BOMList(1, i)
            '                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
            '                    'MarkForDelete(LinesToDelete, i)
            '                ElseIf BOMList(3, i) <> Nothing And BOMList(5, i) = Nothing And BOMList(9, i) = Nothing Then
            '                    BOMList(1, i) = "Delete" & BOMList(1, i)
            '                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
            '                    'MarkForDelete(LinesToDelete, i)
            '                    AssyMKtmp = BOMList(3, i)
            '                    i = i + 1
            '                    If BOMList(3, i) = "" And Left(BOMList(1, i), 2) = FCODwgNo Then
            '                        BOMList(3, i) = AssyMKtmp
            '                    End If
            '                Else
            '                    If BOMList(3, i) = "" Then
            '                        BOMList(3, i) = AssyMK
            '                    End If
            '                End If
            '                i = i + 1
            '            Loop
            '            i = i - 1
            '        ElseIf BOMList(3, i) <> Nothing And BOMList(5, i) <> Nothing And BOMList(4, i) <> Nothing Then
            '        Else
            '            GetShipMk = BOMList(3, i)
            '            GetNextShipMk = BOMList(3, (i + 1))

            '            If GetShipMk <> "" And GetNextShipMk <> "" Then
            '                If BOMList(9, i) = "" And BOMList(10, i) = "" Then          '9 = MX1800 and 10 Std Number = 1-4
            '                    If BOMList(5, i) <> Nothing Then                        '5 = part number
            '                        BOMList(1, i) = "Delete" & BOMList(1, i)
            '                        ReDim Preserve BOMList(20, UBound(BOMList, 2))
            '                        'MarkForDelete(LinesToDelete, i)
            '                    End If
            '                End If
            '            Else
            '                If i < (UBound(BOMList, 2) - 1) Then
            '                    AssyMK = BOMList(3, i)
            '                    GetDesc = BOMList(7, i)

            '                    If i < TotalCnt Then
            '                        BOMList(1, i) = "Delete" & BOMList(1, i)
            '                        ReDim Preserve BOMList(20, UBound(BOMList, 2))
            '                        'MarkForDelete(LinesToDelete, i)
            '                    End If
            '                End If
            '            End If
            '        End If
            '    End If
            'ElseIf InStr(1, BOMList(7, i), "SEE DWG") <> 0 Or InStr(1, BOMList(7, i), "SEE DRAWING") <> 0 Then  'if ship mark is empty AND reference to see drawing
            '    BOMList(3, i) = AssyMK
            'Else
            '    If BOMList(3, i) <> Nothing And BOMList(5, i) = Nothing And BOMList(4, i) <> Nothing Then
            '        If BOMList(3, i) = "" And BOMList(5, i).ToString = "" And BOMList(4, i).ToString = "" Then
            '            BOMList(1, i) = "Delete" & BOMList(1, i)
            '            ReDim Preserve BOMList(20, UBound(BOMList, 2))
            '            'MarkForDelete(LinesToDelete, i)
            '        Else
            '            BOMList(3, i) = AssyMK
            '        End If
            '    End If
            'End If

            '------------------------------------------------------------------------Drawing 18B for Job 9318-0206
            If GetShipMkYesNo = "Yes" And GetShipMk = GetNextShipMk Then            'Found issue were some Ship marks are not getting deleted due to Ship Mark in wrong column.
                If BOMList(1, i) <> "Delete" Then
                    BOMList(1, i) = "Delete" & BOMList(1, i)
                    ReDim Preserve BOMList(20, UBound(BOMList, 2))
                End If
            End If

            BOM_Menu3D.ProgressBar1.Value = i
        Next i

        GenInfo3233.BOMList = BOMList

Err_FormatBulkBOM:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

            BOM_Menu3D.HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If

        End If

    End Function

    '    Function UpdateShpMarks(ByRef BOMList As Object) As Object
    '        Dim GetDwgNo, OldGetDwgNo, GetShipMk, GetShopMk, FndGetDwgNo, FndGetShipMk, FndGetShopMk, FndGetPartDesc As String
    '        Dim FindShipMarks, PrevGetDwgNo, PrevGetShipMk, PrevGetShopMk, GetPartDesc, PrevGetPartDesc, PrevCcolumn As String
    '        Dim Style, Msg, Title As String
    '        Dim Response As Object
    '        Dim BOMWrkSht As Worksheet, WorkSht As Worksheet
    '        Dim Workbooks As Microsoft.Office.Interop.Excel.Workbooks
    '        Dim ExceptionPos As Integer, CallPos As Integer
    '        Dim ShpMkList(3, 1)

    '        PrgName = "UpdateShpMarks"

    '        On Error Resume Next

    '        ExcelApp = GetObject(, "Excel.Application")

    '        If Err.Number Then
    '            Information.Err.Clear()
    '            ExcelApp = CreateObject("Excel.Application")
    '            If Err.Number Then
    '                MsgBox(Err.Description)
    '                Exit Function
    '            End If
    '        End If

    '        On Error GoTo Err_UpdateShpMarks

    '        Workbooks = ExcelApp.Workbooks
    '        WorkShtName = "Bulk BOM"
    '        BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
    '        WorkSht = Workbooks.Application.ActiveSheet
    '        WorkShtName = WorkSht.Name

    '        For i = 5 To (UBound(BOMList, 2) + 3)
    '            With BOMWrkSht
    '                GetPartDesc = (.Range("F" & i).Value)
    '                GetDwgNo = (.Range("A" & i).Value)
    '                GetShipMk = .Range("C" & i).Value
    '                GetShipMk = LTrim(GetShipMk)
    '                GetShipMk = RTrim(GetShipMk)

    '                GetShopMk = .Range("D" & i).Value

    '                If GetShipMk <> "" Then
    '                    If GetShipMk = " " Then
    '                        GoTo EmptySpace
    '                    End If

    '                    'GetDwgNo = .Range("A" & i).Value

    '                    If GetDwgNo = "" And .Range("F" & i).Value <> "" Then
    '                        GetDwgNo = "XX"
    '                        .Range("A" & i).Value = GetDwgNo
    '                    End If

    '                    'FndGetShipMk = GetShipMk                            'Question need for this?
    '                    ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
    '                    ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo              'If assembly is called out on another drawing, Need way to Update Ship Mark.
    '                    ShpMkList(2, UBound(ShpMkList, 2)) = GetShipMk
    '                    ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
    '                    ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
    '                    FindShipMarks = "No"
    '                Else
    'EmptySpace:

    '                    If GetDwgNo = "" And .Range("F" & i).Value <> "" Then
    '                        GetDwgNo = "XX"
    '                        .Range("A" & i).Value = GetDwgNo
    '                    End If

    '                    If GetShipMk = " " Then
    '                        GetShipMk = ""
    '                    End If

    '                    If GetShipMk = Nothing Then
    '                        If FndGetShipMk = "FCO" And GetShipMk = Nothing Then
    '                            .Range("C" & i).Value = FndGetShipMk

    '                            ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
    '                            ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo              'If assembly is called out on another drawing, Need way to Update Ship Mark.
    '                            ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
    '                            ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
    '                            ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
    '                            GoTo EndFixFCO
    '                        End If

    '                        PrevGetShopMk = (.Range("D" & (i - 1)).Value)
    '                        PrevGetPartDesc = (.Range("F" & (i - 1)).Value)

    '                        If GetShopMk = PrevGetShopMk And GetDwgNo <> PrevGetDwgNo Then              'New Drawing but Piecemarks are the same and so is the Descriptions
    '                            If GetPartDesc = PrevGetPartDesc And GetShopMk <> "" Then
    '                                PrevGetDwgNo = (.Range("A" & (i - 1)).Value)

    '                                Msg = "Is this the same part " & PrevGetShopMk & " on drawing " & PrevGetDwgNo & " Description = " & GetPartDesc & " as item " & GetShopMk & " on drawing " & GetDwgNo & " Description = " & GetPartDesc & "?"
    '                                Style = MsgBoxStyle.YesNo
    '                                Title = "Bulk BOM"
    '                                Response = MsgBox(Msg, Style, Title)

    '                                If Response = 6 Then                    'if user clicks yes
    '                                    GetShipMk = PrevGetShipMk
    '                                    .Range("C" & i).Value = GetShipMk
    '                                Else
    '                                    GoTo NextDwg                'This is not a match go to next item in list.
    '                                End If

    '                                ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
    '                                ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo              'If assembly is called out on another drawing, Need way to Update Ship Mark.
    '                                ShpMkList(2, UBound(ShpMkList, 2)) = GetShipMk           'ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
    '                                ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
    '                                ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
    '                                GoTo NextDwg
    '                            End If
    '                        Else
    '                            If GetDwgNo = PrevGetDwgNo And GetShipMk = Nothing Then              'Same Drawing Number but Ship marks are nothing, copy previous Ship marks.
    '                                If PrevGetShipMk <> "" And .Range("C" & (i - 1)).Value <> Nothing Then    'if Previous GetShipMk not nothing.
    '                                    GetShipMk = PrevGetShipMk
    '                                    .Range("C" & i).Value = GetShipMk

    '                                    ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
    '                                    ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo          'If assembly is called out on another drawing, Need way to Update Ship Mark.
    '                                    ShpMkList(2, UBound(ShpMkList, 2)) = GetShipMk           'ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
    '                                    ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
    '                                    ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
    '                                    GoTo NextDwg
    '                                End If
    '                            End If
    '                        End If

    '                        If Mid(GetDwgNo, 1, 2) = Mid(OldGetDwgNo, 1, 2) And GetDwgNo <> OldGetDwgNo Then
    '                            FindShipMarks = "Yes"
    '                            If GetShipMk = Nothing Or GetShipMk = "" Then
    'FindNextShopMak:
    '                                If Len(GetShopMk) > 2 Then                           'If Len(FndGetShopMk) > 2 Then
    '                                    For j = 0 To UBound(ShpMkList, 2)
    '                                        FndGetPartDesc = ShpMkList(0, j)
    '                                        FndGetDwgNo = ShpMkList(1, j)
    '                                        FndGetShipMk = ShpMkList(2, j)
    '                                        FndGetShopMk = ShpMkList(3, j)

    '                                        If Mid(FndGetDwgNo, 1, 2) = Mid(GetDwgNo, 1, 2) Then
    '                                            'FndGetShipMk = ShpMkList(2, j)
    '                                            'FndGetShopMk = ShpMkList(3, j)

    '                                            Select Case FndGetShipMk
    '                                                Case "FCO"
    'FixFCO:
    '                                                    .Range("C" & i).Value = FndGetShipMk

    '                                                    ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
    '                                                    ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
    '                                                    ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
    '                                                    ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
    '                                                    ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
    '                                                    GoTo EndFixFCO
    '                                                Case Else
    '                                                    If FndGetShopMk = GetShopMk And FndGetDwgNo = GetDwgNo Then
    '                                                        .Range("C" & i).Value = FndGetShipMk

    '                                                        ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
    '                                                        ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
    '                                                        ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
    '                                                        ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
    '                                                        ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
    '                                                        GoTo EndFixFCO
    '                                                    Else
    '                                                        If FndGetShopMk = GetShopMk And FndGetDwgNo <> GetDwgNo Then
    '                                                            Msg = "Is this the same part " & FndGetShopMk & " on drawing " & FndGetDwgNo & " Description = " & FndGetPartDesc & " as item " & GetShopMk & " on drawing " & GetDwgNo & " Description = " & GetPartDesc & "?"
    '                                                            Style = MsgBoxStyle.YesNo
    '                                                            Title = "Bulk BOM"
    '                                                            Response = MsgBox(Msg, Style, Title)

    '                                                            If Response = 6 Then                    'if user clicks yes
    '                                                                GetShipMk = FndGetShipMk
    '                                                                .Range("C" & i).Value = GetShipMk
    '                                                            Else
    '                                                                GoTo NextItemInList                 'This is not a match go to next item in list.
    '                                                            End If

    '                                                            '.Range("C" & i).Value = FndGetShipMk

    '                                                            ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
    '                                                            ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
    '                                                            ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
    '                                                            ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
    '                                                            ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
    '                                                            GoTo EndFixFCO

    '                                                        Else
    'NextItemInList:
    '                                                            If FndGetShipMk = GetShopMk Then
    '                                                                .Range("C" & i).Value = FndGetShipMk

    '                                                                ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
    '                                                                ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
    '                                                                ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
    '                                                                ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
    '                                                                ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
    '                                                                GoTo EndFixFCO
    '                                                            End If
    '                                                        End If
    '                                                    End If
    '                                            End Select
    '                                        End If
    '                                    Next j
    '                                End If
    'EndFixFCO:
    '                            End If
    '                        Else
    '                            If FindShipMarks = "Yes" Then
    '                                If Regex.IsMatch(Strings.Right(Mid(GetShopMk, 1, 1), 1), "[0-9]") Then
    '                                    .Range("C" & i).Value = FndGetShipMk

    '                                    ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
    '                                    ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
    '                                    ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
    '                                    ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
    '                                    ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
    '                                Else
    '                                    If Regex.IsMatch(Strings.Right(Mid(GetShopMk, 1, 1), 1), "[A-Z]") Then
    '                                        GoTo FindNextShopMak
    '                                    Else
    '                                        PrevGetDwgNo = (.Range("A" & (i - 1)).Value)
    '                                        PrevGetShopMk = (.Range("D" & (i - 1)).Value)
    '                                        PrevGetPartDesc = (.Range("F" & (i - 1)).Value)

    '                                        If GetShopMk = Nothing Then
    '                                            If GetDwgNo = PrevGetDwgNo And FndGetShipMk <> Nothing Then
    '                                                .Range("C" & i).Value = FndGetShipMk
    '                                            End If

    '                                            ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
    '                                            ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
    '                                            ShpMkList(2, UBound(ShpMkList, 2)) = GetShipMk
    '                                            ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
    '                                            ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
    '                                        End If
    '                                    End If
    '                                End If
    '                            Else
    '                                If PrevGetDwgNo = GetDwgNo And InStr(GetDwgNo, "10D") > 0 Then
    '                                    .Range("C" & i).Value = FndGetShipMk                           'PittsBurgh
    '                                Else
    '                                    If InStr(GetDwgNo, "10D") = 0 Then
    '                                        .Range("C" & i).Value = FndGetShipMk                           'Tulsa
    '                                    End If
    '                                End If

    '                                ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
    '                                ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
    '                                ShpMkList(2, UBound(ShpMkList, 2)) = GetShipMk                           'ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk

    '                                If InStr(GetShipMk, "SR") = 1 Then                           'If InStr(FndGetShipMk, "SR") = 1 Then
    '                                    .Range("F" & i).Value = "SHELL PLATE " & GetShipMk & " " & .Range("F" & i).Value     '.Range("F" & i).Value = "SHELL PLATE " & FndGetShipMk & " " & .Range("F" & i).Value
    '                                End If

    '                                ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
    '                                ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
    '                            End If
    '                        End If

    '                        If PrevGetDwgNo = GetDwgNo And GetShipMk = "" Then
    '                            If PrevGetShipMk <> "" And .Range("C" & i).Value = "" Then
    '                                If .Range("C" & (i - 1)).Value <> "" Then
    '                                    .Range("C" & i).Value = PrevGetShipMk
    '                                End If
    '                            End If
    '                        End If
    '                    End If
    '                End If
    '            End With
    '            If Mid(OldGetDwgNo, 1, 2) <> Mid(GetDwgNo, 1, 2) Then
    '                FindShipMarks = "No"
    '                OldGetDwgNo = GetDwgNo
    '            Else
    '                OldGetDwgNo = GetDwgNo
    '            End If

    '            If PrevGetDwgNo <> GetDwgNo And InStr(GetDwgNo, "10D") > 0 Then
    '                If PrevGetShipMk <> GetShipMk And GetShipMk <> Nothing Then              'If PrevGetShipMk <> GetShipMk And (GetShipMk) = False Then
    '                    GoTo FoundGetShipMk
    '                End If

    '                If PrevGetShipMk <> GetShipMk And IsNothing(PrevGetShipMk) = False Then          'If PrevGetShipMk <> FndGetShipMk And IsNothing(PrevGetShipMk) = False Then
    '                    With BOMWrkSht
    '                        FndGetShipMk = .Range("C" & i).Value
    '                        OldGetDwgNo = .Range("A" & i).Value
    '                    End With

    '                    If GetDwgNo = OldGetDwgNo And FndGetShipMk <> Nothing Then                          'If GetDwgNo = OldGetDwgNo Then
    '                        PrevGetShipMk = FndGetShipMk
    '                    End If
    '                Else
    '                    FndGetShipMk = Nothing
    '                End If
    '            Else
    'FoundGetShipMk:
    '                'With BOMWrkSht
    '                '    PrevCcolumn = .Range("C" & i - 1).Value
    '                'End With

    '                'If IsNothing(GetShipMk) = False And PrevCcolumn <> Nothing Then
    '                PrevGetShipMk = GetShipMk                            'PrevGetShipMk = FndGetShipMk
    '                'Else
    '                '    PrevGetShipMk = ""
    '                'End If
    '            End If

    'NextDwg:

    '            PrevGetDwgNo = GetDwgNo
    '        Next i

    'Err_UpdateShpMarks:
    '        ErrNo = Err.Number

    '        If ErrNo <> 0 Then
    '            PriPrg = "BulkBOMFab3D-Intent"
    '            ErrMsg = Err.Description
    '            ErrSource = Err.Source
    '            ErrDll = Err.LastDllError
    '            ErrLastLineX = Err.Erl
    '            ErrException = Err.GetException

    '            Dim st As New StackTrace(Err.GetException, True)
    '            CntFrames = st.FrameCount
    '            GetFramesSrt = st.GetFrames
    '            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
    '            PrgLineNo = PrgLineNo.Replace("@", "at")
    '            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
    '            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

    '            BOM_Menu3D.HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)

    '            If IsNothing(ManwayInfo3134.UserName) = True Then
    '                ManwayInfo3134.UserName = System.Environment.UserName()
    '            End If

    '            If ManwayInfo3134.UserName = "dlong" Then
    '                MsgBox(ErrMsg)
    '                Stop
    '                Resume
    '            Else
    '                ExceptionPos = InStr(1, ErrMsg, "Exception")
    '                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
    '                CntExcept = (CntExcept + 1)

    '                If CntExcept < 20 Then
    '                    If ExceptionPos > 0 Then
    '                        Resume
    '                    End If
    '                    If CallPos > 0 Then
    '                        Resume
    '                    End If
    '                End If
    '            End If
    '        End If

    '    End Function

    Function UpdateShpMarksArray(ByRef BOMList As Object) As Object
        '-------DJL-10-11-2023
        '-------Do it all in an array
        'This program updates the ShipMark when blank from PrevShipMark     ' GetShipMk = PrevGetShipMk     'BOMList(3, i) = GetShipMk
        Dim GetDwgNo, OldGetDwgNo, GetShipMk, GetShopMk, FndGetDwgNo, FndGetShipMk, FndGetShopMk, FndGetPartDesc As String
        Dim FindShipMarks, PrevGetDwgNo, PrevGetShipMk, PrevGetShopMk, GetPartDesc, PrevGetPartDesc, PrevCcolumn, GetShopPartDesc As String
        Dim Style, Msg, Title, GetNextShopMk, GetNextShipMk As String
        Dim Response As Object
        'Dim BOMWrkSht As Worksheet, WorkSht As Worksheet
        Dim Workbooks As Microsoft.Office.Interop.Excel.Workbooks
        Dim ExceptionPos, CallPos, LineNo, CntBOMItems As Integer
        Dim ShpMkList(3, 1)

        PrgName = "UpdateShpMarks"

        'On Error Resume Next

        'ExcelApp = GetObject(, "Excel.Application")

        'If Err.Number Then
        '    Information.Err.Clear()
        '    ExcelApp = CreateObject("Excel.Application")
        '    If Err.Number Then
        '        MsgBox(Err.Description)
        '        Exit Function
        '    End If
        'End If

        On Error GoTo Err_UpdateShpMarksArray

        'Workbooks = ExcelApp.Workbooks
        'WorkShtName = "Bulk BOM"
        'BOMWrkSht = Workbooks.Application.Worksheets(WorkShtName)
        'WorkSht = Workbooks.Application.ActiveSheet
        'WorkShtName = WorkSht.Name
        'LineNo = BOMWrkSht.Range("B4000").End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).Row
        'CntBOMItems = (UBound(BOMList, 2) - 1)

        '-------DJL-------12-20-2023-------Not sure ShpMkList is needed anymore?

        For i = 1 To (UBound(BOMList, 2) - 1)                           'For i = 0 To (UBound(BOMList, 2) + 3)
            '                                       'With BOMWrkSht
            GetPartDesc = BOMList(7, i)            '(.Range("F" & i).Value)
            'GetShopPartDesc = BOMList(6, i)       Column6 has nothing in it now all descriptions moved to column7-------DJL-12-29-2023
            GetDwgNo = BOMList(1, i)               '(.Range("A" & i).Value)
            GetShipMk = BOMList(3, i)          '.Range("C" & i).Value
            GetShipMk = LTrim(GetShipMk)
            GetShipMk = RTrim(GetShipMk)

            GetShopMk = BOMList(5, i)          '.Range("D" & i).Value

            'If GetDwgNo = "18B" Then
            '    Stop
            'End If

            If GetShipMk <> "" Then
                If GetShipMk = " " Then
                    GoTo EmptySpace
                End If

                If GetDwgNo = "" And BOMList(7, i) <> "" Then                        '.Range("F" & i).Value <> "" Then
                    GetDwgNo = "XX"
                    BOMList(1, i) = GetDwgNo                       '.Range("A" & i).Value = GetDwgNo
                End If

                'FndGetShipMk = GetShipMk                            'Question need for this?

                If GetPartDesc = Nothing And GetShopPartDesc <> Nothing Then
                    GetPartDesc = GetShopPartDesc
                End If

                ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
                ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo              'If assembly is called out on another drawing, Need way to Update Ship Mark.
                ShpMkList(2, UBound(ShpMkList, 2)) = GetShipMk
                ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
                ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
                FindShipMarks = "No"
            Else
EmptySpace:

                If GetDwgNo = "" And BOMList(7, i) <> "" Then                           '.Range("F" & i).Value <> "" Then
                    GetDwgNo = "XX"
                    BOMList(1, i) = GetDwgNo                           '.Range("A" & i).Value = GetDwgNo
                End If

                If GetShipMk = " " Then
                    GetShipMk = ""
                End If

                If GetShipMk = Nothing Then
                    If FndGetShipMk = "FCO" And GetShipMk = Nothing Then
                        BOMList(3, i) = FndGetShipMk                    '.Range("C" & i).Value = FndGetShipMk

                        If GetPartDesc = "" And GetShopPartDesc = "" Then
                            GetPartDesc = GetShopPartDesc
                        End If

                        ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
                        ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo              'If assembly is called out on another drawing, Need way to Update Ship Mark.
                        ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
                        ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
                        ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
                        GoTo EndFixFCO
                    End If

                    If i > 1 Then
                        PrevGetShopMk = BOMList(5, (i - 1))                                       '(.Range("D" & (i - 1)).Value)
                        PrevGetPartDesc = BOMList(7, (i - 1))                               'PrevGetPartDesc = (.Range("F" & (i - 1)).Value)
                    End If

                    If i = 0 And GetPartDesc = Nothing Then
                        GoTo NextDwg
                    End If

                    If GetDwgNo = Nothing And GetShipMk = Nothing Then
                        GoTo NextDwg
                    End If

                    If GetShopMk = PrevGetShopMk And GetDwgNo <> PrevGetDwgNo Then      'New Drawing but Piecemarks are the same and so is the Descriptions
                        If GetPartDesc = PrevGetPartDesc And GetShopMk <> "" Then
                            If i > 1 Then
                                PrevGetDwgNo = BOMList(1, (i - 1))                          '(.Range("A" & (i - 1)).Value)
                            End If

                            Msg = "Is this the same part " & PrevGetShopMk & " on drawing " & PrevGetDwgNo & " Description = " & GetPartDesc & " as item " & GetShopMk & " on drawing " & GetDwgNo & " Description = " & GetPartDesc & "?"
                            Style = MsgBoxStyle.YesNo
                            Title = "Bulk BOM"
                            Response = MsgBox(Msg, Style, Title)

                            If Response = 6 Then                                    'if user clicks yes
                                GetShipMk = PrevGetShipMk
                                BOMList(3, i) = GetShipMk                           '.Range("C" & i).Value = GetShipMk
                            Else
                                GoTo NextDwg                'This is not a match go to next item in list.
                            End If

                            If GetPartDesc = "" And GetShopPartDesc = "" Then
                                GetPartDesc = GetShopPartDesc
                            End If

                            ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
                            ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo              'If assembly is called out on another drawing, Need way to Update Ship Mark.
                            ShpMkList(2, UBound(ShpMkList, 2)) = GetShipMk           'ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
                            ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
                            ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
                            GoTo NextDwg
                        End If
                    Else
                        If GetDwgNo = PrevGetDwgNo And GetShipMk = Nothing Then              'Same Drawing Number but Ship marks are nothing, copy previous Ship marks.
                            If PrevGetShipMk <> "" And BOMList(3, (i - 1)) <> Nothing Then    'If PrevGetShipMk <> "" And .Range("C" & (i - 1)).Value <> Nothing Then       'if Previous GetShipMk not nothing.
                                If PrevGetShipMk <> GetShopMk Then
                                    If Regex.IsMatch(Strings.Right(Mid(GetShopMk, 1, 1), 1), "[0-99]") Then
                                        GetShipMk = PrevGetShipMk
                                        BOMList(3, i) = GetShipMk                           '.Range("C" & i).Value = GetShipMk
                                    Else
                                        GoTo SolutionNotFound
                                    End If
                                End If

                                If GetPartDesc = "" And IsNothing(GetShopPartDesc) = False Then           'If GetPartDesc = "" And GetShopPartDesc = "" Then
                                    GetPartDesc = GetShopPartDesc
                                End If

                                ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
                                ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo          'If assembly is called out on another drawing, Need way to Update Ship Mark.
                                ShpMkList(2, UBound(ShpMkList, 2)) = GetShipMk           'ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
                                ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
                                ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
                                GoTo NextDwg
                            End If
                        End If
SolutionNotFound:
                    End If

                    If Mid(GetDwgNo, 1, 2) = Mid(OldGetDwgNo, 1, 2) And GetDwgNo <> OldGetDwgNo Then
                        FindShipMarks = "Yes"
                        If GetShipMk = Nothing Or GetShipMk = "" Then
FindNextShopMak:
                            If Len(GetShopMk) > 2 Then                                  'If Len(FndGetShopMk) > 2 Then
                                For j = 0 To UBound(ShpMkList, 2)
                                    FndGetPartDesc = ShpMkList(0, j)
                                    FndGetDwgNo = ShpMkList(1, j)
                                    FndGetShipMk = ShpMkList(2, j)
                                    FndGetShopMk = ShpMkList(3, j)

                                    If Mid(FndGetDwgNo, 1, 2) = Mid(GetDwgNo, 1, 2) Then
                                        'FndGetShipMk = ShpMkList(2, j)
                                        'FndGetShopMk = ShpMkList(3, j)

                                        Select Case FndGetShipMk
                                            Case "FCO"
FixFCO:
                                                BOMList(3, i) = FndGetShipMk                                    '.Range("C" & i).Value = FndGetShipMk

                                                If GetPartDesc = "" And GetShopPartDesc = "" Then
                                                    GetPartDesc = GetShopPartDesc
                                                End If

                                                ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
                                                ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
                                                ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
                                                ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
                                                ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
                                                GoTo EndFixFCO
                                            Case Else
                                                If FndGetShopMk = GetShopMk And FndGetDwgNo = GetDwgNo Then
                                                    BOMList(3, i) = FndGetShipMk                                '.Range("C" & i).Value = FndGetShipMk

                                                    If GetPartDesc = "" And GetShopPartDesc = "" Then
                                                        GetPartDesc = GetShopPartDesc
                                                    End If

                                                    ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
                                                    ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
                                                    ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
                                                    ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
                                                    ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
                                                    GoTo EndFixFCO
                                                Else
                                                    If FndGetShopMk = GetShopMk And FndGetDwgNo <> GetDwgNo Then
                                                        Msg = "Is this the same part " & FndGetShopMk & " on drawing " & FndGetDwgNo & " Description = " & FndGetPartDesc & " as item " & GetShopMk & " on drawing " & GetDwgNo & " Description = " & GetPartDesc & "?"
                                                        Style = MsgBoxStyle.YesNo
                                                        Title = "Bulk BOM"
                                                        Response = MsgBox(Msg, Style, Title)

                                                        If Response = 6 Then                    'if user clicks yes
                                                            GetShipMk = FndGetShipMk
                                                            BOMList(3, i) = GetShipMk                           '.Range("C" & i).Value = GetShipMk
                                                        Else
                                                            GoTo NextItemInList                 'This is not a match go to next item in list.
                                                        End If

                                                        '.Range("C" & i).Value = FndGetShipMk

                                                        If GetPartDesc = "" And GetShopPartDesc = "" Then
                                                            GetPartDesc = GetShopPartDesc
                                                        End If

                                                        ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
                                                        ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
                                                        ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
                                                        ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
                                                        ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
                                                        GoTo EndFixFCO

                                                    Else
NextItemInList:
                                                        If FndGetShipMk = GetShopMk Then
                                                            BOMList(3, i) = FndGetShipMk                    '.Range("C" & i).Value = FndGetShipMk
                                                            GetShipMk = FndGetShipMk

                                                            If GetPartDesc = "" And GetShopPartDesc = "" Then
                                                                GetPartDesc = GetShopPartDesc
                                                            End If

                                                            ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
                                                            ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
                                                            ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
                                                            ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
                                                            ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
                                                            GoTo EndFixFCO
                                                        End If
                                                    End If
                                                End If
                                        End Select
                                    End If
                                Next j
                            End If
EndFixFCO:
                        End If
                    Else
                        If FindShipMarks = "Yes" Then
                            If Regex.IsMatch(Strings.Right(Mid(GetShopMk, 1, 1), 1), "[0-9]") Then
                                BOMList(3, i) = FndGetShipMk                                            '.Range("C" & i).Value = FndGetShipMk

                                If GetPartDesc = "" And GetShopPartDesc = "" Then
                                    GetPartDesc = GetShopPartDesc
                                End If

                                ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
                                ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
                                ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk
                                ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
                                ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
                            Else
                                If Regex.IsMatch(Strings.Right(Mid(GetShopMk, 1, 1), 1), "[A-Z]") Then
                                    GoTo FindNextShopMak
                                Else
                                    If i > 1 Then
                                        PrevGetDwgNo = BOMList(1, (i - 1))                            '(.Range("A" & (i - 1)).Value)
                                        PrevGetShopMk = BOMList(5, (i - 1))                                   '(.Range("D" & (i - 1)).Value)
                                        PrevGetPartDesc = BOMList(7, (i - 1))                       '(.Range("F" & (i - 1)).Value)
                                    End If

                                    If GetShopMk = Nothing Then
                                        If GetDwgNo = PrevGetDwgNo And FndGetShipMk <> Nothing Then
                                            BOMList(3, i) = FndGetShipMk                                '.Range("C" & i).Value = FndGetShipMk
                                        End If

                                        If GetPartDesc = "" And GetShopPartDesc = "" Then
                                            GetPartDesc = GetShopPartDesc
                                        End If

                                        ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
                                        ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
                                        ShpMkList(2, UBound(ShpMkList, 2)) = GetShipMk
                                        ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
                                        ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
                                    End If
                                End If
                            End If
                        Else
                            If PrevGetDwgNo = GetDwgNo And InStr(GetDwgNo, "10D") > 0 Then
                                BOMList(3, i) = PrevGetShipMk
                            Else
                                If InStr(GetDwgNo, "10D") = 0 And FndGetShipMk <> Nothing Then
                                    BOMList(3, i) = PrevGetShipMk
                                Else
                                    If PrevGetDwgNo = GetDwgNo And InStr(GetDwgNo, "10E") > 0 Then
                                        BOMList(3, i) = PrevGetShipMk
                                    Else
                                        If InStr(GetDwgNo, "10E") = 0 And FndGetShipMk <> Nothing Then
                                            BOMList(3, i) = PrevGetShipMk
                                        End If
                                    End If
                                End If
                            End If

                            If GetPartDesc = "" And GetShopPartDesc = "" Then
                                GetPartDesc = GetShopPartDesc
                            End If

                            ShpMkList(0, UBound(ShpMkList, 2)) = GetPartDesc
                            ShpMkList(1, UBound(ShpMkList, 2)) = GetDwgNo
                            ShpMkList(2, UBound(ShpMkList, 2)) = GetShipMk                           'ShpMkList(2, UBound(ShpMkList, 2)) = FndGetShipMk

                            If InStr(GetShipMk, "SR") = 1 Then                                      'If InStr(FndGetShipMk, "SR") = 1 Then
                                BOMList(7, i) = "SHELL PLATE " & GetShipMk & BOMList(7, i)        '.Range("F" & i).Value = "SHELL PLATE " & GetShipMk & " " & .Range("F" & i).Value     '.Range("F" & i).Value = "SHELL PLATE " & FndGetShipMk & " " & .Range("F" & i).Value
                            End If

                            ShpMkList(3, UBound(ShpMkList, 2)) = GetShopMk
                            ReDim Preserve ShpMkList(3, UBound(ShpMkList, 2) + 1)
                        End If
                    End If

                    If PrevGetDwgNo = GetDwgNo And GetShipMk = "" Then
                        If PrevGetShipMk <> "" And BOMList(3, i) = "" Then                          'If PrevGetShipMk <> "" And .Range("C" & i).Value = "" Then
                            If BOMList(3, (i - 1)) <> "" Then                                       'If .Range("C" & (i - 1)).Value <> "" Then

                                If Regex.IsMatch(Strings.Right(Mid(GetShopMk, 1, 1), 1), "[A-Z]") Then
                                    BOMList(3, i) = GetShopMk
                                    PrevGetShipMk = GetShopMk
                                    BOMList(8, i) = "Yes"           'GetShipMKYesNo = BOMList(8, i)
                                Else
                                    BOMList(3, i) = PrevGetShipMk                                       '.Range("C" & i).Value = PrevGetShipMk
                                End If
                            End If
                        End If
                    Else
                        If PrevGetDwgNo <> GetDwgNo And GetShipMk = "" Then                         'Job Found new drawing with no Ship marks for Assembly drawings.
                            GetNextShipMk = BOMList(3, (i + 1))

                            If PrevGetShipMk <> "" And GetNextShipMk <> "" Then
                                Msg = ("An error was found on your drawings were " & GetNextShipMk & " is not on the Assembly Items or Plates! Description = " & GetPartDesc & ". Is this the correct Shop Mark?")
                                Style = MsgBoxStyle.YesNo
                                Title = "Bulk BOM"
                                Response = MsgBox(Msg, Style, Title)

                                If Response = 6 Then                                    'if user clicks yes
                                    GetShipMk = GetNextShipMk
                                    BOMList(3, i) = GetNextShipMk

                                    'With BOMWrkSht
                                    '    .Range("D" & (i + 4)).Value = GetNextShipMk
                                    'End With
                                    GoTo FoundGetShipMk                 'NextDwg
                                End If
                            End If
                        End If
                    End If
                End If
            End If
            'End With
            If Mid(OldGetDwgNo, 1, 2) <> Mid(GetDwgNo, 1, 2) Then
                FindShipMarks = "No"
                OldGetDwgNo = GetDwgNo
            Else
                OldGetDwgNo = GetDwgNo
            End If

            If PrevGetDwgNo <> GetDwgNo And InStr(GetDwgNo, "10D") > 0 Then
                If PrevGetShipMk <> GetShipMk And GetShipMk <> Nothing Then              'If PrevGetShipMk <> GetShipMk And (GetShipMk) = False Then
                    GoTo FoundGetShipMk
                End If

                If PrevGetShipMk <> GetShipMk And IsNothing(PrevGetShipMk) = False Then          'If PrevGetShipMk <> FndGetShipMk And IsNothing(PrevGetShipMk) = False Then
                    'With BOMWrkSht

                    FndGetShipMk = BOMList(3, i)                            '.Range("C" & i).Value
                    OldGetDwgNo = BOMList(1, i)                             '.Range("A" & i).Value

                    'End With

                    If GetDwgNo = OldGetDwgNo And FndGetShipMk <> Nothing Then                          'If GetDwgNo = OldGetDwgNo Then
                        PrevGetShipMk = FndGetShipMk
                    End If
                Else
                    FndGetShipMk = Nothing
                End If
            Else
                If PrevGetDwgNo <> GetDwgNo And InStr(GetDwgNo, "10E") > 0 Then
                    If PrevGetShipMk <> GetShipMk And GetShipMk <> Nothing Then              'If PrevGetShipMk <> GetShipMk And (GetShipMk) = False Then
                        GoTo FoundGetShipMk
                    End If

                    If PrevGetShipMk <> GetShipMk And IsNothing(PrevGetShipMk) = False Then          'If PrevGetShipMk <> FndGetShipMk And IsNothing(PrevGetShipMk) = False Then
                        'With BOMWrkSht

                        FndGetShipMk = BOMList(3, i)                            '.Range("C" & i).Value
                        OldGetDwgNo = BOMList(1, i)                             '.Range("A" & i).Value

                        'End With

                        If GetDwgNo = OldGetDwgNo And FndGetShipMk <> Nothing Then                          'If GetDwgNo = OldGetDwgNo Then
                            PrevGetShipMk = FndGetShipMk
                        End If
                    Else
                        FndGetShipMk = Nothing
                    End If
                Else
FoundGetShipMk:
                    'With BOMWrkSht
                    '    PrevCcolumn = .Range("C" & i - 1).Value
                    'End With

                    'If IsNothing(GetShipMk) = False And PrevCcolumn <> Nothing Then
                    If GetShipMk <> "" Then
                        PrevGetShipMk = GetShipMk                            'PrevGetShipMk = FndGetShipMk
                    End If
                    'Else
                    '    PrevGetShipMk = ""
                    'End If
                End If
                End If

NextDwg:

            PrevGetDwgNo = GetDwgNo
        Next i

        GenInfo3233.BOMList = BOMList

Err_UpdateShpMarksArray:
        ErrNo = Err.Number

        If ErrNo <> 0 Then
            PriPrg = "BulkBOMFab3D-Intent"
            PrgName = "UpdateShpMarksArray"
            ErrMsg = Err.Description
            ErrSource = Err.Source
            ErrDll = Err.LastDllError
            ErrLastLineX = Err.Erl
            ErrException = Err.GetException

            Dim st As New StackTrace(Err.GetException, True)
            CntFrames = st.FrameCount
            GetFramesSrt = st.GetFrames
            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
            PrgLineNo = PrgLineNo.Replace("@", "at")
            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

            BOM_Menu3D.HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)

            If IsNothing(ManwayInfo3134.UserName) = True Then
                ManwayInfo3134.UserName = System.Environment.UserName()
            End If

            If ManwayInfo3134.UserName = "dlong" Then
                MsgBox(ErrMsg)
                Stop
                Resume
            Else
                ExceptionPos = InStr(1, ErrMsg, "Exception")
                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
                CntExcept = (CntExcept + 1)

                If CntExcept < 20 Then
                    If ExceptionPos > 0 Then
                        Resume
                    End If
                    If CallPos > 0 Then
                        Resume
                    End If
                End If
            End If
        End If

    End Function

    '    Function FormatSTDItems(ByRef StdsBOMList As Object) As Object
    '        Dim Range As Object
    '        Dim Worksheets As Object
    '        Dim i As Object
    '        Dim j As Short
    '        Dim LinesToDelete As Object
    '        Dim DupShipMk As Object
    '        Dim AssyMK As Object
    '        Dim AssyMKtmp As Object
    '        Dim RefDwgLen As Short
    '        Dim RefDwgLetter, RefMk, RefDwg As String
    '        Dim BOMWrkSht As Worksheet
    '        Dim StdItemsWrkSht As Worksheet
    '        Dim WorkSht As Worksheet
    '        Dim Workbooks As Microsoft.Office.Interop.Excel.Workbooks

    '        PrgName = "FormatSTDItems"

    '        On Error Resume Next

    '        ExcelApp = GetObject(, "Excel.Application")

    '        If Err.Number Then
    '            Information.Err.Clear()
    '            ExcelApp = CreateObject("Excel.Application")
    '            If Err.Number Then
    '                MsgBox(Err.Description)
    '                Exit Function
    '            End If
    '        End If

    '        On Error GoTo Err_FormatSTDItems

    '        Workbooks = ExcelApp.Workbooks
    '        WorkShtName = "STD Items"
    '        StdItemsWrkSht = Workbooks.Application.Worksheets(WorkShtName)
    '        WorkSht = Workbooks.Application.ActiveSheet
    '        WorkShtName = WorkSht.Name
    '        ReDim LinesToDelete(1)
    '        ReDim DupShipMk(1)

    '        For i = 5 To (UBound(StdsBOMList, 2) + 4)
    '            For j = 1 To 10
    '                With StdItemsWrkSht
    '                    Dim Test As String
    '                    Test = (Chr(64 + j) & i)
    '                    With .Range(Test)
    '                        If .Value <> vbNullString Then
    '                            If .Value.ToString = " " Then
    '                                .Value = vbNullString
    '                            End If
    '                        End If
    '                    End With
    '                End With
    '            Next j
    '        Next i

    '        Dim FCODwgNo As String
    '        For i = 5 To (UBound(StdsBOMList, 2) + 4)
    '            With StdItemsWrkSht
    '                If .Range("C" & i).Value <> "" Then
    '                    If .Range("G" & i).Value = "" Then
    '                        If InStr(1, .Range("F" & i).Value, "FLUSH CLEAN") <> 0 Then
    '                            MarkForDelete(LinesToDelete, i)
    '                            AssyMK = .Range("C" & i).Value
    '                            FCODwgNo = Left(.Range("A" & i).Value, 2)

    '                            Do Until Left(.Range("A" & i).Value, 2) <> FCODwgNo
    '                                If .Range("C" & i).Value = "" And .Range("D" & i).Value = "" And .Range("E" & i).Value = "" Then
    '                                    MarkForDelete(LinesToDelete, i)
    '                                ElseIf .Range("C" & i).Value <> "" And .Range("D" & i).Value = "" And .Range("G" & i).Value = "" Then
    '                                    MarkForDelete(LinesToDelete, i)
    '                                    AssyMKtmp = .Range("C" & i).Value
    '                                    i = i + 1
    '                                    If .Range("C" & i).Value = "" And Left(.Range("A" & i).Value, 2) = FCODwgNo Then
    '                                        .Range("C" & i).Value = AssyMKtmp
    '                                    End If
    '                                Else
    '                                    If .Range("C" & i).Value = "" Then
    '                                        .Range("C" & i).Value = AssyMK
    '                                    End If
    '                                End If
    '                                i = i + 1
    '                            Loop
    '                            i = i - 1
    '                        ElseIf .Range("C" & i).Value <> "" And .Range("D" & i).Value <> "" And .Range("E" & i).Value.ToString <> "" Then
    '                        Else
    '                            If .Range("C" & i).Value <> "" And .Range("C" & i + 1).Value <> "" Then
    '                                If InStr(1, .Range("F" & i).Value, "SEE D") <> 0 Then
    '                                    MarkForDelete(LinesToDelete, i)
    '                                End If
    '                            Else
    '                                AssyMK = .Range("C" & i).Value
    '                                MarkForDelete(LinesToDelete, i)
    '                            End If
    '                        End If
    '                    End If
    '                ElseIf InStr(1, .Range("F" & i).Value, "SEE DWG") <> 0 Or InStr(1, .Range("F" & i).Value, "SEE DRAWING") <> 0 Then
    '                    .Range("C" & i).Value = AssyMK
    '                Else                                        'if ship mark is empty
    '                    If .Range("C" & i).Value <> Nothing And .Range("D" & i).Value = Nothing And .Range("E" & i).Value <> Nothing Then
    '                        If .Range("C" & i).Value = "" And .Range("D" & i).Value.ToString = "" And .Range("E" & i).Value.ToString = "" Then
    '                            MarkForDelete(LinesToDelete, i)
    '                        Else
    '                            .Range("C" & i).Value = AssyMK
    '                        End If
    '                    End If
    '                End If
    '            End With
    '        Next i

    '        If UBound(LinesToDelete) <> 1 Then
    '            For i = UBound(LinesToDelete) To LBound(LinesToDelete) Step -1
    '                With StdItemsWrkSht
    '                    If i <> 0 Then
    '                        .Rows(LinesToDelete(i)).Delete()
    '                    Else
    '                        GoTo NextI
    '                    End If
    '                End With
    'NextI:      Next i
    '        End If

    'Err_FormatSTDItems:
    '        ErrNo = Err.Number

    '        If ErrNo <> 0 Then
    '            PriPrg = "BulkBOMFab3D-Intent"
    '            ErrMsg = Err.Description
    '            ErrSource = Err.Source
    '            ErrDll = Err.LastDllError
    '            ErrLastLineX = Err.Erl
    '            ErrException = Err.GetException

    '            Dim st As New StackTrace(Err.GetException, True)
    '            CntFrames = st.FrameCount
    '            GetFramesSrt = st.GetFrames
    '            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
    '            PrgLineNo = PrgLineNo.Replace("@", "at")
    '            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
    '            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

    '            BOM_Menu3D.HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)

    '            If IsNothing(ManwayInfo3134.UserName) = True Then
    '                ManwayInfo3134.UserName = System.Environment.UserName()
    '            End If

    '            If ManwayInfo3134.UserName = "dlong" Then
    '                MsgBox(ErrMsg)
    '                Stop
    '                Resume
    '            Else
    '                ExceptionPos = InStr(1, ErrMsg, "Exception")
    '                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
    '                CntExcept = (CntExcept + 1)

    '                If CntExcept < 20 Then
    '                    If ExceptionPos > 0 Then
    '                        Resume
    '                    End If
    '                    If CallPos > 0 Then
    '                        Resume
    '                    End If
    '                End If
    '            End If
    '        End If

    '    End Function

    '    Function MarkForDelete(ByRef LinesToDelete As Object, ByVal LineNo As Short) As Object
    '        PrgName = "MarkForDelete"

    '        On Error GoTo Err_MarkForDelete

    '        Dim Test As String
    '        Test = LinesToDelete(UBound(LinesToDelete))

    '        If LinesToDelete(UBound(LinesToDelete)) = Nothing Then
    '            If LinesToDelete(UBound(LinesToDelete)) <> LineNo Then
    '                LinesToDelete(UBound(LinesToDelete)) = LineNo
    '            End If
    '        Else
    '            If LinesToDelete(UBound(LinesToDelete)) <> LineNo Then
    '                ReDim Preserve LinesToDelete(UBound(LinesToDelete) + 1)
    '                LinesToDelete(UBound(LinesToDelete)) = LineNo
    '            End If
    '        End If

    'Err_MarkForDelete:
    '        ErrNo = Err.Number

    '        If ErrNo <> 0 Then
    '            PriPrg = "BulkBOMFab3D-Intent"
    '            ErrMsg = Err.Description
    '            ErrSource = Err.Source
    '            ErrDll = Err.LastDllError
    '            ErrLastLineX = Err.Erl
    '            ErrException = Err.GetException

    '            Dim st As New StackTrace(Err.GetException, True)
    '            CntFrames = st.FrameCount
    '            GetFramesSrt = st.GetFrames
    '            PrgLineNo = GetFramesSrt(CntFrames - 1).ToString
    '            PrgLineNo = PrgLineNo.Replace("@", "at")
    '            PrgLineNo = PrgLineNo.Replace("VbCrlf", "")
    '            PrgLineNo = PrgLineNo.Replace(Chr(15), "")

    '            BOM_Menu3D.HandleErrSQL(PrgName, ErrNo, ErrMsg, ErrSource, PriPrg, ErrDll, DwgItem, PrgLineNo)

    '            If IsNothing(ManwayInfo3134.UserName) = True Then
    '                ManwayInfo3134.UserName = System.Environment.UserName
    '            End If

    '            If ManwayInfo3134.UserName = "dlong" Then
    '                MsgBox(ErrMsg)
    '                Stop
    '                Resume
    '            Else
    '                ExceptionPos = InStr(1, ErrMsg, "Exception")
    '                CallPos = InStr(1, ErrMsg, "Call was rejected by callee")
    '                CntExcept = (CntExcept + 1)

    '                If CntExcept < 20 Then
    '                    If ExceptionPos > 0 Then
    '                        Resume
    '                    End If
    '                    If CallPos > 0 Then
    '                        Resume
    '                    End If
    '                End If
    '            End If
    '        End If

    '    End Function
End Module