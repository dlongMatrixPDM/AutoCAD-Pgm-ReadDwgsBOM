﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class BOM_Menu3D
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BOM_Menu3D))
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.BtnStart2 = New System.Windows.Forms.Button()
        Me.LblProgress = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.DwgsNotFoundList = New System.Windows.Forms.ListBox()
        Me.btnNewDir = New System.Windows.Forms.Button()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.DwgList = New System.Windows.Forms.ListBox()
        Me.SelectList = New System.Windows.Forms.ListBox()
        Me.BtnAdd = New System.Windows.Forms.Button()
        Me.BtnAddAll = New System.Windows.Forms.Button()
        Me.BtnRemove = New System.Windows.Forms.Button()
        Me.BtnClear = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ComboBxRev = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.BtnGetMWInfo = New System.Windows.Forms.Button()
        Me.PathBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadioBtnHVEC = New System.Windows.Forms.RadioButton()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.BtnVideo = New System.Windows.Forms.Button()
        Me.CancelButton_Renamed = New System.Windows.Forms.Button()
        Me.MatrixLogo = New System.Windows.Forms.PictureBox()
        Me.HandleErrorsToFabMat = New System.Windows.Forms.BindingSource(Me.components)
        Me.ChkBoxAutoCAD3D = New System.Windows.Forms.CheckBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.TxtBoxBOMItemsToProcess = New System.Windows.Forms.TextBox()
        Me.TxtBoxDwgsToProcess = New System.Windows.Forms.TextBox()
        Me.LblDwgsToProcess = New System.Windows.Forms.Label()
        Me.LblBOMItemsToProess = New System.Windows.Forms.Label()
        Me.LblBulkBOM = New System.Windows.Forms.Label()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.MatrixLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HandleErrorsToFabMat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(10, 446)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(665, 22)
        Me.ProgressBar1.TabIndex = 48
        '
        'BtnStart2
        '
        Me.BtnStart2.BackColor = System.Drawing.SystemColors.Control
        Me.BtnStart2.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnStart2.Enabled = False
        Me.BtnStart2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnStart2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnStart2.Location = New System.Drawing.Point(611, 133)
        Me.BtnStart2.Name = "BtnStart2"
        Me.BtnStart2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnStart2.Size = New System.Drawing.Size(64, 32)
        Me.BtnStart2.TabIndex = 47
        Me.BtnStart2.Text = "Start"
        Me.BtnStart2.UseVisualStyleBackColor = False
        '
        'LblProgress
        '
        Me.LblProgress.BackColor = System.Drawing.SystemColors.Control
        Me.LblProgress.Cursor = System.Windows.Forms.Cursors.Default
        Me.LblProgress.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblProgress.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LblProgress.Location = New System.Drawing.Point(12, 420)
        Me.LblProgress.Name = "LblProgress"
        Me.LblProgress.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LblProgress.Size = New System.Drawing.Size(594, 23)
        Me.LblProgress.TabIndex = 45
        Me.LblProgress.Text = "Progress........"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.DwgsNotFoundList)
        Me.GroupBox5.Controls.Add(Me.btnNewDir)
        Me.GroupBox5.Controls.Add(Me.CheckBox1)
        Me.GroupBox5.Location = New System.Drawing.Point(434, 102)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(97, 48)
        Me.GroupBox5.TabIndex = 44
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Comparison"
        Me.GroupBox5.Visible = False
        '
        'DwgsNotFoundList
        '
        Me.DwgsNotFoundList.BackColor = System.Drawing.SystemColors.Window
        Me.DwgsNotFoundList.Cursor = System.Windows.Forms.Cursors.Default
        Me.DwgsNotFoundList.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DwgsNotFoundList.ForeColor = System.Drawing.SystemColors.WindowText
        Me.DwgsNotFoundList.Location = New System.Drawing.Point(30, 39)
        Me.DwgsNotFoundList.Name = "DwgsNotFoundList"
        Me.DwgsNotFoundList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DwgsNotFoundList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.DwgsNotFoundList.Size = New System.Drawing.Size(143, 4)
        Me.DwgsNotFoundList.TabIndex = 60
        Me.DwgsNotFoundList.Visible = False
        '
        'btnNewDir
        '
        Me.btnNewDir.BackColor = System.Drawing.SystemColors.Control
        Me.btnNewDir.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnNewDir.Enabled = False
        Me.btnNewDir.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNewDir.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNewDir.Location = New System.Drawing.Point(183, 25)
        Me.btnNewDir.Name = "btnNewDir"
        Me.btnNewDir.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btnNewDir.Size = New System.Drawing.Size(64, 12)
        Me.btnNewDir.TabIndex = 31
        Me.btnNewDir.Text = "New Directory"
        Me.btnNewDir.UseVisualStyleBackColor = False
        '
        'CheckBox1
        '
        Me.CheckBox1.BackColor = System.Drawing.SystemColors.Control
        Me.CheckBox1.Cursor = System.Windows.Forms.Cursors.Default
        Me.CheckBox1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CheckBox1.Location = New System.Drawing.Point(6, 19)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CheckBox1.Size = New System.Drawing.Size(151, 24)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "Compare To Existing Bulk BOM"
        Me.CheckBox1.UseVisualStyleBackColor = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.DwgList)
        Me.GroupBox4.Controls.Add(Me.SelectList)
        Me.GroupBox4.Controls.Add(Me.BtnAdd)
        Me.GroupBox4.Controls.Add(Me.BtnAddAll)
        Me.GroupBox4.Controls.Add(Me.BtnRemove)
        Me.GroupBox4.Controls.Add(Me.BtnClear)
        Me.GroupBox4.Location = New System.Drawing.Point(12, 204)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(663, 213)
        Me.GroupBox4.TabIndex = 43
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Drawings Found in Directory above.                        Selected Drawings"
        '
        'DwgList
        '
        Me.DwgList.BackColor = System.Drawing.SystemColors.Window
        Me.DwgList.Cursor = System.Windows.Forms.Cursors.Default
        Me.DwgList.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DwgList.ForeColor = System.Drawing.SystemColors.WindowText
        Me.DwgList.Location = New System.Drawing.Point(6, 21)
        Me.DwgList.Name = "DwgList"
        Me.DwgList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DwgList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.DwgList.Size = New System.Drawing.Size(285, 160)
        Me.DwgList.TabIndex = 16
        '
        'SelectList
        '
        Me.SelectList.BackColor = System.Drawing.SystemColors.Window
        Me.SelectList.Cursor = System.Windows.Forms.Cursors.Default
        Me.SelectList.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SelectList.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SelectList.Location = New System.Drawing.Point(370, 19)
        Me.SelectList.Name = "SelectList"
        Me.SelectList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SelectList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.SelectList.Size = New System.Drawing.Size(285, 160)
        Me.SelectList.TabIndex = 15
        '
        'BtnAdd
        '
        Me.BtnAdd.BackColor = System.Drawing.SystemColors.Control
        Me.BtnAdd.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnAdd.Enabled = False
        Me.BtnAdd.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAdd.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnAdd.Location = New System.Drawing.Point(297, 21)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnAdd.Size = New System.Drawing.Size(67, 32)
        Me.BtnAdd.TabIndex = 8
        Me.BtnAdd.Text = "&Add ->"
        Me.BtnAdd.UseVisualStyleBackColor = False
        '
        'BtnAddAll
        '
        Me.BtnAddAll.BackColor = System.Drawing.SystemColors.Control
        Me.BtnAddAll.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnAddAll.Enabled = False
        Me.BtnAddAll.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAddAll.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnAddAll.Location = New System.Drawing.Point(297, 59)
        Me.BtnAddAll.Name = "BtnAddAll"
        Me.BtnAddAll.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnAddAll.Size = New System.Drawing.Size(67, 32)
        Me.BtnAddAll.TabIndex = 9
        Me.BtnAddAll.Text = "A&dd All ->"
        Me.BtnAddAll.UseVisualStyleBackColor = False
        '
        'BtnRemove
        '
        Me.BtnRemove.BackColor = System.Drawing.SystemColors.Control
        Me.BtnRemove.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnRemove.Enabled = False
        Me.BtnRemove.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRemove.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnRemove.Location = New System.Drawing.Point(297, 97)
        Me.BtnRemove.Name = "BtnRemove"
        Me.BtnRemove.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRemove.Size = New System.Drawing.Size(67, 32)
        Me.BtnRemove.TabIndex = 10
        Me.BtnRemove.Text = "<-Remove"
        Me.BtnRemove.UseVisualStyleBackColor = False
        '
        'BtnClear
        '
        Me.BtnClear.BackColor = System.Drawing.SystemColors.Control
        Me.BtnClear.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnClear.Enabled = False
        Me.BtnClear.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClear.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnClear.Location = New System.Drawing.Point(297, 135)
        Me.BtnClear.Name = "BtnClear"
        Me.BtnClear.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnClear.Size = New System.Drawing.Size(67, 32)
        Me.BtnClear.TabIndex = 11
        Me.BtnClear.Text = "&Clear"
        Me.BtnClear.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.ComboBxRev)
        Me.GroupBox3.Location = New System.Drawing.Point(187, 97)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(131, 49)
        Me.GroupBox3.TabIndex = 42
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "BOM Revision"
        '
        'ComboBxRev
        '
        Me.ComboBxRev.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBxRev.FormattingEnabled = True
        Me.ComboBxRev.Location = New System.Drawing.Point(6, 17)
        Me.ComboBxRev.Name = "ComboBxRev"
        Me.ComboBxRev.Size = New System.Drawing.Size(87, 21)
        Me.ComboBxRev.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.BtnGetMWInfo)
        Me.GroupBox2.Controls.Add(Me.PathBox)
        Me.GroupBox2.Location = New System.Drawing.Point(13, 151)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(568, 47)
        Me.GroupBox2.TabIndex = 41
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Select Path"
        '
        'BtnGetMWInfo
        '
        Me.BtnGetMWInfo.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnGetMWInfo.Location = New System.Drawing.Point(524, 14)
        Me.BtnGetMWInfo.Name = "BtnGetMWInfo"
        Me.BtnGetMWInfo.Size = New System.Drawing.Size(38, 27)
        Me.BtnGetMWInfo.TabIndex = 10
        Me.BtnGetMWInfo.Text = "..."
        Me.BtnGetMWInfo.UseVisualStyleBackColor = True
        '
        'PathBox
        '
        Me.PathBox.Location = New System.Drawing.Point(9, 19)
        Me.PathBox.Name = "PathBox"
        Me.PathBox.Size = New System.Drawing.Size(509, 20)
        Me.PathBox.TabIndex = 9
        Me.PathBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioBtnHVEC)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 97)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(168, 48)
        Me.GroupBox1.TabIndex = 40
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "External Project?"
        '
        'RadioBtnHVEC
        '
        Me.RadioBtnHVEC.AutoSize = True
        Me.RadioBtnHVEC.Location = New System.Drawing.Point(9, 19)
        Me.RadioBtnHVEC.Name = "RadioBtnHVEC"
        Me.RadioBtnHVEC.Size = New System.Drawing.Size(135, 17)
        Me.RadioBtnHVEC.TabIndex = 21
        Me.RadioBtnHVEC.TabStop = True
        Me.RadioBtnHVEC.Text = "HVEC\Enhance\Acker"
        Me.RadioBtnHVEC.UseVisualStyleBackColor = True
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Location = New System.Drawing.Point(286, 75)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(169, 17)
        Me.RadioButton3.TabIndex = 22
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "Intent compare Bill of Materials"
        Me.RadioButton3.UseVisualStyleBackColor = True
        Me.RadioButton3.Visible = False
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(537, 131)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(138, 17)
        Me.RadioButton2.TabIndex = 21
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Seal Bulk Bill of Material"
        Me.RadioButton2.UseVisualStyleBackColor = True
        Me.RadioButton2.Visible = False
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(537, 108)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(142, 17)
        Me.RadioButton1.TabIndex = 20
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Tank Bulk Bill of Material"
        Me.RadioButton1.UseVisualStyleBackColor = True
        Me.RadioButton1.Visible = False
        '
        'BtnVideo
        '
        Me.BtnVideo.BackColor = System.Drawing.SystemColors.Control
        Me.BtnVideo.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnVideo.Enabled = False
        Me.BtnVideo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnVideo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnVideo.Location = New System.Drawing.Point(611, 94)
        Me.BtnVideo.Name = "BtnVideo"
        Me.BtnVideo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnVideo.Size = New System.Drawing.Size(64, 32)
        Me.BtnVideo.TabIndex = 37
        Me.BtnVideo.Text = "Video"
        Me.BtnVideo.UseVisualStyleBackColor = False
        '
        'CancelButton_Renamed
        '
        Me.CancelButton_Renamed.BackColor = System.Drawing.SystemColors.Control
        Me.CancelButton_Renamed.Cursor = System.Windows.Forms.Cursors.Default
        Me.CancelButton_Renamed.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CancelButton_Renamed.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CancelButton_Renamed.Location = New System.Drawing.Point(611, 170)
        Me.CancelButton_Renamed.Name = "CancelButton_Renamed"
        Me.CancelButton_Renamed.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CancelButton_Renamed.Size = New System.Drawing.Size(64, 32)
        Me.CancelButton_Renamed.TabIndex = 38
        Me.CancelButton_Renamed.Text = "&Cancel"
        Me.CancelButton_Renamed.UseVisualStyleBackColor = False
        '
        'MatrixLogo
        '
        Me.MatrixLogo.BackgroundImage = CType(resources.GetObject("MatrixLogo.BackgroundImage"), System.Drawing.Image)
        Me.MatrixLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.MatrixLogo.Location = New System.Drawing.Point(13, 12)
        Me.MatrixLogo.Name = "MatrixLogo"
        Me.MatrixLogo.Size = New System.Drawing.Size(259, 79)
        Me.MatrixLogo.TabIndex = 53
        Me.MatrixLogo.TabStop = False
        '
        'ChkBoxAutoCAD3D
        '
        Me.ChkBoxAutoCAD3D.AutoSize = True
        Me.ChkBoxAutoCAD3D.Location = New System.Drawing.Point(332, 102)
        Me.ChkBoxAutoCAD3D.Margin = New System.Windows.Forms.Padding(2)
        Me.ChkBoxAutoCAD3D.Name = "ChkBoxAutoCAD3D"
        Me.ChkBoxAutoCAD3D.Size = New System.Drawing.Size(87, 17)
        Me.ChkBoxAutoCAD3D.TabIndex = 2
        Me.ChkBoxAutoCAD3D.Text = "AutoCAD 3D"
        Me.ChkBoxAutoCAD3D.UseVisualStyleBackColor = True
        Me.ChkBoxAutoCAD3D.Visible = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'TxtBoxBOMItemsToProcess
        '
        Me.TxtBoxBOMItemsToProcess.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtBoxBOMItemsToProcess.ForeColor = System.Drawing.Color.SkyBlue
        Me.TxtBoxBOMItemsToProcess.Location = New System.Drawing.Point(624, 63)
        Me.TxtBoxBOMItemsToProcess.Name = "TxtBoxBOMItemsToProcess"
        Me.TxtBoxBOMItemsToProcess.Size = New System.Drawing.Size(52, 26)
        Me.TxtBoxBOMItemsToProcess.TabIndex = 299
        Me.TxtBoxBOMItemsToProcess.Visible = False
        '
        'TxtBoxDwgsToProcess
        '
        Me.TxtBoxDwgsToProcess.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtBoxDwgsToProcess.ForeColor = System.Drawing.Color.SkyBlue
        Me.TxtBoxDwgsToProcess.Location = New System.Drawing.Point(624, 31)
        Me.TxtBoxDwgsToProcess.Name = "TxtBoxDwgsToProcess"
        Me.TxtBoxDwgsToProcess.Size = New System.Drawing.Size(52, 26)
        Me.TxtBoxDwgsToProcess.TabIndex = 300
        Me.TxtBoxDwgsToProcess.Visible = False
        '
        'LblDwgsToProcess
        '
        Me.LblDwgsToProcess.AutoSize = True
        Me.LblDwgsToProcess.Location = New System.Drawing.Point(516, 38)
        Me.LblDwgsToProcess.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblDwgsToProcess.Name = "LblDwgsToProcess"
        Me.LblDwgsToProcess.Size = New System.Drawing.Size(103, 13)
        Me.LblDwgsToProcess.TabIndex = 301
        Me.LblDwgsToProcess.Text = "Drawings to process"
        Me.LblDwgsToProcess.Visible = False
        '
        'LblBOMItemsToProess
        '
        Me.LblBOMItemsToProess.AutoSize = True
        Me.LblBOMItemsToProess.Location = New System.Drawing.Point(503, 70)
        Me.LblBOMItemsToProess.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblBOMItemsToProess.Name = "LblBOMItemsToProess"
        Me.LblBOMItemsToProess.Size = New System.Drawing.Size(116, 13)
        Me.LblBOMItemsToProess.TabIndex = 302
        Me.LblBOMItemsToProess.Text = "BOM Items on Drawing"
        Me.LblBOMItemsToProess.Visible = False
        '
        'LblBulkBOM
        '
        Me.LblBulkBOM.AutoSize = True
        Me.LblBulkBOM.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblBulkBOM.Location = New System.Drawing.Point(282, 9)
        Me.LblBulkBOM.Name = "LblBulkBOM"
        Me.LblBulkBOM.Size = New System.Drawing.Size(235, 24)
        Me.LblBulkBOM.TabIndex = 303
        Me.LblBulkBOM.Text = "Bulk BOM Autocad 2024"
        '
        'BOM_Menu3D
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(686, 477)
        Me.Controls.Add(Me.LblBulkBOM)
        Me.Controls.Add(Me.LblBOMItemsToProess)
        Me.Controls.Add(Me.LblDwgsToProcess)
        Me.Controls.Add(Me.TxtBoxDwgsToProcess)
        Me.Controls.Add(Me.TxtBoxBOMItemsToProcess)
        Me.Controls.Add(Me.BtnVideo)
        Me.Controls.Add(Me.BtnStart2)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.LblProgress)
        Me.Controls.Add(Me.RadioButton1)
        Me.Controls.Add(Me.RadioButton2)
        Me.Controls.Add(Me.RadioButton3)
        Me.Controls.Add(Me.ChkBoxAutoCAD3D)
        Me.Controls.Add(Me.MatrixLogo)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.CancelButton_Renamed)
        Me.Controls.Add(Me.GroupBox5)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "BOM_Menu3D"
        Me.Text = "Menu---Bulk BOM Fab & 3D drawings on AutoCAD drawing."
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.MatrixLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HandleErrorsToFabMat, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Public WithEvents BtnStart2 As System.Windows.Forms.Button
    Public WithEvents LblProgress As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Public WithEvents btnNewDir As System.Windows.Forms.Button
    Public WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Public WithEvents DwgList As System.Windows.Forms.ListBox
    Public WithEvents SelectList As System.Windows.Forms.ListBox
    Public WithEvents BtnAdd As System.Windows.Forms.Button
    Public WithEvents BtnAddAll As System.Windows.Forms.Button
    Public WithEvents BtnRemove As System.Windows.Forms.Button
    Public WithEvents BtnClear As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBxRev As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Public WithEvents BtnVideo As System.Windows.Forms.Button
    Public WithEvents CancelButton_Renamed As System.Windows.Forms.Button
    Public WithEvents DwgsNotFoundList As System.Windows.Forms.ListBox
    Friend WithEvents MatrixLogo As System.Windows.Forms.PictureBox
    Friend WithEvents HandleErrorsToFabMat As System.Windows.Forms.BindingSource
    Friend WithEvents ChkBoxAutoCAD3D As CheckBox
    Friend WithEvents RadioBtnHVEC As RadioButton
    Friend WithEvents PathBox As TextBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents BtnGetMWInfo As Button
    Friend WithEvents TxtBoxBOMItemsToProcess As TextBox
    Friend WithEvents TxtBoxDwgsToProcess As TextBox
    Friend WithEvents LblDwgsToProcess As Label
    Friend WithEvents LblBOMItemsToProess As Label
    Friend WithEvents LblBulkBOM As Label
End Class
