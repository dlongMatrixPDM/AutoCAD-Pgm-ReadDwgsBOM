﻿Option Strict Off
Option Explicit On
Option Compare Text

Module Err_Handler31_069
    Dim PriPrg As String
    Dim BOMMnu As BOM_Menu3D
End Module
